import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { CartItem, Product, User } from '@/types';

interface AppState {
  // User state
  user: User | null;
  setUser: (user: User | null) => void;
  logout: () => void;

  // Cart state
  cart: CartItem[];
  addToCart: (product: Product, quantity: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  getCartTotal: () => { subtotal: number; uplift: number; total: number; charity: number; ops: number };

  // Wishlist state
  wishlist: string[]; // store product IDs
  addToWishlist: (productId: string) => void;
  removeFromWishlist: (productId: string) => void;
  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;
  clearWishlist: () => void;

  // UI state
  isInstallPromptVisible: boolean;
  setInstallPromptVisible: (visible: boolean) => void;

  // Search and filters
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: string | null;
  setSelectedCategory: (category: string | null) => void;
  priceRange: [number, number];
  setPriceRange: (range: [number, number]) => void;

  // Network status
  isOnline: boolean;
  setOnlineStatus: (online: boolean) => void;
}

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      // User state
      user: null,
      setUser: (user) => set({ user }),
      // Do NOT clear wishlist on logout; keep it persisted so it reappears after next login
      logout: () => set({ user: null }),

      // Cart state
      cart: [],
      
      addToCart: (product, quantity) => {
        const { cart } = get();
        const existingItem = cart.find(item => item.productId === product.id);
        
        if (existingItem) {
          set({
            cart: cart.map(item =>
              item.productId === product.id
                ? { ...item, quantity: item.quantity + quantity }
                : item
            )
          });
        } else {
          const newItem: CartItem = {
            productId: product.id,
            title: product.title,
            image: product.images[0] || '',
            quantity,
            basePrice: product.basePriceSeller,
            upliftPercent: product.upliftPercent,
            projectAllocations: product.projectAllocations,
          };
          set({ cart: [...cart, newItem] });
        }
      },

      removeFromCart: (productId) => {
        const { cart } = get();
        set({ cart: cart.filter(item => item.productId !== productId) });
      },

      updateQuantity: (productId, quantity) => {
        const { cart } = get();
        if (quantity <= 0) {
          get().removeFromCart(productId);
          return;
        }
        set({
          cart: cart.map(item =>
            item.productId === productId
              ? { ...item, quantity }
              : item
          )
        });
      },

      clearCart: () => set({ cart: [] }),

      getCartTotal: () => {
        const { cart } = get();
        let subtotal = 0;
        let uplift = 0;

        cart.forEach(item => {
          const itemSubtotal = item.basePrice * item.quantity;
          const itemUplift = itemSubtotal * (item.upliftPercent / 100);
          subtotal += itemSubtotal;
          uplift += itemUplift;
        });

        const total = subtotal + uplift;
        const charity = uplift * 0.8;
        const ops = uplift * 0.2;

        return { subtotal, uplift, total, charity, ops };
      },

      // Wishlist state
      wishlist: [],
      addToWishlist: (productId) => {
        const { wishlist } = get();
        if (!wishlist.includes(productId)) {
          set({ wishlist: [...wishlist, productId] });
        }
      },
      removeFromWishlist: (productId) => {
        const { wishlist } = get();
        set({ wishlist: wishlist.filter(id => id !== productId) });
      },
      toggleWishlist: (productId) => {
        const { wishlist } = get();
        if (wishlist.includes(productId)) {
          set({ wishlist: wishlist.filter(id => id !== productId) });
        } else {
          set({ wishlist: [...wishlist, productId] });
        }
      },
      isWishlisted: (productId) => {
        const { wishlist } = get();
        return wishlist.includes(productId);
      },
      clearWishlist: () => set({ wishlist: [] }),

      // UI state
      isInstallPromptVisible: false,
      setInstallPromptVisible: (visible) => set({ isInstallPromptVisible: visible }),

      // Search and filters
      searchQuery: '',
      setSearchQuery: (query) => set({ searchQuery: query }),
      selectedCategory: null,
      setSelectedCategory: (category) => set({ selectedCategory: category }),
      priceRange: [0, 1000],
      setPriceRange: (range) => set({ priceRange: range }),

      // Network status
      isOnline: navigator.onLine,
      setOnlineStatus: (online) => set({ isOnline: online }),
    }),
    {
      name: 'ew-sells-storage',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        cart: state.cart,
        user: state.user,
        selectedCategory: state.selectedCategory,
        priceRange: state.priceRange,
        wishlist: state.wishlist,
      }),
    }
  )
);