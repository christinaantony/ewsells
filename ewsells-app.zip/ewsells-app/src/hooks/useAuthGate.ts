import { useLocation, useNavigate } from 'react-router-dom';
import { useStore } from '@/store/useStore';

/**
 * useAuthGate provides a simple way to guard actions behind auth.
 * If unauthenticated, redirects to /login with a return path.
 * If authenticated, runs the provided callback.
 */
export function useAuthGate() {
  const { user } = useStore();
  const navigate = useNavigate();
  const location = useLocation();

  function runOrLogin(onAuthed: () => void, from?: string) {
    if (user) {
      onAuthed();
    } else {
      const returnTo = from || (location.pathname + location.search);
      navigate('/login', { state: { from: returnTo } });
    }
  }

  return { runOrLogin, user };
}
