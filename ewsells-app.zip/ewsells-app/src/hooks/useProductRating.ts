import { useEffect, useMemo, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '@/lib/firebase';

/**
 * useProductRating
 * Returns { rating, count, loading } for a product. It first tries to use aggregate
 * fields present on the product document (ratingAvg | avgRating | rating and
 * ratingCount | reviewsCount). If missing, it fetches products/{id}/reviews and
 * computes an average as a fallback.
 */
export function useProductRating(productId: string | undefined, docData?: any) {
  const docRating = useMemo(() => {
    if (!docData) return undefined as number | undefined;
    const v = docData.ratingAvg ?? docData.avgRating ?? docData.rating;
    return typeof v === 'number' ? v : undefined;
  }, [docData]);

  const docCount = useMemo(() => {
    if (!docData) return undefined as number | undefined;
    const v = docData.ratingCount ?? docData.reviewsCount;
    return typeof v === 'number' ? v : undefined;
  }, [docData]);

  const [fetched, setFetched] = useState<{ rating?: number; count?: number; loading: boolean }>({ loading: false });

  useEffect(() => {
    let cancelled = false;
    async function load() {
      if (!productId) return;
      if (typeof docRating === 'number') return; // already have it
      setFetched((s) => ({ ...s, loading: true }));
      try {
        const rs = await getDocs(collection(db, 'products', productId, 'reviews'));
        let sum = 0;
        let count = 0;
        rs.forEach((d) => {
          const r: any = d.data();
          const val = Number(r?.rating ?? 0);
          if (!Number.isNaN(val) && val > 0) { sum += val; count += 1; }
        });
        const avg = count > 0 ? Math.round((sum / count) * 10) / 10 : undefined;
        if (!cancelled) setFetched({ rating: avg, count: count || undefined, loading: false });
      } catch {
        if (!cancelled) setFetched({ rating: undefined, count: undefined, loading: false });
      }
    }
    load();
    return () => { cancelled = true; };
  }, [productId, docRating]);

  const rating = typeof docRating === 'number' ? docRating : fetched.rating;
  const count = typeof docCount === 'number' ? docCount : fetched.count;

  return { rating, count, loading: fetched.loading } as const;
}
