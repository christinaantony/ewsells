import { useState, useCallback, useEffect } from 'react';
import { sendChatMessageDirect, type ChatMessage } from '../services/chatService';
import { saveChatMessages, getChatMessages } from '../services/chatStorage';
import { auth } from '../lib/firebase';

export const useChat = (initialMessages: ChatMessage[] = []) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  // Load messages from Firestore on component mount
  useEffect(() => {
    const loadMessages = async () => {
      try {
        const userId = auth.currentUser?.uid;
        if (!userId) return;
        
        const savedMessages = await getChatMessages(userId);
        if (savedMessages.length > 0) {
          setMessages(savedMessages);
        } else if (initialMessages.length > 0) {
          // If no saved messages but we have initial messages, use them
          setMessages(initialMessages);
          await saveChatMessages(userId, initialMessages);
        }
      } catch (err) {
        console.error('Error loading messages:', err);
        setMessages(initialMessages);
      } finally {
        setIsLoading(false);
      }
    };

    loadMessages();
  }, [initialMessages]);

  const sendMessage = useCallback(async (content: string, additionalMessages: ChatMessage[] = []) => {
    if (!content.trim() || !auth.currentUser?.uid) return;

    const userId = auth.currentUser.uid;
    const userMessage: ChatMessage = { role: 'user', content };
    const updatedMessages = [...messages, userMessage];
    
    // If additional messages are provided (like product search results), add them
    const messagesToDisplay = additionalMessages.length > 0 
      ? [...updatedMessages, ...additionalMessages]
      : updatedMessages;
    
    setMessages(messagesToDisplay);
    setIsSending(true);
    setError(null);

    try {
      // Save user message and any additional messages to Firestore
      await saveChatMessages(userId, messagesToDisplay);
      
      // Only get AI response if no additional messages were provided
      if (additionalMessages.length === 0) {
        // Get AI response
        const response = await sendChatMessageDirect(updatedMessages);
        
        // Update local state and Firestore with AI response
        const messagesWithResponse = [...messagesToDisplay, response];
        setMessages(messagesWithResponse);
        await saveChatMessages(userId, messagesWithResponse);
        
        return response;
      }
      
      return additionalMessages[0]; // Return the first additional message as the response
    } catch (err) {
      console.error('Error in chat:', err);
      const errorMessage = err instanceof Error ? err.message : 'Failed to send message';
      setError(new Error(errorMessage));
      
      // Add error message to chat
      const errorMessageObj: ChatMessage = {
        role: 'assistant',
        content: `Sorry, I encountered an error: ${errorMessage}`
      };
      
      const messagesWithError = [...updatedMessages, errorMessageObj];
      setMessages(messagesWithError);
      await saveChatMessages(userId, messagesWithError);
      
      throw err;
    } finally {
      setIsSending(false);
    }
  }, [messages]);

  const clearMessages = useCallback(() => {
    setMessages([]);
    setError(null);
  }, []);

  return {
    messages,
    sendMessage,
    clearMessages,
    isLoading,
    isSending,
    error,
    setMessages, // Expose setMessages for direct manipulation
  };
};

export default useChat;
