// Railway station codes for Kerala
export const RAILWAY_CODES: Record<string, string> = {
  // Major Cities with Multiple Names
  'thiruvananthapuram': 'TVC',  // Trivandrum Central
  'trivandrum': 'TVC',
  'kochi': 'ERS',  // Ernakulam Junction
  'ernakulam': 'ERS',
  'cochin': 'ERS',
  'kozhikode': 'CLT',  // Kozhikode Main
  'calicut': 'CLT',
  'thrissur': 'TCR',  // Thrissur
  'trichur': 'TCR',
  'palakkad': 'PGT',  // Palakkad Junction
  'palghat': 'PGT',
  'kannur': 'CAN',  // Kannur Main
  'cannanore': 'CAN',
  'kollam': 'QLN',  // Kollam Junction
  'quilon': 'QLN',
  'alappuzha': 'ALLP',  // Alappuzha
  'alleppey': 'ALLP',
  'kottayam': 'KTYM',
  'kayamkulam': 'KYJ',
  'kasaragod': 'KGQ',
  'shoranur': 'SRR',
  'tirur': 'TIR',
  'aluva': 'AWY',
  'cherthala': 'SRTL',
  'thalassery': 'TLY',
  'tellicherry': 'TLY',
  'vadakara': 'BDJ',
  'badagara': 'BDJ',
  'tripunittura': 'TRTR',
  'payyanur': 'PAY',
  'kanhangad': 'KZE',
  'ottappalam': 'OTP',
  'varkala': 'VAK',
  'angamaly': 'AFK',
  'changanassery': 'CGY',
  'changanacherry': 'CGY',
  'kuttippuram': 'KTU',
  'koyilandy': 'QLD',
  'guruvayur': 'GUV',
  'mavelikara': 'MVLK',
  'chalakudi': 'CKI',
  'chalakudy': 'CKI',
  'karunagapalli': 'KPY',
  'karunagappally': 'KPY',
  'irinjalakuda': 'IJK',
  'parpanangadi': 'PGI',
  'wadakanchery': 'WKI',
  'ferok': 'FK',
  'feroke': 'FK',
  'paravur': 'PVU',
  'pattambi': 'PTB',
  'nileshwar': 'NLE',
  'ambalappuzha': 'AMPA',
  'haripad': 'HAD',
  'kannapuram': 'KPQ',
  'sasthamkotta': 'STKT',
  'tanur': 'TA',
  'charvattur': 'CHV',
  'payangadi': 'PAZ',
  'piravam road': 'PVRD',
  'neyyattinkara': 'NYY',
  'chirayinkil': 'CRY',
  'kazhakuttam': 'KZK',
  'kazhakkottam': 'KZK',
  'parassala': 'PASA',
  'kumbala': 'KMQ',
  'kumbla': 'KMQ',
  'palakkad town': 'PGTN',
  'vaniyambalam': 'VNB',
  'angadippuram': 'AAM',
  'nilambur road': 'NIL',
  'trivandrum pettah': 'TVP',
  'kadakavur': 'KVU',
  'kadakkavoor': 'KVU',
  'turavur': 'TUVR',
  'idaplli': 'IPL',
  'manjeshwar': 'MJS',
  'kundara': 'KUV',
  'mararikulam': 'MAKM',
  'vallikunnu': 'VLI',
  'auvaneswarem': 'AVS',
  'kotikulam': 'KQK',
  'kottarakara': 'KKZ',
  'mayyanad': 'MYY',
  'pudukad': 'PUK',
  'punalur': 'PUU',
  'punkunnam': 'PNQ',
  'vaikam road': 'VARD',
  'mulanturutti': 'MNTT',
  'valapattanam': 'VAPM',
  'ettumanur': 'ETM',
  'trikarpur': 'TKQ',
  'cheriyanad': 'CYN',
  'payyoli': 'PYOL',
  'kilikollur': 'KLQ',
  'bekal fort': 'BFR',
  'kuruppanthara': 'KRPP',
  'edamann': 'EDN',
  'kollengode': 'KLGD',
  'perinad': 'PRND',
  'tirunnavaya': 'TUA',
  'ezhukone': 'EKN',
  'uppala': 'UAA',
  'elimala': 'ELM',
  'ezhimala': 'ELM',
  'murukkampuzha': 'MQU',
  'ochira': 'OCR',
  'kadalundi': 'KN',
  'cheppad': 'CHPD',
  'lakkiti': 'LDY',
  'mulangunnathukavu': 'MGK',
  'trivandrum south': 'TVCS',
  'pappinissery': 'PPNS',
  'balaramapuram': 'BRAM',
  'pudunagaram': 'PDGM',
  'muthalamada': 'MMDA',
  'ottakkal': 'OKL',
  'elattur': 'ETR',
  'karukkutty': 'KUC',
  'kallayi': 'KUL',
  'vallathol nagar': 'VTK',
  'kumbalam': 'KUMM',
  'west hill': 'WH',
  'walayar': 'WRA',
  'kanjikode': 'KJKD',
  'kannur south': 'CS',
  'cannanore south': 'CS',
  'pallippuram': 'PUM',
  'jagannath temple gate': 'JGE',
  'tikkotti': 'TKT',
  'parli': 'PLL',
  'kalamassery': 'KLMR',
  'ollur': 'OLR',
  'kaniyapuram': 'KXP',
  'edakkad': 'ETK',
  'etakkot': 'ETK',
  'edavai': 'EVA',
  'mankarai': 'MNY',
  'mannanur': 'MNUR',
  'karakkad': 'KRKD',
  'chingavanam': 'CGV',
  'divinenagar': 'DINR',
  'munroturuttu': 'MQO',
  'tuvvur': 'TUV',
  'vallapuzha': 'VPZ',
  'pattikkad': 'PKQ',
  'cherukara': 'CQA',
  'aryankavu': 'AYV',
  'melattur': 'MLTR',
  'dhanuvachapuram': 'DAVM',
  'punnapra': 'PNPR',
  'takazhi': 'TZH',
  'nadapuram road': 'NAU',
  'vellarakkad': 'VEK',
  'amaravila': 'AMVA',
  'vadanam kurussi': 'VDKS',
  'akathumuri': 'AMY',
  'kaduturutti': 'KDTY',
  'chandanattop': 'CTPE',
  'vellayil': 'VLL',
  'chullimada': 'CLMD',
  'kurikad': 'KFE',
  'edapalayam': 'EDP',
  'kumaranallur': 'KFQ',
  'iravipuram': 'IRP',
  'aroor': 'AROR',
  'ezhuppunna': 'EZP',
  'chirakkal': 'CQL',
  'iringal': 'IGL',
  'kappil': 'KFI',
  'palappuram': 'PLPM',
  'kulukkalur': 'KZC',
  'chovvara': 'CWR',
  'karuvatta': 'KVTA',
  'veli': 'VELI',
  'nellayi': 'NYI',
  'kalanad': 'KLAD',
  'tumboli': 'TMPY',
  'kanjiramattom': 'KPTM',
  'chemancheri': 'CMC',
  'tiruvizha': 'TRVZ',
  'perunguzhi': 'PGZ',
  'kodumunda': 'KODN',
  'dharmadam': 'DMD',
  'kundara east': 'KFV',
  'kazhuthuruthy': 'KTHY',
  'perssannur': 'PEU',
  'mullurkara': 'MUC',
  'mukkali': 'MUKE',
  'kuri': 'KIF',
  'kalavur': 'KAVR',
  'koratti angadi': 'KRAN',
  'chandera': 'CDRA',
  'vayalar': 'VAY'
};

// Function to get railway code for a city
export function getRailwayCode(cityName: string): string {
  if (!cityName) return 'EWS';
  
  // Normalize city name (lowercase, trim, remove special characters)
  const normalizedCity = cityName.toLowerCase().trim().replace(/[^a-z]/g, '');
  
  // Try exact match first
  if (RAILWAY_CODES[normalizedCity]) {
    return RAILWAY_CODES[normalizedCity];
  }
  
  // Try partial match (e.g., 'new delhi' matches 'delhi')
  // Sort by key length in descending order to match the most specific name first
  const sortedEntries = Object.entries(RAILWAY_CODES).sort((a, b) => b[0].length - a[0].length);
  
  for (const [city, code] of sortedEntries) {
    if (normalizedCity.includes(city) || city.includes(normalizedCity)) {
      return code;
    }
  }
  
  // Try to find a match by removing common suffixes
  const commonSuffixes = ['junction', 'jnc', 'jct', 'town', 'city', 'central'];
  for (const suffix of commonSuffixes) {
    const cityWithoutSuffix = normalizedCity.replace(new RegExp(`${suffix}$`), '').trim();
    if (RAILWAY_CODES[cityWithoutSuffix]) {
      return RAILWAY_CODES[cityWithoutSuffix];
    }
  }
  
  // Last resort: Use first 3 uppercase letters of city
  return normalizedCity.substring(0, 3).toUpperCase();
}
