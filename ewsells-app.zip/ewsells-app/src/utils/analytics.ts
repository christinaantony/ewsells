// Lightweight analytics utilities (no external deps)
// - toDateKey: YYYY-MM-DD key from a Date
// - bucketByDay: buckets an array of { ts: Date|number|string, value: number } into a map of dateKey->sum
// - dateRangeKeys: inclusive date keys for a range [start, end]

export function toDateKey(d: Date): string {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }
  
  export function dateRangeKeys(start: Date, end: Date): string[] {
    const keys: string[] = [];
    const cur = new Date(start);
    cur.setHours(0, 0, 0, 0);
    const endDay = new Date(end);
    endDay.setHours(0, 0, 0, 0);
    while (cur <= endDay) {
      keys.push(toDateKey(cur));
      cur.setDate(cur.getDate() + 1);
    }
    return keys;
  }
  
  export function bucketByDay(items: Array<{ ts: Date | number | string; value: number }>): Record<string, number> {
    const out: Record<string, number> = {};
    for (const it of items) {
      let date: Date | null = null;
      if (it.ts instanceof Date) date = it.ts;
      else if (typeof it.ts === 'number') date = new Date(it.ts);
      else if (typeof it.ts === 'string') {
        const parsed = Date.parse(it.ts);
        if (!Number.isNaN(parsed)) date = new Date(parsed);
      }
      if (!date) continue;
      const key = toDateKey(date);
      out[key] = (out[key] || 0) + (Number.isFinite(it.value) ? it.value : 0);
    }
    return out;
  }
  