export interface Product {
  id: string;
  title: string;
  description: string;
  images: string[];
  category: string;
  tags: string[];
  sellerId: string;
  basePriceSeller: number;
  upliftPercent: number;
  projectAllocations: ProjectAllocation[];
  location: Location;
  badges: string[];
  isRental: boolean;
  customizable?: boolean;
  rentalTerms?: RentalTerms;
  status: 'active' | 'sold' | 'inactive';
  createdAt: Date;
  updatedAt: Date;
  // Optional inventory fields (from Firestore) for stock management UI
  stock?: number;
  outOfStock?: boolean;
  published?: boolean;
  [key: string]: any; // Allow additional properties
}

export interface ProjectAllocation {
  projectId: string;
  percent: number;
}

export interface RentalTerms {
  monthlyFee: number;
  deposit: number;
  duration: string;
  terms: string[];
}

export interface Project {
  id: string;
  name: string;
  description: string;
  goalAmount: number;
  currentRaised: number;
  coverImage: string;
  region: string;
  status: 'active' | 'completed' | 'paused';
  createdAt: Date;
  updatedAt: Date;
}

export interface Seller {
  id: string;
  name: string;
  avatar: string;
  region: string;
  categories: string[];
  rating: number;
  leadTime: string;
  deliveryRadiusKm: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface Order {
  id: string;
  items: OrderItem[];
  totals: OrderTotals;
  donationFromUplift: number;
  userId?: string;
  status: 'pending' | 'confirmed' | 'delivered' | 'cancelled';
  createdAt: Date;
  updatedAt: Date;
}

export interface OrderItem {
  productId: string;
  title: string;
  image: string;
  quantity: number;
  basePrice: number;
  uplift: number;
}

export interface OrderTotals {
  subtotal: number;
  uplift: number;
  total: number;
  charity: number;
  ops: number;
}

export interface Location {
  address: string;
  city: string;
  state: string;
  country: string;
  lat?: number;
  lng?: number;
}

export interface CartItem {
  productId: string;
  title: string;
  image: string;
  quantity: number;
  basePrice: number;
  upliftPercent: number;
  projectAllocations: ProjectAllocation[];
}

export interface User {
  id: string;
  uid: string; // Firebase auth UID
  email: string;
  displayName?: string;
  photoURL?: string;
  phoneNumber?: string;
  role?: 'user' | 'seller' | 'admin';
  addresses?: Address[];
  defaultAddressId?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Address {
  id: string;
  name: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phoneNumber: string;
  landmark?: string;
  isDefault: boolean;
}