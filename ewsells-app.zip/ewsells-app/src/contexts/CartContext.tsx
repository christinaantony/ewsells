import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { db } from '@/lib/firebase';
import { collection, doc, setDoc, updateDoc, deleteDoc, onSnapshot, getDocs, query, where } from 'firebase/firestore';
import { useStore } from '@/store/useStore';

// Define the cart item interface
export interface CartItem {
  id: string;
  productId: string;
  name: string;
  price: number;
  quantity: number;
  imageUrl?: string | null;
  category?: string | null;
  sellerId?: string | null;
}

// Define the cart context interface
interface CartContextType {
  cartItems: CartItem[];
  addToCart: (product: any, quantity?: number) => Promise<void>;
  removeFromCart: (productId: string) => Promise<void>;
  updateQuantity: (productId: string, quantity: number) => Promise<void>;
  clearCart: () => Promise<void>;
  cartTotal: number;
  cartCount: number;
  isLoading: boolean;
  // Saved for later
  savedItems: CartItem[];
  moveToSaved: (productId: string) => Promise<void>;
  removeFromSaved: (savedItemId: string) => Promise<void>;
  moveSavedToCart: (savedItemId: string) => Promise<void>;
}

// Create the cart context
const CartContext = createContext<CartContextType | undefined>(undefined);

// Create a provider component
export function CartProvider({ children }: { children: ReactNode }) {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { user } = useStore();
  const [savedItems, setSavedItems] = useState<CartItem[]>([]);

  // Calculate cart total
  const cartTotal = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  
  // Calculate cart count
  const cartCount = cartItems.reduce((count, item) => count + item.quantity, 0);

  // Load cart items from Firebase when user changes
  useEffect(() => {
    let unsubscribe: () => void = () => {};
    
    const loadCartItems = async () => {
      setIsLoading(true);
      
      if (user?.id) {
        // User is logged in, load from Firebase (cart only)
        const cartRef = collection(db, 'users', user.id, 'cart');
        unsubscribe = onSnapshot(cartRef, (snapshot) => {
          const items: CartItem[] = [];
          snapshot.forEach((doc) => {
            items.push({ id: doc.id, ...doc.data() } as CartItem);
          });
          setCartItems(items);
          setIsLoading(false);
        });
        // For Saved For Later, rely on localStorage only to avoid permission issues
        const savedLater = localStorage.getItem('ewsells-saved');
        if (savedLater) {
          try {
            const parsed: CartItem[] = JSON.parse(savedLater);
            const used = new Set<string>();
            const normalized = parsed.map((it, idx) => {
              let id = it.id;
              if (!id || used.has(id)) id = `saved-${Date.now()}-${idx}-${Math.random().toString(36).slice(2,6)}`;
              used.add(id);
              return { ...it, id } as CartItem;
            });
            setSavedItems(normalized);
          } catch {
            setSavedItems([]);
          }
        } else {
          setSavedItems([]);
        }
      } else {
        // User is not logged in, load from localStorage
        const savedCart = localStorage.getItem('ewsells-cart');
        if (savedCart) {
          setCartItems(JSON.parse(savedCart));
        } else {
          setCartItems([]);
        }
        const savedLater = localStorage.getItem('ewsells-saved');
        if (savedLater) {
          try {
            const parsed: CartItem[] = JSON.parse(savedLater);
            const used = new Set<string>();
            const normalized = parsed.map((it, idx) => {
              let id = it.id;
              if (!id || used.has(id)) id = `saved-${Date.now()}-${idx}-${Math.random().toString(36).slice(2,6)}`;
              used.add(id);
              return { ...it, id } as CartItem;
            });
            setSavedItems(normalized);
          } catch {
            setSavedItems([]);
          }
        } else {
          setSavedItems([]);
        }
        setIsLoading(false);
      }
    };

    loadCartItems();
    
    return () => unsubscribe();
  }, [user]);

  // Save cart to localStorage when it changes (for non-logged in users)
  useEffect(() => {
    if (!user?.id && !isLoading) {
      localStorage.setItem('ewsells-cart', JSON.stringify(cartItems));
    }
  }, [cartItems, user, isLoading]);

  // Save savedItems to localStorage when it changes
  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem('ewsells-saved', JSON.stringify(savedItems));
    }
  }, [savedItems, isLoading]);

  // Add item to cart
  const addToCart = async (product: any, quantity = 1) => {
    // Create cart item without id first (id will be added based on context)
    const cartItemBase: Omit<CartItem, 'id'> = {
      productId: product.id,
      name: product.name,
      price: product.price,
      quantity: quantity,
      imageUrl: product.imageUrl || (product.imageUrls && product.imageUrls.length > 0 ? product.imageUrls[0] : null),
      category: product.category || null,
      sellerId: product.sellerId || product.ownerId || null,
    };
    
    // Remove undefined values to prevent Firestore errors
    Object.keys(cartItemBase).forEach(key => {
      if (cartItemBase[key as keyof typeof cartItemBase] === undefined) {
        delete cartItemBase[key as keyof typeof cartItemBase];
      }
    });

    if (user?.id) {
      // User is logged in, merge by productId in Firebase
      const cartColRef = collection(db, 'users', user.id, 'cart');
      const existingSnap = await getDocs(query(cartColRef, where('productId', '==', product.id)));
      if (!existingSnap.empty) {
        // Update quantity on the first matching item
        const docRef = existingSnap.docs[0].ref;
        const current = existingSnap.docs[0].data() as any;
        const newQty = Number(current.quantity || 0) + quantity;
        await updateDoc(docRef, { quantity: newQty, updatedAt: new Date() });
      } else {
        // Add new item
        const cartItemRef = doc(cartColRef);
        const cartItemWithId = {
          ...cartItemBase,
          id: cartItemRef.id,
          updatedAt: new Date()
        };
        await setDoc(cartItemRef, cartItemWithId);
      }
    } else {
      // User is not logged in, save to local state
      const existingItemIndex = cartItems.findIndex(item => item.productId === product.id);
      
      if (existingItemIndex !== -1) {
        // Item already exists, update quantity
        const updatedItems = [...cartItems];
        updatedItems[existingItemIndex].quantity += quantity;
        setCartItems(updatedItems);
      } else {
        // Add new item with a generated id
        const newItem = { ...cartItemBase, id: Date.now().toString() };
        setCartItems([...cartItems, newItem]);
      }
    }
  };

  // Remove item from cart
  const removeFromCart = async (productId: string) => {
    if (user?.id) {
      // Find the cart item with the matching productId
      const itemToRemove = cartItems.find(item => item.productId === productId);
      if (itemToRemove) {
        await deleteDoc(doc(db, 'users', user.id, 'cart', itemToRemove.id));
      }
    } else {
      // User is not logged in, update local state
      setCartItems(cartItems.filter(item => item.productId !== productId));
    }
  };

  // Update item quantity
  const updateQuantity = async (productId: string, quantity: number) => {
    if (quantity <= 0) {
      await removeFromCart(productId);
      return;
    }

    if (user?.id) {
      // Find the cart item with the matching productId
      const itemToUpdate = cartItems.find(item => item.productId === productId);
      if (itemToUpdate) {
        await updateDoc(doc(db, 'users', user.id, 'cart', itemToUpdate.id), {
          quantity,
          updatedAt: new Date()
        });
      }
    } else {
      // User is not logged in, update local state
      const updatedItems = cartItems.map(item => 
        item.productId === productId ? { ...item, quantity } : item
      );
      setCartItems(updatedItems);
    }
  };

  // Clear cart
  const clearCart = async () => {
    if (user?.id) {
      // Delete all cart items from Firebase
      const promises = cartItems.map(item => 
        deleteDoc(doc(db, 'users', user.id, 'cart', item.id))
      );
      await Promise.all(promises);
    } else {
      // User is not logged in, clear local state
      setCartItems([]);
    }
  };

  // Saved For Later (local only)
  const moveToSaved = async (productId: string) => {
    const item = cartItems.find(i => i.productId === productId);
    if (!item) return;
    const existingIndex = savedItems.findIndex(i => i.productId === productId);
    let newSaved = [...savedItems];
    if (existingIndex !== -1) {
      newSaved[existingIndex] = { ...newSaved[existingIndex], quantity: newSaved[existingIndex].quantity + item.quantity };
    } else {
      newSaved = [...newSaved, { ...item, id: `saved-${Date.now()}-${Math.random().toString(36).slice(2,8)}` }];
    }
    setSavedItems(newSaved);
    setCartItems(cartItems.filter(i => i.productId !== productId));
  };

  const removeFromSaved = async (savedItemId: string) => {
    setSavedItems(prev => prev.filter(it => it.id !== savedItemId));
  };

  const moveSavedToCart = async (savedItemId: string) => {
    const item = savedItems.find(i => i.id === savedItemId);
    if (!item) return;
    setCartItems(prev => {
      const without = prev.filter(i => i.productId !== item.productId);
      return [...without, { ...item, quantity: Number(item.quantity || 1) }];
    });
    setSavedItems(prev => prev.filter(i => i.id !== savedItemId));
  };

  return (
    <CartContext.Provider value={{
      cartItems,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
      cartTotal,
      cartCount,
      isLoading,
      savedItems,
      moveToSaved,
      removeFromSaved,
      moveSavedToCart
    }}>
      {children}
    </CartContext.Provider>
  );
}

// Custom hook to use the cart context
export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}