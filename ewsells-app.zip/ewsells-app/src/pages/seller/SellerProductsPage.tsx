import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { collection, query, where, getDocs, orderBy, doc, getDoc, updateDoc, onSnapshot, deleteDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, ArrowLeft, Search, Eye, Trash2, Check, X, Pencil, Save } from 'lucide-react';
import { useToast } from '@/components/ui/toast-context';
import { Input } from '@/components/ui/input';
import { formatCurrency } from '@/lib/utils';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

// Tiny inline carousel for seller products table
function MiniCarousel({ images, className }: { images: string[]; className?: string }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  if (!images || !images.length) {
    return (
      <div className={`relative flex items-center justify-center bg-gray-100 rounded ${className || ''}`}>
        <div className="text-xs text-gray-500">No image</div>
      </div>
    );
  }

  const goToPrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };

  const goToNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setCurrentIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };

  return (
    <div className={`relative h-14 w-14 ${className || ''}`}>
      <img 
        src={images[currentIndex]} 
        alt={`Product ${currentIndex + 1}`}
        className="h-full w-full object-cover rounded border cursor-zoom-in"
      />
      {images.length > 1 && (
        <>
          <button 
            type="button" 
            onClick={goToPrev}
            className="absolute left-0 top-1/2 -translate-y-1/2 h-6 w-6 flex items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/70"
            aria-label="Previous image"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
              <path d="m15 18-6-6 6-6"></path>
            </svg>
          </button>
          <button 
            type="button" 
            onClick={goToNext}
            className="absolute right-0 top-1/2 -translate-y-1/2 h-6 w-6 flex items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/70"
            aria-label="Next image"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
              <path d="m9 18 6-6-6-6"></path>
            </svg>
          </button>
        </>
      )}
    </div>
  );
}

export function SellerProductsPage() {
  const { sellerId } = useParams<{ sellerId: string }>();
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [sellerInfo, setSellerInfo] = useState<any>(null);
  const [editingProduct, setEditingProduct] = useState<string | null>(null);
  const [editingStock, setEditingStock] = useState<string | null>(null);
  const [editingPublish, setEditingPublish] = useState<string | null>(null);
  const [editedPrice, setEditedPrice] = useState<string | number>('');
  const [editedStock, setEditedStock] = useState('');
  const [editedPublish, setEditedPublish] = useState(false);
  const [editedDescription, setEditedDescription] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const { showToast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    if (!sellerId) return;

    // Fetch seller info
    const sellerRef = doc(db, 'users', sellerId);
    const unsubscribeSeller = onSnapshot(sellerRef, (doc) => {
      if (doc.exists()) {
        setSellerInfo({ id: doc.id, ...doc.data() });
      } else {
        showToast({
          message: 'Seller not found',
          type: 'error'
        });
        navigate(-1);
      }
    });

    // Set up real-time listener for products with error handling
    const productsQuery = query(
      collection(db, 'products'),
      where('sellerId', '==', sellerId),
      orderBy('createdAt', 'desc')
    );

    const unsubscribeProducts = onSnapshot(
      productsQuery,
      (snapshot) => {
        const productsData = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
        setProducts(productsData);
        setLoading(false);
      },
      (error) => {
        console.error('Error in products listener:', error);
        showToast({
          message: 'Error receiving product updates',
          type: 'error'
        });
        setLoading(false);
      }
    );

    // Clean up listeners on unmount
    return () => {
      unsubscribeSeller();
      unsubscribeProducts();
    };
  }, [sellerId, navigate, showToast]);

  const handleSavePrice = async (productId: string) => {
    try {
      // keep UI responsive: don't trigger global page loading
      const productRef = doc(db, 'products', productId);
      await updateDoc(productRef, {
        finalPrice: Number(editedPrice),
        updatedAt: new Date()
      });
      
      // Update local state
      setProducts(products.map(p => 
        p.id === productId 
          ? { ...p, finalPrice: Number(editedPrice) } 
          : p
      ));
      
      setEditingProduct(null);
      showToast({
        message: 'Price updated successfully',
        type: 'success'
      });
    } catch (error) {
      console.error('Error updating price:', error);
      showToast({
        message: 'Failed to update price',
        type: 'error'
      });
    } finally {
      // no-op: avoid global loading flicker
    }
  };

  const handleSaveStock = async (productId: string) => {
    try {
      setLoading(true);
      const productRef = doc(db, 'products', productId);
      const stockValue = Number(editedStock);
      
      await updateDoc(productRef, {
        stock: stockValue,
        updatedAt: new Date()
      });
      
      // Update local state
      setProducts(products.map(p => 
        p.id === productId 
          ? { ...p, stock: stockValue } 
          : p
      ));
      
      setEditingStock(null);
      showToast({
        message: 'Stock updated successfully',
        type: 'success'
      });
    } catch (error) {
      console.error('Error updating stock:', error);
      showToast({
        message: 'Failed to update stock',
        type: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSavePublish = async (productId: string) => {
    try {
      setLoading(true);
      const productRef = doc(db, 'products', productId);
      
      await updateDoc(productRef, {
        published: editedPublish,
        updatedAt: new Date()
      });
      
      // Update local state
      setProducts(products.map(p => 
        p.id === productId 
          ? { ...p, published: editedPublish } 
          : p
      ));
      
      setEditingPublish(null);
      showToast({
        message: `Product ${editedPublish ? 'published' : 'unpublished'} successfully`,
        type: 'success'
      });
    } catch (error) {
      console.error('Error updating publish status:', error);
      showToast({
        message: 'Failed to update publish status',
        type: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePublishToggle = async (productId: string, currentStatus: boolean) => {
    try {
      setLoading(true);
      const productRef = doc(db, 'products', productId);
      
      await updateDoc(productRef, {
        published: !currentStatus,
        updatedAt: new Date()
      });
      
      // Update local state
      setProducts(products.map(p => 
        p.id === productId 
          ? { ...p, published: !currentStatus } 
          : p
      ));
      
      showToast({
        message: `Product ${!currentStatus ? 'published' : 'unpublished'} successfully`,
        type: 'success'
      });
    } catch (error) {
      console.error('Error updating publish status:', error);
      showToast({
        message: 'Failed to update publish status',
        type: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSaveDescription = async (productId: string) => {
    if (!editedDescription.trim()) {
      showToast({
        message: 'Description cannot be empty',
        type: 'error'
      });
      return;
    }
    
    setLoading(true);
    try {
      const productRef = doc(db, 'products', productId);
      await updateDoc(productRef, {
        description: editedDescription.trim(),
        updatedAt: new Date()
      });
      
      // Update local state
      setProducts(products.map(p => 
        p.id === productId 
          ? { ...p, description: editedDescription.trim() } 
          : p
      ));
      
      showToast({
        message: 'Description updated successfully',
        type: 'success'
      });
      setEditingProduct(null);
    } catch (error) {
      console.error('Error updating description:', error);
      showToast({
        message: 'Failed to update description',
        type: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (productId: string) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      try {
        setLoading(true);
        const productRef = doc(db, 'products', productId);
        
        await deleteDoc(productRef);
        
        // Update local state
        setProducts(products.filter(p => p.id !== productId));
        
        showToast({
          message: 'Product deleted successfully',
          type: 'success'
        });
      } catch (error) {
        console.error('Error deleting product:', error);
        showToast({
          message: 'Failed to delete product',
          type: 'error'
        });
      } finally {
        setLoading(false);
      }
    }
  };

  const filteredProducts = products.filter(product => 
    product.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-gold" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-8">
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="mb-4 flex items-center gap-2"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Sellers
        </Button>
        
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
          <div>
            <h1 className="text-3xl font-bold">
              {sellerInfo?.displayName || 'Seller'}'s Products
            </h1>
            <p className="text-muted-foreground">
              {products.length} {products.length === 1 ? 'product' : 'products'} available
            </p>
          </div>
          
          <div className="relative w-full max-w-sm">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="search"
              placeholder="Search by name, category, or id…"
              className="w-full pl-8 pr-3 py-2 rounded-md bg-muted/40 outline-none border border-border/60 focus:border-gold"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {filteredProducts.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">
              {searchQuery 
                ? 'No products match your search.'
                : 'No products found for this seller.'}
            </p>
            {searchQuery && (
              <Button
                variant="outline"
                className="mt-4"
                onClick={() => setSearchQuery('')}
              >
                Clear search
              </Button>
            )}
          </div>
        ) : (
          <div className="rounded-md border">
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr>
                    <th className="py-2 pr-4">Image</th>
                    <th className="py-2 pr-4">Name</th>
                    <th className="py-2 pr-4">Category</th>
                    <th className="py-2 pr-4">Seller Price</th>
                    <th className="py-2 pr-4">Stock</th>
                    <th className="py-2 pr-4">Description</th>
                    <th className="py-2 pr-4">Final Price</th>
                    
                    <th className="py-2 pr-4">Published</th>
                    <th className="py-2 pr-4">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.map((p) => (
                    <tr key={p.id} className="border-t border-border/60 align-top">
                      <td className="py-2 pr-4">
                        {(() => {
                          const imgs = Array.isArray(p.imageUrls)
                            ? p.imageUrls
                            : Array.isArray(p.images)
                              ? p.images
                              : (p.imageUrl ? [p.imageUrl] : []);
                          return <MiniCarousel images={imgs} />;
                        })()}
                      </td>
                      <td className="py-2 pr-4 max-w-xs">
                        <div className="flex items-center gap-2">
                          <div className="font-medium truncate" title={p.name}>{p.name || '-'}</div>
                          {p.needsReview && (
                            <span className="inline-flex items-center rounded-full bg-yellow-100 px-2.5 py-0.5 text-xs font-medium text-yellow-800">
                              Review 
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-muted-foreground truncate">{p.id}</div>
                      </td>
                      <td className="py-2 pr-4">{p.category || '-'}</td>
                      
                      {/* Seller Price (Read-only) */}
                      <td className="py-2 pr-4">
                        {p.sellerPrice ? `₹${Number(p.sellerPrice).toLocaleString()}` : '-'}
                      </td>
                      
                      {/* Stock (Read-only) */}
                      <td className="py-2 pr-4">
                        {typeof p.stock === 'number' ? p.stock : '-'}
                        {p.stock === 0 && (
                          <div className="text-xs text-red-500">Out of stock</div>
                        )}
                      </td>

                      {/* Description (Editable) */}
                      <td className="py-2 pr-4">
                        {editingProduct === p.id ? (
                          <div className="flex items-center gap-2">
                            <Input
                              type="text"
                              value={editedDescription}
                              onChange={(e) => setEditedDescription(e.target.value)}
                              className="min-w-[200px]"
                            />
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="h-8 w-8 p-0"
                              onClick={() => handleSaveDescription(p.id)}
                              disabled={loading}
                            >
                              {loading && editingProduct === p.id ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                <Check className="h-4 w-4" />
                              )}
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="h-8 w-8 p-0"
                              onClick={() => setEditingProduct(null)}
                              disabled={loading}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            <div className="text-sm line-clamp-1 max-w-[200px]" title={p.description}>
                              {p.description || 'No description'}
                            </div>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-6 w-6 p-0"
                              onClick={(e) => {
                                e.stopPropagation();
                                setEditingProduct(p.id);
                                setEditedDescription(p.description || '');
                              }}
                            >
                              <Pencil className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                      </td>

                      {/* Final Price (Editable) */}
                      <td className="py-2 pr-4">
                        {editingProduct === p.id ? (
                          <div className="flex items-center gap-2">
                            <Input
                              type="number"
                              className="w-24"
                              value={editedPrice}
                              onChange={(e) => setEditedPrice(e.target.value)}
                            />
                            <Button
                              type="button"
                              size="sm"
                              onClick={(e) => { e.preventDefault(); e.stopPropagation(); handleSavePrice(p.id); }}
                            >
                              <Check className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => setEditingProduct(null)}>
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            {p.finalPrice ? `₹${Number(p.finalPrice).toLocaleString()}` : '-'}
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-6 w-6"
                              onClick={() => {
                                setEditingProduct(p.id);
                                setEditedPrice(p.finalPrice || '');
                              }}
                            >
                              <Pencil className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                      </td>
                      <td className="py-2 pr-4">
                        <div className="flex items-center gap-2">
                          <Switch
                            id={`publish-${p.id}`}
                            checked={p.published || false}
                            onCheckedChange={(checked) => handlePublishToggle(p.id, !checked)}
                            disabled={loading}
                          />
                          <Label htmlFor={`publish-${p.id}`} className="sr-only">
                            {p.published ? 'Published' : 'Unpublished'}
                          </Label>
                        </div>
                      </td>
                      <td className="py-2 pr-4">
                        <div className="flex items-center gap-2">
                          <Button 
                            variant="destructive" 
                            size="sm" 
                            onClick={() => handleDelete(p.id)}
                            disabled={loading}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default SellerProductsPage;