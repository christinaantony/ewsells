import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { db, auth } from '@/lib/firebase';
import { collection, onSnapshot, query, where, Timestamp, updateDoc, doc, addDoc, serverTimestamp, getDoc } from 'firebase/firestore';
import { Link, useSearchParams } from 'react-router-dom';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface OrderItem {
  id: string;
  amount?: number;
  paymentMethod?: 'card' | 'upi' | 'cod';
  paymentStatus?: 'initiated' | 'processing' | 'pending' | 'paid' | 'failed';
  status?: 'created' | 'placed' | 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  createdAt?: Timestamp;
  userId?: string;
  contact?: {
    email: string;
    name: string;
    phone: string;
  };
  shippingAddress?: {
    fullName: string;
    phone: string;
    email: string;
    line1: string;
    city: string;
    state: string;
    pincode: string;
  };
  updatedAt?: Timestamp;
  items?: Array<{
    productId?: string;
    id?: string;
    name: string;
    price: number;
    quantity?: number;
    imageUrl?: string;
    category?: string;
  }>;
}

function StatusBadge({ status }: { status?: string }) {
  const cls = useMemo(() => {
    switch (status) {
      case 'paid':
      case 'delivered':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'pending':
      case 'placed':
      case 'processing':
        return 'bg-amber-100 text-amber-900 border-amber-200';
      case 'failed':
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  }, [status]);
  return <span className={`px-2 py-0.5 rounded text-xs border ${cls}`}>{status || 'unknown'}</span>;
}

export default function OrdersPage() {
  const { user } = useStore();
  const [orders, setOrders] = useState<OrderItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [params] = useSearchParams();
  const highlight = params.get('highlight') || '';
  const [openMap, setOpenMap] = useState<Record<string, boolean>>({});
  const [busyId, setBusyId] = useState<string | null>(null);
  const [reqOpenMap, setReqOpenMap] = useState<Record<string, boolean>>({});
  const [reqReasonMap, setReqReasonMap] = useState<Record<string, string>>({});
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);
  const [orderToCancel, setOrderToCancel] = useState<OrderItem | null>(null);
  const [customizableMap, setCustomizableMap] = useState<Record<string, boolean>>({});
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState<{ status: 'all' | 'on_the_way' | 'delivered' | 'cancelled' | 'returned'; time: 'all' | '30days'; }>({
    status: 'all',
    time: '30days',
  });

  useEffect(() => {
    setLoading(true);

    // Check for user in localStorage if not available in auth or store
    let uid = auth.currentUser?.uid || user?.uid || user?.id;

    // Try to get user from localStorage as fallback
    if (!uid) {
      const localStorageUser = localStorage.getItem('currentUser');
      if (localStorageUser) {
        try {
          const parsedUser = JSON.parse(localStorageUser);
          uid = parsedUser.uid;
          console.log('Using user ID from localStorage:', uid);
        } catch (e) {
          console.error('Error parsing user from localStorage');
        }
      }
    }

    if (!uid) { 
      console.log('No user ID found, cannot fetch orders');
      setOrders([]);
      setLoading(false);
      return;
    }

    console.log('Fetching orders for user ID:', uid);

    // Try multiple field names for user ID with separate queries
    // First try with userId field
    const userIdQuery = query(
      collection(db, 'orders'),
      where('userId', '==', uid)
    );

    const unsub = onSnapshot(userIdQuery, (snap) => {
      const list: OrderItem[] = [];

      snap.forEach((doc) => {
        const data = doc.data();
        console.log('Order found for user:', doc.id);
        list.push({ id: doc.id, ...data as any });
      });

      console.log('Orders found:', list.length);
      setOrders(list);
      setLoading(false);
    }, (error) => {
      console.error('Error fetching orders:', error);

      // If first query fails, try with uid field
      console.log('Trying alternative field: uid');
      const uidQuery = query(
        collection(db, 'orders'),
        where('uid', '==', uid)
      );

      onSnapshot(uidQuery, (snap) => {
        const list: OrderItem[] = [];
        snap.forEach((doc) => {
          const data = doc.data();
          list.push({ id: doc.id, ...data as any });
        });

        console.log('Orders found with uid field:', list.length);
        setOrders(list);
        setLoading(false);
      }, (innerError) => {
        console.error('Error with alternative query:', innerError);
        setLoading(false);
      });
    });

    return () => unsub();
  }, [user]);

  // Add auth state listener to handle auth state changes
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((firebaseUser) => {
      if (firebaseUser) {
        console.log('Auth state changed, user logged in:', firebaseUser.uid);
      } else {
        console.log('Auth state changed, user logged out');
      }
    });

    return () => unsubscribe();
  }, []);

  // Get user ID from either Firebase auth or Zustand store
  const uid = auth.currentUser?.uid || user?.uid || user?.id;

  // Determine if order is considered purchased (eligible for customization chat)
  const isPurchased = (o: OrderItem) => {
    const status = String(o.status || '').toLowerCase();
    const paid = String(o.paymentStatus || '').toLowerCase() === 'paid';
    return paid || ['placed', 'processing', 'shipped', 'delivered'].includes(status);
  };

  // Lazy-load customizable flag for products in visible orders
  useEffect(() => {
    const load = async () => {
      const idsToFetch = new Set<string>();
      orders.forEach(o => {
        o.items?.forEach(it => {
          const pid = it.productId || it.id;
          if (pid && customizableMap[pid] === undefined) idsToFetch.add(pid);
        });
      });
      if (idsToFetch.size === 0) return;
      const updates: Record<string, boolean> = {};
      await Promise.all(Array.from(idsToFetch).map(async (pid) => {
        try {
          const snap = await getDoc(doc(db, 'products', pid));
          const data = snap.data() as any | undefined;
          updates[pid] = !!data?.customizable;
        } catch (e) {
          console.warn('Failed fetching product for customizable check', pid, e);
          updates[pid] = false;
        }
      }));
      if (Object.keys(updates).length) {
        setCustomizableMap(prev => ({ ...prev, ...updates }));
      }
    };
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orders]);

  const canMarkDelivered = (o: OrderItem) => {
    const status = String(o.status || '').toLowerCase();
    if (!status) return false;
    // Allow user confirmation when not already delivered/cancelled
    return status !== 'delivered' && status !== 'cancelled';
  };

  // Check if order can be cancelled based on status and items
  const canCancelOrder = (order: OrderItem) => {
    const status = String(order.status || '').toLowerCase();

    // Prevent cancellation for processing orders
    if (status === 'processing') {
      return false;
    }

    // Already cancelled or delivered orders can't be cancelled
    if (['cancelled', 'delivered', 'shipped'].includes(status)) {
      return false;
    }

    // Check if any item is non-cancellable (customized or perishable)
    const hasNonCancellableItems = order.items?.some(item => {
      const category = item.category?.toLowerCase() || '';
      return ['custom', 'perishable', 'customized'].some(term => category.includes(term));
    });

    if (hasNonCancellableItems) {
      return false;
    }

    // For prepaid orders, only allow cancellation if not yet processed
    if (order.paymentMethod !== 'cod') {
      return status === 'pending';
    }
    
    // For COD orders, allow cancellation only if pending or placed
    return ['pending', 'placed'].includes(status);
  };

  const handleCancelClick = (order: OrderItem) => {
    console.log('Cancel button clicked', order.id);
    setOrderToCancel(order);
    setShowCancelConfirm(true);
  };

  const confirmCancelOrder = async () => {
    if (!orderToCancel?.id || busyId) {
      setShowCancelConfirm(false);
      return;
    }

    console.log('Attempting to cancel order', orderToCancel.id);
    setBusyId(orderToCancel.id);
    
    try {
      await updateDoc(doc(db, 'orders', orderToCancel.id), {
        status: 'cancelled',
        updatedAt: Timestamp.now(),
        cancelledAt: Timestamp.now(),
        cancelledBy: auth.currentUser?.uid || 'user'
      });
      
      console.log('Order cancelled successfully', orderToCancel.id);
      
      setOrders(prev => prev.map(o => 
        o.id === orderToCancel.id 
          ? { ...o, status: 'cancelled' } 
          : o
      ));
      
      alert('Order has been cancelled successfully');
    } catch (error) {
      console.error('Failed to cancel order:', error);
      alert('Failed to cancel order. Please try again or contact support.');
    } finally {
      setBusyId(null);
      setShowCancelConfirm(false);
      setOrderToCancel(null);
    }
  };

  const markDelivered = async (o: OrderItem) => {
    if (!o?.id || busyId) return;
    try {
      setBusyId(o.id);
      await updateDoc(doc(db, 'orders', o.id), {
        status: 'delivered',
        updatedAt: Timestamp.now(),
        userConfirmedDelivery: true,
      });
      setOrders(prev => prev.map(x => x.id === o.id ? { ...x, status: 'delivered' } : x));
    } catch (e) {
      console.error('Failed to mark delivered', e);
    } finally {
      setBusyId(null);
    }
  };

  const submitCorrectionRequest = async (o: OrderItem) => {
    const reason = (reqReasonMap[o.id] || '').trim();
    if (!reason) return;
    try {
      setBusyId(o.id);
      await addDoc(collection(db, 'order-status-corrections'), {
        orderId: o.id,
        userId: uid || null,
        currentStatus: o.status || null,
        reason,
        status: 'pending',
        createdAt: serverTimestamp(),
      });
      setReqReasonMap(m => ({ ...m, [o.id]: '' }));
      setReqOpenMap(m => ({ ...m, [o.id]: false }));
    } catch (e) {
      console.error('Failed to submit correction request', e);
    } finally {
      setBusyId(null);
    }
  };

  const displayOrders = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    const withinTime = (o: OrderItem) => {
      if (filters.time === 'all') return true;
      const d = o.createdAt?.toDate ? o.createdAt.toDate() : undefined;
      if (!d) return true;
      const now = new Date();
      if (filters.time === '30days') {
        const cutoff = new Date();
        cutoff.setDate(now.getDate() - 30);
        return d >= cutoff;
      }
      return true;
    };
    const statusMatch = (o: OrderItem) => {
      const s = String(o.status || '').toLowerCase();
      if (filters.status === 'all') return true;
      if (filters.status === 'on_the_way') return ['placed','processing','shipped'].includes(s);
      if (filters.status === 'delivered') return s === 'delivered';
      if (filters.status === 'cancelled') return s === 'cancelled';
      if (filters.status === 'returned') return s === 'returned';
      return true;
    };
    const filtered = orders.filter((o) => {
      if (!statusMatch(o)) return false;
      if (!withinTime(o)) return false;
      if (!q) return true;
      const idMatch = o.id.toLowerCase().includes(q);
      const itemMatch = o.items?.some((it) => it.name?.toLowerCase().includes(q));
      return idMatch || itemMatch;
    });

    // Sort by most recent first (createdAt desc, fallback to updatedAt)
    const getDate = (o: OrderItem) =>
      (o.createdAt?.toDate ? o.createdAt.toDate() : (o.updatedAt?.toDate ? o.updatedAt.toDate() : new Date(0))).getTime();

    return filtered.sort((a, b) => getDate(b) - getDate(a));
  }, [orders, searchTerm, filters]);

  return (
    <motion.div
      className="min-h-screen pt-20 pb-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <div className="container mx-auto px-4 max-w-7xl">
        <h1 className="text-3xl font-bold mb-6">My Orders</h1>

        {!uid && (
          <div className="border border-yellow-200 bg-yellow-50 text-yellow-900 rounded p-4 mb-6">
            Please sign in to see your orders.
          </div>
        )}

        <div className="flex flex-col md:flex-row gap-6">
          {/* Filters Sidebar */}
          <aside className="w-full md:w-64 flex-shrink-0">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-4 min-h-[72vh] md:sticky md:top-24">
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-5">Filters</h1>
              <div className="mb-6">
                <h4 className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-2 tracking-wide">ORDER STATUS</h4>
                <div className="space-y-3">
                  {[
                    { value: 'on_the_way', label: 'On the way' },
                    { value: 'delivered', label: 'Delivered' },
                    { value: 'cancelled', label: 'Cancelled' },
                    { value: 'returned', label: 'Returned' },
                  ].map(opt => (
                    <label key={opt.value} className="flex items-center gap-3 text-base text-gray-700 dark:text-gray-300 leading-6">
                      <input
                        type="radio"
                        name="statusFilter"
                        className="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        checked={filters.status === opt.value}
                        onChange={() => setFilters(f => ({ ...f, status: opt.value as any }))}
                      />
                      <span>{opt.label}</span>
                    </label>
                  ))}
                  <label className="flex items-center gap-3 text-base text-gray-700 dark:text-gray-300 leading-6">
                    <input
                      type="radio"
                      name="statusFilter"
                      className="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      checked={filters.status === 'all'}
                      onChange={() => setFilters(f => ({ ...f, status: 'all' }))}
                    />
                    <span>All</span>
                  </label>
                </div>
              </div>
              <div className="mt-6">
                <h4 className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-2 tracking-wide">ORDER TIME</h4>
                <div className="space-y-3">
                  <label className="flex items-center gap-3 text-base text-gray-700 dark:text-gray-300 leading-6">
                    <input
                      type="radio"
                      name="timeFilter"
                      className="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      checked={filters.time === '30days'}
                      onChange={() => setFilters(f => ({ ...f, time: '30days' }))}
                    />
                    <span>Last 30 days</span>
                  </label>
                  <label className="flex items-center gap-3 text-base text-gray-700 dark:text-gray-300 leading-6">
                    <input
                      type="radio"
                      name="timeFilter"
                      className="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      checked={filters.time === 'all'}
                      onChange={() => setFilters(f => ({ ...f, time: 'all' }))}
                    />
                    <span>All Time</span>
                  </label>
                </div>
              </div>
            </div>
          </aside>

          {/* Main column: Search + Orders */}
          <section className="flex-1">
            {/* Search Bar like screenshot */}
            <div className="mb-6">
              <div className="relative flex">
                <div className="relative flex-1">
                  <input
                    type="text"
                    placeholder="Search your orders here"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full px-4 py-2 pl-10 rounded-l-sm md:rounded-l-md border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <svg
                    className="h-5 w-5 text-gray-400 absolute left-3 top-2.5"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                    />
                  </svg>
                </div>
                <button
                  onClick={() => { /* search is applied live by input */ }}
                  className="inline-flex items-center gap-2 px-4 py-2 rounded-r-sm md:rounded-r-md bg-blue-600 text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  aria-label="Search Orders"
                >
                  <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                  Search Orders
                </button>
              </div>
            </div>

            {loading ? (
              <div className="text-muted-foreground">Loading orders…</div>
            ) : orders.length === 0 ? (
              <div className="text-muted-foreground">No orders yet.</div>
            ) : displayOrders.length === 0 ? (
              <div className="text-muted-foreground">No matching orders. Try a different search.</div>
            ) : (
              <ul className="space-y-4 w-full">
                {displayOrders.map((o) => {
                  const created = o.createdAt?.toDate ? o.createdAt.toDate() : undefined;
                  const isHighlight = o.id === highlight;
                  // Expand items by default so Add Review is visible
                  const isOpen = openMap[o.id] ?? true;
                  return (
                    <li
                      key={o.id}
                      className={`rounded-lg border border-gray-200 dark:border-gray-700 bg-white/80 dark:bg-gray-900/60 backdrop-blur-sm p-5 shadow-sm hover:shadow md:hover:shadow-md transition-shadow w-full ${isHighlight ? 'ring-2 ring-gold' : ''}`}
                    >
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex flex-col">
                          <span className="text-sm text-muted-foreground">Order ID</span>
                          <span className="font-mono text-sm">{o.id}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-2 justify-end">
                            <StatusBadge status={o.status} />
                            {String(o.status).toLowerCase() === 'delivered' && (
                              <div className="flex items-center text-xs text-green-600 dark:text-green-400">
                                <span className="h-2 w-2 rounded-full bg-green-500 mr-2"></span>
                                Delivered on {new Date((o as any).deliveredAt?.toDate?.() || o.updatedAt?.toDate?.() || created).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}
                              </div>
                            )}
                          </div>
                          {Array.isArray(o.items) && o.items.length > 0 && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setOpenMap((m) => ({ ...m, [o.id]: !isOpen }))}
                              className="ml-2"
                            >
                              {isOpen ? 'Hide' : 'View'} items ({o.items.length})
                            </Button>
                          )}
                          {canCancelOrder(o) && (
                            <Button
                              variant="outline"
                              size="sm"
                              disabled={busyId === o.id}
                              onClick={() => handleCancelClick(o)}
                              className="ml-2"
                              title="Cancel this order"
                            >
                              {busyId === o.id ? 'Cancelling...' : 'Cancel Order'}
                            </Button>
                          )}
                          {canMarkDelivered(o) && (
                            <Button
                              variant="default"
                              size="sm"
                              disabled={busyId === o.id}
                              onClick={() => markDelivered(o)}
                              className="ml-2"
                              title="Confirm you have received this order"
                            >
                              Mark Delivered
                            </Button>
                          )}
                        </div>
                      </div>
                      <div className="mt-3 grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                        <div>
                          <div className="text-muted-foreground">Amount</div>
                          <div className="font-medium">₹{(o.amount || 0).toFixed(2)}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Payment</div>
                          <div className="uppercase font-medium">{o.paymentMethod || '—'}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Created</div>
                          <div>{created ? created.toLocaleString() : '—'}</div>
                        </div>
                      </div>
                      <div className="my-3 border-t border-gray-200 dark:border-gray-700" />
                      {/* Display shipping address from the document structure */}
                      {o.shippingAddress && (
                        <div className="mt-3">
                          <div className="text-muted-foreground mb-1 text-sm">Delivery Address</div>
                          <div className="text-sm bg-gray-50 dark:bg-gray-900/50 rounded p-3 border border-gray-200/60 dark:border-gray-700/60">
                            <div className="font-medium">{o.shippingAddress.fullName} <span className="text-muted-foreground">• {o.shippingAddress.phone}</span></div>
                            <div>{o.shippingAddress.email}</div>
                            <div>{o.shippingAddress.line1}</div>
                            <div>{o.shippingAddress.city}, {o.shippingAddress.state} {o.shippingAddress.pincode}</div>
                          </div>
                        </div>
                      )}
                      {/* Fallback to contact info if shippingAddress is not available */}
                      {!o.shippingAddress && o.contact && (
                        <div className="mt-3">
                          <div className="text-muted-foreground mb-1 text-sm">Contact Information</div>
                          <div className="text-sm bg-gray-50 dark:bg-gray-900/50 rounded p-3 border border-gray-200/60 dark:border-gray-700/60">
                            <div className="font-medium">{o.contact.name} <span className="text-muted-foreground">• {o.contact.phone}</span></div>
                            <div>{o.contact.email}</div>
                          </div>
                        </div>
                      )}
                      {/* Items in this order */}
                      {Array.isArray(o.items) && o.items.length > 0 && isOpen && (
                        <div className="mt-4 space-y-2">
                          {o.items.map((it, idx) => {
                            const pid = it.productId || it.id || '';
                            const canReview = String(o.status || '').toLowerCase() === 'delivered';
                            return (
                              <Card key={`${o.id}-${pid}-${idx}`} className="overflow-hidden border border-gray-200 dark:border-gray-700 bg-white/80 dark:bg-gray-900/40">
                                <CardContent className="p-3">
                                  <div className="flex items-center gap-3">
                                    <img
                                      src={it.imageUrl || '/images/placeholder-item.jpg'}
                                      alt={it.name}
                                      className="h-14 w-14 rounded object-cover border border-gray-200 dark:border-gray-700"
                                      loading="lazy"
                                    />
                                    <div className="flex-1 min-w-0">
                                      {pid ? (
                                        <Link to={`/product/${pid}`} className="font-medium hover:underline truncate block">
                                          {it.name}
                                        </Link>
                                      ) : (
                                        <div className="font-medium truncate">{it.name}</div>
                                      )}
                                      <div className="text-sm text-muted-foreground">₹{Number(it.price || 0).toFixed(2)} × {it.quantity || 1}</div>
                                    </div>
                                    <div className="flex items-center gap-2 shrink-0">
                                      {pid && canReview && (
                                        <Button asChild variant="outline">
                                          <Link to={`/product/${pid}?review=1`}>Add Review</Link>
                                        </Button>
                                      )}
                                      {pid && isPurchased(o) && customizableMap[pid] && (
                                        <Button asChild size="sm" title="Request post-purchase customization with the seller">
                                          <Link to={`/customize/${pid}?orderId=${o.id}`}>Request customization</Link>
                                        </Button>
                                      )}
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            );
                          })}
                        </div>
                      )}
                      {/* Status correction request */}
                      <div className="mt-4 pt-3 border-t border-gray-200 dark:border-gray-700">
                        <div className="flex items-center justify-between">
                          <div className="text-sm text-muted-foreground">Need to correct this order's status?</div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setReqOpenMap(m => ({ ...m, [o.id]: !m[o.id] }))}
                          >
                            {reqOpenMap[o.id] ? 'Hide' : 'Request correction'}
                          </Button>
                        </div>
                        {reqOpenMap[o.id] && (
                          <div className="mt-2">
                            <textarea
                              value={reqReasonMap[o.id] || ''}
                              onChange={(e) => setReqReasonMap(m => ({ ...m, [o.id]: e.target.value }))}
                              placeholder="Describe the issue (e.g., marked delivered by mistake)."
                              className="w-full rounded-md border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 p-2 text-sm"
                              rows={3}
                            />
                            <div className="mt-2 flex items-center gap-2">
                              <Button
                                size="sm"
                                disabled={busyId === o.id || !(reqReasonMap[o.id] || '').trim()}
                                onClick={() => submitCorrectionRequest(o)}
                              >
                                Submit request
                              </Button>
                              <span className="text-xs text-muted-foreground">Admin will review and can adjust the status if needed.</span>
                            </div>
                          </div>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        </div>
      </div>
      {showCancelConfirm && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.5)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 1000
        }}>
          <div style={{
            backgroundColor: '#f8f9fa',
            padding: '16px',
            borderRadius: '8px',
            maxWidth: '320px',
            width: '85%',
            boxShadow: '0 2px 10px rgba(0,0,0,0.1)'
          }}>
            <h3 style={{ fontSize: '16px', marginBottom: '12px', color: '#333' }}>Yes, cancel</h3>
            <p style={{ fontSize: '14px', color: '#555', marginBottom: '16px' }}>Are you sure you want to cancel this order?</p>
            <div style={{
              display: 'flex',
              justifyContent: 'flex-end',
              gap: '8px',
              marginTop: '16px'
            }}>
              <button 
                onClick={() => setShowCancelConfirm(false)}
                disabled={!!busyId}
                style={{
                  padding: '6px 12px',
                  borderRadius: '4px',
                  background: 'transparent',
                  border: 'none',
                  cursor: 'pointer',
                  fontSize: '13px',
                  color: '#555'
                }}
              >
                No, Cancel
              </button>
              <button 
                onClick={confirmCancelOrder}
                disabled={!!busyId}
                style={{ 
                  backgroundColor: '#dc3545', 
                  color: 'white',
                  padding: '6px 12px',
                  borderRadius: '4px',
                  border: 'none',
                  cursor: 'pointer',
                  fontSize: '13px',
                  opacity: busyId ? 0.7 : 1
                }}
              >
                {busyId === orderToCancel?.id ? 'Cancelling...' : 'Yes, Cancel'}
              </button>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
}
