import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { LayoutGrid, List, Search, Filter, ShoppingCart } from 'lucide-react';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useNavigate } from 'react-router-dom';
import { useStore } from '@/store/useStore';
import { useCart } from '@/contexts/CartContext';
import { useAuthGate } from '@/hooks/useAuthGate';
import { ProductCard } from '@/components/ProductCard';

type ProductDoc = {
  id: string;
  name: string;
  description?: string;
  price: number;
  sellerPrice?: number;
  finalPrice?: number;
  category?: string;
  imageUrl?: string;
  imageUrls?: string[];
  ingredients?: string;
  benefits?: string;
  creator?: string;
  published?: boolean;
  customizable?: boolean;
};

export default function BeautyProductsPage() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<ProductDoc[]>([]);
  const { toggleWishlist, isWishlisted } = useStore();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [priceFilter, setPriceFilter] = useState<'all' | 'under25' | '25-50' | '50-100' | 'over100'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'priceLow' | 'priceHigh' | 'impact' | 'popular'>('newest');
  const { addToCart } = useCart();
  const { runOrLogin } = useAuthGate();

  useEffect(() => {
    document.title = 'Beauty Homemade Products | ewsells';
  }, []);

  useEffect(() => {
    const q = query(
      collection(db, 'products'),
      where('category', '==', 'beauty-homemade'),
      where('published', '==', true)
    );
    const unsub = onSnapshot(q, (snap) => {
      const rows: ProductDoc[] = snap.docs.map((d) => ({
        id: d.id,
        name: d.data().name || 'Unnamed Item',
        description: d.data().description,
        price: typeof d.data().price === 'number' ? d.data().price : Number(d.data().price || 0),
        sellerPrice: d.data().sellerPrice,
        finalPrice: d.data().finalPrice,
        category: d.data().category || 'beauty-homemade',
        imageUrl: d.data().imageUrl,
        imageUrls: d.data().imageUrls || [],
        ingredients: d.data().ingredients,
        benefits: d.data().benefits,
        creator: d.data().creator || 'Local Seller',
        published: d.data().published,
        customizable: !!d.data().customizable
      }));
      setItems(rows);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const filteredItems = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const searched = q
      ? items.filter((item) =>
          (item.name || '').toLowerCase().includes(q) ||
          (item.description || '').toLowerCase().includes(q) ||
          (item.category || '').toLowerCase().includes(q) ||
          (item.ingredients || '').toLowerCase().includes(q) ||
          (item.benefits || '').toLowerCase().includes(q)
        )
      : items;

    const priced = searched.filter((item) => {
      const price = Number(item.finalPrice ?? item.sellerPrice ?? item.price ?? 0);
      switch (priceFilter) {
        case 'under25': return price < 25;
        case '25-50': return price >= 25 && price <= 50;
        case '50-100': return price >= 50 && price <= 100;
        case 'over100': return price > 100;
        default: return true;
      }
    });

    const sorted = [...priced];
    if (sortBy === 'priceLow') {
      sorted.sort((a, b) => 
        Number(a.finalPrice ?? a.sellerPrice ?? a.price ?? 0) - 
        Number(b.finalPrice ?? b.sellerPrice ?? b.price ?? 0)
      );
    } else if (sortBy === 'priceHigh') {
      sorted.sort((a, b) => 
        Number(b.finalPrice ?? b.sellerPrice ?? b.price ?? 0) - 
        Number(a.finalPrice ?? a.sellerPrice ?? a.price ?? 0)
      );
    }
    return sorted;
  }, [items, searchQuery, priceFilter, sortBy]);

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Beauty <span className="text-gold">Homemade Products</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover natural and organic beauty products made with love and care.
            Each purchase supports local artisans and sustainable practices.
          </p>
        </motion.div>

        <motion.div
          className="mb-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search beauty products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 pl-10"
              />
            </div>
            <div className="flex items-center gap-2 relative">
              <Button
                variant="outline"
                size="sm"
                className="flex items-center gap-2"
                onClick={() => setFiltersOpen((v) => !v)}
              >
                <Filter className="h-4 w-4" />
                Filters
              </Button>

              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="w-10 h-10 p-0"
              >
                <LayoutGrid className="h-4 w-4" />
                <span className="sr-only">Grid view</span>
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="w-10 h-10 p-0"
              >
                <List className="h-4 w-4" />
                <span className="sr-only">List view</span>
              </Button>

              {filtersOpen && (
                <div className="absolute top-12 right-0 z-40 w-80 sm:w-[28rem] bg-background border border-border rounded-md shadow-lg p-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Price Range</label>
                    <div className="space-y-2">
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === 'all' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setPriceFilter('all')}
                      >
                        All Prices
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === 'under25' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setPriceFilter('under25')}
                      >
                        Under $25
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === '25-50' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setPriceFilter('25-50')}
                      >
                        $25 - $50
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === '50-100' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setPriceFilter('50-100')}
                      >
                        $50 - $100
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === 'over100' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setPriceFilter('over100')}
                      >
                        Over $100
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Sort By</label>
                    <div className="space-y-2">
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'newest' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setSortBy('newest')}
                      >
                        Newest First
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'priceLow' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setSortBy('priceLow')}
                      >
                        Price: Low to High
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'priceHigh' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setSortBy('priceHigh')}
                      >
                        Price: High to Low
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'impact' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setSortBy('impact')}
                      >
                        Highest Impact
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'popular' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setSortBy('popular')}
                      >
                        Most Popular
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </motion.div>

        {loading ? (
          <motion.div
            className="col-span-full text-center py-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <p className="text-muted-foreground">Loading beauty products…</p>
          </motion.div>
        ) : filteredItems.length > 0 ? (
          <motion.div
            className={viewMode === 'grid' ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6' : 'space-y-4'}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {filteredItems.map((item) => (
              <div key={item.id} className="relative group">
                <ProductCard
                  id={item.id}
                  name={item.name}
                  description={
                    <>
                      {item.creator && <p className="text-sm text-muted-foreground">By {item.creator}</p>}
                      {item.ingredients && <p className="text-xs mt-1">Ingredients: {item.ingredients}</p>}
                      {item.benefits && <p className="text-xs text-emerald-600 font-medium mt-1">{item.benefits}</p>}
                    </>
                  }
                  price={item.price}
                  finalPrice={item.finalPrice}
                  sellerPrice={item.sellerPrice}
                  category={item.category || 'beauty-homemade'}
                  imageUrl={item.imageUrl}
                  imageUrls={item.imageUrls}
                  customizable={item.customizable}
                  isWishlisted={isWishlisted(item.id)}
                  onWishlistClick={() => toggleWishlist(item.id)}
                  onClick={() => navigate(`/product/${item.id}`)}
                  viewMode={viewMode}
                  className="h-full"
                  docData={item as any}
                />
                <Button
                  className="absolute bottom-4 right-4 bg-gold hover:bg-amber-500 text-black border border-amber-300 rounded-md px-3 py-1.5 h-8 text-sm font-medium transition-colors shadow-sm hover:shadow flex items-center gap-1.5 whitespace-nowrap z-10"
                  onClick={(e) => {
                    e.stopPropagation();
                    runOrLogin(async () => {
                      await addToCart({
                        id: item.id,
                        name: item.name,
                        price: Number(item.finalPrice ?? item.sellerPrice ?? item.price ?? 0),
                        imageUrl: item.imageUrl || (item.imageUrls && item.imageUrls[0]) || '',
                        category: item.category || 'beauty-homemade'
                      });
                    });
                  }}
                >
                  <ShoppingCart className="h-3.5 w-3.5" />
                  <span>Add to Cart</span>
                </Button>
              </div>
            ))}
          </motion.div>
        ) : (
          <motion.div
            className="col-span-full text-center py-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {items.length === 0 ? (
              <>
                <p className="text-muted-foreground">No beauty products available at the moment.</p>
                <p className="text-sm mt-2">Check back soon for our latest collection of homemade beauty products.</p>
              </>
            ) : (
              <p className="text-muted-foreground">No products found matching your search.</p>
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
}
