import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/toast-context';
import { db, storage, auth } from '@/lib/firebase';
import { addDoc, collection, serverTimestamp, setDoc, doc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { Link, useNavigate } from 'react-router-dom';

export default function HelpingHandsRegister() {
  const { showToast } = useToast();
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);

  async function uploadIfPresent(file: File | null, dest: string): Promise<string | null> {
    if (!file) return null;
    const storageRef = ref(storage, dest);
    await uploadBytes(storageRef, file);
    return await getDownloadURL(storageRef);
  }

  const handleSubmit: React.FormEventHandler<HTMLFormElement> = async (e) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);

    // Require auth to satisfy Firestore/Storage rules
    if (!auth.currentUser) {
      showToast({ message: 'Please sign in to submit your request.', type: 'error' });
      navigate('/login');
      return;
    }

    const uid = auth.currentUser.uid;
    const requestId = `${uid}-${Date.now()}`;

    const fullName = String(formData.get('fullName') || '').trim();
    const email = String(formData.get('email') || '').trim();
    const phone = String(formData.get('phone') || '').trim();
    const address = String(formData.get('address') || '').trim();
    const dob = String(formData.get('dob') || '').trim();
    const gender = String(formData.get('gender') || '').trim();

    const bankAccountName = String(formData.get('bankAccountName') || '').trim();
    const bankAccountNumber = String(formData.get('bankAccountNumber') || '').trim();
    const ifsc = String(formData.get('ifsc') || '').trim();
    const bankName = String(formData.get('bankName') || '').trim();
    const branch = String(formData.get('branch') || '').trim();
    const upiId = String(formData.get('upiId') || '').trim();

    const medicalCondition = String(formData.get('medicalCondition') || '').trim();
    const consent = formData.get('consent') === 'on';

    const medicalCert = (formData.get('medicalCertificate') as File) || null;
    const userPhoto = (formData.get('userPhoto') as File) || null;
    const identityProof = (formData.get('identityProof') as File) || null;

    const hasFullBank = !!(bankAccountName && bankAccountNumber && ifsc && bankName && branch);
    const hasUpi = !!upiId;

    if (!fullName || !phone || !address || !userPhoto || !consent || (!hasFullBank && !hasUpi)) {
      showToast({ message: 'Please fill all required fields: either provide UPI ID or complete all bank details, upload your photo, and accept consent.', type: 'error' });
      return;
    }

    try {
      setSubmitting(true);
      // Must include uid segment to match Storage rules: helping-hands/{uid}/**
      const basePath = `helping-hands/${uid}/${requestId}`;
      const medicalUrl = await uploadIfPresent(medicalCert, `${basePath}/medical-certificate_${medicalCert?.name || 'file'}`);
      const photoUrl = await uploadIfPresent(userPhoto, `${basePath}/user-photo_${userPhoto?.name || 'file'}`);
      const identityProofUrl = await uploadIfPresent(identityProof, `${basePath}/identity-proof_${identityProof?.name || 'file'}`);

      // Upsert a user profile for Helping Hands
      await setDoc(doc(db, 'helping-hands-users', uid), {
        uid,
        fullName,
        email,
        phone,
        address,
        dob,
        gender,
        bank: {
          accountName: bankAccountName,
          accountNumber: bankAccountNumber,
          ifsc,
          bankName,
          branch,
          upiId,
        },
        photoUrl,
        updatedAt: serverTimestamp(),
      }, { merge: true });

      await addDoc(collection(db, 'helping-hands-requests'), {
        requestId,
        uid: auth.currentUser.uid,
        fullName,
        email,
        phone,
        address,
        dob,
        gender,
        bank: {
          accountName: bankAccountName,
          accountNumber: bankAccountNumber,
          ifsc,
          bankName,
          branch,
          upiId,
        },
        medical: {
          condition: medicalCondition,
          certificateUrl: medicalUrl,
        },
        photoUrl,
        identityProofUrl,
        status: 'pending',
        createdAt: serverTimestamp(),
      });

      showToast({ message: 'Request submitted successfully. We will reach out soon.', type: 'success' });
      navigate('/helping-hands');
    } catch (err) {
      console.error(err);
      showToast({ message: 'Submission failed. Please try again.', type: 'error' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-12"
    >
      <div className="container mx-auto px-4 max-w-3xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Helping Hands Registration</h1>
          <p className="text-muted-foreground">Provide your details to request support. We respect your privacy.</p>
        </div>

        <Card>
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* User Details */}
              <section>
                <h2 className="font-semibold text-lg mb-3">User Details</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm mb-1 block">Full Name *</label>
                    <Input name="fullName" required placeholder="Your full name" />
                  </div>
                  <div>
                    <label className="text-sm mb-1 block">Email</label>
                    <Input type="email" name="email" placeholder="you@example.com" />
                  </div>
                  <div>
                    <label className="text-sm mb-1 block">Phone *</label>
                    <Input name="phone" required placeholder="Phone number" />
                  </div>
                  <div>
                    <label className="text-sm mb-1 block">Date of Birth</label>
                    <Input type="date" name="dob" />
                  </div>
                  <div>
                    <label className="text-sm mb-1 block">Gender</label>
                    <Input name="gender" placeholder="Female / Male / Other" />
                  </div>
                  <div className="md:col-span-2">
                    <label className="text-sm mb-1 block">Address *</label>
                    <Input name="address" required placeholder="Street, City, State, ZIP" />
                  </div>
                </div>
              </section>

              {/* Medical */}
              <section>
                <h2 className="font-semibold text-lg mb-3">Medical Information</h2>
                <div className="grid grid-cols-1 gap-4">
                  <div>
                    <label className="text-sm mb-1 block">Medical Condition (short note)</label>
                    <Input name="medicalCondition" placeholder="e.g., surgery recovery, chronic illness" />
                  </div>
                  <div>
                    <label className="text-sm mb-1 block">Medical Certificate (PDF/Image)</label>
                    <Input type="file" name="medicalCertificate" accept=".pdf,image/*" />
                  </div>
                </div>
              </section>

              {/* Bank */}
              <section>
                <h2 className="font-semibold text-lg mb-1">Bank Details</h2>
                <p className="text-xs text-muted-foreground mb-3">Either fill UPI ID or complete all bank fields.</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  <div>
                    <label className="text-sm mb-1 block">Account Holder Name</label>
                    <Input name="bankAccountName" />
                  </div>
                  <div>
                    <label className="text-sm mb-1 block">Account Number</label>
                    <Input name="bankAccountNumber" />
                  </div>
                  <div>
                    <label className="text-sm mb-1 block">IFSC / SWIFT</label>
                    <Input name="ifsc" />
                  </div>
                  <div>
                    <label className="text-sm mb-1 block">Bank Name</label>
                    <Input name="bankName" />
                  </div>
                  <div >
                    <label className="text-sm mb-1 block">Branch</label>
                    <Input name="branch" />
                  </div>
                  <div className="md:col-span-2">
                    <label className="text-sm mb-1 block">UPI ID</label>
                    <Input name="upiId" placeholder="yourname@bank" />
                  </div>
                </div>
              </section>

              {/* Upload */}
              <section>
                <h2 className="font-semibold text-lg mb-3">Identity</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm mb-1 block">User Photo (Image) *</label>
                    <Input type="file" name="userPhoto" accept="image/*" required />
                  </div>
                  <div>
                    <label className="text-sm mb-1 block">Identity Proof (PDF/Image)</label>
                    <Input type="file" name="identityProof" accept=".pdf,image/*" />
                  </div>
                </div>
              </section>

              {/* Consent */}
              <section>
                <div className="flex items-start gap-3">
                  <input type="checkbox" id="consent" name="consent" className="mt-1" />
                  <label htmlFor="consent" className="text-sm text-muted-foreground">
                    I consent to provide my details for the purpose of receiving support. Information may be
                    verified by the charity team. *
                  </label>
                </div>
              </section>

              <div className="flex items-center justify-between">
                <Link to="/helping-hands" className="text-sm hover:text-gold">Back</Link>
                <Button type="submit" disabled={submitting} className="bg-gold hover:bg-gold/90 text-black">
                  {submitting ? 'Submitting…' : 'Submit Request'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </motion.div>
  );
}
