import React, { useEffect, useState, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, EyeOff, LogIn, Camera, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { authService } from '@/services/auth';
import { FaceAuth, FaceAuthHandle } from '@/components/ui/face-auth';
import { faceAuthService } from '@/services/faceAuth';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useStore } from '@/store/useStore';

export function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [faceImage, setFaceImage] = useState<string | null>(null);
  const location = useLocation();
  const [showPasswordFields, setShowPasswordFields] = useState<boolean>(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('mode') !== 'face';
  });
  const navigate = useNavigate();
  const { setUser } = useStore();
  const faceAuthRef = useRef<FaceAuthHandle>(null);

  // React to URL changes to switch between face/password modes (e.g., /login?mode=face)
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const isFace = params.get('mode') === 'face';
    setShowPasswordFields(!isFace);
  }, [location.search]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (showPasswordFields) {
      if (!email.trim()) {
        setError('Email is required');
        return;
      }
      if (!password.trim()) {
        setError('Password is required');
        return;
      }
    } else if (!faceImage) {
      setError('Please capture your face for authentication');
      return;
    }

    setIsLoading(true);

    try {
      if (showPasswordFields) {
        // Login with email and password
        const user = await authService.login(email, password);
        console.log('Email/password login successful');

        // Fetch Firestore user data for complete profile
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        const userData = userDoc.exists() ? userDoc.data() : {} as any;

        const completeUser = {
          id: user.uid,
          uid: user.uid,
          email: user.email || userData.email || '',
          displayName: user.displayName || userData.displayName || '',
          photoURL: user.photoURL || userData.photoURL || '',
          role: userData.role || 'user',
          createdAt: userData.createdAt || new Date(),
          updatedAt: new Date()
        };
        setUser(completeUser);

        // Persist for face auth/session
        localStorage.setItem('currentUser', JSON.stringify({
          uid: user.uid,
          email: completeUser.email,
          displayName: completeUser.displayName,
          photoURL: completeUser.photoURL,
          role: completeUser.role,
          lastLogin: new Date().toISOString()
        }));

        // Redirect to intended destination if provided, else home
        const from = (location.state as any)?.from || '/';
        navigate(from, { replace: true });
      } else {
        // Login with face authentication
        await handleFaceLogin();
      }
    } catch (err: any) {
      setError(err.message || 'Failed to login. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFaceLogin = async () => {
    setIsLoading(true);
    setError('');
    
    if (!faceImage) {
      setError('Please capture your face image first');
      setIsLoading(false);
      return;
    }

    try {
      console.log('Attempting face authentication...');
      const userId = await faceAuthService.authenticateWithFace(faceImage);
      
      if (!userId) {
        console.error('Face authentication failed: No user ID returned');
        setError('Face not recognized. Please try again or use email/password login.');
        setIsLoading(false);
        return;
      }
      
      console.log('Face authenticated successfully for user:', userId);

      // Directly authenticate using the user ID
      await handleDirectFaceLogin(userId);
    } catch (err: any) {
      console.error('Face recognition error:', err);
      setError(err.message || 'Face authentication failed. Please try again.');
      setIsLoading(false);
    }
  };

  const handleDirectFaceLogin = async (userId: string) => {
    setIsLoading(true);
    setError('');
    
    try {
      console.log('Face authenticated successfully for user:', userId);

      // Stop the camera before proceeding with login
      if (faceAuthRef.current) {
        console.log('Stopping camera before login...');
        faceAuthRef.current.stopCamera();
      }
      
      try {
        // First authenticate the user
        const user = await authService.loginWithFace(userId);
        console.log('Authentication successful, user:', user);
        
        if (user) {
          // Now that we're authenticated, we can fetch user data
          const userDoc = await getDoc(doc(db, 'users', userId));
          if (!userDoc.exists()) {
            throw new Error('User data not found');
          }
          
          const userData = userDoc.data();
          console.log('User data from Firestore:', userData);
          
          // Create a complete user object with all necessary data
          const completeUserData = {
            uid: userId,
            email: userData.email || user.email || '',
            displayName: userData.displayName || user.displayName || '',
            photoURL: userData.photoURL || '',
            role: userData.role || 'user',
            lastLogin: new Date().toISOString()
          };
          
          console.log('Storing user data in localStorage:', completeUserData);
          
          // Store the user data in localStorage for App.tsx to use
          localStorage.setItem('currentUser', JSON.stringify(completeUserData));

          // Immediately set global user so navbar updates
          setUser({
            id: userId,
            uid: userId,
            email: completeUserData.email,
            displayName: completeUserData.displayName,
            photoURL: completeUserData.photoURL,
            role: completeUserData.role,
            createdAt: userData.createdAt?.toDate() || new Date(),
            updatedAt: new Date()
          });
          
          // Set a flag to force data refresh on home page
          localStorage.setItem('forceDataRefresh', 'true');
          
          // Add a slight delay to ensure state persists, then go home
          setTimeout(() => {
            console.log('Navigating after face login');
            const from = (location.state as any)?.from || '/';
            navigate(from, { replace: true });
          }, 300);
        }
      } catch (loginErr: any) {
        console.error('Error during face login:', loginErr);
        setError(loginErr.message || 'Login failed. Please try again.');
      }
    } catch (err: any) {
      console.error('Error in handleDirectFaceLogin:', err);
      setError(err.message || 'An error occurred during login.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFaceCapture = (imageData: string) => {
    setFaceImage(imageData);
    // Automatically attempt login when face is captured
    if (imageData) {
      setTimeout(() => {
        const form = document.getElementById('loginForm');
        if (form) {
          form.dispatchEvent(new Event('submit', { cancelable: true, bubbles: true }));
        }
      }, 500);
    }
  };

  const handleFaceError = (errorMessage: string) => {
    setError(errorMessage);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      {/* Animated background dots */}
      <div className="absolute inset-0 z-15">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-gold/30 rounded-full"
            style={{
              left: `${20 + i * 15}%`,
              top: `${30 + i * 10}%`,
            }}
            animate={{
              y: [0, -20, 0],
              opacity: [0.3, 0.8, 0.3],
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 3 + i * 0.5,
              repeat: Infinity,
              delay: i * 0.3,
            }}
          />
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md z-20"
      >
        <div className="bg-card/80 backdrop-blur-md shadow-xl rounded-2xl p-8 border border-white/10">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">Welcome Back</h1>
            <p className="text-muted-foreground">Sign in to your account</p>
          </div>

          <div className="flex items-center justify-center mb-6">
            <Button
              type="button"
              variant={!showPasswordFields ? "default" : "outline"}
              size="sm"
              onClick={() => setShowPasswordFields(false)}
              className={!showPasswordFields ? "bg-gold hover:bg-gold/90 text-black mr-2" : "mr-2"}
            >
              <Camera className="mr-2 h-4 w-4" />
              Face
            </Button>
            <Button
              type="button"
              variant={showPasswordFields ? "default" : "outline"}
              size="sm"
              onClick={() => setShowPasswordFields(true)}
              className={showPasswordFields ? "bg-gold hover:bg-gold/90 text-black" : ""}
            >
              <User className="mr-2 h-4 w-4" />
              Password
            </Button>
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-destructive/20 text-destructive p-3 rounded-lg mb-6 text-sm"
            >
              {error}
            </motion.div>
          )}

          <form id="loginForm" onSubmit={handleLogin}>
            <div className="space-y-4">
              {/* Face Authentication Component */}
              {!showPasswordFields && (
                <div className="mt-4 border border-border rounded-lg p-4">
                  <h3 className="text-sm font-medium mb-3">Face Authentication</h3>
                  <FaceAuth
                    ref={faceAuthRef}
                    onCapture={handleFaceCapture}
                    onError={handleFaceError}
                    isRegistration={false}
                  />
                </div>
              )}

              {/* Email/Password Fields */}
              {showPasswordFields && (
                <>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-1">
                      Email
                    </label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required={showPasswordFields}
                      className="w-full"
                    />
                  </div>

                  <div>
                    <label htmlFor="password" className="block text-sm font-medium mb-1">
                      Password
                    </label>
                    <div className="relative">
                      <Input
                        id="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required={showPasswordFields}
                        className="w-full pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500"
                      >
                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                      </button>
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Link to="/forgot-password" className="text-sm text-primary hover:underline">
                      Forgot password?
                    </Link>
                  </div>
                </>
              )}

              {showPasswordFields && (
                <Button
                  type="submit"
                  className="w-full bg-gold hover:bg-gold/90 text-black"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                      className="mr-2 h-4 w-4 border-2 border-black border-t-transparent rounded-full"
                    />
                  ) : (
                    <LogIn className="mr-2 h-4 w-4" />
                  )}
                  {isLoading ? 'Signing In...' : 'Sign In'}
                </Button>
              )}
            </div>
          </form>

          <div className="mt-6 text-center text-sm">
            <p>
              Don't have an account?{' '}
              <Link to="/register" className="text-primary hover:underline">
                Sign up
              </Link>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
