import React, { useEffect, useRef, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Image as ImageIcon, ArrowRight, Plus, ArrowLeft } from 'lucide-react';
import { db, storage } from '@/lib/firebase';
import { addDoc, collection, serverTimestamp, doc, getDoc, query, where, getDocs, updateDoc, setDoc } from 'firebase/firestore';
import { useStore } from '@/store/useStore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';

// In-page upload panel (no modal)

type ProductDoc = {
  name: string;
  description: string;
  price: number;
  category: string;
  imageUrl?: string;
  sellerId: string;
  createdAt?: any;
  updatedAt?: any;
};

const CATEGORY_KEYS = [
  'charity-craft',
  'organic-store',
  'scrap-store',
  'scrap-books',
  'moms-made-united',
  'green-cup-challenge',
  'charity-bakes',
  'home-decor',
  'packed-food',
  'home-plants',
  'beauty-homemade',
  'homemade-households',
  'birthday-gifts',
] as const;
type CategoryKey = typeof CATEGORY_KEYS[number];

const CATEGORY_META: Record<
  CategoryKey,
  { name: string; description: string; image: string; color: string }
> = {
  'charity-craft': {
    name: 'Charity Craft',
    description: 'Handmade items supporting artisan communities',
    image:
      'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'from-rose-500 to-pink-600',
  },
  'organic-store': {
    name: 'Organic Store',
    description: 'Fresh, sustainable produce from local farms',
    image:
      'https://images.pexels.com/photos/4518843/pexels-photo-4518843.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'from-green-500 to-emerald-600',
  },
  'scrap-store': {
    name: 'Scrap Store',
    description: 'Upcycled treasures giving new life to materials',
    image:
      'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'from-amber-500 to-orange-600',
  },
  'scrap-books': {
    name: 'Scrap Books',
    description: 'Handcrafted scrapbooks and memory albums',
    image: 'https://images.unsplash.com/photo-1507842217343-583bb7270b66?q=80&w=600&auto=format&fit=crop',
    color: 'from-amber-500 to-orange-600',
  },
  'moms-made-united': {
    name: 'Moms Made United',
    description: 'Caring mothers creating with love and dedication',
    image:
      'https://images.pexels.com/photos/6849159/pexels-photo-6849159.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'from-purple-500 to-violet-600',
  },
  'green-cup-challenge': {
    name: 'Green Cup Challenge',
    description: 'Sustainable menstrual products that reduce waste',
    image: '/images/menstrual-cup.svg',
    color: 'from-cyan-500 to-sky-600',
  },
  'charity-bakes': {
    name: 'Charity Bakes',
    description: 'Sweet treats baked to support good causes',
    image:
      'https://images.pexels.com/photos/213200/pexels-photo-213200.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'from-pink-500 to-rose-600',
  },
  'home-decor': {
    name: 'Home Decor',
    description: 'Artful decor to brighten your living spaces',
    image:
      'https://images.pexels.com/photos/271743/pexels-photo-271743.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'from-fuchsia-500 to-purple-600',
  },
  'packed-food': {
    name: 'Packed Food',
    description: 'Homemade packaged foods and snacks',
    image:
      'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'from-orange-500 to-amber-600',
  },
  'home-plants': {
    name: 'Home Plants',
    description: 'Indoor plants to refresh your home',
    image:
      'https://images.pexels.com/photos/3076899/pexels-photo-3076899.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'from-emerald-500 to-green-600',
  },
  'beauty-homemade': {
    name: 'Beauty Homemade',
    description: 'Natural, handcrafted beauty and self-care items',
    image:
      'https://images.pexels.com/photos/3738767/pexels-photo-3738767.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'from-rose-500 to-pink-600',
  },
  'homemade-households': {
    name: 'Homemade Households',
    description: 'Eco-friendly and practical household products',
    image:
      'https://images.pexels.com/photos/4239014/pexels-photo-4239014.jpeg?auto=compress&cs=tinysrgb&w=600',
    color: 'from-sky-500 to-blue-600',
  },
  'birthday-gifts': {
    name: 'Birthday Gifts',
    description: 'Thoughtful handmade gifts for special days',
    image:
      'https://images.unsplash.com/photo-1513885535751-8b9238bd345a?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjB8fGJpcnRoZGF5JTIwZ2lmdHxlbnwwfHwwfHx8MA%3D%3D',
    color: 'from-yellow-500 to-amber-500',
  },
};

const CATEGORY_SUGGESTIONS = [
  'scrap-store',
  'organic-store',
  'charity-craft',
  'scrap-books',
  'moms-made-united',
  'green-cup-challenge',
  'charity-bakes',
  'home-decor',
  'packed-food',
  'home-plants',
  'beauty-homemade'
];

const SellerRequestForm = ({ onSubmit, loading }: { onSubmit: (data: any) => void, loading: boolean }) => {
  const [formData, setFormData] = useState({
    storeName: '',
    phone: '',
    address: '',
    description: '',
    categories: [] as string[],
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const toggleCategory = (category: string) => {
    setFormData(prev => ({
      ...prev,
      categories: prev.categories.includes(category)
        ? prev.categories.filter(c => c !== category)
        : [...prev.categories, category]
    }));
  };

  return (
    <Card className="mb-8">
      <CardContent className="pt-6">
        <h2 className="text-2xl font-bold mb-4">Become a Seller</h2>
        <p className="text-muted-foreground mb-6">
          Fill out the form below to submit your seller application. Our team will review your 
          request and get back to you soon.
        </p>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="storeName">Store Name</Label>
              <Input
                id="storeName"
                placeholder="Enter your store name"
                value={formData.storeName}
                onChange={(e) => setFormData({...formData, storeName: e.target.value})}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="Enter your phone number"
                value={formData.phone}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">Business Address</Label>
            <Input
              id="address"
              placeholder="Enter your business address"
              value={formData.address}
              onChange={(e) => setFormData({...formData, address: e.target.value})}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Business Description</Label>
            <textarea
              className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              placeholder="Tell us about your business and what you plan to sell"
              rows={4}
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>Categories (Select all that apply)</Label>
            <div className="flex flex-wrap gap-2">
              {Object.entries(CATEGORY_META).map(([key, { name }]) => (
                <Button
                  key={key}
                  type="button"
                  variant={formData.categories.includes(key) ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => toggleCategory(key)}
                >
                  {name}
                </Button>
              ))}
            </div>
          </div>

          <div className="pt-4">
            <Button type="submit" disabled={loading || formData.categories.length === 0}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                'Submit Request'
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export function SellerDashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useStore();
  const [productCategories, setProductCategories] = useState<string[] | 'loading'>(
    'loading'
  );
  const [allowedDepts, setAllowedDepts] = useState<string[]>([]);
  const [loadingDepts, setLoadingDepts] = useState(false);
  const [sellerCode, setSellerCode] = useState<string>('');
  const [assignedProject, setAssignedProject] = useState<null | {
    projectId: number;
    projectTitle: string;
    focusArea?: string;
    matchedKeywords?: string[];
    score?: number;
    assignedAt?: string;
    method?: string;
  }>(null);

  // Local form state per category
  type FormState = { name: string; description: string; price: string; imageFile: File | null; submitting: boolean; message: string | null };
  const initialForm: FormState = { name: '', description: '', price: '', imageFile: null, submitting: false, message: null };
  const [forms, setForms] = useState<Record<CategoryKey, FormState>>({
    'charity-craft': { ...initialForm },
    'organic-store': { ...initialForm },
    'scrap-store': { ...initialForm },
    'scrap-books': { ...initialForm },
    'moms-made-united': { ...initialForm },
    'green-cup-challenge': { ...initialForm },
    'charity-bakes': { ...initialForm },
    'home-decor': { ...initialForm },
    'packed-food': { ...initialForm },
    'home-plants': { ...initialForm },
    'beauty-homemade': { ...initialForm },
    'homemade-households': { ...initialForm },
    'birthday-gifts': { ...initialForm },
  });

  // Form state
  const imageInputRefs = useRef<Record<CategoryKey, HTMLInputElement | null>>({
    'charity-craft': null,
    'organic-store': null,
    'scrap-store': null,
    'scrap-books': null,
    'moms-made-united': null,
    'green-cup-challenge': null,
    'charity-bakes': null,
    'home-decor': null,
    'packed-food': null,
    'home-plants': null,
    'beauty-homemade': null,
    'homemade-households': null,
    'birthday-gifts': null,
  });

  // In-page panel state
  const [selected, setSelected] = useState<CategoryKey | null>(null);
  const uploadPanelRef = useRef<HTMLDivElement | null>(null);

  // Category request state
  const [isRequestDialogOpen, setIsRequestDialogOpen] = useState(false);
  const [categoryRequest, setCategoryRequest] = useState({
    name: '',
    categories: [] as string[],
    description: '',
    // New FSSAI fields
    fssaiNumber: '',
    fssaiFile: null as File | null,
    submitting: false,
    message: ''
  });

  // Seller request state
  const [isSubmittingRequest, setIsSubmittingRequest] = useState(false);

  const handleSubmitSellerRequest = async (requestData: any) => {
    if (!user) return;
    
    setIsSubmittingRequest(true);
    try {
      await addDoc(collection(db, 'seller-requests'), {
        ...requestData,
        sellerId: user.id,
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      
      // Show success message
      // toast.success('Your seller request has been submitted for review.');
    } catch (error) {
      console.error('Error submitting seller request:', error);
      // toast.error('Failed to submit seller request. Please try again.');
    } finally {
      setIsSubmittingRequest(false);
    }
  };

  // Guard: must be logged in
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
  }, [user, navigate]);

  // Fetch seller profile and code
  useEffect(() => {
    const fetchSellerProfile = async () => {
      if (!user) return;
      
      try {
        const sellerProfileRef = doc(db, 'seller-profiles', user.id);
        const sellerProfileDoc = await getDoc(sellerProfileRef);
        
        if (sellerProfileDoc.exists()) {
          const sellerData = sellerProfileDoc.data();
          if (sellerData.sellerCode) {
            setSellerCode(sellerData.sellerCode);
          }
          if (sellerData.assignedProject) {
            setAssignedProject(sellerData.assignedProject as any);
          } else {
            // Fallback: check seller-registrations and backfill profile
            const regRef = doc(db, 'seller-registrations', user.id);
            const regSnap = await getDoc(regRef);
            const regData = regSnap.exists() ? regSnap.data() : null;
            if (regData && (regData as any).assignedProject) {
              const ap = (regData as any).assignedProject;
              setAssignedProject(ap);
              await updateDoc(sellerProfileRef, {
                assignedProject: ap,
                updatedAt: new Date().toISOString(),
              });
            }
          }
        }
      } catch (error) {
        console.error('Error fetching seller profile:', error);
      }
    };

    fetchSellerProfile();
  }, [user]);

  // Fetch distinct categories from products for this seller
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (!user?.id) {
          setProductCategories([]);
          return;
        }
        setProductCategories('loading');
        const prodsRef = collection(db, 'products');
        const qy = query(prodsRef, where('sellerId', '==', user.id));
        const snap = await getDocs(qy);
        const setCats = new Set<string>();
        snap.forEach((d) => {
          const data: any = d.data();
          const cat = (data?.category || '').toString().trim();
          if (cat) setCats.add(cat);
        });
        const cats = Array.from(setCats).sort((a, b) => a.localeCompare(b));
        if (!cancelled) setProductCategories(cats);
      } catch (e) {
        console.warn('Failed to load seller product categories', e);
        if (!cancelled) setProductCategories([]);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  // Role-based guard: if logged in but not a seller, redirect to home
  useEffect(() => {
    if (user && (user as any).role !== 'seller') {
      navigate('/');
    }
  }, [user, navigate]);

  // Fetch allowed departments for this seller from Firestore (seller-profiles)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (!user?.id) { 
          setAllowedDepts([]); 
          return; 
        }
        
        setLoadingDepts(true);
        
        // First, try to get from seller-profiles
        const profRef = doc(db, 'seller-profiles', user.id);
        const snap = await getDoc(profRef);
        
        if (cancelled) return;
        
        let depts: string[] = [];
        
        if (snap.exists()) {
          const data = snap.data();
          depts = Array.isArray(data.departments) ? data.departments : [];
          console.log('Fetched departments from seller-profiles:', depts);
          
          // If no departments, check for individual category flags
          if (depts.length === 0) {
            // Check for individual category flags (backward compatibility)
            const categoryFlags = [
              'scrapStore', 'organicStore', 'charityCraft', 'scrapBooks',
              'momsMadeUnited', 'greenCupChallenge', 'charityBakes', 'homeDecor',
              'packedFood', 'homePlants', 'beautyHomemade', 'homemadeHouseholds',
              'birthdayGifts'
            ];
            
            depts = categoryFlags.filter(flag => data[flag] === true);
            console.log('Fetched departments from category flags:', depts);
          }
        } 
        
        // If still no departments, try the sellers collection as fallback
        if (depts.length === 0) {
          const sellerRef = doc(db, 'sellers', user.id);
          const sellerSnap = await getDoc(sellerRef);
          
          if (sellerSnap.exists()) {
            const sellerData = sellerSnap.data();
            depts = Array.isArray(sellerData.departments) ? sellerData.departments : [];
            console.log('Fetched departments from sellers collection:', depts);
          }
        }
        
        // Ensure all department IDs are in the correct format (kebab-case)
        depts = depts.map(dept => {
          // Convert camelCase to kebab-case if needed
          if (dept.match(/[A-Z]/)) {
            return dept.replace(/([A-Z])/g, '-$1').toLowerCase();
          }
          return dept;
        }).filter(Boolean);
        
        console.log('Final departments after formatting:', depts);
        
        if (!cancelled) {
          setAllowedDepts(depts);
        }
        
      } catch (error) {
        console.error('Error fetching seller departments:', error);
        if (!cancelled) {
          setAllowedDepts([]);
        }
      } finally {
        if (!cancelled) {
          setLoadingDepts(false);
        }
      }
    })();
    
    return () => {
      cancelled = true;
    };
  }, [user?.id]);

  // Add this function to fetch and update approved categories
  const fetchAndUpdateApprovedCategories = async () => {
    if (!user?.id) return;
    
    try {
      setLoadingDepts(true);
      
      // 1. Get all approved category requests for this seller
      const requestsRef = collection(db, 'category-requests');
      const q = query(
        requestsRef, 
        where('requestedBy', '==', user.id),
        where('status', '==', 'approved')
      );
      
      const querySnapshot = await getDocs(q);
      const approvedCategories: CategoryKey[] = [];
      
      // 2. Process approved requests
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        const categoryName = data.categoryName?.toLowerCase().replace(/\s+/g, '-');
        if (categoryName && CATEGORY_KEYS.includes(categoryName as CategoryKey)) {
          approvedCategories.push(categoryName as CategoryKey);
        }
      });
      
      // 3. Update seller profile with approved categories
      if (approvedCategories.length > 0) {
        const profRef = doc(db, 'seller-profiles', user.id);
        const profSnap = await getDoc(profRef);
        
        if (profSnap.exists()) {
          // Update existing profile
          const currentData = profSnap.data();
          const currentDepts = Array.isArray(currentData.departments) 
            ? currentData.departments 
            : [];
          
          // Merge and deduplicate categories
          const updatedDepts = [...new Set([...currentDepts, ...approvedCategories])];
          
          await updateDoc(profRef, {
            departments: updatedDepts,
            updatedAt: new Date().toISOString()
          });
          
          console.log('Updated seller profile with categories:', updatedDepts);
          setAllowedDepts(updatedDepts);
        } else {
          // Create new profile with approved categories
          await setDoc(profRef, {
            sellerId: user.id,
            departments: approvedCategories,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          });
          
          console.log('Created new seller profile with categories:', approvedCategories);
          setAllowedDepts(approvedCategories);
        }
      }
      
    } catch (error) {
      console.error('Error updating approved categories:', error);
    } finally {
      setLoadingDepts(false);
    }
  };
  
  // Call this function when component mounts and when user changes
  useEffect(() => {
    fetchAndUpdateApprovedCategories();
  }, [user?.id]);

  // Handle category from query string and optional hash for scrolling
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const catParam = params.get('category') as CategoryKey | null;
    // Do not open in-page panel for Scrap Books; it has a dedicated page
    if (
      catParam &&
      catParam !== 'scrap-books' &&
      (CATEGORY_KEYS as readonly string[]).includes(catParam) &&
      (allowedDepts.includes(catParam))
    ) {
      setSelected(catParam as CategoryKey);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.search, allowedDepts]);

  // If hash is #projects, just scroll to the Projects section
  useEffect(() => {
    if (location.hash === '#projects') {
      setTimeout(() => {
        const el = document.getElementById('projects');
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 50);
    }
  }, [location.hash]);

  // Scroll to upload panel when selected and hash requests it
  useEffect(() => {
    if (!selected) return;
    if (location.hash === '#seller-upload') {
      // wait a tick for panel to render
      setTimeout(() => {
        const el = uploadPanelRef.current || document.getElementById('seller-upload');
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 50);
    }
  }, [selected, location.hash]);
  
  const resetForm = (cat: CategoryKey) => {
    setForms((prev) => ({ ...prev, [cat]: { ...initialForm } }));
    const inputEl = imageInputRefs.current[cat];
    if (inputEl) inputEl.value = '';
  };

  const handleSubmit = async (e: React.FormEvent, cat: CategoryKey) => {
    e.preventDefault();
    if (!user) return;
    const form = forms[cat];
    if (!form.name.trim() || !form.description.trim() || !form.price) {
      setForms((prev) => ({ ...prev, [cat]: { ...prev[cat], message: 'Please fill all required fields.' } }));
      return;
    }
    const priceVal = Number(form.price);
    if (Number.isNaN(priceVal) || priceVal < 0) {
      setForms((prev) => ({ ...prev, [cat]: { ...prev[cat], message: 'Enter a valid price.' } }));
      return;
    }

    setForms((prev) => ({ ...prev, [cat]: { ...prev[cat], submitting: true, message: null } }));
    try {
      let imageUrl: string | undefined = undefined;
      if (form.imageFile) {
        const path = `sellers/${user.id}/${cat}/${Date.now()}_${form.imageFile.name}`;
        const storageRef = ref(storage, path);
        await uploadBytes(storageRef, form.imageFile);
        imageUrl = await getDownloadURL(storageRef);
      }

      // Get seller profile to include seller code
      const sellerProfileRef = doc(db, 'seller-profiles', user.id);
      const sellerProfileDoc = await getDoc(sellerProfileRef);
      const sellerCode = sellerProfileDoc.exists() ? sellerProfileDoc.data()?.sellerCode : '';

      await addDoc(collection(db, 'products'), {
        name: form.name.trim(),
        description: form.description.trim(),
        price: priceVal,
        category: cat,
        imageUrl: imageUrl || '',
        sellerId: user.id,
        sellerCode: sellerCode || '',
        published: false,
        status: 'pending_approval',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      } as ProductDoc);
      setForms((prev) => ({ ...prev, [cat]: { ...initialForm, message: 'Product created successfully.' } }));
      const inputEl = imageInputRefs.current[cat];
      if (inputEl) inputEl.value = '';
    } catch (err) {
      console.error(err);
      setForms((prev) => ({ ...prev, [cat]: { ...prev[cat], submitting: false, message: 'Failed to save product.' } }));
      return;
    }
    setForms((prev) => ({ ...prev, [cat]: { ...prev[cat], submitting: false } }));
  };

  const handleCategoryRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setCategoryRequest(prev => ({
        ...prev,
        message: 'You must be logged in to submit a category request',
        submitting: false
      }));
      return;
    }
    
    // Require at least one category
    if (!categoryRequest.categories || categoryRequest.categories.length === 0) {
      setCategoryRequest(prev => ({
        ...prev,
        submitting: false,
        message: 'Please select at least one category.'
      }));
      return;
    }

    // FSSAI is required only for food-related categories
    const requiresFSSAI = categoryRequest.categories.some((c) => ['charity-bakes', 'packed-food'].includes(c.toLowerCase()));
    if (requiresFSSAI) {
      const fssaiOk = categoryRequest.fssaiNumber ? /^\d{14}$/.test(categoryRequest.fssaiNumber.trim()) : false;
      if (!fssaiOk) {
        setCategoryRequest(prev => ({
          ...prev,
          submitting: false,
          message: 'Please enter a valid 14-digit FSSAI number for food categories.'
        }));
        return;
      }
      if (!categoryRequest.fssaiFile) {
        setCategoryRequest(prev => ({
          ...prev,
          submitting: false,
          message: 'Please upload your FSSAI license image or PDF for food categories.'
        }));
        return;
      }
    }

    setCategoryRequest(prev => ({ ...prev, submitting: true, message: '' }));
    
    try {
      // Upload FSSAI license image if provided
      let fssaiLicenseUrl: string | undefined = undefined;
      if (categoryRequest.fssaiFile) {
        const path = `category-requests/${user.uid}/fssai/${Date.now()}_${categoryRequest.fssaiFile.name}`;
        const storageRef = ref(storage, path);
        await uploadBytes(storageRef, categoryRequest.fssaiFile);
        fssaiLicenseUrl = await getDownloadURL(storageRef);
      }

      const categoryData = {
        // Backward compatibility: keep the first as categoryName, but store all in categories
        categoryName: categoryRequest.categories[0] || '',
        categories: categoryRequest.categories,
        description: categoryRequest.description.trim(),
        requestedBy: user.uid,
        status: 'pending',
        createdAt: serverTimestamp(),
        // Persist FSSAI fields (may be empty if not required)
        fssaiNumber: categoryRequest.fssaiNumber?.trim() || '',
        fssaiLicenseUrl: fssaiLicenseUrl || ''
      };
      
      console.log('Submitting category request:', categoryData);
      
      await addDoc(collection(db, 'category-requests'), categoryData);
      
      setCategoryRequest({
        name: '',
        categories: [],
        description: '',
        fssaiNumber: '',
        fssaiFile: null,
        submitting: false,
        message: 'Category request submitted successfully! Our team will review it soon.'
      });
      
      // Auto-close the dialog after 2 seconds
      setTimeout(() => {
        setIsRequestDialogOpen(false);
        setCategoryRequest(prev => ({ ...prev, message: '' }));
      }, 2000);
      
    } catch (error) {
      console.error('Error submitting category request:', error);
      setCategoryRequest(prev => ({
        ...prev,
        submitting: false,
        message: `Failed to submit request: ${error instanceof Error ? error.message : 'Unknown error'}`
      }));
    }
  };

  if (!user) return null;

  return (
    <div className="relative min-h-screen z-10">
      {/* Global background animation (gold dots) */}
      <style>{`
        @keyframes ewFloat {
          0% { transform: translateY(0) scale(1); opacity: 0.35; }
          50% { transform: translateY(-14px) scale(1.08); opacity: 0.6; }
          100% { transform: translateY(0) scale(1); opacity: 0.35; }
        }
      `}</style>
      <div className="pointer-events-none absolute inset-0 z-0">
        {/* soft radial at top for warmth */}
        <div className="absolute inset-0" style={{
          background: 'radial-gradient(60% 40% at 50% 0%, rgba(245,197,66,0.14) 0%, rgba(245,197,66,0) 60%)'
        }} />
        {/* floating gold dots */}
        <div className="absolute w-2.5 h-2.5 bg-gold/50 rounded-full" style={{ left: '12%', top: '26%', animation: 'ewFloat 7.8s ease-in-out -1s infinite' }} />
        <div className="absolute w-2.5 h-2.5 bg-gold/50 rounded-full" style={{ left: '22%', top: '38%', animation: 'ewFloat 8.6s ease-in-out -2s infinite' }} />
        <div className="absolute w-2.5 h-2.5 bg-gold/50 rounded-full" style={{ left: '34%', top: '50%', animation: 'ewFloat 9.2s ease-in-out -1.6s infinite' }} />
        <div className="absolute w-2.5 h-2.5 bg-gold/50 rounded-full" style={{ left: '48%', top: '62%', animation: 'ewFloat 7.2s ease-in-out -0.8s infinite' }} />
        <div className="absolute w-2.5 h-2.5 bg-gold/50 rounded-full" style={{ left: '60%', top: '28%', animation: 'ewFloat 10s ease-in-out -2.4s infinite' }} />
        <div className="absolute w-2.5 h-2.5 bg-gold/50 rounded-full" style={{ left: '72%', top: '44%', animation: 'ewFloat 8.2s ease-in-out -1.2s infinite' }} />
        <div className="absolute w-2.5 h-2.5 bg-gold/50 rounded-full" style={{ left: '84%', top: '58%', animation: 'ewFloat 9.6s ease-in-out -0.4s infinite' }} />
        <div className="absolute w-2.5 h-2.5 bg-gold/50 rounded-full" style={{ left: '92%', top: '72%', animation: 'ewFloat 11s ease-in-out -3s infinite' }} />
        {/* a few soft blurred orbs for depth */}
        <div className="absolute w-20 h-20 bg-gold/10 rounded-full blur-2xl" style={{ left: '5%', top: '70%' }} />
        <div className="absolute w-24 h-24 bg-gold/10 rounded-full blur-2xl" style={{ right: '6%', top: '20%' }} />
      </div>
      {/* Hero Section */}
      <section className="py-4 md:py-6">
        <div className="mx-auto px-0 max-w-[100vw]">
          <div className="relative overflow-hidden rounded-xl shadow-[0_12px_48px_rgba(0,0,0,0.12)] h-[30vh] min-h-[220px] max-h-[420px] bg-gradient-to-b from-black/10 via-transparent to-transparent">
            {/* Back Button */}
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => navigate('/')}
              className="absolute top-4 left-4 z-20 rounded-full w-12 h-12 bg-white/10 backdrop-blur-sm hover:bg-white/20 border border-gold/30 hover:border-gold/50 transition-all duration-200"
              title="Back to Home"
            >
              <ArrowLeft className="h-6 w-6 text-gold" />
            </Button>

            {/* Simple clean background (no image) */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-transparent" />

            {/* Foreground content */}
            <div className="relative z-10 h-full flex items-center justify-center">
              <div className="text-center px-6">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight drop-shadow-[0_2px_8px_rgba(0,0,0,0.6)]">
                  AI for Charity. Products with Purpose.
                </h1>
              </div>
            </div>
          </div>
        </div>
      </section>

      {(user as any).role !== 'seller' && (
        <SellerRequestForm 
          onSubmit={handleSubmitSellerRequest} 
          loading={isSubmittingRequest} 
        />
      )}

      {/* Categories Section */}
      {(user as any).role === 'seller' && (
        <section id="seller-categories" className="py-12 scroll-mt-24">
          <div className="container mx-auto px-4 py-8">
            <div className="flex justify-between items-center mb-8">
              <h1 className="text-3xl font-bold">Seller Dashboard</h1>
              <div className="flex flex-col md:flex-row gap-2 md:items-center">
                {assignedProject && (
                  <div className="rounded-full bg-gold text-black px-4 py-2 shadow-sm border border-gold/70">
                    <span className="text-xs uppercase tracking-wide opacity-80 mr-1">Assigned Project:</span>
                    <span className="font-semibold">{assignedProject.projectTitle}</span>
                  </div>
                )}
                {sellerCode && (
                  <div className="rounded-full bg-gold text-black px-4 py-2 shadow-sm border border-gold/70">
                    <span className="text-xs uppercase tracking-wide opacity-80 mr-1">Your Seller Code:</span>
                    <span className="font-mono tracking-wider font-semibold">{sellerCode}</span>
                  </div>
                )}
              </div>
            </div>
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Your Product Categories</h3>
              <div className="flex flex-wrap gap-2">
                {productCategories === 'loading' ? (
                  <span className="text-sm text-muted-foreground">Loading…</span>
                ) : productCategories.length === 0 ? (
                  <span className="text-sm text-muted-foreground">No products yet</span>
                ) : (
                  productCategories.map((c) => (
                    <Badge key={c} variant="secondary">{c}</Badge>
                  ))
                )}
              </div>
            </div>
            <div className="mb-6 md:mb-8 flex justify-between items-center">
              <div>
                <h2 className="text-2xl md:text-3xl font-bold">Choose a Category</h2>
                <p className="text-muted-foreground">Click a category card to open the upload panel below.</p>
              </div>
              <Button 
                variant="outline" 
                onClick={() => setIsRequestDialogOpen(true)}
                className="gap-2"
              >
                <Plus className="h-4 w-4" />
                Request New Category
              </Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {(CATEGORY_KEYS
                .filter((c) => allowedDepts.includes(c)) as CategoryKey[]).map((cat, index) => (
                <motion.div
                  key={cat}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.45, delay: index * 0.04 }}
                >
                  <div
                    role="button"
                    tabIndex={0}
                    onClick={() => (cat === 'scrap-books' ? navigate('/seller/upload/scrap-books') : setSelected(cat))}
                    onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); (cat === 'scrap-books' ? navigate('/seller/upload/scrap-books') : setSelected(cat)); } }}
                    className="block w-full text-left group"
                  >
                    <Card className="overflow-hidden relative rounded-xl border border-border/60 bg-card h-56 md:h-60">
                      <div className="absolute inset-0">
                        <img
                          src={CATEGORY_META[cat].image}
                          alt={CATEGORY_META[cat].name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                      </div>

                      <CardContent className="relative z-10 p-5 h-full flex flex-col justify-end">
                        <div className="mb-4">
                          <div className={`w-8 h-8 rounded-lg bg-gradient-to-r ${CATEGORY_META[cat].color} flex items-center justify-center mb-3`}>
                            {/* Decorative square, keep consistent with Home */}
                          </div>
                          <h3 className="text-xl md:text-2xl font-semibold mb-1.5">{CATEGORY_META[cat].name}</h3>
                          <p className="text-sm text-gray-300/90 line-clamp-2">{CATEGORY_META[cat].description}</p>
                        </div>
                        <Link to={`/seller/upload/${cat}`} onClick={(e) => e.stopPropagation()} className="inline-flex items-center text-sm font-medium btn-hover border bg-transparent h-9 w-fit rounded-full border-gold/50 text-gold hover:bg-gold hover:text-black transition-colors px-3 py-1.5">
                          Upload to {CATEGORY_META[cat].name} <ArrowRight className="ml-2 h-3.5 w-3.5" />
                        </Link>
                      </CardContent>
                    </Card>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Category Request Dialog */}
      {isRequestDialogOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-background rounded-lg shadow-xl max-w-md w-full p-6 max-h-[85vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold">Request New Category</h3>
              <button 
                onClick={() => {
                  setIsRequestDialogOpen(false);
                  setCategoryRequest({ name: '', categories: [], description: '', fssaiNumber: '', fssaiFile: null, submitting: false, message: '' });
                }}
                className="text-muted-foreground hover:text-foreground"
              >
                ✕
              </button>
            </div>
            
            {categoryRequest.message && (
              <div className={`mb-4 p-3 rounded text-sm ${
                categoryRequest.message.includes('successfully') 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-red-100 text-red-800'
              }`}>
                {categoryRequest.message}
              </div>
            )}
            
            <form onSubmit={handleCategoryRequest} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="category-name">Add Category</Label>
                <div className="flex gap-2">
                  <Input
                    id="category-name"
                    list="category-suggestions"
                    value={categoryRequest.name}
                    onChange={(e) => setCategoryRequest(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="Type a category and click Add"
                    disabled={categoryRequest.submitting}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      const raw = categoryRequest.name.trim();
                      if (!raw) return;
                      const norm = raw.toLowerCase().replace(/\s+/g, '-');
                      if (!categoryRequest.categories.includes(norm)) {
                        setCategoryRequest(prev => ({ ...prev, categories: [...prev.categories, norm], name: '' }));
                      } else {
                        setCategoryRequest(prev => ({ ...prev, name: '' }));
                      }
                    }}
                    disabled={categoryRequest.submitting}
                  >Add</Button>
                </div>
                <datalist id="category-suggestions" className="bg-black text-white">
                  {CATEGORY_SUGGESTIONS
                    .filter((category) => !allowedDepts.includes(category as any))
                    .filter((category) => !categoryRequest.categories.includes(category))
                    .map((category) => (
                    <option key={category} value={category}>
                      {category.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                    </option>
                  ))}
                </datalist>
              </div>

              {/* Quick-select suggestions */}
              <div className="space-y-2">
                <Label>Suggestions</Label>
                <div className="flex flex-wrap gap-2">
                  {CATEGORY_SUGGESTIONS
                    .filter((c) => !allowedDepts.includes(c as any))
                    .map((c) => (
                      <Button
                        key={c}
                        type="button"
                        size="sm"
                        variant={categoryRequest.categories.includes(c) ? 'default' : 'outline'}
                        onClick={() => {
                          setCategoryRequest(prev => ({
                            ...prev,
                            categories: prev.categories.includes(c)
                              ? prev.categories.filter(x => x !== c)
                              : [...prev.categories, c]
                          }));
                        }}
                      >
                        {c.split('-').map(w => w[0].toUpperCase() + w.slice(1)).join(' ')}
                      </Button>
                    ))}
                </div>
              </div>

              {/* Selected categories */}
              {categoryRequest.categories.length > 0 && (
                <div className="space-y-2">
                  <Label>Selected</Label>
                  <div className="flex flex-wrap gap-2">
                    {categoryRequest.categories.map((c) => (
                      <span key={c} className="inline-flex items-center gap-2 px-2 py-1 rounded-full border text-sm">
                        {c.split('-').map(w => w[0].toUpperCase() + w.slice(1)).join(' ')}
                        <button
                          type="button"
                          className="text-xs text-muted-foreground hover:text-foreground"
                          onClick={() => setCategoryRequest(prev => ({ ...prev, categories: prev.categories.filter(x => x !== c) }))}
                          aria-label={`Remove ${c}`}
                        >✕</button>
                      </span>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="category-description">Description</Label>
                <textarea
                  id="category-description"
                  value={categoryRequest.description}
                  onChange={(e) => setCategoryRequest(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Briefly describe what kind of products would be in this category"
                  className="flex h-20 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  required
                  disabled={categoryRequest.submitting}
                />
              </div>

              {/* FSSAI fields (only if food categories selected) */}
              {categoryRequest.categories.some((c) => ['charity-bakes', 'packed-food'].includes(c.toLowerCase())) && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fssai-number">FSSAI License Number</Label>
                    <Input
                      id="fssai-number"
                      placeholder="14-digit FSSAI number"
                      value={categoryRequest.fssaiNumber}
                      onChange={(e) => setCategoryRequest(prev => ({ ...prev, fssaiNumber: e.target.value }))}
                      disabled={categoryRequest.submitting}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="fssai-file">FSSAI License Image/PDF</Label>
                    <Input
                      id="fssai-file"
                      type="file"
                      accept="image/*,application/pdf"
                      onChange={(e) => setCategoryRequest(prev => ({ ...prev, fssaiFile: e.target.files?.[0] || null }))}
                      disabled={categoryRequest.submitting}
                    />
                    {/* Preview */}
                    {categoryRequest.fssaiFile && (
                      <div className="mt-2 border rounded p-2 text-sm">
                        {categoryRequest.fssaiFile.type.includes('pdf') ? (
                          <div className="flex items-center justify-between">
                            <span className="truncate mr-2">{categoryRequest.fssaiFile.name}</span>
                            <a
                              href={URL.createObjectURL(categoryRequest.fssaiFile)}
                              target="_blank"
                              rel="noreferrer"
                              className="text-blue-500 underline"
                              onClick={(e) => e.stopPropagation()}
                            >
                              Preview PDF
                            </a>
                          </div>
                        ) : (
                          <img
                            src={URL.createObjectURL(categoryRequest.fssaiFile)}
                            alt="FSSAI License Preview"
                            className="max-h-40 rounded border"
                          />
                        )}
                      </div>
                    )}
                  </div>
                </div>
              )}
              
              <div className="flex justify-end gap-2 pt-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setIsRequestDialogOpen(false);
                    setCategoryRequest({ name: '', categories: [], description: '', fssaiNumber: '', fssaiFile: null, submitting: false, message: '' });
                  }}
                  disabled={categoryRequest.submitting}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={categoryRequest.submitting}
                  className="bg-gold text-black hover:bg-gold/90"
                >
                  {categoryRequest.submitting ? (
                    <span className="flex items-center">
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Submitting...
                    </span>
                  ) : 'Submit Request'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
