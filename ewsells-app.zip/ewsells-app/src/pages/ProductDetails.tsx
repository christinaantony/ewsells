import { useEffect, useMemo, useRef, useState } from 'react';
import { useParams, useNavigate, useSearchParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { doc, getDoc, collection, getDocs, orderBy, query, addDoc, serverTimestamp, where, updateDoc } from 'firebase/firestore';
import { db, storage } from '@/lib/firebase';
import { ref as storageRef, uploadBytes, getDownloadURL } from 'firebase/storage';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatCurrency } from '@/lib/utils';
import { useCart } from '@/contexts/CartContext';
import { useStore } from '@/store/useStore';
import { Star, X, Heart } from 'lucide-react';
import { useAuthGate } from '@/hooks/useAuthGate';

interface ProductDoc {
  id: string;
  name: string;
  description?: string;
  price: number;
  sellerPrice?: number;
  finalPrice?: number;
  category?: string;
  imageUrl?: string;
  images?: string[];
  imageUrls?: string[];
  rating?: number; // optional
  reviewsCount?: number; // optional
  stock?: number;
  outOfStock?: boolean;
  sellerId?: string;
  sellerCode?: string;
  customizable?: boolean;
}

interface ReviewDoc {
  id: string;
  rating: number;
  comment?: string;
  userDisplayName?: string;
  createdAt?: any;
  photos?: string[];
}

export default function ProductDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { user, toggleWishlist, isWishlisted } = useStore();
  const { runOrLogin } = useAuthGate();
  const [params] = useSearchParams();
  const [loading, setLoading] = useState(true);
  const [product, setProduct] = useState<ProductDoc | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [reviews, setReviews] = useState<ReviewDoc[]>([]);
  const [avgRating, setAvgRating] = useState<number | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewRating, setReviewRating] = useState<number>(5);
  const [reviewComment, setReviewComment] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);
  const [reviewFiles, setReviewFiles] = useState<File[]>([]);
  const [filePreviews, setFilePreviews] = useState<string[]>([]);
  const reviewFormRef = useRef<HTMLDivElement | null>(null);
  const reviewsSectionRef = useRef<HTMLDivElement | null>(null);
  const reviewHeaderRef = useRef<HTMLDivElement | null>(null);
  const [canWriteReview, setCanWriteReview] = useState<boolean>(false);
  const [sellerCode, setSellerCode] = useState<string>('');
  const [canCustomize, setCanCustomize] = useState<boolean>(false);
  const [customizeOrderId, setCustomizeOrderId] = useState<string>('');
  // Ratings popover state
  const [showRatings, setShowRatings] = useState(false);
  const ratingsRef = useRef<HTMLDivElement | null>(null);
  // Lightbox for review images
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<string>('');
  const [lightboxReview, setLightboxReview] = useState<ReviewDoc | null>(null);
  const ratingData = useMemo(() => {
    // Compute from loaded reviews if available, else use product fields / fallbacks
    const total = (reviews?.length || 0) > 0 ? reviews.length : Number(product?.reviewsCount ?? 2717);
    const avg = typeof avgRating === 'number' ? avgRating : Number(product?.rating ?? 3.8);
    const breakdownInit: Record<1 | 2 | 3 | 4 | 5, number> = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    if (reviews && reviews.length) {
      for (const r of reviews) {
        const s = Math.max(1, Math.min(5, Math.round(Number(r.rating || 0) as number)));
        // @ts-expect-error narrow
        breakdownInit[s] = (breakdownInit[s as 1 | 2 | 3 | 4 | 5] || 0) + 1;
      }
      (Object.keys(breakdownInit) as unknown as Array<1|2|3|4|5>).forEach((k) => {
        breakdownInit[k] = total ? Math.round((breakdownInit[k] / total) * 100) : 0;
      });
    } else {
      Object.assign(breakdownInit, { 5: 63, 4: 23, 3: 6, 2: 2, 1: 6 });
    }
    return { total, avg, breakdown: breakdownInit };
  }, [reviews, product?.reviewsCount, product?.rating, avgRating]);

  useEffect(() => {
    if (!showRatings) return;
    const onDown = (e: MouseEvent) => {
      if (ratingsRef.current && !ratingsRef.current.contains(e.target as Node)) setShowRatings(false);
    };
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setShowRatings(false); };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('mousedown', onDown); document.removeEventListener('keydown', onKey); };
  }, [showRatings]);

  // Close lightbox on Escape
  useEffect(() => {
    if (!lightboxOpen) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setLightboxOpen(false); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [lightboxOpen]);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      if (!id) {
        setError('Invalid product link');
        setLoading(false);
        return;
      }
      setLoading(true);
      try {
        const ref = doc(db, 'products', id);
        const snap = await getDoc(ref);
        if (!snap.exists()) {
          if (!cancelled) {
            setError('Product not found');
            setLoading(false);
          }
          return;
        }
        const data = snap.data() as any;
        const images: string[] = Array.isArray(data.images)
          ? data.images
          : Array.isArray(data.imageUrls)
          ? data.imageUrls
          : data.imageUrl
          ? [data.imageUrl]
          : [];

        const prod: ProductDoc = {
          id: snap.id,
          name: data.name || 'Unnamed Product',
          description: data.description || '',
          imageUrl: data.imageUrl,
          images,
          category: data.category,
          price: typeof data.price === 'number' ? data.price : Number(data.price || 0),
          sellerPrice: typeof data.sellerPrice === 'number' ? data.sellerPrice : (data.sellerPrice != null ? Number(data.sellerPrice) : undefined),
          finalPrice: typeof data.finalPrice === 'number' ? data.finalPrice : (data.finalPrice != null ? Number(data.finalPrice) : undefined),
          rating: typeof data.rating === 'number' ? data.rating : undefined,
          reviewsCount: typeof data.reviewsCount === 'number' ? data.reviewsCount : undefined,
          stock: typeof data.stock === 'number' ? data.stock : (data.stock != null ? Number(data.stock) : undefined),
          outOfStock: typeof data.outOfStock === 'boolean' ? data.outOfStock : (typeof data.stock === 'number' ? data.stock <= 0 : undefined),
          sellerId: data.sellerId,
          sellerCode: data.sellerCode,
          customizable: !!data.customizable
        };

       
        // If seller code is not in product data, try to fetch it from seller profile
        if (prod.sellerId && !prod.sellerCode) {
          try {
            const sellerProfileRef = doc(db, 'seller-profiles', prod.sellerId);
            const sellerProfileDoc = await getDoc(sellerProfileRef);
            if (sellerProfileDoc.exists() && sellerProfileDoc.data()?.sellerCode) {
              prod.sellerCode = sellerProfileDoc.data()?.sellerCode;
              // Update the product in state to include the seller code
              if (!cancelled) {
                setProduct({...prod});
              }
              // Also update the product document in Firestore for future use
              const productRef = doc(db, 'products', prod.id);
              await updateDoc(productRef, { sellerCode: prod.sellerCode });
              return;
            }
          } catch (err) {
            console.error('Error fetching seller profile:', err);
          }
        }
        
        if (!cancelled) {
          setProduct(prod);
        }
      } catch (e: any) {
        if (!cancelled) {
          setError(e?.message || 'Failed to load product');
        }
      }
      // Load reviews separately
      try {
        const reviewsRef = collection(db, 'products', id, 'reviews');
        const qy = query(reviewsRef, orderBy('createdAt', 'desc'));
        const rs = await getDocs(qy);
        const list: ReviewDoc[] = rs.docs.map(d => {
          const r = d.data() as any;
          return {
            id: d.id,
            rating: Number(r.rating || 0),
            comment: r.comment || '',
            userDisplayName: r.userDisplayName || r.userName || 'Anonymous',
            createdAt: r.createdAt,
            photos: Array.isArray(r.photos) ? r.photos : [],
          };
        });
        if (!cancelled) {
          setReviews(list);
          if (list.length > 0) {
            const avg = list.reduce((s, r) => s + (r.rating || 0), 0) / list.length;
            setAvgRating(Math.round(avg * 10) / 10);
          } else {
            setAvgRating(null);
          }
        }
      } catch {
        if (!cancelled) {
          setReviews([]);
          setAvgRating(null);
        }
      }
      if (!cancelled) setLoading(false);
    }
    load();
    return () => { cancelled = true; };
  }, [id]);

  // Check if the current user can write a review (must have a delivered order containing this product)
  useEffect(() => {
    let cancelled = false;
    async function checkEligibility() {
      try {
        if (!user || !id) { if (!cancelled) setCanWriteReview(false); return; }
        const uid = (user as any)?.uid || (user as any)?.id;
        if (!uid) { if (!cancelled) setCanWriteReview(false); return; }

        // Fetch delivered orders by this user; handle both 'userId' and 'uid' fields in orders
        const ordersRef = collection(db, 'orders');
        const q1 = query(ordersRef, where('userId', '==', uid), where('status', '==', 'delivered'));
        const q2 = query(ordersRef, where('uid', '==', uid), where('status', '==', 'delivered'));
        const [rs1, rs2] = await Promise.allSettled([getDocs(q1), getDocs(q2)]);
        const docs = [rs1, rs2]
          .filter((r): r is PromiseFulfilledResult<import('firebase/firestore').QuerySnapshot> => r.status === 'fulfilled')
          .flatMap(r => r.value.docs);

        let eligible = false;
        for (const d of docs) {
          const data: any = d.data();
          const items: any[] = Array.isArray(data?.items) ? data.items : [];
          if (items.some(it => (it?.productId || it?.id) === id)) { eligible = true; break; }
        }
        if (!cancelled) setCanWriteReview(eligible);
      } catch {
        if (!cancelled) setCanWriteReview(false);
      }
    }
    checkEligibility();
    return () => { cancelled = true; };
  }, [user, id]);

  // Determine if user can request customization chat (bought & product customizable)
  useEffect(() => {
    let cancelled = false;
    async function checkCustomizeEligibility() {
      try {
        if (!user || !id) { if (!cancelled) { setCanCustomize(false); setCustomizeOrderId(''); } return; }
        if (!product?.customizable) { if (!cancelled) { setCanCustomize(false); setCustomizeOrderId(''); } return; }
        const uid = (user as any)?.uid || (user as any)?.id;
        if (!uid) { if (!cancelled) { setCanCustomize(false); setCustomizeOrderId(''); } return; }

        const ordersRef = collection(db, 'orders');
        const q1 = query(ordersRef, where('userId', '==', uid));
        const q2 = query(ordersRef, where('uid', '==', uid));
        const [rs1, rs2] = await Promise.allSettled([getDocs(q1), getDocs(q2)]);
        const docs = [rs1, rs2]
          .filter((r): r is PromiseFulfilledResult<import('firebase/firestore').QuerySnapshot> => r.status === 'fulfilled')
          .flatMap(r => r.value.docs);

        let eligible = false;
        let foundOrderId = '';
        for (const d of docs) {
          const data: any = d.data();
          const items: any[] = Array.isArray(data?.items) ? data.items : [];
          const containsProduct = items.some(it => (it?.productId || it?.id) === id);
          if (!containsProduct) continue;
          const status = String(data?.status || '').toLowerCase();
          const paid = String(data?.paymentStatus || '').toLowerCase() === 'paid';
          const purchased = paid || ['placed','processing','shipped','delivered'].includes(status);
          if (purchased) { eligible = true; foundOrderId = d.id; break; }
        }
        if (!cancelled) { setCanCustomize(eligible); setCustomizeOrderId(foundOrderId); }
      } catch {
        if (!cancelled) { setCanCustomize(false); setCustomizeOrderId(''); }
      }
    }
    checkCustomizeEligibility();
    return () => { cancelled = true; };
  }, [user, id, product?.customizable]);

  // Revoke object URLs created for local previews to avoid memory leaks
  useEffect(() => {
    return () => {
      try {
        filePreviews.forEach((url) => URL.revokeObjectURL(url));
      } catch {}
    };
  }, [filePreviews]);

  // Auto-open the review form if ?review=1 is present and user is eligible
  useEffect(() => {
    const shouldOpen = params.get('review') === '1';
    if (shouldOpen && canWriteReview) {
      setShowReviewForm(true);
      setTimeout(() => {
        reviewFormRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 0);
    }
  }, [params, canWriteReview]);

  // If the URL already has #reviews, scroll there after load
  useEffect(() => {
    if (typeof window !== 'undefined' && window.location.hash === '#reviews') {
      setTimeout(() => {
        reviewsSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 0);
    }
  }, []);

  const priceValue = (p: ProductDoc | null) => Number(p?.finalPrice ?? p?.sellerPrice ?? p?.price ?? 0);

  // Fallback dummy reviews (shown when no Firestore reviews exist)
  const dummyReviews: ReviewDoc[] = [
    {
      id: 'd1',
      rating: 5,
      userDisplayName: 'Verified Buyer',
      comment: 'Excellent quality and fresh taste. Packaging was neat and delivery was on time. Highly recommended!',
      createdAt: null,
    },
    {
      id: 'd2',
      rating: 4,
      userDisplayName: 'Ananya',
      comment: 'Good product for the price. Would love a bigger pack size option.',
      createdAt: null,
    },
    {
      id: 'd3',
      rating: 5,
      userDisplayName: 'Rahul (Verified Purchase)',
      comment: 'Crispy and tasty. Exactly like shown in the pictures. Will buy again!',
      createdAt: null,
    },
  ];

  // Smooth scroll to the reviews header with precise offset handling for sticky headers
  const scrollToReviewsHeader = () => {
    const target = reviewHeaderRef.current || reviewsSectionRef.current;
    if (!target) return;
    // Defer to allow popover close/layout settle, then measure and scroll
    setTimeout(() => {
      // Try to find a sticky header at the top
      const sticky = (document.querySelector('header.sticky, .sticky.top-0, [data-sticky-header]') as HTMLElement | null);
      const offset = (sticky?.offsetHeight ?? 0) + 12; // small gap
      const y = target.getBoundingClientRect().top + window.scrollY - offset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    }, 0);
  };

  if (loading) {
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="min-h-screen pt-20 pb-12">
        <div className="container mx-auto px-4">
          <p className="text-muted-foreground">Loading product…</p>
        </div>
      </motion.div>
    );
  }

  if (error || !product) {
    return (
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="min-h-screen pt-20 pb-12">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <p className="text-destructive mb-4">{error || 'Product not found'}</p>
            <Button onClick={() => navigate(-1)}>Go Back</Button>
          </div>
        </div>
      </motion.div>
    );
  }

  const images = product.images && product.images.length ? product.images : (product.imageUrl ? [product.imageUrl] : []);
  const price = priceValue(product);
  const isOut = product.outOfStock === true || (typeof product.stock === 'number' && product.stock <= 0);
  const prevImage = () => {
    setCurrentIndex((currentIndex + images.length - 1) % images.length);
  };

  const nextImage = () => {
    setCurrentIndex((currentIndex + 1) % images.length);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        <div className="mb-6">
          <button className="text-sm text-muted-foreground hover:text-foreground" onClick={() => navigate(-1)}>
            ← Back
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="overflow-hidden">
            <div className="relative overflow-hidden bg-gray-100 w-full h-[420px]">
              {images.length > 0 ? (
                <img
                  src={images[currentIndex]}
                  alt={product.name}
                  className="object-cover w-full h-full"
                  loading="lazy"
                />
              ) : (
                <div className="flex items-center justify-center w-full h-full text-muted-foreground">No image</div>
              )}
              {/* Wishlist heart overlay */}
              <button
                type="button"
                className="absolute top-3 right-3 z-20 inline-flex items-center justify-center h-10 w-10 rounded-full bg-black/40 text-white hover:bg-black/60 border border-white/20 backdrop-blur-sm"
                aria-label={isWishlisted(product.id) ? 'Remove from wishlist' : 'Add to wishlist'}
                onClick={(e) => {
                  e.stopPropagation();
                  runOrLogin(() => toggleWishlist(product.id));
                }}
              >
                <Heart className={`h-5 w-5 ${isWishlisted(product.id) ? 'fill-red-500 text-red-500' : ''}`} />
              </button>
              {/* Prev / Next buttons */}
              <button
                aria-label="Previous image"
                className="absolute left-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/40 text-white hover:bg-black/60 z-20"
                onClick={prevImage}
              >
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5"><path d="m15 18-6-6 6-6"/></svg>
              </button>
              <button
                aria-label="Next image"
                className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/40 text-white hover:bg-black/60 z-20"
                onClick={nextImage}
              >
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5"><path d="m9 18 6-6-6-6"/></svg>
              </button>
              {/* Dots */}
              <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
                {images.map((_, i) => (
                  <span
                    key={i}
                    className={`h-1.5 w-1.5 rounded-full ${i === currentIndex ? 'bg-white' : 'bg-white/50'}`}
                  />
                ))}
              </div>
            </div>
            {/* Thumbnail strip */}
            {images.length > 1 && (
              <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
                {images.map((src, i) => (
                  <button
                    key={`thumb-${i}`}
                    type="button"
                    aria-label={`Show image ${i + 1}`}
                    onClick={() => setCurrentIndex(i)}
                    className={`relative shrink-0 h-16 w-16 rounded-md overflow-hidden border transition ring-offset-2 focus:outline-none focus:ring-2 focus:ring-ring ${i === currentIndex ? 'border-gold ring-2 ring-gold/60' : 'border-border hover:border-foreground/30'}`}
                  >
                    <img src={src} alt={`thumb ${i + 1}`} className="h-full w-full object-cover" loading="lazy" />
                  </button>
                ))}
              </div>
            )}
          </Card>

          <div>
            <div className="flex items-center gap-2.5 mb-3">
              {product.category && (
                <Badge className="inline-flex items-center h-8 px-3 rounded-full text-sm bg-gold text-black shadow-sm">
                  {product.category}
                </Badge>
              )}
              {product.customizable && (
                <Badge className="inline-flex items-center h-8 px-3 rounded-full text-sm bg-emerald-500 text-white shadow-sm">
                  Customizable
                </Badge>
              )}
              {isOut && (
                <Badge className="inline-flex items-center h-8 px-3 rounded-full text-sm bg-red-600 text-white shadow-sm">
                  Out of stock
                </Badge>
              )}
              {(typeof product.rating === 'number' || typeof avgRating === 'number') && (
                <div className="relative">
                  <button
                    type="button"
                    className="inline-flex items-center h-8 px-3 rounded-full text-sm bg-gold text-black border border-amber-300 shadow-sm hover:shadow transition"
                    onClick={() => setShowRatings((v) => !v)}
                    aria-label="Open ratings breakdown"
                  >
                    <Star className="h-4 w-4 mr-1 text-black" />
                    <span className="text-sm font-semibold leading-none">{Number(ratingData.avg).toFixed(1)}</span>
                  </button>

                  {showRatings && (
                    <div
                      ref={ratingsRef}
                      className="absolute left-0 mt-2 w-[400px] rounded-2xl border border-border/60 shadow-[0_12px_28px_rgba(0,0,0,0.25)] bg-card text-card-foreground z-[1000]"
                      role="dialog"
                      aria-label="Ratings breakdown"
                    >
                      <div className="absolute -top-1.5 left-10 w-3.5 h-3.5 bg-card rotate-45 border-l border-t border-border/60" />
                      <div className="p-5">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center text-[#FF9900]">
                            {Array.from({ length: 4 }).map((_, i) => (
                              <Star key={i} className="h-4 w-4 mr-0.5 text-[#FF9900] fill-[#FF9900]" />
                            ))}
                            <Star className="h-4 w-4 mr-2 text-[#FF9900]" />
                            <span className="text-xl font-bold">{Number(ratingData.avg).toFixed(1)} out of 5</span>
                          </div>
                          <button
                            className="h-9 w-9 inline-flex items-center justify-center rounded-full border border-border/60 text-foreground hover:bg-muted/40"
                            onClick={() => setShowRatings(false)}
                            aria-label="Close ratings"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                        <p className="text-sm text-muted-foreground mt-2">{(ratingData.total || 0).toLocaleString()} global ratings</p>
                        <div className="mt-4 space-y-2.5">
                          {([5,4,3,2,1] as const).map((star) => (
                            <div key={star} className="flex items-center gap-3">
                              <span className="w-12 text-[15px]">{star} star</span>
                              <div className="flex-1 h-6 rounded-full border border-border/50 bg-muted/40 overflow-hidden">
                                <div className="h-full bg-[#FF9900] rounded-l-full shadow-[inset_0_0_0_1px_rgba(0,0,0,0.06)]" style={{ width: `${Math.round(ratingData.breakdown[star] ?? 0)}%` }} />
                              </div>
                              <span className="w-14 text-[15px] text-right font-medium">{Math.round(ratingData.breakdown[star] ?? 0)}%</span>
                            </div>
                          ))}
                        </div>
                        <div className="mt-5 pt-3 border-t">
                          <button
                            className="text-sm text-sky-700 hover:underline"
                            onClick={() => {
                              setShowRatings(false);
                              scrollToReviewsHeader();
                            }}
                          >
                            See customer reviews
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
            <div className="flex items-center gap-3 mb-2 relative z-[1]">
              <img
                src={images[0] || '/images/placeholder-item.jpg'}
                alt={product.name}
                className="h-10 w-10 rounded-xl object-cover ring-2 ring-gold/60"
                loading="lazy"
              />
              <h1 className="text-2xl md:text-3xl font-bold">{product.name}</h1>
            </div>
            {product.description && (
              <p className="text-muted-foreground mb-4 whitespace-pre-line">{product.description}</p>
            )}

            <div className="flex flex-col gap-2 mb-4">
              <div className="text-2xl font-bold">{formatCurrency(price)}</div>
              {(product.sellerCode || sellerCode) && (
                <div className="flex items-center gap-2 text-sm">
                  <button 
                    onClick={() => navigate(`/products?sellerId=${product.sellerId}&sellerCode=${encodeURIComponent(product.sellerCode || sellerCode)}`)}
                    className="inline-flex items-center rounded-md bg-muted px-2 py-1 text-xs font-medium text-muted-foreground ring-1 ring-inset ring-gray-200 dark:ring-gray-700 hover:bg-accent hover:text-accent-foreground transition-colors"
                    title="View all products from this seller"
                  >
                    <span className="mr-1">Seller:</span>
                    <span className="font-mono font-medium text-foreground">{product.sellerCode || sellerCode}</span>
                  </button>
                </div>
              )}
            </div>

            <div className="flex gap-3 items-center">
              <img
                src={images[0] || '/images/placeholder-item.jpg'}
                alt={`${product.name} thumbnail`}
                className="h-9 w-9 rounded-lg object-cover border border-border"
                loading="lazy"
              />
              <Button
                className="bg-gold hover:bg-gold/90 text-black"
                disabled={isOut}
                aria-disabled={isOut}
                onClick={async () => {
                  if (isOut) return;
                  const cartProduct = {
                    id: product.id,
                    name: product.name,
                    price,
                    imageUrl: images[0] || '/images/placeholder-item.jpg',
                    category: product.category || 'products',
                  };
                  await addToCart(cartProduct);
                  // Stay on the same page after adding to cart
                }}
              >
                Add to Cart
              </Button>
              <Button
                variant="default"
                className="bg-emerald-500 hover:bg-emerald-600 text-white"
                onClick={async () => {
                  const cartProduct = {
                    id: product.id,
                    name: product.name,
                    price,
                    imageUrl: images[0] || '/images/placeholder-item.jpg',
                    category: product.category || 'products',
                  };
                  await addToCart(cartProduct);
                  navigate('/cart');
                }}
              >
                {String(product.category || '').toLowerCase() === 'scrap-books' ? 'Rent' : 'Buy Now'}
              </Button>
              {canCustomize && customizeOrderId && (
                <Button
                  asChild
                  className="bg-blue-600 hover:bg-blue-700 text-white"
                  title="Request post-purchase customization with the seller"
                >
                  <Link to={`/customize/${product.id}?orderId=${customizeOrderId}&from=product`}>Request customization</Link>

                </Button>
              )}
            </div>

            <div className="mt-8">
              <h2 className="text-lg font-semibold mb-2">Highlights</h2>
              <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                <li>Quality checked by our team</li>
                <li>Supports local sellers</li>
                <li>Easy returns if item is damaged</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-8">
          {/* Reviews full width */}
          <div ref={reviewsSectionRef} id="reviews">
            <Card>
              <CardContent className="p-6">
                <div
                  ref={reviewHeaderRef}
                  id="reviews-header"
                  className="flex items-baseline justify-between mb-4"
                  style={{ scrollMarginTop: '128px' }}
                >
                  <h2 className="text-xl font-semibold">Reviews</h2>
                  <span className="text-sm text-muted-foreground">{(reviews.length || dummyReviews.length)} review{(reviews.length || dummyReviews.length) === 1 ? '' : 's'}</span>
                </div>

                {/* Add Review Form (gated by delivered order) */}
                <div ref={reviewFormRef} className="mb-6">
                  {!user ? (
                    <div className="border border-yellow-200 bg-yellow-50 text-yellow-900 rounded p-3 text-sm">
                      Please sign in to write a review.
                    </div>
                  ) : !canWriteReview ? (
                    <div className="border border-yellow-200 bg-yellow-50 text-yellow-900 rounded p-3 text-sm">
                      You can write a review after your order is delivered.
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <button
                        type="button"
                        className="text-sm underline"
                        onClick={() => setShowReviewForm((s) => !s)}
                      >
                        {showReviewForm ? 'Hide review form' : 'Write a review'}
                      </button>
                      {showReviewForm && (
                        <form
                          onSubmit={async (e) => {
                            e.preventDefault();
                            if (!id) return;
                            if (!reviewRating || reviewRating < 1 || reviewRating > 5) return;
                            try {
                              setSubmitting(true);
                              // 1) Upload selected images (if any)
                              let photoUrls: string[] = [];
                              if (reviewFiles.length > 0 && (user as any)?.uid) {
                                const uid = (user as any).uid;
                                const uploads = reviewFiles.slice(0, 4).map(async (file) => {
                                  const path = `reviews/${id}/${uid}/${Date.now()}-${file.name}`;
                                  const r = storageRef(storage, path);
                                  const snap = await uploadBytes(r, file);
                                  return await getDownloadURL(snap.ref);
                                });
                                photoUrls = await Promise.all(uploads);
                              }

                              // 2) Build payload and write review
                              const displayName = (user as any)?.displayName || 'Anonymous';
                              const payload = {
                                rating: Number(reviewRating),
                                comment: reviewComment?.trim() || '',
                                userId: (user as any)?.uid || (user as any)?.id,
                                userDisplayName: displayName,
                                createdAt: serverTimestamp(),
                                photos: photoUrls.length ? photoUrls : [],
                              };
                              await addDoc(collection(db, 'products', id, 'reviews'), payload as any);
                              // Optimistically update list
                              setReviews((prev) => [
                                {
                                  id: Math.random().toString(36).slice(2),
                                  rating: payload.rating,
                                  comment: payload.comment,
                                  userDisplayName: payload.userDisplayName,
                                  createdAt: null,
                                  photos: payload.photos,
                                },
                                ...prev,
                              ]);
                              setReviewRating(5);
                              setReviewComment('');
                              setReviewFiles([]);
                              setFilePreviews([]);
                              setShowReviewForm(false);
                            } catch (err) {
                              // noop; could show toast
                            } finally {
                              setSubmitting(false);
                            }
                          }}
                          className="border rounded p-3 bg-black/20"
                        >
                          <div className="flex items-center gap-3 mb-3">
                            <label htmlFor="rating" className="text-sm w-20">Rating</label>
                            <select
                              id="rating"
                              value={reviewRating}
                              onChange={(e) => setReviewRating(Number(e.target.value))}
                              className="bg-background border border-border rounded px-2 py-1 text-sm"
                            >
                              {[5,4,3,2,1].map((r) => (
                                <option key={r} value={r}>{r} Star{r>1?'s':''}</option>
                              ))}
                            </select>
                          </div>
                          <div className="mb-3">
                            <label htmlFor="comment" className="text-sm block mb-1">Comment (optional)</label>
                            <textarea
                              id="comment"
                              rows={3}
                              value={reviewComment}
                              onChange={(e) => setReviewComment(e.target.value)}
                              className="w-full bg-background border border-border rounded px-2 py-2 text-sm"
                              placeholder="Share details about quality, packaging, delivery, etc."
                            />
                          </div>
                          <div className="mb-3">
                            <label className="text-sm block mb-1">Photos (optional, up to 4)</label>
                            <input
                              type="file"
                              multiple
                              accept="image/*"
                              onChange={(e) => {
                                const files = Array.from(e.target.files || []).slice(0, 4);
                                setReviewFiles(files as File[]);
                                const previews = files.map((f) => URL.createObjectURL(f));
                                setFilePreviews(previews);
                              }}
                              className="text-sm"
                            />
                            {filePreviews.length > 0 && (
                              <div className="mt-2 flex gap-2 flex-wrap">
                                {filePreviews.map((src, i) => (
                                  <button
                                    key={i}
                                    type="button"
                                    onClick={() => {
                                      setLightboxImage(src);
                                      // Build a temporary review object from current form state for preview
                                      setLightboxReview({
                                        id: `preview-${i}`,
                                        rating: reviewRating,
                                        comment: reviewComment,
                                        userDisplayName: (user as any)?.displayName || 'You',
                                        createdAt: null,
                                        photos: [src],
                                      });
                                      setLightboxOpen(true);
                                    }}
                                    className="p-0 m-0 inline-block"
                                  >
                                    <img src={src} alt={`preview-${i}`} className="h-16 w-16 object-cover rounded border" />
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>
                          <Button
                            type="submit"
                            className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 btn-hover h-10 px-4 py-2 bg-gold text-black hover:bg-gold/90"
                            disabled={submitting}
                          >
                            {submitting ? 'Submitting...' : 'Submit Review'}
                          </Button>
                        </form>
                      )}
                    </div>
                  )}
                </div>
                {reviews.length === 0 ? (
                  <ul className="space-y-4">
                    {dummyReviews.map((r) => (
                      <li key={r.id} className="border-b border-border pb-4 last:border-b-0 last:pb-0">
                        <div className="flex items-start gap-3 justify-between">
                          <img
                            src={images[0] || '/images/placeholder-item.jpg'}
                            alt={`${product.name} thumbnail`}
                            className="h-10 w-10 rounded-lg object-cover border border-border"
                            loading="lazy"
                          />
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <div className="font-medium">{r.userDisplayName || 'Anonymous'}</div>
                              <div className="text-yellow-400" aria-label={`Rating ${r.rating} out of 5`}>
                                {'★'.repeat(Math.round(r.rating || 0))}
                              </div>
                            </div>
                            {r.comment && <p className="text-sm text-muted-foreground mt-1 whitespace-pre-line">{r.comment}</p>}
                            {Array.isArray(r.photos) && r.photos.length > 0 && (
                              <div className="mt-2 flex gap-2 flex-wrap">
                                {r.photos.map((src, i) => (
                                  <button
                                    key={i}
                                    type="button"
                                    onClick={() => {
                                      setLightboxImage(src);
                                      setLightboxReview(r);
                                      setLightboxOpen(true);
                                    }}
                                    className="p-0 m-0 inline-block"
                                  >
                                    <img src={src} alt={`review-photo-${i}`} className="h-16 w-16 object-cover rounded border" loading="lazy" />
                                  </button>
                                ))}
                              </div>
                            )}
                            <div className="mt-2 inline-flex items-center gap-2 text-xs text-muted-foreground">
                              <span className="rounded bg-gold/15 text-gold px-2 py-0.5">Verified Purchase</span>
                              <span>Fast delivery</span>
                            </div>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <ul className="space-y-4">
                    {reviews.map((r) => (
                      <li key={r.id} className="border-b border-border pb-4 last:border-b-0 last:pb-0">
                        <div className="flex items-start gap-3 justify-between">
                          <img
                            src={images[0] || '/images/placeholder-item.jpg'}
                            alt={`${product.name} thumbnail`}
                            className="h-10 w-10 rounded-lg object-cover border border-border"
                            loading="lazy"
                          />
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <div className="font-medium">{r.userDisplayName || 'Anonymous'}</div>
                              <div className="text-yellow-400" aria-label={`Rating ${r.rating} out of 5`}>
                                {'★'.repeat(Math.round(r.rating || 0))}
                              </div>
                            </div>
                            {r.comment && <p className="text-sm text-muted-foreground mt-1 whitespace-pre-line">{r.comment}</p>}
                            {Array.isArray(r.photos) && r.photos.length > 0 && (
                              <div className="mt-2 flex gap-2 flex-wrap">
                                {r.photos.map((src, i) => (
                                  <button
                                    key={i}
                                    type="button"
                                    onClick={() => {
                                      setLightboxImage(src);
                                      setLightboxReview(r);
                                      setLightboxOpen(true);
                                    }}
                                    className="p-0 m-0 inline-block"
                                  >
                                    <img src={src} alt={`review-photo-${i}`} className="h-16 w-16 object-cover rounded border" loading="lazy" />
                                  </button>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
          </div>
          </div>
          </div>
          {/* Lightbox for review images */}
          {lightboxOpen && (
            <div
              className="fixed inset-0 z-[1000] bg-black/70 flex items-center justify-center p-4"
              onClick={() => setLightboxOpen(false)}
              role="dialog"
              aria-modal="true"
              onKeyDown={(e) => {
                if (e.key === 'Escape') {
                  setLightboxOpen(false);
                }
              }}
            >
              <div
                className="relative bg-background rounded-lg shadow-2xl w-full max-w-5xl grid grid-cols-1 md:grid-cols-2 overflow-hidden"
                onClick={(e) => e.stopPropagation()}
              >
                <button
                  aria-label="Close"
                  className="absolute top-3 right-3 h-9 w-9 inline-flex items-center justify-center rounded-full bg-black/60 text-white hover:bg-black/80"
                  onClick={() => setLightboxOpen(false)}
                >
                  <X className="h-5 w-5" />
                </button>
                <div className="bg-black flex items-center justify-center p-2">
                  <img src={lightboxImage} alt="review-full" className="max-h-[80vh] w-full object-contain" />
                </div>
                <div className="p-4 md:p-5 overflow-y-auto max-h-[80vh]">
                  {lightboxReview && (
                    <div>
                      <div className="flex items-center gap-3 mb-2">
                        <div className="h-9 w-9 rounded-full bg-muted flex items-center justify-center text-sm font-semibold">
                          {(lightboxReview.userDisplayName || 'User').slice(0,1).toUpperCase()}
                        </div>
                        <div className="font-medium">{lightboxReview.userDisplayName || 'User'}</div>
                      </div>
                      <div className="text-yellow-400" aria-label={`Rating ${lightboxReview.rating} out of 5`}>
                        {'★'.repeat(Math.round(lightboxReview.rating || 0))}
                      </div>
                      {lightboxReview.comment && (
                        <p className="mt-3 text-sm text-foreground whitespace-pre-line">{lightboxReview.comment}</p>
                      )}
                      <div className="mt-4 inline-flex items-center gap-2 text-xs text-muted-foreground">
                        <span className="rounded bg-gold/15 text-gold px-2 py-0.5">Verified Purchase</span>
                        <span>Customer review</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </motion.div>
      );
}
