import React, { useRef, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Label } from '@/components/ui/label';
import { Image as ImageIcon, X } from 'lucide-react';
import { db, storage, auth } from '@/lib/firebase';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { useStore } from '@/store/useStore';
import { ProductUploadForm } from '@/components/forms/ProductUploadForm';
import { generateProductCode } from '@/lib/utils';

export default function HomeDecorUpload() {
  const navigate = useNavigate();
  const { user } = useStore();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: '',
    description: '',
    price: '',
    stock: '',
    dimensions: '',
    material: ''
  });
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const imageInputRef = useRef<HTMLInputElement | null>(null);
  const [isCustomizable, setIsCustomizable] = useState<boolean>(false);

  // Reset form to initial state
  const resetForm = () => {
    setForm({
      name: '',
      description: '',
      price: '',
      stock: '',
      dimensions: '',
      material: ''
    });
    setIsCustomizable(false);
    setImageFiles([]);
    setPreviews([]);
    if (imageInputRef.current) {
      imageInputRef.current.value = '';
    }
    setMessage(null);
  };

  // Handle image previews
  useEffect(() => {
    const urls = imageFiles.map((file) => URL.createObjectURL(file));
    setPreviews(urls);
    return () => urls.forEach(url => URL.revokeObjectURL(url));
  }, [imageFiles]);

  const onFilesSelected = (files: FileList | File[]) => {
    const valid = Array.from(files).filter((f) => f.type.startsWith('image/'));
    if (valid.length > 0) {
      setImageFiles(prev => [...prev, ...valid].slice(0, 10));
    }
  };

  const removeImage = (index: number) => {
    setImageFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      navigate('/login');
      return;
    }

    const uid = auth.currentUser?.uid;
    if (!uid) {
      setMessage('Please sign in to your seller account before uploading.');
      navigate('/seller-login');
      return;
    }

    // Validation
    if (!form.name.trim() || !form.description.trim() || !form.price || form.stock === '') {
      setMessage('Please fill all required fields.');
      return;
    }

    const priceVal = Number(form.price);
    if (Number.isNaN(priceVal) || priceVal < 0) {
      setMessage('Enter a valid price.');
      return;
    }

    const stockVal = Number(form.stock);
    if (!Number.isInteger(stockVal) || stockVal < 0) {
      setMessage('Enter a valid stock (non-negative integer).');
      return;
    }

    if (imageFiles.length < 3) {
      setMessage('Please upload at least 3 images (minimum is 3).');
      return;
    }

    setIsSubmitting(true);
    setMessage(null);

    try {
      // Upload images
      const imageUrls = await Promise.all(
        imageFiles.map(async (file) => {
          const path = `sellers/${uid}/home-decor/${Date.now()}_${file.name}`;
          const storageRef = ref(storage, path);
          await uploadBytes(storageRef, file);
          return getDownloadURL(storageRef);
        })
      );

      // Generate product code
      const sellerName = user?.displayName || 'Unknown';
      const productCode = await generateProductCode(sellerName, uid);

      // Save product data
      await addDoc(collection(db, 'products'), {
        name: form.name.trim(),
        description: form.description.trim(),
        price: priceVal,
        stock: stockVal,
        dimensions: form.dimensions.trim(),
        material: form.material.trim(),
        category: 'home-decor',
        imageUrl: imageUrls[0] || '',
        imageUrls: imageUrls,
        customizable: !!isCustomizable,
        published: false,
        sellerId: uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        productCode: productCode,
      });

      // Reset form
      resetForm();
      setMessage(`Home decor item added successfully! Code: ${productCode}`);
    } catch (err: any) {
      console.error('Error saving product:', err);
      setMessage(err.message || 'Failed to save home decor item. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Image upload component
  const imageUpload = (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <Label>Product Images</Label>
        <span className="text-xs text-muted-foreground">
          {imageFiles.length} of 10 images
        </span>
      </div>
      
      <input
        ref={imageInputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => e.target.files && onFilesSelected(e.target.files)}
      />

      <div 
        className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-accent/50 transition-colors"
        onClick={() => imageInputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          e.stopPropagation();
        }}
        onDrop={(e) => {
          e.preventDefault();
          e.stopPropagation();
          if (e.dataTransfer?.files?.length) {
            onFilesSelected(e.dataTransfer.files);
          }
        }}
      >
        <div className="flex flex-col items-center justify-center space-y-2">
          <ImageIcon className="h-8 w-8 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">
            Drag & drop images here, or click to browse
          </p>
          <p className="text-xs text-muted-foreground">
            Minimum 3 images required (max 10)
          </p>
        </div>
      </div>

      {previews.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 mt-4">
          {previews.map((preview, index) => (
            <div key={index} className="relative group">
              <img
                src={preview}
                alt={`Preview ${index + 1}`}
                className="h-24 w-full rounded-md object-cover border"
              />
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  removeImage(index);
                }}
                className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <ProductUploadForm
      title="Add to Home Decor"
      description="List your unique home decor items to help others beautify their spaces."
      onSubmit={handleSubmit}
      formFields={{
        basic: [
          {
            id: 'name-home-decor',
            label: 'Item Name',
            placeholder: 'e.g. Handcrafted Ceramic Vase',
            required: true,
            value: form.name,
            onChange: (value) => setForm(p => ({ ...p, name: value })),
            helpText: 'Name of your home decor item'
          },
          {
            id: 'material-home-decor',
            label: 'Material',
            placeholder: 'e.g. Ceramic, Wood, Metal, etc.',
            required: true,
            value: form.material,
            onChange: (value) => setForm(p => ({ ...p, material: value })),
            helpText: 'Primary material used in this item'
          },
          {
            id: 'dimensions-home-decor',
            label: 'Dimensions',
            placeholder: 'e.g. 12" x 8" x 8"',
            value: form.dimensions,
            onChange: (value) => setForm(p => ({ ...p, dimensions: value })),
            helpText: 'Size in inches or centimeters (optional)'
          },
          {
            id: 'price-home-decor',
            label: 'Price (₹)',
            type: 'number',
            min: 0,
            step: '0.01',
            placeholder: '0.00',
            required: true,
            value: form.price,
            onChange: (value) => setForm(p => ({ ...p, price: value })),
            helpText: 'Set the selling price in INR',
            prefix: '₹'
          },
          {
            id: 'stock-home-decor',
            label: 'Available Stock',
            type: 'number',
            inputMode: 'numeric',
            pattern: '[0-9]*',
            min: 0,
            step: 1,
            placeholder: 'e.g. 5',
            required: true,
            value: form.stock,
            onChange: (value) => setForm(p => ({ ...p, stock: value })),
            helpText: 'Number of items available'
          }
        ],
        description: {
          id: 'description-home-decor',
          label: 'Product Description',
          placeholder: 'Describe your home decor item in detail. Include its features, care instructions, and any special characteristics that make it unique.',
          required: true,
          value: form.description,
          onChange: (value) => setForm(p => ({ ...p, description: value })),
          helpText: 'Minimum 50 characters',
          rows: 5
        }
      }}
      imageUpload={imageUpload}
      customizable={{
        checked: isCustomizable,
        onChange: setIsCustomizable
      }}
      message={message}
      isSubmitting={isSubmitting}
      onBack={() => navigate('/seller')}
      onReset={resetForm}
    />
  );
}
