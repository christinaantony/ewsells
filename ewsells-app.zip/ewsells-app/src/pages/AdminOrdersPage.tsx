import React, { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { Search, ShoppingBag, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/toast-context';
import { auth, db } from '@/lib/firebase';
import { collection, deleteDoc, doc, getCountFromServer, getDoc, getDocs, limit, orderBy, query, serverTimestamp, startAfter, updateDoc, where } from 'firebase/firestore';

export default function AdminOrdersPage() {
  const [loading, setLoading] = useState(true);
  const [orders, setOrders] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [statusTab, setStatusTab] = useState<'all' | 'pending' | 'processing' | 'delivered' | 'cancelled'>('all');
  const [detailOpen, setDetailOpen] = useState(false);
  const [activeOrder, setActiveOrder] = useState<any | null>(null);
  const { showToast } = useToast();
  const navigate = useNavigate();
  const [actionBusyId, setActionBusyId] = useState<string | null>(null);
  // Server-side pagination
  const [pageSize] = useState<number>(20);
  const [cursors, setCursors] = useState<any[]>([]); // document snapshots for each page start
  const [pageIndex, setPageIndex] = useState<number>(0);
  const [hasNext, setHasNext] = useState<boolean>(false);
  // Cache for user info looked up by userId when orders lack userName
  const [userCache, setUserCache] = useState<Record<string, any>>({});
  // Remote counts by status (entire collection)
  const [countsRemote, setCountsRemote] = useState<{ all: number; pending: number; processing: number; delivered: number; cancelled: number }>({ all: 0, pending: 0, processing: 0, delivered: 0, cancelled: 0 });
  // Client-side sorting for current page
  const [sortBy, setSortBy] = useState<'created_desc' | 'created_asc' | 'name_asc' | 'name_desc' | 'total_desc' | 'total_asc'>('created_desc');
  const [sortOpen, setSortOpen] = useState<boolean>(false);

  // Verify admin before loading
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const currentUser = auth.currentUser;
        if (!currentUser) { navigate('/admin-login'); return; }
        const userRef = doc(db, 'users', currentUser.uid);
        const snap = await getDoc(userRef);
        if (!snap.exists() || snap.data()?.role !== 'admin') {
          try { /* best effort */ } catch {}
          navigate('/admin-login');
          return;
        }
        // load first page
        await loadOrders('first');
      } catch (e) {
        console.error('Admin verification failed for orders:', e);
        navigate('/admin-login');
      }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toDate = (v: any): Date | null => {
    if (!v) return null;
    if (typeof v?.toDate === 'function') return v.toDate();
    if (v instanceof Date) return v;
    if (typeof v === 'number') return new Date(v);
    const parsed = Date.parse(v);
    return Number.isNaN(parsed) ? null : new Date(parsed);
  };

  // Load orders with pagination and status filter
  async function loadOrders(mode: 'first' | 'next' | 'prev' = 'first') {
    try {
      setLoading(true);
      const ordersRef = collection(db, 'orders');
      const filters: any[] = [];
      if (statusTab !== 'all') {
        filters.push(where('status', '==', statusTab));
      }

      // Always order by createdAt desc for stable paging
      let baseQ: any;
      try {
        baseQ = query(ordersRef, ...filters, orderBy('createdAt', 'desc'), limit(pageSize + 1));
      } catch {
        // If createdAt is missing or not indexed, fall back to un-ordered query (no pagination guarantees)
        baseQ = query(ordersRef, ...filters, limit(pageSize + 1));
      }

      let qRef: any = baseQ;
      // We model pages as 0-based indices; pageIndex holds current page (0-based)
      if (mode === 'next') {
        const currentCursor = cursors[pageIndex];
        if (currentCursor) {
          try { qRef = query(baseQ, startAfter(currentCursor)); } catch { qRef = baseQ; }
        }
      } else if (mode === 'prev') {
        const prevIndex = Math.max(0, pageIndex - 1);
        if (prevIndex === 0) {
          // going back to first page: no startAfter
          qRef = baseQ;
        } else {
          const beforePrevCursor = cursors[prevIndex - 1];
          if (beforePrevCursor) {
            try { qRef = query(baseQ, startAfter(beforePrevCursor)); } catch { qRef = baseQ; }
          }
        }
      }

      const snap = await getDocs(qRef);
      const docs = snap.docs;
      // Determine if there is a next page by fetching one extra record
      const pageDocs = docs.slice(0, pageSize);
      setHasNext(docs.length > pageSize);
      const rows = pageDocs
        .map(d => ({ id: d.id, ...(d.data() as any) } as any))
        .sort((a: any, b: any) => {
          const toDate = (v: any): number => {
            if (!v) return 0;
            if (typeof v?.toDate === 'function') return v.toDate().getTime();
            if (v instanceof Date) return v.getTime();
            if (typeof v === 'number') return v;
            const parsed = Date.parse(v);
            return Number.isNaN(parsed) ? 0 : parsed;
          };
          const aT = toDate(a?.createdAt) || toDate(a?.created) || toDate(a?.orderedAt);
          const bT = toDate(b?.createdAt) || toDate(b?.created) || toDate(b?.orderedAt);
          return bT - aT; // newest first
        });
      setOrders(rows);

      // Manage cursors stack (store last doc per page); pageIndex is 0-based
      if (pageDocs.length > 0) {
        const last = pageDocs[pageDocs.length - 1];
        if (mode === 'first') {
          setCursors([last]);
          setPageIndex(0);
        } else if (mode === 'next') {
          setCursors(prev => {
            const arr = [...prev];
            arr[pageIndex + 1] = last; // cursor for the new page
            return arr;
          });
          setPageIndex(i => i + 1);
        } else if (mode === 'prev') {
          setPageIndex(i => Math.max(0, i - 1));
        }
      } else if (mode === 'first') {
        setCursors([]);
        setPageIndex(0);
        setHasNext(false);
      }
    } catch (e) {
      console.error('Failed to load orders:', e);
      showToast({ message: 'Failed to load orders', type: 'error' });
    } finally {
      setLoading(false);
    }
  }

  // Reload when status tab changes (reset pagination)
  useEffect(() => {
    setCursors([]);
    setPageIndex(0);
    loadOrders('first');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusTab]);

  // Load remote counts for all statuses
  const loadCounts = useCallback(async () => {
    try {
      const ordersRef = collection(db, 'orders');
      const [allSnap, pendSnap, procSnap, delSnap, cancSnap] = await Promise.all([
        getCountFromServer(query(ordersRef)),
        getCountFromServer(query(ordersRef, where('status', '==', 'pending'))),
        getCountFromServer(query(ordersRef, where('status', '==', 'processing'))),
        getCountFromServer(query(ordersRef, where('status', '==', 'delivered'))),
        getCountFromServer(query(ordersRef, where('status', '==', 'cancelled'))),
      ]);
      setCountsRemote({
        all: allSnap.data().count,
        pending: pendSnap.data().count,
        processing: procSnap.data().count,
        delivered: delSnap.data().count,
        cancelled: cancSnap.data().count,
      });
    } catch (e) {
      console.warn('Failed to load counts:', e);
    }
  }, [db]);

  useEffect(() => { loadCounts(); }, [loadCounts]);

  const norm = (s: string) => (s || '').toLowerCase();
  const matches = (o: any) => {
    if (!search) return true;
    return [o.id, o.userEmail, o.userName, o.userId]
      .map((x: any) => String(x || ''))
      .some(txt => norm(txt).includes(norm(search)));
  };
  const byStatus = (o: any) => statusTab === 'all' ? true : (String(o?.status || '').toLowerCase() === statusTab);
  const visible = orders.filter(byStatus).filter(matches);
  const counts = countsRemote;

  // Provide a display name for a row (from order fields or loaded user cache)
  const getDisplayName = (o: any) => {
    const u = o?.userName;
    if (u) return u;
    const info = o?.userId ? userCache[o.userId] : null;
    return info?.fullName || info?.name || info?.displayName || info?.email || '-';
  };

  // Sorting helpers
  const getCreatedAtMs = (o: any): number => {
    const d = toDate(o?.createdAt) || toDate(o?.created) || toDate(o?.orderedAt);
    return d ? d.getTime() : 0;
  };
  const getUserName = (o: any): string => {
    const name = getDisplayName(o);
    return String(name || '').toLowerCase();
  };
  const getTotalNumber = (o: any): number => {
    const direct = Number(o?.total);
    if (Number.isFinite(direct) && direct > 0) return direct;
    const items: any[] = Array.isArray(o?.items) ? o.items : [];
    return items.reduce((acc, it: any) => {
      const price = Number(it?.price ?? it?.finalPrice ?? it?.sellerPrice ?? 0);
      const qty = Number(it?.qty ?? it?.quantity ?? 1);
      const sub = (Number.isFinite(price) ? price : 0) * (Number.isFinite(qty) ? qty : 1);
      return acc + sub;
    }, 0);
  };
  const statusRank = (s: any): number => {
    const v = String(s || '').toLowerCase();
    return v === 'pending' ? 0 : v === 'processing' ? 1 : v === 'delivered' ? 2 : v === 'cancelled' ? 3 : 4;
  };
  const compareOrder = (a: any, b: any) => {
    switch (sortBy) {
      case 'created_desc':
        return getCreatedAtMs(b) - getCreatedAtMs(a) || getUserName(a).localeCompare(getUserName(b));
      case 'created_asc':
        return getCreatedAtMs(a) - getCreatedAtMs(b) || getUserName(a).localeCompare(getUserName(b));
      case 'name_asc':
        return getUserName(a).localeCompare(getUserName(b));
      case 'name_desc':
        return getUserName(b).localeCompare(getUserName(a));
      case 'total_desc':
        return getTotalNumber(b) - getTotalNumber(a) || getCreatedAtMs(b) - getCreatedAtMs(a);
      case 'total_asc':
        return getTotalNumber(a) - getTotalNumber(b) || getCreatedAtMs(b) - getCreatedAtMs(a);
      default:
        return 0;
    }
  };
  const sortedVisible = [...visible].sort(compareOrder);

  // When orders load, fetch missing user names from users collection using userId
  useEffect(() => {
    const ids = Array.from(new Set(
      orders
        .filter(o => !o?.userName && o?.userId && !userCache[o.userId])
        .map(o => String(o.userId))
    ));
    if (ids.length === 0) return;
    (async () => {
      try {
        const entries: Record<string, any> = {};
        await Promise.all(ids.map(async (uid) => {
          try {
            const ref = doc(db, 'users', uid);
            const snap = await getDoc(ref);
            if (snap.exists()) entries[uid] = snap.data();
          } catch {}
        }));
        if (Object.keys(entries).length > 0) {
          setUserCache(prev => ({ ...prev, ...entries }));
        }
      } catch {}
    })();
  }, [orders, userCache, db]);

  

  const openDetails = (o: any) => { setActiveOrder(o); setDetailOpen(true); };

  // Update order status
  const updateStatus = async (o: any, newStatus: 'pending' | 'processing' | 'delivered' | 'cancelled') => {
    if (!o?.id || actionBusyId) return;
    try {
      setActionBusyId(o.id);
      const ref = doc(db, 'orders', o.id);
      await updateDoc(ref, { status: newStatus, updatedAt: serverTimestamp() });
      setOrders(prev => prev.map(x => x.id === o.id ? { ...x, status: newStatus, updatedAt: serverTimestamp() } : x));
      if (activeOrder?.id === o.id) setActiveOrder((p: any) => ({ ...p, status: newStatus, updatedAt: serverTimestamp() }));
      showToast({ message: `Order ${o.id} marked as ${newStatus}`, type: 'success' });
      // Refresh counts in background
      loadCounts();
    } catch (e: any) {
      console.error('Failed to update status', e);
      showToast({ message: `Failed to update status: ${e?.message || e?.code || 'unknown error'}`.trim(), type: 'error' });
    } finally {
      setActionBusyId(null);
    }
  };

  // CSV export of visible rows
  const exportCsv = () => {
    try {
      const cols = ['id','userName','userEmail','userId','status','total','createdAt'];
      const rows = visible.map((o: any) => {
        const created = toDate(o?.createdAt) || toDate(o?.created) || toDate(o?.orderedAt);
        // Remove currency symbol for CSV readability
        const total = fmtAmt(o).replace(/^₹\s*/, '');
        return {
          id: o.id,
          userName: o?.userName || '',
          userEmail: o?.userEmail || '',
          userId: o?.userId || '',
          status: String(o?.status || ''),
          total,
          createdAt: created ? created.toISOString() : ''
        };
      });
      const escape = (v: any) => {
        const s = String(v ?? '');
        if (/[",\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
        return s;
      };
      const header = cols.join(',');
      const body = rows.map(r => cols.map(c => (escape as any)((r as any)[c])).join(',')).join('\n');
      const csv = header + '\n' + body;
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `orders-export-${statusTab}-${Date.now()}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('CSV export failed', e);
      showToast({ message: 'CSV export failed', type: 'error' });
    }
  };

  const fmtAmt = (o: any) => {
    const direct = Number(o?.total);
    if (Number.isFinite(direct) && direct > 0) return `₹ ${direct.toLocaleString()}`;
    const items: any[] = Array.isArray(o?.items) ? o.items : [];
    const sum = items.reduce((acc, it: any) => {
      const price = Number(it?.price ?? it?.finalPrice ?? it?.sellerPrice ?? 0);
      const qty = Number(it?.qty ?? it?.quantity ?? 1);
      return acc + (Number.isFinite(price) ? price : 0) * (Number.isFinite(qty) ? qty : 1);
    }, 0);
    return `₹ ${Math.round(sum).toLocaleString()}`;
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 mb-4">
        <div>
          <h1 className="text-3xl font-bold mb-1">Order Management</h1>
          <p className="text-muted-foreground">View and manage all orders on the platform</p>
        </div>
        {/* Sort By aligned to right of title */}
        <div className="relative">
          <Button
            type="button"
            variant="outline"
            className="btn-hover h-10 px-4 py-2"
            aria-haspopup="listbox"
            aria-expanded={sortOpen}
            onClick={() => setSortOpen((o) => !o)}
            onBlur={(e: React.FocusEvent<HTMLButtonElement>) => {
              if (!e.currentTarget.parentElement?.contains(e.relatedTarget as Node)) setSortOpen(false);
            }}
          >
            Sort By
          </Button>
          {sortOpen && (
            <div className="absolute right-0 mt-2 z-10 w-48 rounded-md border border-border/60 bg-background shadow-lg py-1">
              <ul role="listbox" aria-label="Sort by" className="max-h-64 overflow-auto text-sm">
                <li><button type="button" role="option" aria-selected={sortBy==='created_desc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='created_desc'?'font-medium':''}`} onClick={() => { setSortBy('created_desc'); setSortOpen(false); }} autoFocus>Newest</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='created_asc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='created_asc'?'font-medium':''}`} onClick={() => { setSortBy('created_asc'); setSortOpen(false); }}>Oldest</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='name_asc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='name_asc'?'font-medium':''}`} onClick={() => { setSortBy('name_asc'); setSortOpen(false); }}>Customer A → Z</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='name_desc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='name_desc'?'font-medium':''}`} onClick={() => { setSortBy('name_desc'); setSortOpen(false); }}>Customer Z → A</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='total_desc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='total_desc'?'font-medium':''}`} onClick={() => { setSortBy('total_desc'); setSortOpen(false); }}>Total: High → Low</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='total_asc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='total_asc'?'font-medium':''}`} onClick={() => { setSortBy('total_asc'); setSortOpen(false); }}>Total: Low → High</button></li>
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Tabs + Search */}
      <div className="mb-4 flex flex-col md:flex-row md:items-center gap-3">
        <div className="flex items-center gap-2">
          {(['all','pending','processing','delivered','cancelled'] as const).map(s => (
            <Button
              key={s}
              variant={statusTab === s ? 'default' : 'ghost'}
              className={statusTab === s ? 'bg-gold text-black hover:bg-gold/90' : ''}
              onClick={() => setStatusTab(s)}
            >
              <span className="capitalize">{s}</span>
              <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${statusTab === s ? 'bg-black/20 text-black' : 'bg-gold/20 text-gold'}`}>
                {counts[s] as any}
              </span>
            </Button>
          ))}
        </div>
        <div className="relative w-full max-w-sm md:ml-auto flex items-center gap-2">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by order id, user, or email…"
            className="w-full pl-8 pr-3 py-2 rounded-md bg-muted/40 outline-none border border-border/60 focus:border-gold"
          />
          <Button type="button" variant="outline" onClick={exportCsv} title="Export visible orders to CSV">Export CSV</Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><ShoppingBag className="h-5 w-5"/>Orders</CardTitle>
          <CardDescription>Track and manage orders</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center gap-2 text-muted-foreground py-10"><Loader2 className="h-5 w-5 animate-spin"/>Loading…</div>
          ) : visible.length === 0 ? (
            <div className="text-muted-foreground">No orders found.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr>
                    <th className="py-2 pr-4">Order</th>
                    <th className="py-2 pr-4">User</th>
                    <th className="py-2 pr-4">Status</th>
                    <th className="py-2 pr-4">Total</th>
                    <th className="py-2 pr-4">Created</th>
                    <th className="py-2 pr-4">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedVisible.map((o) => (
                    <tr key={o.id} className="border-t border-border/60 align-top">
                      <td className="py-2 pr-4 font-mono text-xs break-all">{o.id}</td>
                      <td className="py-2 pr-4">
                        <div>{getDisplayName(o)}</div>
                        <div className="text-xs text-muted-foreground break-all" title={o.userEmail || (o.userId ? userCache[o.userId]?.email || '' : '')}>{o.userId || '-'}</div>
                      </td>
                      <td className="py-2 pr-4 capitalize">{String(o?.status || '').toLowerCase() || '-'}</td>
                      <td className="py-2 pr-4">{fmtAmt(o)}</td>
                      <td className="py-2 pr-4">{toDate(o?.createdAt)?.toLocaleString() || toDate(o?.created)?.toLocaleString() || toDate(o?.orderedAt)?.toLocaleString() || '-'}</td>
                      <td className="py-2 pr-4">
                        <div className="flex flex-wrap items-center gap-2">
                          <Button type="button" variant="outline" size="sm" onClick={() => openDetails(o)}>View</Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Pagination */}
              <div className="mt-4 flex items-center justify-between">
                <Button type="button" variant="outline" disabled={pageIndex <= 0} onClick={() => loadOrders('prev')}>Previous</Button>
                <div className="text-sm text-muted-foreground">Page {pageIndex + 1}{hasNext ? '' : ' (end)'}</div>
                <Button type="button" variant="outline" disabled={!hasNext} onClick={() => loadOrders('next')}>Next</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Order details modal */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Order Details</DialogTitle>
          </DialogHeader>
          {activeOrder && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Order</div>
                  <div className="font-mono text-xs break-all">{activeOrder.id}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">User</div>
                  <div>{activeOrder.userName || '-'}</div>
                  <div className="text-xs text-muted-foreground break-all">{activeOrder.userEmail || '-'}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Status</div>
                  <div className="capitalize">{String(activeOrder?.status || '').toLowerCase() || '-'}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Total</div>
                  <div>{fmtAmt(activeOrder)}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Created</div>
                  <div>{toDate(activeOrder?.createdAt)?.toLocaleString() || toDate(activeOrder?.created)?.toLocaleString() || toDate(activeOrder?.orderedAt)?.toLocaleString() || '-'}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Shipping</div>
                  {(() => {
                    const addr = activeOrder.shippingAddress || activeOrder.address || activeOrder.deliveryAddress || null;
                    if (!addr) return <div className="mt-1">—</div>;
                    return (
                      <div className="mt-1 space-y-1">
                        <div className="font-medium break-all">{addr.fullName || addr.name || '—'}</div>
                        <div className="text-xs text-muted-foreground break-all">{addr.email || ''}</div>
                        <div className="text-xs text-muted-foreground break-all">{addr.phone || ''}</div>
                        <div className="break-all">{addr.line1 || addr.address1 || ''}</div>
                        <div className="break-all">{[addr.city, addr.state, addr.pincode || addr.zip].filter(Boolean).join(', ')}</div>
                      </div>
                    );
                  })()}
                </div>
              </div>
              <Separator />
              <div>
                <div className="text-muted-foreground mb-2">Items</div>
                <div className="overflow-x-auto">
                  <table className="min-w-full text-xs">
                    <thead className="text-left text-muted-foreground">
                      <tr>
                        <th className="py-2 pr-3">Product</th>
                        <th className="py-2 pr-3">Qty</th>
                        <th className="py-2 pr-3">Price</th>
                        <th className="py-2 pr-3">Subtotal</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(Array.isArray(activeOrder.items) ? activeOrder.items : []).map((it: any, idx: number) => {
                        const name = String(it?.name ?? it?.title ?? 'Item');
                        const qty = Number(it?.qty ?? it?.quantity ?? 1);
                        const price = Number(it?.price ?? it?.finalPrice ?? it?.sellerPrice ?? 0);
                        const subtotal = (Number.isFinite(price) ? price : 0) * (Number.isFinite(qty) ? qty : 1);
                        return (
                          <tr key={idx} className="border-t border-border/60">
                            <td className="py-2 pr-3 max-w-xs">
                              <div className="truncate" title={name}>{name}</div>
                              <div className="text-[10px] text-muted-foreground break-all">{String(it?.productId ?? it?.id ?? '')}</div>
                            </td>
                            <td className="py-2 pr-3">{qty}</td>
                            <td className="py-2 pr-3">₹ {Math.round(price).toLocaleString()}</td>
                            <td className="py-2 pr-3">₹ {Math.round(subtotal).toLocaleString()}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
              {/* Inline status actions (modal only) */}
              <div className="pt-2 flex items-center gap-2">
                <div className="text-muted-foreground text-xs">Update Status:</div>
                <Button size="sm" variant="outline" disabled={actionBusyId === activeOrder.id} onClick={() => updateStatus(activeOrder, 'pending')}>Pending</Button>
                <Button size="sm" variant="outline" disabled={actionBusyId === activeOrder.id} onClick={() => updateStatus(activeOrder, 'processing')}>Processing</Button>
                <Button size="sm" variant="outline" disabled={actionBusyId === activeOrder.id} onClick={() => updateStatus(activeOrder, 'delivered')}>Delivered</Button>
                <Button size="sm" variant="destructive" disabled={actionBusyId === activeOrder.id} onClick={() => updateStatus(activeOrder, 'cancelled')}>Cancel</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
