import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, useTransform } from 'framer-motion';
import { ArrowRight, ShoppingBag, Heart, Users, Zap, Eye } from 'lucide-react';
import { CategoryTrendingProducts } from '@/components/CategoryTrendingProducts';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { AnimatedCounter } from '@/components/ui/animated-counter';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { firestoreService } from '@/services/firebase';
import { auth } from '@/lib/firebase';
import { mockProducts, totalRaised } from '@/fixtures/mockData';
import { formatCurrency } from '@/lib/utils';
import { ProductCarousel } from '@/components/ui/ProductCarousel';
import { ProductVerticalList } from '@/components/ui/ProductVerticalList';
import type { Product } from '@/types';
import type { SearchResult } from '@/services/searchService';

const categories = [
  {
    name: 'Charity Craft',
    description: 'Handmade items supporting artisan communities',
    image: 'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg?auto=compress&cs=tinysrgb&w=600',
    href: '/category/charity-craft',
    icon: Heart,
    color: 'from-rose-500 to-pink-600'
  },
  {
    name: 'Organic Store',
    description: 'Fresh, sustainable produce from local farms',
    image: 'https://images.pexels.com/photos/4518843/pexels-photo-4518843.jpeg?auto=compress&cs=tinysrgb&w=600',
    href: '/category/organic-store',
    icon: ShoppingBag,
    color: 'from-green-500 to-emerald-600'
  },
  {
    name: 'Scrap Store',
    description: 'Upcycled treasures giving new life to materials',
    image: 'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=600',
    href: '/category/scrap-store',
    icon: Zap,
    color: 'from-amber-500 to-orange-600'
  },
  {
    name: 'Moms Made United',
    description: 'Caring mothers creating with love and dedication',
    image: 'https://images.pexels.com/photos/6849159/pexels-photo-6849159.jpeg?auto=compress&cs=tinysrgb&w=600',
    href: '/category/moms-made-united',
    icon: Users,
    color: 'from-purple-500 to-violet-600'
  },
  {
    name: 'Home Plants',
    description: 'Indoor greens to brighten and purify your home',
    image: 'https://images.unsplash.com/photo-1501004318641-b39e6451bec6?q=80&w=1200&auto=format&fit=crop',
    href: '/category/home-plants',
    icon: Heart,
    color: 'from-emerald-500 to-teal-600'
  },
  {
    name: 'Beauty Homemade',
    description: 'Natural, handcrafted skincare and self-care',
    image: 'https://images.pexels.com/photos/3738348/pexels-photo-3738348.jpeg?auto=compress&cs=tinysrgb&w=600',
    href: '/category/beauty-homemade',
    icon: Heart,
    color: 'from-pink-500 to-rose-600'
  },
  {
    name: 'Homemade Households',
    description: 'Eco-friendly essentials for everyday living',
    image: 'https://images.pexels.com/photos/3736397/pexels-photo-3736397.jpeg?auto=compress&cs=tinysrgb&w=600',
    href: '/category/homemade-households',
    icon: Zap,
    color: 'from-cyan-500 to-blue-600'
  },
  {
    name: 'Birthday Gifts',
    description: 'Thoughtful handmade gifts to celebrate moments',
    image: 'https://images.pexels.com/photos/1303093/pexels-photo-1303093.jpeg?auto=compress&cs=tinysrgb&w=600',
    href: '/category/birthday-gifts',
    icon: Zap,
    color: 'from-yellow-500 to-amber-600'
  },
  {
    name: 'Home Decor',
    description: 'Artisanal decor to style your space beautifully',
    image: 'https://images.pexels.com/photos/1571458/pexels-photo-1571458.jpeg?auto=compress&cs=tinysrgb&w=600',
    href: '/category/home-decor',
    icon: Users,
    color: 'from-indigo-500 to-blue-700'
  },
  {
    name: 'Packed Food',
    description: 'Tasty homemade snacks and preserves',
    image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?q=80&w=1200&auto=format&fit=crop',
    href: '/category/packed-food',
    icon: ShoppingBag,
    color: 'from-orange-500 to-red-600'
  },
  {
    name: 'Charity Bakes',
    description: 'Bake sales and sweet treats for good causes',
    image: 'https://images.pexels.com/photos/291528/pexels-photo-291528.jpeg?auto=compress&cs=tinysrgb&w=600',
    href: '/category/charity-bakes',
    icon: Heart,
    color: 'from-fuchsia-500 to-purple-600'
  },
  {
    name: 'Scrap Books',
    description: 'Custom scrapbooks and memory keepsakes',
    image: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=1200&auto=format&fit=crop',
    href: '/category/scrap-books',
    icon: Users,
    color: 'from-slate-500 to-gray-700'
  }
];

const stats = [
  { label: 'Total Raised', value: totalRaised, prefix: '', animate: true },
  { label: 'Active Projects', value: 12, animate: true },
  { label: 'Happy Sellers', value: 150, animate: true },
  { label: 'Items Sold', value: 2847, animate: true }
];

export function Home() {
  // const [projects, setProjects] = useState<Project[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [isCarouselPaused, setIsCarouselPaused] = useState(false);
  const navigate = useNavigate();
  
  
  const { ref: statsRef, isInView: statsInView } = useScrollAnimation();
  const { ref: categoriesRef } = useScrollAnimation();
  const { ref: productsRef, isInView: productsInView } = useScrollAnimation();
  const { ref: projectsRef, isInView: projectsInView } = useScrollAnimation();

  useEffect(() => {
    const loadData = async () => {
      // Projects are now hardcoded in the carousel component
      // No need to fetch separately as we display all 7 EWSELLS projects
      
      try {
        // Try to load admin-approved trending products first
        const trending = await firestoreService.getTrendingProducts(8);
        if (trending && trending.length > 0) {
          console.log('Loaded trending products:', trending);
          setProducts(trending);
          return;
        }

        // Fallback to regular published products
        const fetchedProducts = await firestoreService.getProducts();
        console.log('Fetched products from Firebase:', fetchedProducts);
        if (fetchedProducts && fetchedProducts.length > 0) {
          const topProducts = fetchedProducts.slice(0, 8);
          console.log('Setting top products:', topProducts);
          setProducts(topProducts);
        } else {
          // Fallback to mock data if no products in database
          console.log('No products found in Firebase, using mock data');
          setProducts(mockProducts.slice(0, 8));
        }
      } catch (error) {
        console.error('Error loading products:', error);
        // Fallback to mock data on error
        console.log('Error occurred, using mock data');
        setProducts(mockProducts.slice(0, 8));
      }
    };

    loadData();
  }, []);
  
  // Debug: Log products state changes
  useEffect(() => {
    console.log('Products state updated:', products);
  }, [products]);

  // Smooth-scroll to the Featured Projects (Green Cup) section
  const scrollToGreenCup = (e?: React.MouseEvent<HTMLButtonElement | HTMLAnchorElement>) => {
    console.log('View Projects button clicked!'); // Test if button is clickable
    
    if (e) e.preventDefault();
    
    const el = document.getElementById('green-cup');
    console.log('Found element:', el);
    
    if (el) {
      // Simple, reliable scroll method
      const offsetTop = el.offsetTop - 100; // Account for header
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
      
      // Update URL hash
      window.location.hash = 'green-cup';
    } else {
      console.error('Element with id "green-cup" not found');
      // Try to find the section by class or other means
      const section = document.querySelector('section[id="green-cup"]');
      console.log('Backup search found:', section);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Modern Clean Hero Section */}
      <section className="min-h-screen flex items-center justify-center py-20 relative overflow-hidden">
        {/* Enhanced Background with Subtle Patterns */}
        <div className="absolute inset-0 bg-gradient-to-br from-surface via-background to-surface">
          <div className="absolute inset-0 bg-gradient-to-tr from-gold/5 via-transparent to-purple/5" />
          <div className="absolute inset-0 opacity-30" style={{
            backgroundImage: `radial-gradient(circle at 25% 25%, rgba(255, 215, 0, 0.1) 0%, transparent 50%), 
                             radial-gradient(circle at 75% 75%, rgba(168, 85, 247, 0.1) 0%, transparent 50%)`,
          }} />
        </div>
        
        {/* Animated Grid Pattern */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
            backgroundImage: `linear-gradient(rgba(255, 215, 0, 0.1) 1px, transparent 1px), 
                             linear-gradient(90deg, rgba(255, 215, 0, 0.1) 1px, transparent 1px)`,
            backgroundSize: '50px 50px',
          }} />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center max-w-7xl mx-auto">
            
            {/* Left Column - Main Content */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="space-y-8"
            >
              {/* Hero Title */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="space-y-6"
              >
                <div className="relative">
                  <h1 className="text-5xl md:text-7xl font-bold leading-tight relative z-10">
                    <span className="text-foreground drop-shadow-sm">Shop with</span>
                    <br />
                    <span className="bg-gradient-to-r from-gold via-amber-400 to-gold bg-clip-text text-transparent relative">
                      Purpose
                      {/* Subtle accent line */}
                      <div className="absolute -bottom-1 left-0 w-20 h-0.5 bg-gradient-to-r from-gold to-amber-400 rounded-full opacity-60" />
                    </span>
                  </h1>
                  
                  {/* Subtle glow effect */}
                  <div className="absolute top-8 -left-4 w-32 h-32 bg-gold/10 rounded-full blur-3xl opacity-50" />
                  <div className="absolute bottom-4 right-0 w-24 h-24 bg-amber-400/10 rounded-full blur-2xl opacity-40" />
                </div>
                
                <div className="relative">
                  <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl leading-relaxed relative z-10">
                    Every purchase creates{' '}
                    <span className="text-gold font-semibold">impact</span>. Transparent charity giving meets quality products.
                  </p>
                  
                  {/* Decorative accent */}
                  <div className="absolute -left-2 top-2 w-1 h-16 bg-gradient-to-b from-gold/60 to-transparent rounded-full" />
                </div>
              </motion.div>

              {/* Enhanced CTA Buttons */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 1.2 }}
                className="flex flex-col sm:flex-row gap-6"
              >
                <motion.div 
                  whileHover={{ scale: 1.05, y: -2 }} 
                  whileTap={{ scale: 0.95 }}
                  className="relative group"
                >
                  <Button asChild size="lg" className="relative bg-gradient-to-r from-gold to-amber-400 hover:from-gold/90 hover:to-amber-400/90 text-black font-bold px-10 py-5 rounded-2xl shadow-xl hover:shadow-2xl hover:shadow-gold/30 transition-all duration-300">
                    <Link to="/products" className="flex items-center">
                      Start Shopping
                      <ArrowRight className="ml-3 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                    </Link>
                  </Button>
                  {/* Glow effect */}
                  <div className="absolute inset-0 bg-gradient-to-r from-gold to-amber-400 rounded-2xl blur-xl opacity-30 group-hover:opacity-50 transition-opacity duration-300 -z-10" />
                </motion.div>
                
                <motion.div 
                  whileHover={{ scale: 1.05, y: -2 }} 
                  whileTap={{ scale: 0.95 }}
                  className="relative group"
                >
                  <Button 
                    size="lg" 
                    variant="outline" 
                    onClick={scrollToGreenCup}
                    className="relative border-2 border-gold/40 hover:border-gold text-foreground hover:bg-gold/10 px-10 py-5 rounded-2xl backdrop-blur-sm bg-card/30 hover:shadow-xl hover:shadow-gold/20 transition-all duration-300 flex items-center"
                  >
                    View Projects
                    <Eye className="ml-3 h-5 w-5 group-hover:scale-110 transition-transform duration-300" />
                  </Button>
                  {/* Subtle border glow */}
                  <div className="absolute inset-0 border-2 border-gold/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
                </motion.div>
              </motion.div>
            </motion.div>

            {/* Right Column - Visual Elements */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="relative"
            >
              {/* Impact Stats Cards */}
              <div className="grid grid-cols-2 gap-6 mb-8">
                {[
                  { value: 'Most', label: 'Goes to Charity', icon: Heart, color: 'from-red-500 to-pink-500' },
                  { value: 'Full', label: 'Seller Keeps', icon: Users, color: 'from-green-500 to-emerald-500' },
                  { value: '∞', label: 'Impact Created', icon: Zap, color: 'from-gold to-amber-500' },
                  { value: '2.8K+', label: 'Items Sold', icon: ShoppingBag, color: 'from-blue-500 to-cyan-500' }
                ].map((stat, index) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 0.6 + index * 0.1 }}
                    whileHover={{ scale: 1.05, y: -5 }}
                    className="relative group"
                  >
                    <div className="relative bg-gradient-to-br from-card/80 to-card/40 backdrop-blur-xl border border-border/30 rounded-3xl p-6 text-center hover:border-gold/50 transition-all duration-500 hover:shadow-2xl hover:shadow-gold/20 group overflow-hidden">
                      {/* Animated background glow */}
                      <div className="absolute inset-0 bg-gradient-to-br from-gold/10 via-transparent to-purple/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                      
                      {/* Icon with enhanced styling */}
                      <div className={`relative w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-r ${stat.color} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                        <stat.icon className="w-7 h-7 text-white drop-shadow-sm" />
                        {/* Subtle glow effect */}
                        <div className={`absolute inset-0 rounded-2xl bg-gradient-to-r ${stat.color} blur-md opacity-50 -z-10`} />
                      </div>
                      
                      {/* Enhanced typography */}
                      <div className="relative z-10">
                        <div className="text-3xl font-bold text-foreground mb-2 group-hover:text-gold transition-colors duration-300">{stat.value}</div>
                        <div className="text-sm text-muted-foreground font-medium">{stat.label}</div>
                      </div>
                      
                      {/* Subtle border animation */}
                      <div className="absolute inset-0 rounded-3xl border border-gold/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Enhanced Floating Elements */}
              <div className="absolute inset-0 -z-10 overflow-hidden">
                {/* Geometric shapes */}
                <motion.div
                  className="absolute top-10 right-10 w-16 h-16 border border-gold/20 rounded-lg rotate-45"
                  animate={{ rotate: [45, 90, 45] }}
                  transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
                />
                <motion.div
                  className="absolute bottom-20 left-10 w-8 h-8 bg-gradient-to-r from-gold/30 to-amber-400/30 rounded-full"
                  animate={{ scale: [1, 1.2, 1], opacity: [0.3, 0.6, 0.3] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                />
                <motion.div
                  className="absolute top-1/2 right-1/4 w-12 h-12 border-2 border-purple/20 rounded-full"
                  animate={{ y: [0, -15, 0] }}
                  transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                />
                
                {/* Floating particles */}
                {[...Array(8)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute w-1.5 h-1.5 bg-gold/30 rounded-full"
                    style={{
                      left: `${15 + i * 12}%`,
                      top: `${20 + (i % 3) * 25}%`,
                    }}
                    animate={{
                      y: [0, -25, 0],
                      opacity: [0.2, 0.7, 0.2],
                      scale: [1, 1.3, 1],
                    }}
                    transition={{
                      duration: 4 + i * 0.3,
                      repeat: Infinity,
                      ease: "easeInOut",
                      delay: i * 0.2,
                    }}
                  />
                ))}
              </div>

              {/* Trust Indicators */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6, delay: 1.2 }}
                className="bg-card/30 backdrop-blur-sm border border-border/30 rounded-2xl p-6"
              >
                <div className="text-center">
                  <div className="text-3xl font-bold text-gold mb-2">{formatCurrency(totalRaised)}</div>
                  <div className="text-sm text-muted-foreground mb-4">Total Raised for Charity</div>
                  <div className="flex justify-center space-x-4 text-xs text-muted-foreground">
                    <span>• Transparent</span>
                    <span>• Verified</span>
                    <span>• Impactful</span>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Removed the duplicate Trending Products section */}
      
      {/* Stats Section */}
      <section ref={statsRef} className="py-20 bg-surface relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-gold/5 to-transparent" />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 30 }}
                animate={statsInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="text-3xl md:text-4xl font-bold text-gold mb-2">
                  <AnimatedCounter 
                    value={stat.value} 
                    prefix={stat.prefix} 
                    duration={2000}
                  />
                </div>
                <p className="text-muted-foreground text-sm md:text-base">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section ref={categoriesRef} className="py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Shop by Category</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Discover unique items across our diverse marketplace, each purchase 
              supporting meaningful causes
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {categories.map((category) => (
              <motion.div
                key={category.name}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="group"
              >
                <Link 
                  to={category.href}
                  onClick={(e) => {
                    if (!auth.currentUser) {
                      e.preventDefault();
                      navigate('/login', { state: { from: category.href } });
                    }
                  }}
                >
                  <Card className="overflow-hidden h-80 relative">
                    <div className="absolute inset-0">
                      <img
                        src={category.image}
                        alt={category.name}
                        loading="lazy"
                        decoding="async"
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                        onError={(e) => {
                          const t = e.currentTarget;
                          if (t.src !== '/images/charity-background.svg') {
                            t.src = '/images/charity-background.svg';
                          }
                        }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                    </div>
                    
                    <CardContent className="relative z-10 p-6 h-full flex flex-col justify-end">
                      <div className="mb-4">
                        <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${category.color} flex items-center justify-center mb-4`}>
                          <category.icon className="h-6 w-6 text-white" />
                        </div>
                        <h3 className="text-2xl font-bold mb-2">{category.name}</h3>
                        <p className="text-gray-300">{category.description}</p>
                      </div>
                      
                      <Button variant="outline" className="w-fit group-hover:bg-gold group-hover:text-black transition-colors">
                        Explore <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Category-Based Trending Products */}
      <div ref={productsRef} className="relative z-20" style={{ position: 'relative', zIndex: 20 }}>
        {products && products.length > 0 ? (
          <CategoryTrendingProducts products={products} isInView={productsInView} />
        ) : (
          <div className="py-20 text-center">
            <h3 className="text-2xl font-bold mb-4">Loading trending products...</h3>
          </div>
        )}
      </div>

      {/* Featured Projects */}
      <section id="green-cup" ref={projectsRef} className="py-24 relative overflow-hidden" style={{ position: 'relative', zIndex: 10 }}>
        {/* Enhanced Background Elements */}
        <div className="absolute inset-0 bg-gradient-to-br from-background via-surface/50 to-background">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-gold/3 via-transparent to-primary/3" />
          <div className="absolute top-1/4 left-1/6 w-96 h-96 bg-gradient-to-r from-gold/10 to-amber/5 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-1/3 right-1/6 w-80 h-80 bg-gradient-to-l from-primary/8 to-blue/3 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-r from-emerald/5 to-teal/3 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '2s' }} />
          
          {/* Floating Particles */}
          <motion.div 
            className="absolute inset-0"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 2 }}
          >
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 bg-gold/20 rounded-full"
                style={{
                  left: `${20 + i * 15}%`,
                  top: `${30 + (i % 2) * 40}%`,
                }}
                animate={{
                  y: [0, -20, 0],
                  opacity: [0.3, 0.8, 0.3],
                }}
                transition={{
                  duration: 3 + i * 0.5,
                  repeat: Infinity,
                  delay: i * 0.8,
                }}
              />
            ))}
          </motion.div>
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={projectsInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-center mb-20"
          >
            {/* Enhanced Title with Gradient */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={projectsInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative inline-block mb-6"
            >
              <h2 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-gold via-amber-400 to-gold bg-clip-text text-transparent relative">
                Featured Projects
                <motion.div
                  className="absolute -inset-4 bg-gradient-to-r from-gold/20 via-transparent to-gold/20 rounded-2xl blur-xl"
                  animate={{
                    opacity: [0.3, 0.6, 0.3],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                  }}
                />
              </h2>
            </motion.div>

            {/* Enhanced Subtitle */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={projectsInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="relative"
            >
              <p className="text-muted-foreground text-xl md:text-2xl max-w-4xl mx-auto leading-relaxed font-light">
                Support meaningful causes through our curated projects. Every contribution creates lasting impact in communities worldwide.
              </p>
              
              {/* Decorative Line */}
              <motion.div
                initial={{ width: 0 }}
                animate={projectsInView ? { width: "100px" } : {}}
                transition={{ duration: 0.8, delay: 0.6 }}
                className="h-1 bg-gradient-to-r from-transparent via-gold to-transparent mx-auto mt-6 rounded-full"
              />
            </motion.div>

            {/* Stats Cards */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={projectsInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.8 }}
              className="flex flex-wrap justify-center gap-6 mt-12"
            >
              {[
                { label: "Active Projects", value: "7", icon: "🎯" },
                { label: "Lives Impacted", value: "200K+", icon: "❤️" },
                { label: "Funds Raised", value: "₹15Cr+", icon: "💰" }
              ].map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={projectsInView ? { opacity: 1, scale: 1 } : {}}
                  transition={{ duration: 0.5, delay: 1 + index * 0.1 }}
                  whileHover={{ scale: 1.05, y: -5 }}
                  className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl px-6 py-4 min-w-[140px] group hover:bg-white/10 transition-all duration-300"
                >
                  <div className="text-2xl mb-1">{stat.icon}</div>
                  <div className="text-2xl font-bold text-gold group-hover:text-amber-400 transition-colors">
                    {stat.value}
                  </div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </div>

        {/* Full-Width Animated Projects Carousel */}
        <div className="relative overflow-hidden w-full">
          {/* Moving Animation Container */}
          <motion.div 
            className="flex gap-6 pl-6"
            animate={isCarouselPaused ? {} : { 
              x: [0, -2240] 
            }}
            transition={{
              duration: 30,
              repeat: Infinity,
              ease: "linear"
            }}
          >
            {/* All 7 EWSELLS Projects - Duplicated for seamless loop */}
            {(() => {
              const projects = [
                {
                  id: 1,
                  title: 'Be a Proud Indian',
                  description: 'Spreads awareness of the Indian Constitution and BNS laws, starting with schools and colleges.',
                  focusArea: 'Civic Education & Legal Awareness',
                  currentRaised: 32500000,
                  goalAmount: 50000000,
                  region: 'India',
                  status: 'Active',
                  image: 'https://images.unsplash.com/photo-1524749292158-7540c2494485?q=80&w=1200&auto=format&fit=crop',
                  fundedPercent: 65,
                  color: 'from-blue-500 to-indigo-600',
                  stats: { beneficiaries: '50K+', institutions: '200+', workshops: '500+' }
                },
                {
                  id: 2,
                  title: 'You Have Rights',
                  description: 'A public initiative helping especially the elderly and vulnerable understand and access their legal rights.',
                  focusArea: 'Civil Rights & Public Support',
                  currentRaised: 18500000,
                  goalAmount: 30000000,
                  region: 'India',
                  status: 'Active',
                  image: 'https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?q=80&w=1200&auto=format&fit=crop',
                  fundedPercent: 62,
                  color: 'from-purple-500 to-violet-600',
                  stats: { helpedFamilies: '25K+', schemes: '100+', centers: '50+' }
                },
                {
                  id: 3,
                  title: 'Green Revive Genesis',
                  description: 'Encouraging students and communities to embrace eco-conscious living and protect nature.',
                  focusArea: 'Environmental Protection & Eco-Tourism',
                  currentRaised: 22000000,
                  goalAmount: 35000000,
                  region: 'India',
                  status: 'Active',
                  image: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=1200&auto=format&fit=crop',
                  fundedPercent: 63,
                  color: 'from-green-500 to-emerald-600',
                  stats: { bagsDistributed: '100K+', plasticSaved: '50T+', volunteers: '5K+' }
                },
                {
                  id: 4,
                  title: 'Pathway to Progress',
                  description: 'Designed for underprivileged children, this project offers educational opportunities and entrepreneurship training.',
                  focusArea: 'Education & Child Empowerment',
                  currentRaised: 28700000,
                  goalAmount: 40000000,
                  region: 'India',
                  status: 'Active',
                  image: 'https://images.unsplash.com/photo-1497486751825-1233686d5d80?q=80&w=1200&auto=format&fit=crop',
                  fundedPercent: 72,
                  color: 'from-amber-500 to-orange-600',
                  stats: { children: '15K+', scholarships: '2K+', programs: '100+' }
                },
                {
                  id: 5,
                  title: 'Reform Home',
                  description: 'A psychological first-aid and community hub, more than a counseling center—a movement of collective growth.',
                  focusArea: 'Mental Health & Community Support',
                  currentRaised: 15800000,
                  goalAmount: 25000000,
                  region: 'India',
                  status: 'Active',
                  image: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?q=80&w=1200&auto=format&fit=crop',
                  fundedPercent: 63,
                  color: 'from-pink-500 to-rose-600',
                  stats: { sessions: '10K+', counselors: '200+', communities: '75+' }
                },
                {
                  id: 6,
                  title: 'Helping Hands',
                  description: 'A support fund initiative powered by money raised from EWSELLS. Offers financial help for medical needs.',
                  focusArea: 'Medical & Community Development Support',
                  currentRaised: 45300000,
                  goalAmount: 75600000,
                  region: 'India',
                  status: 'Active',
                  image: 'https://images.unsplash.com/photo-1559757175-0eb30cd8c063?q=80&w=1200&auto=format&fit=crop',
                  fundedPercent: 60,
                  color: 'from-red-500 to-pink-500',
                  stats: { fundsRaised: '₹50L+', familiesHelped: '5K+', projects: '300+' }
                },
                {
                  id: 7,
                  title: 'HELPRING',
                  description: 'India\'s first youth-run hybrid offline-online volunteering program providing emotional and mental support.',
                  focusArea: 'Emotional, Legal & Mental Support',
                  currentRaised: 12500000,
                  goalAmount: 20000000,
                  region: 'India',
                  status: 'Active',
                  image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1200&auto=format&fit=crop',
                  fundedPercent: 63,
                  color: 'from-cyan-500 to-blue-600',
                  stats: { calls: '25K+', volunteers: '1K+', districts: '100+' }
                }
              ];
              
              // Create seamless loop by duplicating projects
              const duplicatedProjects = [...projects, ...projects];
              
              return duplicatedProjects.map((project, index) => (
              <motion.div
                key={`${project.id}-${index}`}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={projectsInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.6, delay: (index % 7) * 0.1 }}
                className="group flex-shrink-0 w-72 sm:w-80"
                whileHover={{ scale: 1.05, y: -10 }}
                onMouseEnter={() => setIsCarouselPaused(true)}
                onMouseLeave={() => setIsCarouselPaused(false)}
              >
                <Card className="overflow-hidden bg-gradient-to-br from-card/95 via-card/80 to-card/60 backdrop-blur-xl border border-border/30 hover:border-gold/60 transition-all duration-700 hover:shadow-2xl hover:shadow-gold/30 h-full relative group-hover:bg-gradient-to-br group-hover:from-card/98 group-hover:via-gold/5 group-hover:to-card/80">
                  {/* Project Image */}
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      onError={(e) => {
                        const t = e.currentTarget;
                        if (t.src !== '/images/charity-background.svg') {
                          t.src = '/images/charity-background.svg';
                        }
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
                    
                    {/* Project Number Badge */}
                    <div className="absolute top-3 left-3">
                      <div className={`w-10 h-10 rounded-xl bg-gradient-to-r ${project.color} flex items-center justify-center shadow-lg`}>
                        <span className="text-white font-bold text-sm">{project.id}</span>
                      </div>
                    </div>

                    {/* Status Badge */}
                    <div className="absolute top-3 right-3">
                      <span className="px-2 py-1 text-xs bg-gold text-black rounded-md font-semibold backdrop-blur-sm">
                        {project.status}
                      </span>
                    </div>

                    {/* Funding Progress - Bottom Overlay */}
                    <div className="absolute bottom-0 left-0 right-0 p-4">
                      <div className="mb-2">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-white font-bold text-sm">
                            {formatCurrency(project.currentRaised)}
                          </span>
                          <span className="text-white/80 text-xs">
                            of {formatCurrency(project.goalAmount)}
                          </span>
                        </div>
                        <div className="w-full bg-white/20 rounded-full h-2">
                          <motion.div 
                            className="bg-gold h-2 rounded-full"
                            initial={{ width: 0 }}
                            animate={{ width: `${project.fundedPercent}%` }}
                            transition={{ duration: 2, delay: (index % 7) * 0.2 }}
                          />
                        </div>
                        <div className="text-center mt-1">
                          <span className="text-white text-xs font-medium">{project.fundedPercent}% Funded</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Project Content */}
                  <div className="p-5">
                    <div className="mb-3">
                      <h3 className="text-xl font-bold mb-2 group-hover:text-gold transition-colors line-clamp-1">
                        {project.title}
                      </h3>
                      <div className="text-xs text-gold font-medium mb-2">
                        {project.focusArea}
                      </div>
                    </div>
                    
                    <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
                      {project.description}
                    </p>

                    {/* Stats Grid */}
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      {Object.entries(project.stats).slice(0, 3).map(([key, value]) => (
                        <div key={key} className="text-center bg-white/5 rounded-lg p-2">
                          <div className="text-gold font-bold text-xs">{value}</div>
                          <div className="text-xs text-muted-foreground capitalize">
                            {key.replace(/([A-Z])/g, ' $1').trim()}
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-2">
                      <Button 
                        className="flex-1 bg-gold hover:bg-gold/90 text-black font-semibold h-9 text-sm"
                        onClick={(e) => {
                          if (!auth.currentUser) {
                            e.preventDefault();
                            navigate('/login', { state: { from: `/project/${project.id}` } });
                          } else {
                            navigate(`/project/${project.id}`);
                          }
                        }}
                      >
                        Support Now
                      </Button>
                      <Button 
                        variant="outline" 
                        size="icon"
                        className="border-white/20 hover:border-gold/50 hover:bg-white/10 h-9 w-9"
                        onClick={(e) => {
                          e.stopPropagation();
                          // Add to favorites logic
                        }}
                      >
                        <Heart className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              </motion.div>
              ));
            })()}
          </motion.div>
        </div>

        {/* View All Projects Button */}
        <div className="container mx-auto px-4 relative z-10 mt-16">
          <motion.div
            initial={{ opacity: 0 }}
            animate={projectsInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="text-center"
          >
            <Button asChild size="lg" variant="outline" className="border-gold/30 hover:border-gold hover:bg-gold/10 px-8">
              <Link to="/projects">
                View All Projects
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-gold/20 to-transparent" />
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-4xl font-bold mb-6"
            >
              Ready to Make a Difference?
            </motion.h2>
            
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-lg text-muted-foreground mb-8"
            >
              Join thousands of conscious shoppers creating positive impact 
              with every purchase. Your shopping choices matter.
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Button asChild size="lg">
                <Link to="/products">Start Shopping Now</Link>
              </Button>
              
              <Button asChild size="lg" variant="outline">
                <Link to="/become-seller">Become a Seller</Link>
              </Button>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}