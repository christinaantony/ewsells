import { useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function SellerPromotionsCheckout() {
  const [params] = useSearchParams();
  const navigate = useNavigate();

  const requestId = params.get('requestId') || '';
  const total = useMemo(() => {
    const t = Number(params.get('total'));
    return Number.isFinite(t) && t > 0 ? t : 0;
  }, [params]);

  return (
    <div className="container mx-auto px-6 py-12">
      <div className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Promotion Checkout</h1>
        <div className="mt-1 h-0.5 w-28 bg-gradient-to-r from-gold via-amber-400 to-gold rounded-full" />
        <p className="text-muted-foreground mt-3">Complete your payment to submit your promotion request for review.</p>
      </div>

      <div className="max-w-xl">
        <Card className="p-6 space-y-4 bg-white/5 border-white/10 backdrop-blur-sm">
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">Request ID</div>
            <div className="font-mono text-sm">{requestId ? requestId : '—'}</div>
          </div>
          <div className="flex items-center justify-between">
            <div className="text-sm text-muted-foreground">Amount to Pay</div>
            <div className="text-2xl font-semibold">₹{total}</div>
          </div>
          <div className="text-xs text-muted-foreground">Amount and duration are configured by Admin.</div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <Button className="w-full bg-gold text-black hover:bg-gold/90" onClick={() => navigate('/seller/promotions')}>Pay Now</Button>
            <Button variant="outline" className="w-full" onClick={() => navigate('/seller/promotions')}>Cancel</Button>
          </div>
        </Card>
        <div className="mt-4 text-xs text-muted-foreground">
          Note: Integrate your payment gateway here. After successful payment, you can mark the request as paid or handle it via webhook.
        </div>
      </div>
    </div>
  );
}
