import { motion } from 'framer-motion';
import { 
  Heart, 
  Users, 
  Leaf, 
  GraduationCap, 
  Brain, 
  HandHeart, 
  Phone,
  ArrowRight,
  Target,
  Lightbulb,
  TrendingUp,
  Shield,
  Globe,
  BookOpen,
  Headphones
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const projects = [
  {
    id: 1,
    title: 'Be a Proud Indian',
    focusArea: 'Civic Education & Legal Awareness',
    description: 'Spreads awareness of the Indian Constitution and BNS laws, starting with schools and colleges. Through webinars, workshops, and campaigns, it nurtures students into informed and responsible citizens.',
    objectives: [
      'Promote legal literacy across educational institutions',
      'Foster civic pride and constitutional awareness',
      'Build responsible citizenship through education'
    ],
    impact: 'A generation empowered to uphold justice and democracy',
    icon: Shield,
    color: 'from-blue-500 to-indigo-600',
    bgGradient: 'from-blue-500/10 to-indigo-600/10',
    image: 'https://images.unsplash.com/photo-1524749292158-7540c2494485?q=80&w=1200&auto=format&fit=crop',
    stats: { beneficiaries: '50K+', institutions: '200+', workshops: '500+' }
  },
  {
    id: 2,
    title: 'You Have Rights',
    focusArea: 'Civil Rights & Public Support',
    description: 'A public initiative helping especially the elderly and vulnerable understand and access their legal rights, government services, and welfare schemes.',
    objectives: [
      'Guide citizens to claim their entitlements',
      'Ensure dignity and security for vulnerable populations',
      'Bridge the gap between rights and access'
    ],
    impact: 'No one left behind in accessing their rights',
    icon: Users,
    color: 'from-purple-500 to-violet-600',
    bgGradient: 'from-purple-500/10 to-violet-600/10',
    image: 'https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?q=80&w=1200&auto=format&fit=crop',
    stats: { helpedFamilies: '25K+', schemes: '100+', centers: '50+' }
  },
  {
    id: 3,
    title: 'Green Revive Genesis',
    focusArea: 'Environmental Protection & Eco-Tourism',
    description: 'Encouraging students and communities to embrace eco-conscious living and protect nature. The "A Bag for a Life" campaign promotes eco-friendly habits and reduces plastic waste.',
    objectives: [
      'Promote sustainable eco-tourism practices',
      'Reduce plastic use in tourist areas',
      'Create environmental awareness in communities'
    ],
    impact: 'Students and communities become eco-leaders of the future',
    icon: Leaf,
    color: 'from-green-500 to-emerald-600',
    bgGradient: 'from-green-500/10 to-emerald-600/10',
    image: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?q=80&w=1200&auto=format&fit=crop',
    stats: { bagsDistributed: '100K+', plasticSaved: '50T+', volunteers: '5K+' }
  },
  {
    id: 4,
    title: 'Pathway to Progress',
    focusArea: 'Education & Child Empowerment',
    description: 'Designed for underprivileged children, this project offers educational opportunities and exposure to entrepreneurship and leadership training.',
    objectives: [
      'Provide access to quality education',
      'Develop entrepreneurial skills in youth',
      'Foster leadership and personal growth'
    ],
    impact: 'A stronger generation of leaders breaking the cycle of poverty',
    icon: GraduationCap,
    color: 'from-amber-500 to-orange-600',
    bgGradient: 'from-amber-500/10 to-orange-600/10',
    image: 'https://images.unsplash.com/photo-1497486751825-1233686d5d80?q=80&w=1200&auto=format&fit=crop',
    stats: { children: '15K+', scholarships: '2K+', programs: '100+' }
  },
  {
    id: 5,
    title: 'Reform Home',
    focusArea: 'Mental Health & Community Support',
    description: 'A psychological first-aid and community hub, Reform Home is more than a counseling center—it is a movement of collective growth.',
    objectives: [
      'Provide safe spaces for mental health support',
      'Foster community resilience and healing',
      'Reduce stigma around mental health'
    ],
    impact: 'Communities that reform, recover, and rise together',
    icon: Brain,
    color: 'from-pink-500 to-rose-600',
    bgGradient: 'from-pink-500/10 to-rose-600/10',
    image: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?q=80&w=1200&auto=format&fit=crop',
    stats: { sessions: '10K+', counselors: '200+', communities: '75+' }
  },
  {
    id: 6,
    title: 'Helping Hands',
    focusArea: 'Medical & Community Development Support',
    description: 'A support fund initiative powered by money raised from EWSELLS. It offers financial help for medical needs and grassroots community development projects.',
    objectives: [
      'Support individuals in urgent medical needs',
      'Fund grassroots community development',
      'Provide timely financial assistance'
    ],
    impact: 'Timely relief, restored hope, and strengthened communities',
    icon: HandHeart,
    color: 'from-red-500 to-pink-500',
    bgGradient: 'from-red-500/10 to-pink-500/10',
    image: 'https://images.unsplash.com/photo-1559757175-0eb30cd8c063?q=80&w=1200&auto=format&fit=crop',
    stats: { fundsRaised: '₹50L+', familiesHelped: '5K+', projects: '300+' }
  },
  {
    id: 7,
    title: 'HELPRING',
    focusArea: 'Emotional, Legal & Mental Support (Volunteering)',
    description: 'India\'s first youth-run hybrid offline-online volunteering program. HELPRING provides a listening ear and supportive hand to those who suffer in silence.',
    objectives: [
      'Build a volunteer-driven support system',
      'Reduce loneliness and social isolation',
      'Guide people to appropriate solutions'
    ],
    impact: 'A safer, kinder society where no one suffers alone',
    icon: Phone,
    color: 'from-cyan-500 to-blue-600',
    bgGradient: 'from-cyan-500/10 to-blue-600/10',
    image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1200&auto=format&fit=crop',
    stats: { calls: '25K+', volunteers: '1K+', districts: '100+' }
  }
];

const impactStats = [
  { label: 'Lives Touched', value: '200K+', icon: Heart },
  { label: 'Active Projects', value: '7', icon: Target },
  { label: 'Communities Served', value: '500+', icon: Globe },
  { label: 'Volunteers Engaged', value: '10K+', icon: Users }
];

export function ProjectsPage() {
  const { ref: statsRef, isInView: statsInView } = useScrollAnimation();
  const { ref: projectsRef, isInView: projectsInView } = useScrollAnimation();
  const { ref: impactRef, isInView: impactInView } = useScrollAnimation();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center py-20 relative overflow-hidden">
        {/* Enhanced Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-surface via-background to-surface">
          <div className="absolute inset-0 bg-gradient-to-tr from-gold/5 via-transparent to-purple/5" />
          <div className="absolute inset-0 opacity-30" style={{
            backgroundImage: `radial-gradient(circle at 25% 25%, rgba(255, 215, 0, 0.1) 0%, transparent 50%), 
                             radial-gradient(circle at 75% 75%, rgba(168, 85, 247, 0.1) 0%, transparent 50%)`,
          }} />
        </div>
        
        {/* Animated Grid Pattern */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
            backgroundImage: `linear-gradient(rgba(255, 215, 0, 0.1) 1px, transparent 1px), 
                             linear-gradient(90deg, rgba(255, 215, 0, 0.1) 1px, transparent 1px)`,
            backgroundSize: '50px 50px',
          }} />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-6xl mx-auto text-center">
            
            {/* Hero Content */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="space-y-8"
            >
              {/* Main Title */}
              <div className="relative">
                <motion.h1 
                  className="text-5xl md:text-7xl font-bold leading-tight mb-6"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.4 }}
                >
                  <span className="text-foreground drop-shadow-sm">Our Projects Under</span>
                  <br />
                  <span className="bg-gradient-to-r from-gold via-amber-400 to-gold bg-clip-text text-transparent relative">
                    EWSELLS
                    <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-32 h-1 bg-gradient-to-r from-gold to-amber-400 rounded-full opacity-60" />
                  </span>
                </motion.h1>
                
                {/* Tagline */}
                <motion.p 
                  className="text-xl md:text-2xl text-muted-foreground max-w-4xl mx-auto leading-relaxed mb-8"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.8 }}
                >
                  <span className="text-gold font-semibold">EWSELLS | Charity Store Beyond</span> is India's First Online Charity Store, 
                  an initiative by Expectation Walkers. More than a marketplace—a platform of{' '}
                  <span className="text-gold font-semibold">hope, dignity, and empowerment</span>.
                </motion.p>

                {/* Mission Statement */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 1.0 }}
                  className="bg-card/30 backdrop-blur-sm border border-border/30 rounded-2xl p-8 max-w-4xl mx-auto"
                >
                  <p className="text-lg text-muted-foreground leading-relaxed">
                    Every purchase not only supports self-employed individuals but also fuels transformative 
                    community projects that touch lives across{' '}
                    <span className="text-gold font-medium">education, rights, environment, health, and mental well-being</span>.
                  </p>
                </motion.div>

                {/* Decorative elements */}
                <div className="absolute top-8 -left-4 w-32 h-32 bg-gold/10 rounded-full blur-3xl opacity-50" />
                <div className="absolute bottom-4 right-0 w-24 h-24 bg-amber-400/10 rounded-full blur-2xl opacity-40" />
              </div>

              {/* CTA Button */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 1.2 }}
              >
                <motion.div 
                  whileHover={{ scale: 1.05, y: -2 }} 
                  whileTap={{ scale: 0.95 }}
                  className="relative group inline-block"
                >
                  <Button size="lg" className="relative bg-gradient-to-r from-gold to-amber-400 hover:from-gold/90 hover:to-amber-400/90 text-black font-bold px-10 py-5 rounded-2xl shadow-xl hover:shadow-2xl hover:shadow-gold/30 transition-all duration-300">
                    Explore Our Impact
                    <ArrowRight className="ml-3 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
                  </Button>
                  <div className="absolute inset-0 bg-gradient-to-r from-gold to-amber-400 rounded-2xl blur-xl opacity-30 group-hover:opacity-50 transition-opacity duration-300 -z-10" />
                </motion.div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Impact Stats Section */}
      <section ref={statsRef} className="py-20 bg-surface relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-gold/5 to-transparent" />
        
        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={statsInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Collective Impact</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Together, these seven initiatives form a holistic ecosystem of empowerment
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {impactStats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 30 }}
                animate={statsInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center group"
              >
                <div className="relative mb-4">
                  <div className="w-16 h-16 mx-auto bg-gradient-to-r from-gold to-amber-400 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                    <stat.icon className="w-8 h-8 text-black" />
                  </div>
                  <div className="absolute inset-0 w-16 h-16 mx-auto bg-gradient-to-r from-gold to-amber-400 rounded-2xl blur-md opacity-50 -z-10" />
                </div>
                <div className="text-3xl md:text-4xl font-bold text-gold mb-2">{stat.value}</div>
                <p className="text-muted-foreground text-sm md:text-base">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section ref={projectsRef} className="py-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={projectsInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Seven Pillars of Change</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Each project addresses a critical aspect of community development and empowerment
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 30 }}
                animate={projectsInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="group"
              >
                <Card className="overflow-hidden h-full bg-card/30 backdrop-blur-sm border-border/30 hover:border-gold/30 transition-all duration-500 hover:shadow-2xl hover:shadow-gold/10">
                  {/* Project Image */}
                  <div className="relative h-64 overflow-hidden">
                    <img
                      src={project.image}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      onError={(e) => {
                        const t = e.currentTarget;
                        if (t.src !== '/images/charity-background.svg') {
                          t.src = '/images/charity-background.svg';
                        }
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                    
                    {/* Project Icon */}
                    <div className="absolute top-4 left-4">
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${project.color} flex items-center justify-center shadow-lg`}>
                        <project.icon className="w-6 h-6 text-white" />
                      </div>
                    </div>

                    {/* Project Number */}
                    <div className="absolute top-4 right-4">
                      <div className="w-10 h-10 bg-gold/90 rounded-full flex items-center justify-center text-black font-bold text-lg">
                        {project.id}
                      </div>
                    </div>
                  </div>

                  <CardContent className="p-6">
                    {/* Project Header */}
                    <div className="mb-6">
                      <h3 className="text-2xl font-bold mb-2 group-hover:text-gold transition-colors">
                        {project.title}
                      </h3>
                      <div className="flex items-center gap-2 mb-3">
                        <Target className="w-4 h-4 text-gold" />
                        <span className="text-sm font-medium text-gold">{project.focusArea}</span>
                      </div>
                      <p className="text-muted-foreground leading-relaxed">
                        {project.description}
                      </p>
                    </div>

                    {/* Objectives */}
                    <div className="mb-6">
                      <div className="flex items-center gap-2 mb-3">
                        <Lightbulb className="w-4 h-4 text-amber-400" />
                        <span className="font-semibold text-sm">Key Objectives</span>
                      </div>
                      <ul className="space-y-2">
                        {project.objectives.map((objective, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                            <div className="w-1.5 h-1.5 bg-gold rounded-full mt-2 flex-shrink-0" />
                            {objective}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Impact */}
                    <div className="mb-6">
                      <div className="flex items-center gap-2 mb-3">
                        <TrendingUp className="w-4 h-4 text-green-400" />
                        <span className="font-semibold text-sm">Expected Impact</span>
                      </div>
                      <p className="text-sm text-green-400 font-medium italic">
                        "{project.impact}"
                      </p>
                    </div>

                    {/* Stats */}
                    <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border/30">
                      {Object.entries(project.stats).map(([key, value]) => (
                        <div key={key} className="text-center">
                          <div className="text-lg font-bold text-gold">{value}</div>
                          <div className="text-xs text-muted-foreground capitalize">
                            {key.replace(/([A-Z])/g, ' $1').trim()}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why These Projects Matter Section */}
      <section ref={impactRef} className="py-20 bg-surface relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-gold/5 via-transparent to-purple/5" />
        
        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={impactInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="max-w-4xl mx-auto text-center"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-8">Why These Projects Matter</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              {[
                { icon: BookOpen, title: 'Civic Knowledge', subtitle: 'Be a Proud Indian', color: 'from-blue-500 to-indigo-600' },
                { icon: Shield, title: 'Civil Rights', subtitle: 'You Have Rights', color: 'from-purple-500 to-violet-600' },
                { icon: Leaf, title: 'Environmental Care', subtitle: 'Green Revive Genesis', color: 'from-green-500 to-emerald-600' },
                { icon: GraduationCap, title: 'Child Empowerment', subtitle: 'Pathway to Progress', color: 'from-amber-500 to-orange-600' },
                { icon: Brain, title: 'Mental Health', subtitle: 'Reform Home', color: 'from-pink-500 to-rose-600' },
                { icon: HandHeart, title: 'Medical & Community Aid', subtitle: 'Helping Hands', color: 'from-red-500 to-pink-500' },
                { icon: Headphones, title: 'Volunteer Support', subtitle: 'HELPRING', color: 'from-cyan-500 to-blue-600' }
              ].map((item, index) => (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={impactInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="group"
                >
                  <div className="bg-card/30 backdrop-blur-sm border border-border/30 rounded-2xl p-6 text-center hover:border-gold/30 transition-all duration-300 hover:shadow-xl hover:shadow-gold/10">
                    <div className={`w-12 h-12 mx-auto mb-4 rounded-xl bg-gradient-to-r ${item.color} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                      <item.icon className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="font-bold mb-1">{item.title}</h3>
                    <p className="text-sm text-muted-foreground">{item.subtitle}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={impactInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.8 }}
              className="bg-gradient-to-r from-gold/10 to-amber-400/10 backdrop-blur-sm border border-gold/20 rounded-3xl p-8"
            >
              <div className="flex items-center justify-center gap-3 mb-4">
                <Heart className="w-8 h-8 text-gold" />
                <span className="text-2xl font-bold text-gold">✨</span>
              </div>
              <p className="text-xl font-semibold mb-2">
                Every purchase at EWSELLS lights a life
              </p>
              <p className="text-muted-foreground">
                Beyond products, you are fueling <span className="text-gold font-medium">change, healing, and hope</span>.
              </p>
            </motion.div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
