import { Smile, Percent, Package, Star, Heart, Lock, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth } from '@/lib/firebase';
import { ChatInterface } from '@/components/chat/ChatInterface';
import { useAuthGate } from '@/hooks/useAuthGate';
import { Link } from 'react-router-dom';
import { onAuthStateChanged, User } from 'firebase/auth';
import { useEffect, useState } from 'react';

const quickActions = [
  { icon: Star, text: "Popular Items", color: "from-gold to-yellow-600", action: "popular" },
  { icon: Percent, text: "Flash Sales", color: "from-red-500 to-red-600", action: "flash" },
  { icon: Package, text: "Bulk Orders", color: "from-gray-700 to-gray-800", action: "bulk" },
  { icon: Heart, text: "Charity Craft", color: "from-rose-500 to-pink-600", action: "charity" }
];

export default function ChatPage() {
  const { user } = useAuthGate();
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  
  // Force scroll to top on page load/refresh
  useEffect(() => {
    // Immediate scroll to top
    window.scrollTo(0, 0);
    
    // Also use setTimeout to ensure it happens after any rendering
    const timeoutId = setTimeout(() => {
      window.scrollTo(0, 0);
    }, 100);
    
    return () => clearTimeout(timeoutId);
  }, []);

  // Listen to Firebase Auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user);
    });
    return () => unsubscribe();
  }, []);

  // Track chat interactions in Firestore
  const trackInteraction = async (message: string, type: 'user' | 'ai') => {
    // Only track if Firebase user is authenticated
    if (!firebaseUser?.uid) {
      return;
    }

    try {
      await addDoc(collection(db, 'chatInteractions'), {
        userId: firebaseUser.uid,
        message,
        type,
        timestamp: serverTimestamp(),
      });
    } catch (error) {
      console.error('Error tracking interaction:', error);
      // Silently fail - don't show error toast for analytics tracking
    }
  };

  const handleNewMessage = async (content: string) => {
    await trackInteraction(content, 'user');
  };

  // Show login prompt if user is not authenticated
  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-surface to-background flex items-center justify-center">
        <div className="max-w-md mx-auto p-8">
          <div className="text-center space-y-6">
            <div className="relative mx-auto w-20 h-20">
              <div className="w-20 h-20 rounded-3xl bg-gradient-to-r from-gold to-amber-400 flex items-center justify-center shadow-2xl">
                <Lock className="h-10 w-10 text-black" />
              </div>
              <div className="absolute inset-0 bg-gradient-to-r from-gold to-amber-400 rounded-3xl blur-xl opacity-50 -z-10" />
            </div>
            
            <div className="space-y-3">
              <h1 className="text-3xl font-bold text-foreground">Login Required</h1>
              <p className="text-muted-foreground leading-relaxed">
                Please sign in to access Smile Sales AI and start chatting with our intelligent shopping companion.
              </p>
            </div>

            <div className="space-y-4">
              <Button asChild className="w-full bg-gradient-to-r from-gold to-amber-400 hover:from-gold/90 hover:to-amber-400/90 text-black font-semibold py-3 rounded-xl shadow-lg hover:shadow-xl transition-all">
                <Link to="/login" className="flex items-center justify-center gap-2">
                  <LogIn className="h-5 w-5" />
                  Sign In to Continue
                </Link>
              </Button>
              
              <Button asChild variant="outline" className="w-full border-border/50 text-foreground hover:bg-card/50 rounded-xl">
                <Link to="/">
                  Back to Home
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Function to scroll to top
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-surface to-background" id="page-top">
      <div className="container mx-auto max-w-6xl px-4 py-8 pb-24">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="relative">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-r from-gold to-amber-400 flex items-center justify-center shadow-lg">
              <Smile className="h-7 w-7 text-black" />
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-gold to-amber-400 rounded-2xl blur-md opacity-50 -z-10" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-foreground">Smile Sales AI</h1>
            <p className="text-muted-foreground">Your intelligent shopping companion</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Chat Interface */}
          <div className="lg:col-span-3 flex flex-col h-[70vh] min-h-[500px]">
            <ChatInterface 
              onNewMessage={handleNewMessage}
              initialMessages={[
                {
                  role: 'assistant',
                  content: 'Hello! I\'m your Smile Sales AI assistant. I can help you find products, track orders, learn about our charity impact, and answer any questions about our marketplace where every purchase creates positive change.'
                }
              ]}
            />
          </div>
          
          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-card/50 backdrop-blur-sm border border-border/50 rounded-2xl p-6 shadow-lg">
              <h3 className="font-bold text-foreground mb-4 flex items-center gap-2">
                <div className="w-2 h-2 bg-gold rounded-full" />
                Quick Actions
              </h3>
              <div className="space-y-3">
                {quickActions.map((action, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className={`w-full justify-start gap-3 bg-gradient-to-r ${action.color} text-white hover:opacity-90 transition-all border-0 rounded-xl py-3 shadow-md hover:shadow-lg hover:scale-105`}
                    onClick={() => {
                      // Find the chat interface and simulate sending a message based on action
                      const chatInterface = document.querySelector('.chat-interface') as HTMLElement;
                      if (chatInterface) {
                        let message = '';
                        
                        switch(action.action) {
                          case 'popular':
                            message = 'Show me popular items';
                            break;
                          case 'flash':
                            message = 'What are the current flash sales?';
                            break;
                          case 'bulk':
                            message = 'Tell me about bulk order options';
                            break;
                          case 'charity':
                            message = 'Show me charity craft items';
                            break;
                        }
                        
                        if (message) {
                          const event = new CustomEvent('quick-action', { 
                            detail: { message } 
                          });
                          chatInterface.dispatchEvent(event);
                        }
                      }
                    }}
                  >
                    <action.icon className="h-5 w-5" />
                    {action.text}
                  </Button>
                ))}
              </div>
            </div>
            
            {/* Help Section */}
            <div className="bg-card/50 backdrop-blur-sm border border-border/50 rounded-2xl p-6 shadow-lg">
              <h3 className="font-bold text-foreground mb-4 flex items-center gap-2">
                <div className="w-2 h-2 bg-gold rounded-full" />
                Need Help?
              </h3>
              <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                Our AI assistant is here to help 24/7. Ask about products, charity impact, orders, or any questions about Smile Sales.
              </p>
              <Button 
                variant="outline" 
                className="w-full bg-card/30 text-foreground border-border/50 hover:bg-gold/10 hover:border-gold/30 rounded-xl transition-all" 
                onClick={scrollToTop}
              >
                Back to Top
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Help message */}
      <div className="fixed bottom-4 left-4 right-4 flex justify-center pointer-events-none z-10">
        <div className="bg-black/70 text-white text-xs px-4 py-2 rounded-full max-w-xs text-center pointer-events-auto">
          Try typing "search for plants" or "find shoes" in the chat to search products
        </div>
      </div>
    </div>
  );
}
