import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { CheckCircle, ShoppingBag, ArrowRight } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { useStore } from '@/store/useStore';
import { toast } from '@/components/ui/use-toast';

export default function PaymentSuccessPage() {
  const [isVerifying, setIsVerifying] = useState(true);
  const [paymentDetails, setPaymentDetails] = useState<any>(null);
  const navigate = useNavigate();
  const location = useLocation();
  const { clearCart } = useCart();
  const { user } = useStore();
  
  // Parse query parameters
  const queryParams = new URLSearchParams(location.search);
  const transactionId = queryParams.get('transactionId');
  const orderId = queryParams.get('orderId');
  const paymentMethod = queryParams.get('method') || 'card';

  useEffect(() => {
    const verifyPayment = async () => {
      if (!transactionId || !orderId) {
        // If no transaction ID or order ID, this might be a direct navigation
        // We'll still show success but won't verify
        setIsVerifying(false);
        return;
      }

      try {
        // For all payment methods, just show success and clear cart
        clearCart();
        
        // In a real implementation, you would verify the payment status with your payment provider
        // and update the order status in your database
        
        // For demo purposes, we'll simulate a payment details object
        setPaymentDetails({
          amount: parseFloat(queryParams.get('amount') || '0'),
          timestamp: new Date().toISOString()
        });
      } catch (error) {
        console.error('Payment verification error:', error);
        toast({
          title: 'Verification Error',
          description: 'There was an error verifying your payment. Please contact support.',
          variant: 'destructive'
        });
      } finally {
        setIsVerifying(false);
      }
    };

    verifyPayment();
  }, [transactionId, orderId, paymentMethod, clearCart, queryParams]);

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        <motion.div
          className="max-w-lg mx-auto text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {isVerifying ? (
            <div className="flex flex-col items-center justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gold mb-4"></div>
              <h2 className="text-2xl font-semibold">Verifying Payment</h2>
              <p className="text-muted-foreground mt-2">
                Please wait while we confirm your payment...
              </p>
            </div>
          ) : (
            <>
              <div className="flex justify-center mb-6">
                <div className="rounded-full bg-green-100 p-4">
                  <CheckCircle className="h-16 w-16 text-green-600" />
                </div>
              </div>
              <h1 className="text-4xl font-bold mb-4">Payment Successful!</h1>
              <p className="text-lg text-muted-foreground mb-8">
                Thank you for your purchase. Your order has been confirmed.
              </p>

              {paymentDetails && (
                <div className="bg-gray-50 rounded-lg p-6 mb-8 text-left">
                  <h3 className="font-semibold text-lg mb-4">Payment Details</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Order ID:</span>
                      <span className="font-medium">{orderId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Transaction ID:</span>
                      <span className="font-medium">{transactionId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Amount:</span>
                      <span className="font-medium">₹{paymentDetails.amount?.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Payment Method:</span>
                      <span className="font-medium capitalize">{paymentMethod}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Date:</span>
                      <span className="font-medium">
                        {new Date(paymentDetails.timestamp).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  onClick={() => navigate('/orders')}
                  className="bg-gold hover:bg-gold/90 text-black"
                >
                  <ShoppingBag className="h-4 w-4 mr-2" />
                  View Orders
                </Button>
                <Button
                  onClick={() => navigate('/products')}
                  variant="outline"
                >
                  Continue Shopping
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </>
          )}
        </motion.div>
      </div>
    </div>
  );
}
