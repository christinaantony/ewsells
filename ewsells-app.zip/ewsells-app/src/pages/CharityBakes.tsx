import React, { useEffect, useMemo, useRef, useState, type ChangeEvent, type KeyboardEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import * as maptilersdk from '@maptiler/sdk';
import '@maptiler/sdk/dist/maptiler-sdk.css';
import cake from "../assets/cake.jpg";
import ProductImageCarousel from '@/components/ProductImageCarousel';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db } from '@/lib/firebase';

const CATEGORIES = ['All', 'Charity Bakes Seller', 'Smile Community Kitchen'] as const;
type Category = typeof CATEGORIES[number];

const DELIVERY_POINTS: Array<{
    id: string;
    name: string;
    description?: string;
    coordinates: [number, number]; // [lng, lat]
    category: Category;
}> = [
        {
            id: 'dp1',
            name: "Tom's Bakery",
            description: 'Fresh sourdough and pastries. 1-2 day lead time.',
            coordinates: [72.8777, 19.076], // Mumbai approx
            category: 'Charity Bakes Seller',
        },
        {
            id: 'dp2',
            name: 'Smile Community Kitchen - Central',
            description: 'Community meals and tiffin service.',
            coordinates: [72.8358, 19.0183],
            category: 'Smile Community Kitchen',
        },
        {
            id: 'dp3',
            name: 'Smile Community Kitchen - North',
            description: 'Daily meal packs and bulk orders.',
            coordinates: [72.868, 19.218],
            category: 'Smile Community Kitchen',
        },
        {
            id: 'dp4',
            name: 'Bakery Collective',
            description: 'Assorted buns, cakes, cookies.',
            coordinates: [73.0, 19.15],
            category: 'Charity Bakes Seller',
        },
    ];

function haversineDistanceKm(a: [number, number], b: [number, number]) {
    const toRad = (v: number) => (v * Math.PI) / 180;
    const R = 6371;
    const dLat = toRad(b[1] - a[1]);
    const dLng = toRad(b[0] - a[0]);
    const lat1 = toRad(a[1]);
    const lat2 = toRad(b[1]);
    const sinDLat = Math.sin(dLat / 2);
    const sinDLng = Math.sin(dLng / 2);
    const c = 2 * Math.asin(
        Math.sqrt(sinDLat * sinDLat + Math.cos(lat1) * Math.cos(lat2) * sinDLng * sinDLng)
    );
    return R * c;
}

export default function CharityBakesPage() {
    const apiKey = import.meta.env.VITE_MAPTILER_API_KEY as string;
    const mapContainer = useRef<HTMLDivElement | null>(null);
    const mapRef = useRef<maptilersdk.Map | null>(null);
    const markersRef = useRef<Record<string, maptilersdk.Marker>>({});
    const searchMarkerRef = useRef<maptilersdk.Marker | null>(null);

    const [center, setCenter] = useState<[number, number] | null>(null);
    const [radiusKm, setRadiusKm] = useState<number>(25);
    const [category, setCategory] = useState<Category>('All');
    const [mapStyle, setMapStyle] = useState<
        typeof maptilersdk.MapStyle.STREETS | typeof maptilersdk.MapStyle.SATELLITE
    >(maptilersdk.MapStyle.STREETS);

    const [searchValue, setSearchValue] = useState('');
    const [suggestions, setSuggestions] = useState<
        Array<{ place_name: string; center: [number, number]; id: string }>
    >([]);
    const [suggestionsVisible, setSuggestionsVisible] = useState(false);

    const filteredPoints = useMemo(() => {
        if (!center) return [];
        return DELIVERY_POINTS.filter((p) => {
            const dist = haversineDistanceKm(center, p.coordinates);
            const inRadius = dist <= radiusKm;
            const inCategory = category === 'All' || p.category === category;
            return inRadius && inCategory;
        });
    }, [center, radiusKm, category]);

    useEffect(() => {
        if (!mapContainer.current) return;

        maptilersdk.config.apiKey = apiKey;

        const map = new maptilersdk.Map({
            container: mapContainer.current,
            style: mapStyle,
            zoom: 11,
            center: center ?? FALLBACK_CENTER,
            attributionControl: { compact: true },
        });
        // Expose map instance to other hooks and handlers
        mapRef.current = map;

        // Use NavigationControl without compass and without zoom buttons (remove +/- entirely)
        map.addControl(new maptilersdk.NavigationControl({ showCompass: false, showZoom: false } as any));

        // Add a Geolocate control and wire it to our state + fallbacks
        try {
            const geolocateCtrl = new maptilersdk.GeolocateControl({
                positionOptions: { enableHighAccuracy: true, timeout: 8000, maximumAge: 0 },
                trackUserLocation: false,
                showUserLocation: true,
                fitBoundsOptions: { maxZoom: 14 },
            } as any);
            map.addControl(geolocateCtrl as any, 'top-right');

            // When geolocation succeeds, center and zoom
            (geolocateCtrl as any).on('geolocate', (pos: GeolocationPosition) => {
                const lngLat: [number, number] = [pos.coords.longitude, pos.coords.latitude];
                try {
                    setCenter(lngLat);
                    mapRef.current?.flyTo({ center: lngLat, zoom: 13 });
                    console.info('[GeolocateControl] Located user at', lngLat);
                } catch (e) {
                    console.warn('[GeolocateControl] Could not flyTo after geolocate', e);
                }
            });

            // If the control errors, retry with our multi-step fallback
            (geolocateCtrl as any).on('error', async (err: any) => {
                console.warn('[GeolocateControl] error, using locateUser fallback', err);
                try { await locateUser(); } catch (e) { console.error('locateUser fallback failed', e); }
            });
        } catch (e) {
            console.warn('Failed to add GeolocateControl, calling locateUser fallback', e);
            void locateUser();
        }

        // Add text buttons inside the map to switch styles (top-left)
        const styleToggleControl = new (class {
            _container?: HTMLDivElement;
            _mapBtn?: HTMLButtonElement;
            _satBtn?: HTMLButtonElement;
            onAdd() {
                const container = document.createElement('div');
                container.className = 'maplibregl-ctrl maplibregl-ctrl-group';
                // horizontal layout + spacing
                container.style.display = 'flex';
                container.style.flexDirection = 'row';
                container.style.alignItems = 'center';
                container.style.gap = '4px';
                container.style.margin = '6px';
                container.style.zIndex = '10';
                container.style.background = 'rgba(0,0,0,0.6)';
                container.style.borderRadius = '8px';
                container.style.padding = '4px';
                container.style.boxShadow = '0 2px 6px rgba(0,0,0,0.3)';

                const mapBtn = document.createElement('button');
                mapBtn.type = 'button';
                mapBtn.title = 'Map style';
                mapBtn.textContent = 'Map';
                mapBtn.style.padding = '6px 10px';
                mapBtn.style.borderRadius = '6px';
                mapBtn.style.cursor = 'pointer';
                mapBtn.style.border = '1px solid #000';
                mapBtn.style.display = 'inline-flex';
                mapBtn.style.alignItems = 'center';
                mapBtn.style.justifyContent = 'center';
                mapBtn.style.fontSize = '12px';
                mapBtn.style.lineHeight = '1';
                mapBtn.style.whiteSpace = 'nowrap';
                mapBtn.style.flex = '0 0 auto';
                mapBtn.style.width = 'auto';
                mapBtn.style.minWidth = '0';
                mapBtn.style.boxSizing = 'content-box';
                mapBtn.dataset.role = 'map-style-map';
                mapBtn.setAttribute('aria-pressed', String(mapStyle === maptilersdk.MapStyle.STREETS));

                const satBtn = document.createElement('button');
                satBtn.type = 'button';
                satBtn.title = 'Satellite style';
                satBtn.textContent = 'Satellite';
                satBtn.style.padding = '6px 10px';
                satBtn.style.borderRadius = '6px';
                satBtn.style.cursor = 'pointer';
                satBtn.style.border = '1px solid #000';
                satBtn.style.display = 'inline-flex';
                satBtn.style.alignItems = 'center';
                satBtn.style.justifyContent = 'center';
                satBtn.style.fontSize = '12px';
                satBtn.style.lineHeight = '1';
                satBtn.style.whiteSpace = 'nowrap';
                satBtn.style.flex = '0 0 auto';
                satBtn.style.width = 'auto';
                satBtn.style.minWidth = '0';
                satBtn.style.boxSizing = 'content-box';
                satBtn.dataset.role = 'map-style-sat';
                satBtn.setAttribute('aria-pressed', String(mapStyle === maptilersdk.MapStyle.SATELLITE));

                const updateActive = () => {
                    // base styles
                    [mapBtn, satBtn].forEach((b) => {
                        b.style.background = '#fff';
                        b.style.color = '#000';
                    });
                    if (mapStyle === maptilersdk.MapStyle.STREETS) {
                        mapBtn.style.background = '#000';
                        mapBtn.style.color = '#fff';
                        mapBtn.setAttribute('aria-pressed', 'true');
                        satBtn.setAttribute('aria-pressed', 'false');
                    } else {
                        satBtn.style.background = '#000';
                        satBtn.style.color = '#fff';
                        satBtn.setAttribute('aria-pressed', 'true');
                        mapBtn.setAttribute('aria-pressed', 'false');
                    }
                };

                mapBtn.onclick = () => {
                    const newStyle = maptilersdk.MapStyle.STREETS;
                    setMapStyle(newStyle);
                    // apply immediately and wait for style load
                    try {
                        const m = mapRef.current;
                        if (m) {
                            m.setStyle(newStyle as any);
                            m.once('styledata', () => updateActive());
                        }
                    } catch (e) { console.warn('Failed to set Map style', e); }
                    updateActive();
                };
                satBtn.onclick = () => {
                    const newStyle = maptilersdk.MapStyle.SATELLITE;
                    setMapStyle(newStyle);
                    // apply immediately and wait for style load
                    try {
                        const m = mapRef.current;
                        if (m) {
                            m.setStyle(newStyle as any);
                            m.once('styledata', () => updateActive());
                        }
                    } catch (e) {
                        console.warn('Failed to set Satellite style, retrying...', e);
                        setTimeout(() => {
                            try {
                                const m2 = mapRef.current;
                                if (m2) {
                                    m2.setStyle(newStyle as any);
                                    m2.once('styledata', () => updateActive());
                                }
                            } catch (e2) { console.error('Satellite style still failed', e2); }
                        }, 50);
                    }
                    updateActive();
                };

                updateActive();

                container.appendChild(mapBtn);
                container.appendChild(satBtn);

                this._container = container;
                this._mapBtn = mapBtn;
                this._satBtn = satBtn;
                return container;
            }
            onRemove() {
                this._container?.remove();
            }
        })();
        // Add custom style toggle to the bottom-left of the map
        map.addControl(styleToggleControl as any, 'bottom-left');

        // Suppress WebGL warning banner injected by the SDK
        const canvas = map.getCanvas();
        const onLost = (e: Event) => {
            e.preventDefault();
            const banner = document.querySelector('.webgl-warning-div') as HTMLElement | null;
            if (banner) banner.style.display = 'none';
        };
        const onRestored = () => {
            try { map.resize(); } catch { }
            const banner = document.querySelector('.webgl-warning-div') as HTMLElement | null;
            if (banner) banner.style.display = 'none';
        };
        canvas.addEventListener('webglcontextlost', onLost, { passive: false } as any);
        canvas.addEventListener('webglcontextrestored', onRestored);

        // Try to center to the user's current location on first load
        map.once('load', () => {
            void locateUser();
        });

        return () => {
            canvas.removeEventListener('webglcontextlost', onLost as any);
            canvas.removeEventListener('webglcontextrestored', onRestored);
            map.remove();
        };
    }, [apiKey]);

    useEffect(() => {
        if (!mapRef.current) return;
        mapRef.current.setStyle(mapStyle);
    }, [mapStyle]);

    useEffect(() => {
        if (!mapRef.current) return;
        const map = mapRef.current;

        Object.values(markersRef.current).forEach((m) => m.remove());
        markersRef.current = {};

        filteredPoints.forEach((point) => {
            const el = document.createElement('div');
            el.style.width = '16px';
            el.style.height = '16px';
            el.style.borderRadius = '50%';
            el.style.backgroundColor =
                point.category === 'Charity Bakes Seller' ? '#f59e0b' : '#10b981';
            el.style.border = '2px solid white';
            el.style.boxShadow = '0 0 6px rgba(0,0,0,0.3)';

            const marker = new maptilersdk.Marker({ element: el })
                .setLngLat(point.coordinates)
                .setPopup(
                    new maptilersdk.Popup({ offset: 12 }).setHTML(
                        `<strong>${point.name}</strong><br/><small>${point.category}</small><br/>${point.description ?? ''}`
                    )
                )
                .addTo(map);

            markersRef.current[point.id] = marker;
        });

        if (center) {
            map.flyTo({ center, zoom: 12 });
        }
    }, [filteredPoints, center]);

    // Fetch autocomplete suggestions from MapTiler Geocoding API
    async function fetchSuggestions(query: string) {
        if (!query.trim()) {
            setSuggestions([]);
            return;
        }

        try {
            const url = `https://api.maptiler.com/geocoding/${encodeURIComponent(
                query
            )}.json?key=${apiKey}&limit=5`;
            const res = await fetch(url);
            if (!res.ok) throw new Error(`Failed to fetch: ${res.status}`);
            const data = await res.json();

            if (data?.features) {
                const sug = data.features.map((f: any) => ({
                    place_name: f.place_name,
                    center: f.center,
                    id: f.id,
                }));
                setSuggestions(sug);
                setSuggestionsVisible(true);
            }
        } catch (e) {
            console.warn('Autocomplete error', e);
            setSuggestions([]);
            setSuggestionsVisible(false);
        }
    }

    function onSearchChange(e: ChangeEvent<HTMLInputElement>) {
        const val = e.target.value;
        setSearchValue(val);
        fetchSuggestions(val);
    }

    // User clicks a suggestion
    function onSelectSuggestion(sug: { place_name: string; center: [number, number] }) {
        setSearchValue(sug.place_name);
        setCenter(sug.center);
        setSuggestions([]);
        setSuggestionsVisible(false);

        const map = mapRef.current;
        if (!map) return;

        // Create or move a dedicated marker for the searched location
        try {
            // Remove existing search marker, if any
            searchMarkerRef.current?.remove();

            const el = document.createElement('div');
            el.style.width = '18px';
            el.style.height = '18px';
            el.style.borderRadius = '50%';
            el.style.background = '#ef4444'; // red to highlight search result
            el.style.border = '2px solid #fff';
            el.style.boxShadow = '0 0 6px rgba(0,0,0,0.35)';

            const marker = new maptilersdk.Marker({ element: el })
                .setLngLat(sug.center)
                .addTo(map);

            searchMarkerRef.current = marker;
            map.flyTo({ center: sug.center, zoom: 13 });
        } catch (e) {
            console.warn('Failed to place search marker', e);
        }
    }

    // Close suggestions if user clicks outside
    useEffect(() => {
        function handleClickOutside(ev: MouseEvent) {
            const target = ev.target as HTMLElement;
            if (!target.closest('.autocomplete-container')) {
                setSuggestionsVisible(false);
            }
        }
        document.addEventListener('click', handleClickOutside);
        return () => {
            document.removeEventListener('click', handleClickOutside);
        };
    }, []);

    // Fallback center (Mumbai) if geolocation is unavailable/denied
    const FALLBACK_CENTER: [number, number] = [72.8777, 19.076];

    // Attempt to geolocate the user with high-accuracy first, then graceful fallbacks
    async function locateUser() {
        const geolocate = (enableHighAccuracy: boolean, timeout = 8000) =>
            new Promise<GeolocationPosition>((resolve, reject) => {
                if (!navigator.geolocation) return reject(new Error('Geolocation not supported'));
                navigator.geolocation.getCurrentPosition(resolve, reject, {
                    enableHighAccuracy,
                    timeout,
                    maximumAge: 0,
                });
            });

        try {
            const pos = await geolocate(true, 8000);
            const lngLat: [number, number] = [pos.coords.longitude, pos.coords.latitude];
            setCenter(lngLat);
            mapRef.current?.flyTo({ center: lngLat, zoom: 13 });
            return;
        } catch { }

        try {
            const pos2 = await geolocate(false, 8000);
            const lngLat: [number, number] = [pos2.coords.longitude, pos2.coords.latitude];
            setCenter(lngLat);
            mapRef.current?.flyTo({ center: lngLat, zoom: 13 });
            return;
        } catch { }

        try {
            // Fallback to IP-based geolocation via MapTiler if available
            const resp = await fetch(`https://api.maptiler.com/geolocation/ip.json?key=${maptilersdk.config.apiKey}`);
            if (resp.ok) {
                const data = await resp.json();
                const lngLat: [number, number] = [data.lng, data.lat];
                setCenter(lngLat);
                mapRef.current?.flyTo({ center: lngLat, zoom: 12 });
                return;
            }
        } catch { }

        // Final fallback
        setCenter(FALLBACK_CENTER);
        mapRef.current?.flyTo({ center: FALLBACK_CENTER, zoom: 11 });
    }

    // Keep in-map Map/Satellite buttons' active styling in sync with mapStyle changes
    useEffect(() => {
        const root = mapContainer.current?.parentElement ?? document;
        const mapBtn = root.querySelector('button[data-role="map-style-map"]') as HTMLButtonElement | null;
        const satBtn = root.querySelector('button[data-role="map-style-sat"]') as HTMLButtonElement | null;
        if (!mapBtn || !satBtn) return;
        [mapBtn, satBtn].forEach((b) => {
            b.style.background = '#fff';
            b.style.color = '#000';
        });
        if (mapStyle === maptilersdk.MapStyle.STREETS) {
            mapBtn.style.background = '#000';
            mapBtn.style.color = '#fff';
            mapBtn.setAttribute('aria-pressed', 'true');
            satBtn.setAttribute('aria-pressed', 'false');
        } else {
            satBtn.style.background = '#000';
            satBtn.style.color = '#fff';
            satBtn.setAttribute('aria-pressed', 'true');
            mapBtn.setAttribute('aria-pressed', 'false');
        }
    }, [mapStyle]);

    const navigate = useNavigate();

    // Uploaded Charity Bakes products (for Featured section)
    interface BakeProduct {
        id: string;
        name: string;
        description?: string;
        imageUrl?: string;
        images?: string[];
        imageUrls?: string[];
        category?: string;
        price?: number;
        sellerPrice?: number;
        finalPrice?: number;
    }
    const [featuredBakes, setFeaturedBakes] = useState<BakeProduct[]>([]);

    useEffect(() => {
        const q = query(
            collection(db, 'products'),
            where('category', '==', 'charity-bakes'),
            where('published', '==', true)
        );
        const unsub = onSnapshot(q, (snap) => {
            const rows: BakeProduct[] = snap.docs.map((d) => {
                const data = d.data() as any;
                const images: string[] = Array.isArray(data.images)
                    ? data.images
                    : Array.isArray(data.imageUrls)
                    ? data.imageUrls
                    : data.imageUrl
                    ? [data.imageUrl]
                    : [];
                return {
                    id: d.id,
                    name: data.name || 'Untitled',
                    description: data.description,
                    imageUrl: data.imageUrl,
                    images,
                    imageUrls: Array.isArray(data.imageUrls) ? data.imageUrls : undefined,
                    category: data.category,
                    price: typeof data.price === 'number' ? data.price : Number(data.price || 0),
                    sellerPrice: typeof data.sellerPrice === 'number' ? data.sellerPrice : (data.sellerPrice != null ? Number(data.sellerPrice) : undefined),
                    finalPrice: typeof data.finalPrice === 'number' ? data.finalPrice : (data.finalPrice != null ? Number(data.finalPrice) : undefined),
                };
            });
            setFeaturedBakes(rows);
        });
        return () => unsub();
    }, []);

    return (
        <div className="min-h-screen p-4 max-w-7xl mx-auto">
            {/* Featured bakes from uploaded products (no prices) */}
            <section className="mb-6">
                <h2 className="sr-only">Featured Bakes</h2>
                <div className="mx-auto max-w-5xl grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 justify-items-center">
                    {(featuredBakes.length > 0 ? featuredBakes.slice(0, 6) : []).map((p) => (
                        <div
                            key={p.id}
                            className="group w-full sm:w-64 overflow-hidden rounded-xl ring-1 ring-zinc-700/40 bg-zinc-900/40 cursor-pointer focus:outline-none focus:ring-2 focus:ring-gold"
                            role="button"
                            tabIndex={0}
                            onClick={() => navigate(`/product/${p.id}`)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter' || e.key === ' ') {
                                    e.preventDefault();
                                    navigate(`/product/${p.id}`);
                                }
                            }}
                        >
                            <ProductImageCarousel
                                images={p.images && p.images.length ? p.images : (p.imageUrl ? [p.imageUrl] : [])}
                                alt={p.name}
                                className="h-36 w-full object-cover transition-transform duration-300 group-hover:scale-105"
                                aspect="square"
                            />
                            <div className="px-3 py-2 text-center text-sm font-semibold">{p.name}</div>
                        </div>
                    ))}
                    {featuredBakes.length === 0 && (
                        <div className="col-span-full text-center text-sm text-zinc-400">No featured bakes yet. Upload your first item!</div>
                    )}
                </div>
            </section>

            <h1 className="text-3xl font-bold mb-4 bg-yellow-400 text-black px-3 py-2 rounded w-fit text-center mx-auto">
                Select Your Charity Bakes Delivery Location
            </h1>
            <p className="mb-4 text-yellow-400 text-center">
                NB: Change Your Location Instantly On Location Search Bar And Order For Your Dear Ones
            </p>

            <div className="grid grid-cols-1 lg:grid-cols-[320px,1fr] gap-6 items-start">
                {/* Controls */}
                <div className="flex flex-col gap-4 text-white lg:sticky lg:top-4 bg-zinc-900/60 border border-zinc-700/50 rounded-xl p-4 backdrop-blur">
                    {/* Location Search */}
                    <div className="autocomplete-container relative">
                        <label className="block mb-1 font-semibold">Search Location</label>
                        <input
                            type="search"
                            className="w-full border rounded px-3 py-2 bg-white text-black placeholder-gray-500"
                            placeholder="Type a location"
                            value={searchValue}
                            onChange={onSearchChange}
                            spellCheck={false}
                            autoComplete="off"
                            onFocus={() => setSuggestionsVisible(true)}
                        />
                        {suggestionsVisible && suggestions.length > 0 && (
                            <ul className="absolute z-10 top-full left-0 right-0 bg-white text-black border rounded max-h-60 overflow-auto shadow-lg">
                                {suggestions.map((sug) => (
                                    <li
                                        key={sug.id}
                                        onClick={() => onSelectSuggestion(sug)}
                                        className="px-3 py-2 cursor-pointer hover:bg-gray-100"
                                    >
                                        {sug.place_name}
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>

                    {/* Radius filter */}
                    <div>
                        <label className="block mb-1 font-semibold">Radius (km)</label>
                        <select
                            className="w-full border rounded px-3 py-2 bg-white text-black"
                            value={radiusKm}
                            onChange={(e: ChangeEvent<HTMLSelectElement>) =>
                                setRadiusKm(Number(e.target.value))
                            }
                        >
                            {[5, 10, 25, 50, 100, 150, 200, 300].map((km) => (
                                <option key={km} value={km}>
                                    {km} km
                                </option>
                            ))}
                        </select>
                    </div>

                    {/* Category filter */}
                    <div>
                        <label className="block mb-1 font-semibold">Category</label>
                        <select
                            className="w-full border rounded px-3 py-2 bg-white text-black"
                            value={category}
                            onChange={(e: ChangeEvent<HTMLSelectElement>) =>
                                setCategory(e.target.value as Category)
                            }
                        >
                            {CATEGORIES.map((cat) => (
                                <option key={cat} value={cat}>
                                    {cat}
                                </option>
                            ))}
                        </select>
                    </div>

                    {/* Map Style toggle moved into map UI via a small top-right button */}
                </div>

                {/* Map */}
                <div
                  className="rounded-xl overflow-hidden w-full h-[55vh] sm:h-[60vh] md:h-[65vh] lg:h-[70vh] ring-1 ring-zinc-700/50 shadow-xl"
                  ref={mapContainer}
                ></div>
                {/* Force-hide any SDK WebGL warning banner and MapTiler logo */}
                <style>{`
                  .webgl-warning-div{display:none!important}
                  a[aria-label="MapTiler logo"]{display:none!important}
                  /* Hide duplicate geolocate icons; keep only the first */
                  .maplibregl-ctrl-geolocate .maplibregl-ctrl-icon:not(:first-child){display:none!important}
                  /* Hide the geolocate control button entirely */
                  .maplibregl-ctrl-geolocate{display:none!important}
                `}</style>
            </div>
        </div>
    );
}
