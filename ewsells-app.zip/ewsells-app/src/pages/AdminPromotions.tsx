import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye } from 'lucide-react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { firestoreService } from '@/services/firebase';

export function AdminPromotionsPage() {
  const [loading, setLoading] = useState(true);
  const [requests, setRequests] = useState<any[]>([]);
  const [approving, setApproving] = useState<string | null>(null);
  const [rejecting, setRejecting] = useState<string | null>(null);
  const [statusTab, setStatusTab] = useState<'pending' | 'approved' | 'rejected' | 'deleted'>('pending');
  const [counts, setCounts] = useState<{ pending: number; approved: number; rejected: number; deleted: number }>({ pending: 0, approved: 0, rejected: 0, deleted: 0 });
  const [pricing, setPricing] = useState<Record<string, string>>({});
  const [settingPrice, setSettingPrice] = useState<string | null>(null);
  const [openIds, setOpenIds] = useState<Record<string, boolean>>({});
  const navigate = useNavigate();
  // sorting
  const [sortBy, setSortBy] = useState<'updated_desc' | 'updated_asc'>('updated_desc');
  const [sortOpen, setSortOpen] = useState(false);
  const formatStamp = (v: any): string => {
    try {
      if (!v) return '—';
      const d: Date = typeof v?.toDate === 'function' ? v.toDate() : (v instanceof Date ? v : new Date(v));
      if (isNaN(d.getTime())) return '—';
      return d.toLocaleString();
    } catch {
      return '—';
    }
  };

  const load = async () => {
    setLoading(true);
    try {
      const list = await firestoreService.listPromotionRequests(statusTab);
      // Attach some product preview/title counts
      const withMeta = await Promise.all(
        list.map(async (r: any) => {
          // Load up to 3 product previews and capture productCode if present
          const products = await Promise.all(
            (r.productIds || []).slice(0, 3).map(async (pid: string) => {
              try {
                const p = await getDoc(doc(db, 'products', pid));
                const raw: any = p.data() || {};
                const imageCandidates: string[] = [];
                if (Array.isArray(raw.images)) imageCandidates.push(...raw.images);
                if (Array.isArray(raw.imageUrls)) imageCandidates.push(...raw.imageUrls);
                if (typeof raw.imageUrl === 'string') imageCandidates.push(raw.imageUrl);
                if (typeof raw.image === 'string') imageCandidates.push(raw.image);
                if (typeof raw.photo === 'string') imageCandidates.push(raw.photo);
                if (typeof raw.thumbnail === 'string') imageCandidates.push(raw.thumbnail);
                if (typeof raw.coverUrl === 'string') imageCandidates.push(raw.coverUrl);
                const image = imageCandidates.filter(Boolean)[0];
                const title = raw.title ?? raw.name ?? 'Untitled';
                const code = raw.productCode || null;
                const category = raw.category || null;
                const sellerPrice = raw.sellerPrice ?? raw.price ?? null;
                const finalPrice = raw.finalPrice ?? null;
                return { id: pid, title, image, code, category, sellerPrice, finalPrice };
              } catch {
                return { id: pid, title: 'Untitled' };
              }
            })
          );

          // Try to fetch sellerCode using sellerId from sellers or seller-registrations
          let sellerCode: string | null = null;
          if (r.sellerId) {
            try {
              const prof = await getDoc(doc(db, 'sellers', r.sellerId));
              if (prof.exists()) {
                const d: any = prof.data();
                sellerCode = d?.sellerCode ?? d?.code ?? null;
              }
            } catch {}
            if (!sellerCode) {
              try {
                const reg = await getDoc(doc(db, 'seller-registrations', r.sellerId));
                if (reg.exists()) {
                  const d: any = reg.data();
                  sellerCode = d?.sellerCode ?? d?.code ?? null;
                }
              } catch {}
            }
          }

          return { ...r, _preview: products, _sellerCode: sellerCode };
        })
      );

      // Sort latest first using updatedAt/createdAt (support Timestamp/Date/string)
      const toMs = (v: any): number => {
        if (!v) return 0;
        if (typeof v?.toMillis === 'function') return v.toMillis();
        if (v instanceof Date) return v.getTime();
        const t = new Date(v).getTime();
        return Number.isFinite(t) ? t : 0;
      };
      const sorted = [...withMeta].sort((a: any, b: any) => {
        const aMs = toMs(a.updatedAt) || toMs(a.createdAt);
        const bMs = toMs(b.updatedAt) || toMs(b.createdAt);
        return bMs - aMs;
      });
      setRequests(sorted);
      // Default expand the latest item
      if (sorted.length > 0) {
        setOpenIds({ [sorted[0].id]: true });
      } else {
        setOpenIds({});
      }
    } finally {
      setLoading(false);
    }
  };

  const setPrice = async (id: string) => {
    const raw = pricing[id];
    const amt = Number(raw);
    if (!amt || amt <= 0) {
      alert('Enter a valid amount');
      return;
    }
    try {
      setSettingPrice(id);
      await firestoreService.updatePromotionRequest(id, { amount: amt });
      await load();
    } catch (e) {
      console.error(e);
      alert('Failed to set price');
    } finally {
      setSettingPrice(null);
    }
  };

  const doDelete = async (id: string) => {
    try {
      // Can consider adding a confirm dialog in UI; for now perform action.
      await firestoreService.deletePromotionRequest(id);
      await load();
      await loadCounts();
    } catch (e) {
      console.error(e);
      alert('Failed to delete');
    }
  };

  const loadCounts = async () => {
    try {
      const [p, a, r, d] = await Promise.all([
        firestoreService.listPromotionRequests('pending'),
        firestoreService.listPromotionRequests('approved'),
        firestoreService.listPromotionRequests('rejected'),
        firestoreService.listPromotionRequests('deleted'),
      ]);
      setCounts({ pending: p.length, approved: a.length, rejected: r.length, deleted: d.length });
    } catch (e) {
      console.error('Failed to load counts', e);
    }
  };

  useEffect(() => {
    load();
    // Also refresh counts on initial mount and each tab change (keeps badges fresh)
    loadCounts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [statusTab]);

  const approve = async (id: string) => {
    try {
      setApproving(id);
      await firestoreService.approvePromotionRequest(id);
      await load();
      await loadCounts();
    } catch (e) {
      console.error(e);
      alert('Failed to approve');
    } finally {
      setApproving(null);
    }
  };

  const reject = async (id: string) => {
    try {
      setRejecting(id);
      await firestoreService.rejectPromotionRequest(id);
      await load();
      await loadCounts();
    } catch (e) {
      console.error(e);
      alert('Failed to reject');
    } finally {
      setRejecting(null);
    }
  };

  const toggleOpen = (id: string) => setOpenIds((prev) => ({ ...prev, [id]: !prev[id] }));
  const expandAll = () => setOpenIds(Object.fromEntries(requests.map((r) => [r.id, true])));
  const collapseAll = () => setOpenIds(Object.fromEntries(requests.map((r) => [r.id, false])));

  // client-side sorting of loaded requests
  const toMs = (v: any): number => {
    if (!v) return 0;
    if (typeof v?.toMillis === 'function') return v.toMillis();
    if (typeof v?.toDate === 'function') return v.toDate().getTime();
    if (v instanceof Date) return v.getTime();
    const t = new Date(v).getTime();
    return Number.isFinite(t) ? t : 0;
  };
  const getUpdatedMs = (r: any) => toMs(r.updatedAt) || toMs(r.createdAt);
  // removed amount/products/seller based sorts
  const sortedRequests = [...requests].sort((a, b) => {
    switch (sortBy) {
      case 'updated_desc':
        return getUpdatedMs(b) - getUpdatedMs(a);
      case 'updated_asc':
        return getUpdatedMs(a) - getUpdatedMs(b);
      default:
        return 0;
    }
  });

  return (
    <div className="container mx-auto px-6 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold">Promotion Requests</h1>
        </div>
        {/* Sort By near title */}
        <div className="relative">
          <button
            type="button"
            className="btn-hover border border-primary bg-transparent text-primary hover:bg-primary hover:text-primary-foreground h-10 px-4 py-2 rounded-md"
            aria-haspopup="listbox"
            aria-expanded={sortOpen}
            onClick={() => setSortOpen(o => !o)}
            onBlur={(e) => { if (!e.currentTarget.parentElement?.contains(e.relatedTarget as Node)) setSortOpen(false); }}
          >
            Sort By
          </button>
          {sortOpen && (
            <div className="absolute right-0 mt-2 z-10 w-56 rounded-md border border-border/60 bg-background shadow-lg py-1">
              <ul role="listbox" aria-label="Sort by" className="max-h-64 overflow-auto text-sm">
                <li><button type="button" role="option" aria-selected={sortBy==='updated_desc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='updated_desc'?'font-medium':''}`} onClick={() => { setSortBy('updated_desc'); setSortOpen(false); }} autoFocus>Newest</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='updated_asc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='updated_asc'?'font-medium':''}`} onClick={() => { setSortBy('updated_asc'); setSortOpen(false); }}>Oldest</button></li>
              </ul>
            </div>
          )}
        </div>
      </div>
      {/* Segmented button filters to match app UI */}
        <div className="mb-4 flex flex-col md:flex-row md:items-center gap-3">
        <div className="flex items-center gap-2">
          <button
            className={`btn-hover h-10 px-4 py-2 rounded-md ${statusTab === 'pending' ? 'bg-gold text-black hover:bg-gold/90' : 'hover:bg-accent hover:text-accent-foreground'}`}
            onClick={() => setStatusTab('pending')}
          >
            <span>Pending</span>
            <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${statusTab === 'pending' ? 'bg-white text-black' : 'bg-gold/20 text-gold'}`}>{counts.pending}</span>
          </button>
          <button
            className={`btn-hover h-10 px-4 py-2 rounded-md ${statusTab === 'approved' ? 'bg-gold text-black hover:bg-gold/90' : 'hover:bg-accent hover:text-accent-foreground'}`}
            onClick={() => setStatusTab('approved')}
          >
            <span>Approved</span>
            <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${statusTab === 'approved' ? 'bg-white text-black' : 'bg-gold/20 text-gold'}`}>{counts.approved}</span>
          </button>
          <button
            className={`btn-hover h-10 px-4 py-2 rounded-md ${statusTab === 'rejected' ? 'bg-gold text-black hover:bg-gold/90' : 'hover:bg-accent hover:text-accent-foreground'}`}
            onClick={() => setStatusTab('rejected')}
          >
            <span>Rejected</span>
            <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${statusTab === 'rejected' ? 'bg-white text-black' : 'bg-gold/20 text-gold'}`}>{counts.rejected}</span>
          </button>
          <button
            className={`btn-hover h-10 px-4 py-2 rounded-md ${statusTab === 'deleted' ? 'bg-gold text-black hover:bg-gold/90' : 'hover:bg-accent hover:text-accent-foreground'}`}
            onClick={() => setStatusTab('deleted')}
          >
            <span>Deleted</span>
            <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${statusTab === 'deleted' ? 'bg-white text-black' : 'bg-gold/20 text-gold'}`}>{counts.deleted}</span>
          </button>
        </div>
        <div className="flex items-center gap-2 md:ml-auto">
          <button onClick={expandAll} className="btn-hover h-10 px-4 py-2 rounded-md hover:bg-accent hover:text-accent-foreground">Expand all</button>
          <button onClick={collapseAll} className="btn-hover h-10 px-4 py-2 rounded-md hover:bg-accent hover:text-accent-foreground">Collapse all</button>
        </div>
      </div>

      {loading ? (
        <div>Loading...</div>
      ) : requests.length === 0 ? (
        <div className="text-sm text-muted-foreground">No {statusTab} promotion requests.</div>
      ) : (
        <div className="space-y-3">
          {sortedRequests.map((r) => {
            const isOpen = !!openIds[r.id];
            const statusClass = r.status === 'approved'
              ? 'bg-emerald-500/15 text-emerald-400 border-emerald-400/20'
              : r.status === 'rejected'
                ? 'bg-red-500/15 text-red-400 border-red-400/20'
                : r.status === 'deleted'
                  ? 'bg-white/10 text-muted-foreground border-white/10'
                  : 'bg-amber-500/15 text-amber-400 border-amber-400/20';
            return (
              <Card key={r.id} className="p-0 overflow-hidden bg-white/5 border-white/10">
                {/* Header row (compact) */}
                <button
                  className="w-full flex items-center justify-between px-4 py-3 text-left hover:bg-white/5 transition-colors"
                  onClick={() => toggleOpen(r.id)}
                  aria-expanded={isOpen}
                  aria-controls={`req-${r.id}`}
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="flex flex-col min-w-0">
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="font-semibold truncate">₹{r.amount || 0}</div>
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs border ${statusClass}`}>{r.status}</span>
                      </div>
                      <div className="text-xs text-muted-foreground">Duration: {r.durationDays}d</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-sm text-muted-foreground">Products: {r.productIds?.length || 0}</div>
                    {/* Chevron removed to declutter */}
                  </div>
                </button>

                {/* Collapsible content */}
                {isOpen && (
                  <div id={`req-${r.id}`} className="px-4 pb-4 pt-2 border-t border-white/10 space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="text-xs text-muted-foreground">Request #{r.id}</div>
                      <div className="text-right">
                        <div className="text-[10px] text-muted-foreground uppercase">Seller</div>
                        <div className="text-sm font-medium">{r._sellerCode || '—'}</div>
                        <div className="text-[10px] text-muted-foreground font-mono break-all">{r.sellerId || ''}</div>
                      </div>
                    </div>
                    <div className="text-xs text-muted-foreground flex flex-wrap gap-4">
                      <span>Created: {formatStamp(r.createdAt)}</span>
                      <span>Updated: {formatStamp(r.updatedAt)}</span>
                    </div>
                    {r.rejectionReason && r.status === 'rejected' && (
                      <div className="text-xs text-muted-foreground">Reason: {r.rejectionReason}</div>
                    )}
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                      {(r._preview || []).map((p: any) => (
                        <div key={p.id} className="space-y-1">
                          <div className="flex items-center gap-3 border rounded px-3 py-2 text-sm border-white/10">
                            <button
                              type="button"
                              onClick={() => navigate(`/admin/product/${encodeURIComponent(p.id)}`)}
                              className="group relative shrink-0 rounded focus:outline-none focus:ring-2 focus:ring-gold"
                              title="Open Product Details (Admin)"
                            >
                              <img src={p.image || '/images/charity-background.svg'} className="w-20 h-20 object-cover rounded" />
                              <div className="absolute inset-0 flex items-center justify-center rounded bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity">
                                <Eye className="h-5 w-5 text-white" />
                              </div>
                            </button>
                            <div className="flex flex-col min-w-0">
                              <button
                                type="button"
                                onClick={() => navigate(`/admin/product/${encodeURIComponent(p.id)}`)}
                                className="truncate text-left hover:underline mb-2"
                                title={p.title}
                              >
                                {p.title}
                              </button>
                              {(p.finalPrice !== undefined && p.finalPrice !== null) || (p.sellerPrice !== undefined && p.sellerPrice !== null) ? (
                                <div className="text-xs mb-1 flex items-center gap-2">
                                  {p.sellerPrice !== undefined && p.sellerPrice !== null && (
                                    <span className={`${p.finalPrice != null && Number(p.finalPrice) !== Number(p.sellerPrice) ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
                                      ₹ {Number(p.sellerPrice).toLocaleString()}
                                    </span>
                                  )}
                                  {p.finalPrice !== undefined && p.finalPrice !== null && (
                                    <span className="font-semibold text-foreground">
                                      ₹ {Number(p.finalPrice).toLocaleString()}
                                    </span>
                                  )}
                                </div>
                              ) : null}
                              <div className="flex flex-wrap items-center gap-0">
                                {p.code && (
                                  <span className="text-[10px] text-muted-foreground font-mono truncate max-w-[12rem]" title={p.code}>Code: {p.code}</span>
                                )}
                                <span className="text-[10px] text-muted-foreground font-mono truncate max-w-[12rem]" title={p.id}>ID: {p.id}</span>
                              </div>
                            </div>
                          </div>
                          {p.category && (
                            <div className="text-[10px] text-muted-foreground truncate" title={p.category}>Category: {p.category}</div>
                          )}
                        </div>
                      ))}
                      {r.productIds?.length > 3 && (
                        <div className="text-xs text-muted-foreground">+{r.productIds.length - 3} more</div>
                      )}
                    </div>

                    {r.status !== 'deleted' && (
                      <div className="flex flex-wrap gap-3 items-center">
                        {r.status === 'pending' && (
                          <>
                            <div className="flex items-center gap-2">
                              <label className="text-xs text-muted-foreground">Set Amount (₹)</label>
                              <input
                                type="number"
                                min={1}
                                className="w-28 rounded border bg-transparent px-2 py-1"
                                value={pricing[r.id] ?? (r.amount || '')}
                                onChange={(e) => setPricing((p) => ({ ...p, [r.id]: e.target.value }))}
                              />
                              <Button size="sm" onClick={() => setPrice(r.id)} disabled={settingPrice === r.id} className="bg-gold text-black hover:bg-gold/90">
                                {settingPrice === r.id ? 'Saving...' : 'Set Price'}
                              </Button>
                            </div>
                            <Button disabled={approving === r.id} onClick={() => approve(r.id)} className="bg-emerald-500 hover:bg-emerald-600 text-white">
                              {approving === r.id ? 'Approving...' : 'Approve'}
                            </Button>
                            <Button disabled={rejecting === r.id} onClick={() => reject(r.id)} variant="outline" className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white">
                              {rejecting === r.id ? 'Rejecting...' : 'Reject'}
                            </Button>
                          </>
                        )}
                        <Button onClick={() => doDelete(r.id)} variant="outline" className="border-amber-500 text-amber-500 hover:bg-amber-500 hover:text-black">
                          Delete
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
