import { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { firestoreService } from '@/services/firebase';
import { cn } from '@/lib/utils';
import type { Seller } from '@/types';
import { 
  collection, 
  query, 
  getDocs, 
  doc, 
  updateDoc, 
  getDoc,
  orderBy,
  where,
  setDoc,
  deleteDoc
} from 'firebase/firestore';
import { 
  Loader2, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Eye, 
  User,
  Calendar,
  MapPin,
  Phone,
  Mail,
  CreditCard,
  PlusCircle,
  ListPlus,
  RefreshCw,
  FileText,
  Trash2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { db } from '@/lib/firebase';
import { lenis } from '@/lib/smooth-scroll';
import { useStore } from '@/store/useStore';
import { getRailwayCode } from '@/utils/railwayCodes';
import { featuredProjects } from '@/constants/featuredProjects';

// Function to generate seller code (EWS + first 2 letters of name + railway station code)
const generateSellerCode = (name: string, city: string): string => {
  // Get first 2 letters of name (uppercase, remove spaces)
  const namePart = name
    .replace(/\s+/g, '')
    .substring(0, 2)
    .toUpperCase();
  
  // Get railway station code for the city
  const cityCode = getRailwayCode(city);
  
  // Combine parts (EWS + first 2 letters of name + railway code)
  return `EWS${namePart}${cityCode}`.substring(0, 10); // Ensure max length of 10 characters
};

// Helper: Build fallback seller code using first letter of first name and first letter of last name
const generateInitialsSellerCode = (name: string, city: string): string => {
  const parts = name.trim().split(/\s+/);
  const firstInitial = parts[0]?.[0]?.toUpperCase() || '';
  const lastInitial = (parts.length > 1 ? parts[parts.length - 1][0] : '')?.toUpperCase() || '';
  const cityCode = getRailwayCode(city);
  const code = `EWS${firstInitial}${lastInitial}${cityCode}`;
  return code.substring(0, 10);
};

// Check if a seller code already exists in Firestore across relevant collections
const sellerCodeExists = async (code: string): Promise<boolean> => {
  if (!code) return false;
  // Check in seller-registrations
  const regRef = collection(db, 'seller-registrations');
  const regQ = query(regRef, where('sellerCode', '==', code));
  const regSnap = await getDocs(regQ);
  if (!regSnap.empty) return true;

  // Check in seller-profiles
  const profilesRef = collection(db, 'seller-profiles');
  const profilesQ = query(profilesRef, where('sellerCode', '==', code));
  const profilesSnap = await getDocs(profilesQ);
  if (!profilesSnap.empty) return true;

  // Optionally check in sellers (legacy/backward-compat)
  const sellersRef = collection(db, 'sellers');
  const sellersQ = query(sellersRef, where('sellerCode', '==', code));
  const sellersSnap = await getDocs(sellersQ);
  if (!sellersSnap.empty) return true;

  return false;
};

// Generate a unique seller code using base pattern; on collision, fallback to initials; on further collision, append numeric suffix
const generateUniqueSellerCode = async (name: string, city: string): Promise<string> => {
  const base = generateSellerCode(name, city);
  if (!(await sellerCodeExists(base))) return base;

  const fallback = generateInitialsSellerCode(name, city);
  if (!(await sellerCodeExists(fallback))) return fallback;

  // If both collide, append a small numeric suffix (1..99) ensuring max length 10
  for (let i = 1; i < 100; i++) {
    const suffix = i.toString();
    const trimmed = fallback.substring(0, Math.max(0, 10 - suffix.length));
    const attempt = `${trimmed}${suffix}`;
    if (!(await sellerCodeExists(attempt))) return attempt;
  }
  // As a last resort, return the fallback (will collide), but loop above should suffice
  return fallback;
};

interface SellerData {
  businessName?: string;
  ownerName?: string;
  email?: string;
  businessAddress?: {
    city?: string;
    state?: string;
    [key: string]: any;
  };
  businessCategory?: string;
  [key: string]: any;
}

interface CategoryRequest {
  id: string;
  sellerId?: string;
  requestedBy?: string;
  sellerName: string;
  sellerEmail: string;
  sellerLocation: string;
  existingCategory: string;
  createdAt?: any;
  status?: string;
  newCategory?: string;
  categories?: string[];
  phoneNumber?: string;
  // FSSAI fields from category-requests
  fssaiNumber?: string;
  fssaiLicenseUrl?: string;
  [key: string]: any;
}

// Compute current coverage (how many sellers assigned to each project)
const getProjectCoverageCounts = async (): Promise<Record<number, number>> => {
  const counts: Record<number, number> = {};
  featuredProjects.forEach(p => { counts[p.id] = 0; });
  try {
    const profilesRef = collection(db, 'seller-profiles');
    const snapshot = await getDocs(profilesRef);
    snapshot.forEach(docSnap => {
      const ap = (docSnap.data() as any)?.assignedProject;
      if (ap?.projectId != null) {
        counts[ap.projectId] = (counts[ap.projectId] || 0) + 1;
      }
    });
  } catch (e) {
    console.warn('Failed to compute project coverage, proceeding with defaults.', e);
  }
  return counts;
};

// Lightweight scorer to pick a relevant Featured Project for a seller, with coverage awareness
const pickBestProjectForSeller = (seller: any, coverage: Record<number, number>) => {
  try {
    const textParts: string[] = [];
    const depts: string[] = Array.isArray(seller?.departments) ? seller.departments : [];
    const category: string = seller?.businessCategory || seller?.category || '';
    const description: string = seller?.about || seller?.description || seller?.bio || '';
    const name: string = seller?.businessName || seller?.name || '';

    if (depts.length) textParts.push(depts.join(' '));
    if (category) textParts.push(category);
    if (description) textParts.push(description);
    if (name) textParts.push(name);
    const corpus = textParts.join(' ').toLowerCase();

    // If any projects have zero coverage, restrict candidates to those first
    const zeroCoverageIds = featuredProjects
      .filter(p => (coverage?.[p.id] ?? 0) === 0)
      .map(p => p.id);

    const candidates = zeroCoverageIds.length > 0
      ? featuredProjects.filter(p => zeroCoverageIds.includes(p.id))
      : featuredProjects;

    let best = { score: -1, project: candidates[0], matched: [] as string[] };
    for (const p of candidates) {
      let score = 0;
      const matched: string[] = [];
      for (const kw of p.keywords) {
        if (!kw) continue;
        const k = kw.toLowerCase();
        if (new RegExp(`\\b${k}\\b`).test(corpus)) { score += 3; matched.push(k); }
        else if (corpus.includes(k)) { score += 1; matched.push(k); }
      }
      if (p.title.toLowerCase().includes(category.toLowerCase())) score += 2;
      // Small inverse-frequency bias if not in zero-coverage phase
      if (zeroCoverageIds.length === 0) {
        const count = coverage?.[p.id] ?? 0;
        // fewer current assignments -> slightly higher score
        score += Math.max(0, 2 - Math.min(2, count));
      }
      if (score > best.score) best = { score, project: p, matched };
    }

    return {
      projectId: best.project.id,
      projectTitle: best.project.title,
      focusArea: best.project.focusArea,
      score: best.score,
      matchedKeywords: best.matched.slice(0, 5),
    };
  } catch {
    const p = featuredProjects[0];
    return {
      projectId: p.id,
      projectTitle: p.title,
      focusArea: p.focusArea,
      score: 0,
      matchedKeywords: [],
    };
  }
};

// Document Card Component
type DocumentCardProps = {
  title: string;
  url?: string;
  documentType?: 'fssai' | 'passport' | 'address' | 'pan' | 'aadhar' | 'signature' | 'other';
};

const DocumentCard = ({ title, url, documentType = 'other' }: DocumentCardProps) => {
  if (!url) return null;
  
  // Document type specific icons
  const getDocumentIcon = () => {
    switch (documentType) {
      case 'fssai':
        return <FileText className="h-4 w-4 text-green-600" />;
      case 'passport':
        return <User className="h-4 w-4 text-blue-600" />;
      case 'address':
        return <MapPin className="h-4 w-4 text-purple-600" />;
      case 'pan':
        return <FileText className="h-4 w-4 text-yellow-600" />;
      case 'aadhar':
        return <CreditCard className="h-4 w-4 text-indigo-600" />;
      case 'signature':
        return <FileText className="h-4 w-4 text-gray-600" />;
      default:
        return <FileText className="h-4 w-4 text-gray-600" />;
    }
  };
  
  return (
    <div className="border-b pb-3 mb-3">
      <div className="flex items-center gap-2 mb-2">
        {getDocumentIcon()}
        <span className="text-xs uppercase text-gray-500">{title}</span>
      </div>
      <button 
        className="bg-blue-600 hover:bg-blue-700 text-white py-1 px-3 rounded-md text-xs flex items-center gap-1"
        onClick={() => window.open(url, '_blank')}
      >
        <Eye className="h-3 w-3" />
        View {title}
      </button>
    </div>
  );
};

export function AdminSellerApprovals() {
  const navigate = useNavigate();
  const location = useLocation();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sellerRegistrations, setSellerRegistrations] = useState<any[]>([]);
  const [selectedSeller, setSelectedSeller] = useState<any>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [processingAction, setProcessingAction] = useState(false);
  const [activeTab, setActiveTab] = useState('pending');
  const [categoryRequests, setCategoryRequests] = useState<CategoryRequest[]>([]);
  const [selectedRequest, setSelectedRequest] = useState<CategoryRequest | null>(null);
  const [isRequestDialogOpen, setIsRequestDialogOpen] = useState(false);
  const [sellerCategories, setSellerCategories] = useState<{[key: string]: string}>({});
  const [departments, setDepartments] = useState<Record<string, string>>({});
  const [selectedCategoryRequest, setSelectedCategoryRequest] = useState<CategoryRequest | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  // Inner tabs for category requests
  const [categoryTab, setCategoryTab] = useState<'pending' | 'approved' | 'rejected'>('pending');
  const { user } = useStore();

  // Ref to the DialogContent and the inner scrolling wrapper
  const requestDialogRef = useRef<HTMLDivElement | null>(null);
  const requestScrollRef = useRef<HTMLDivElement | null>(null);

  // Client-side pagination states
  const [regPage, setRegPage] = useState<{ pending: number; approved: number; rejected: number }>({ pending: 0, approved: 0, rejected: 0 });
  const [catPage, setCatPage] = useState<{ pending: number; approved: number; rejected: number }>({ pending: 0, approved: 0, rejected: 0 });
  const pageSize = 9;
  // Sorting state for registrations
  const [sortBy, setSortBy] = useState<'name_asc' | 'name_desc' | 'created_desc' | 'created_asc'>('name_asc');
  const [sortOpen, setSortOpen] = useState(false);
  
  // Backfill/balance assignment across all sellers that miss an assignedProject
  const balanceProjectCoverage = async () => {
    // 1) Compute current coverage
    let coverage = await getProjectCoverageCounts();

    // 2) Iterate profiles and assign to those missing assignedProject
    const profilesRef = collection(db, 'seller-profiles');
    const profilesSnap = await getDocs(profilesRef);

    for (const docSnap of profilesSnap.docs) {
      const data = docSnap.data() as any;
      const hasAssignment = !!data?.assignedProject?.projectId;
      if (hasAssignment) continue;

      // Build a minimal seller descriptor from profile for scoring
      const sellerDescriptor = {
        departments: Array.isArray(data?.departments) ? data.departments : [],
        businessCategory: data?.businessCategory || data?.category || '',
        description: data?.about || data?.description || '',
        businessName: data?.name || '',
      };

      const assignment = pickBestProjectForSeller(sellerDescriptor, coverage);

      await updateDoc(doc(db, 'seller-profiles', docSnap.id), {
        assignedProject: {
          ...assignment,
          assignedAt: new Date().toISOString(),
          method: 'coverage-balance',
        },
        updatedAt: new Date().toISOString(),
      });

      // Update in-memory coverage so subsequent assignments consider the new state
      coverage[assignment.projectId] = (coverage[assignment.projectId] || 0) + 1;
    }
  };

  // Helper function to get department name
  const getDepartmentName = (deptId: string) => {
    return departments[deptId] || deptId || '';
  };

  // Helper function to get department name with fallback logic
  const getDepartmentInfo = (sellerData: any) => {
    if (!sellerData) return { id: '', name: '' };
    
    // Get the department using the same logic as in the example
    const departments = Array.isArray(sellerData.departments) ? sellerData.departments : [];
    const departmentId = departments[0] ||
      sellerData.department ||
      sellerData.businessCategory ||
      sellerData.category ||
      '';
    
    const departmentName = departmentId ? getDepartmentName(departmentId) : '';
    
    return {
      id: departmentId,
      name: departmentName
    };
  };

  // Add this effect to fetch departments
  useEffect(() => {
    const fetchDepartments = async () => {
      try {
        const departmentsRef = collection(db, 'departments');
        const snapshot = await getDocs(departmentsRef);
        const deptMap: Record<string, string> = {};
        
        snapshot.forEach(doc => {
          deptMap[doc.id] = doc.data().name;
        });
        
        setDepartments(deptMap);
      } catch (error) {
        console.error('Error fetching departments:', error);
      }
    };
    
    fetchDepartments();
  }, []);

  // Accept tab from navigation state or from ?tab= query parameter
  useEffect(() => {
    const stateTab = (location.state as any)?.tab as 'pending' | 'approved' | 'rejected' | 'category-requests' | undefined;
    const queryTab = new URLSearchParams(location.search).get('tab') as 'pending' | 'approved' | 'rejected' | 'category-requests' | null;
    const desired = stateTab || queryTab || null;
    if (desired === 'pending' || desired === 'approved' || desired === 'rejected' || desired === 'category-requests') {
      setActiveTab(desired);
    }
    // We only want to run this on mount/first render
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Reset pagination when switching main tabs
  useEffect(() => {
    setRegPage({ pending: 0, approved: 0, rejected: 0 });
  }, [activeTab]);

  // Reset pagination when sort changes
  useEffect(() => {
    setRegPage({ pending: 0, approved: 0, rejected: 0 });
  }, [sortBy]);

  // Reset pagination when switching category inner tabs
  useEffect(() => {
    setCatPage({ pending: 0, approved: 0, rejected: 0 });
  }, [categoryTab]);

  // Pause global smooth scrolling while modal is open so wheel scroll targets the dialog
  useEffect(() => {
    try {
      if (isDialogOpen || isRequestDialogOpen || showDeleteDialog) {
        (lenis as any)?.stop?.();
      } else {
        (lenis as any)?.start?.();
      }
    } catch {}
    return () => {
      try { (lenis as any)?.start?.(); } catch {}
    };
  }, [isDialogOpen, isRequestDialogOpen, showDeleteDialog]);

  // Robust body + html scroll lock when the Category Request dialog is open
  useEffect(() => {
    if (!isRequestDialogOpen) return;
    const scrollY = window.scrollY || window.pageYOffset;
    const { overflow, position, top, width } = document.body.style as CSSStyleDeclaration;
    const html = document.documentElement;
    const prevHtmlOverflow = html.style.overflow;
    const prevHtmlHeight = html.style.height;
    document.body.style.overflow = 'hidden';
    document.body.style.position = 'fixed';
    document.body.style.top = `-${scrollY}px`;
    document.body.style.width = '100%';
    html.style.overflow = 'hidden';
    html.style.height = '100%';
    return () => {
      document.body.style.overflow = overflow;
      document.body.style.position = position;
      document.body.style.top = top;
      document.body.style.width = width;
      html.style.overflow = prevHtmlOverflow;
      html.style.height = prevHtmlHeight;
      window.scrollTo(0, scrollY);
    };
  }, [isRequestDialogOpen]);

  // Trap wheel/touch/legacy wheel + keyboard events globally when the dialog is open: manually scroll the dialog content
  useEffect(() => {
    if (!isRequestDialogOpen) return;
    const onWheel = (e: WheelEvent) => {
      const scroller = requestScrollRef.current;
      if (!scroller) return;
      // Always prevent default so background never scrolls
      e.preventDefault();
      // Manually scroll the inner dialog container
      scroller.scrollTop += e.deltaY;
    };
    const onMouseWheel = (e: any) => {
      // Legacy event for some browsers/devices
      const scroller = requestScrollRef.current;
      if (!scroller) return;
      const delta = e.wheelDelta ? -e.wheelDelta : (e.deltaY || 0);
      e.preventDefault();
      scroller.scrollTop += delta;
    };
    let lastY: number | null = null;
    const onTouchStart = (e: TouchEvent) => {
      lastY = e.touches && e.touches.length ? e.touches[0].clientY : null;
    };
    const onTouchMove = (e: TouchEvent) => {
      const scroller = requestScrollRef.current;
      if (!scroller) return;
      if (lastY === null) {
        lastY = e.touches && e.touches.length ? e.touches[0].clientY : null;
        return;
      }
      const currentY = e.touches && e.touches.length ? e.touches[0].clientY : lastY;
      const deltaY = lastY - currentY;
      lastY = currentY;
      e.preventDefault();
      scroller.scrollTop += deltaY;
    };
    window.addEventListener('wheel', onWheel, { passive: false, capture: true });
    document.addEventListener('wheel', onWheel as any, { passive: false, capture: true } as any);
    window.addEventListener('mousewheel', onMouseWheel as any, { passive: false, capture: true } as any);
    window.addEventListener('DOMMouseScroll', onMouseWheel as any, { passive: false, capture: true } as any);
    window.addEventListener('touchstart', onTouchStart, { passive: false, capture: true });
    window.addEventListener('touchmove', onTouchMove, { passive: false, capture: true });
    document.addEventListener('touchmove', onTouchMove as any, { passive: false, capture: true } as any);
    const onKeyDown = (e: KeyboardEvent) => {
      const scroller = requestScrollRef.current;
      if (!scroller) return;
      const keys = ['ArrowUp','ArrowDown','PageUp','PageDown','Home','End',' '];
      if (!keys.includes(e.key)) return;
      e.preventDefault();
      const view = scroller.clientHeight;
      switch (e.key) {
        case 'ArrowUp': scroller.scrollTop -= 40; break;
        case 'ArrowDown': scroller.scrollTop += 40; break;
        case 'PageUp': scroller.scrollTop -= view; break;
        case 'PageDown': scroller.scrollTop += view; break;
        case 'Home': scroller.scrollTop = 0; break;
        case 'End': scroller.scrollTop = scroller.scrollHeight; break;
        case ' ': scroller.scrollTop += view; break;
      }
    };
    window.addEventListener('keydown', onKeyDown, { capture: true });
    return () => {
      window.removeEventListener('wheel', onWheel as any, { capture: true } as any);
      document.removeEventListener('wheel', onWheel as any, { capture: true } as any);
      window.removeEventListener('mousewheel', onMouseWheel as any, { capture: true } as any);
      window.removeEventListener('DOMMouseScroll', onMouseWheel as any, { capture: true } as any);
      window.removeEventListener('touchstart', onTouchStart as any, { capture: true } as any);
      window.removeEventListener('touchmove', onTouchMove as any, { capture: true } as any);
      document.removeEventListener('touchmove', onTouchMove as any, { capture: true } as any);
      window.removeEventListener('keydown', onKeyDown as any, { capture: true } as any);
    };
  }, [isRequestDialogOpen]);

  // Check if user is admin (this is a simple check, you might want to implement a more robust admin check)
  useEffect(() => {
    const checkAdminStatus = async () => {
      if (!user) {
        navigate('/login');
        return;
      }

      try {
        // This is a placeholder for admin check
        // In a real application, you would check if the user has admin privileges
        const userRef = doc(db, 'users', user.id);           //const userRef = doc(db, 'users', user.uid);
        const userDoc = await getDoc(userRef);
        
        if (!userDoc.exists() || userDoc.data().role !== 'admin') {
          navigate('/');
          return;
        }
        
        fetchSellerRegistrations();
        fetchCategoryRequests();
      } catch (error) {
        console.error('Error checking admin status:', error);
        navigate('/');
      }
    };

    checkAdminStatus();
  }, [user, navigate]);

  const fetchSellerRegistrations = async () => {
    try {
      setLoading(true);
      
      // Get all seller registrations
      const sellerRegistrationsRef = collection(db, 'seller-registrations');
      const q = query(sellerRegistrationsRef, orderBy('createdAt', 'desc'));
      const querySnapshot = await getDocs(q);
      
      const registrations: any[] = [];
      querySnapshot.forEach((doc) => {
        registrations.push({
          id: doc.id,
          ...doc.data()
        });
      });
      
      setSellerRegistrations(registrations);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching seller registrations:', error);
      setError('Failed to load seller registrations. Please try again later.');
      setLoading(false);
    }
  };

  const fetchCategoryRequests = async () => {
    try {
      setLoading(true);
      setError(null);

      const categoryRequestsRef = collection(db, 'category-requests');
      const q = query(categoryRequestsRef, orderBy('createdAt', 'desc'));
      const querySnapshot = await getDocs(q);

      const requests = await Promise.all(
        querySnapshot.docs.map(async (docSnapshot) => {
          const data = docSnapshot.data();
          let requestData: CategoryRequest = {
            id: docSnapshot.id,
            sellerId: data?.sellerId || data?.requestedBy,
            requestedBy: data?.requestedBy,
            sellerName: data?.sellerName || 'Unknown Seller',
            sellerEmail: data?.sellerEmail || 'No email',
            phoneNumber: data?.phoneNumber || 'No phone',
            sellerLocation: 'Location not specified',
            existingCategory: 'Loading...',
            status: data?.status || 'pending',
            newCategory: data?.newCategory || data?.categoryName || '',
            categories: Array.isArray(data?.categories) ? data.categories : (data?.categoryName ? [data.categoryName] : []),
            createdAt: data?.createdAt || new Date(),
            description: data?.description || '',
            // Pull through FSSAI fields if present on the request
            fssaiNumber: data?.fssaiNumber || '',
            fssaiLicenseUrl: data?.fssaiLicenseUrl || ''
          };

          try {
            if (requestData.sellerId) {
              // First try to get from seller-registrations
              let sellerDoc = await getDoc(doc(db, 'seller-registrations', requestData.sellerId));

              // If not found, try the sellers collection
              if (!sellerDoc.exists()) {
                sellerDoc = await getDoc(doc(db, 'sellers', requestData.sellerId));
              }

              if (sellerDoc.exists()) {
                const sellerData = sellerDoc.data();

                // Get the department from seller registration data
                const departments = Array.isArray(sellerData.departments) ? sellerData.departments : [];
                const department = departments[0] ||
                  sellerData.department ||
                  sellerData.businessCategory ||
                  sellerData.category ||
                  'No category';

                // Get the seller's name with 'name' as the first priority
                const sellerName = sellerData.name ||
                  sellerData.sellerName ||
                  sellerData.businessName ||
                  sellerData.ownerName ||
                  sellerData.displayName ||
                  requestData.sellerName ||
                  'Unknown Seller';

                // Update request data with seller information
                requestData = {
                  ...requestData,
                  sellerName: sellerName,
                  sellerEmail: sellerData.email || requestData.sellerEmail,
                  phoneNumber: sellerData.phoneNumber || sellerData.phone || requestData.phoneNumber,
                  sellerLocation: [
                    sellerData.businessAddress?.city,
                    sellerData.businessAddress?.state,
                    sellerData.city,
                    sellerData.state
                  ].filter(Boolean).join(', ') || 'Location not specified',
                  existingCategory: department
                };
              }
            }
          } catch (error) {
            console.error('Error fetching seller details:', error);
          }

          return requestData;
        })
      );

      setCategoryRequests(requests);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching category requests:', error);
      setError('Failed to load category requests. Please try again later.');
      setLoading(false);
    }
  };

  const handleViewDetails = (seller: any) => {
    setSelectedSeller(seller);
    setIsDialogOpen(true);
  };

  const handleApprove = async (sellerId: string) => {
    try {
      setProcessingAction(true);
      
      // Get seller data
      const sellerRegistrationRef = doc(db, 'seller-registrations', sellerId);
      const sellerDoc = await getDoc(sellerRegistrationRef);
      const sellerData = sellerDoc.data();
      
      if (!sellerData) {
        throw new Error('Seller registration data not found');
      }
      
      // Generate seller code (unique) and assign a Featured Project (coverage-aware)
      const sellerCode = await generateUniqueSellerCode(sellerData.name, sellerData.city);
      const coverage = await getProjectCoverageCounts();
      const assignment = pickBestProjectForSeller(sellerData, coverage);
      
      // Update seller registration: approved + seller code + assigned project
      await updateDoc(sellerRegistrationRef, {
        status: 'approved',
        approvedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        sellerCode,
        assignedProject: {
          ...assignment,
          assignedAt: new Date().toISOString(),
          method: 'keyword-scoring',
        },
      });
      
      // Create seller profile document if it doesn't exist, else update with assignment
      const sellerProfileRef = doc(db, 'seller-profiles', sellerId);
      const sellerProfileDoc = await getDoc(sellerProfileRef);
      
      if (!sellerProfileDoc.exists()) {
        const sellerRegistrationDoc = await getDoc(sellerRegistrationRef);
        const sd = sellerRegistrationDoc.data();
        
        if (!sd) {
          throw new Error('Seller registration data not found');
        }
        
        await setDoc(sellerProfileRef, {
          userId: sellerId,
          name: sd.name,
          email: sd.email,
          phone: sd.phone,
          address: sd.address,
          city: sd.city,
          departments: sd.departments,
          profilePictureUrl: sd.passportPhotoUrl,
          status: 'pending_agreement',
          sellerCode,
          assignedProject: {
            ...assignment,
            assignedAt: new Date().toISOString(),
            method: 'keyword-scoring',
          },
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
      } else {
        await updateDoc(sellerProfileRef, {
          sellerCode,
          assignedProject: {
            ...assignment,
            assignedAt: new Date().toISOString(),
            method: 'keyword-scoring',
          },
          updatedAt: new Date().toISOString(),
        });
      }
      
      // Close dialog and refresh data
      setIsDialogOpen(false);
      fetchSellerRegistrations();
    } catch (error) {
      console.error('Error approving seller:', error);
      setError('Failed to approve seller. Please try again later.');
    } finally {
      setProcessingAction(false);
    }
  };

  const handleReject = async (sellerId: string) => {
    try {
      setProcessingAction(true);
      
      // Update seller registration status to rejected
      const sellerRegistrationRef = doc(db, 'seller-registrations', sellerId);
      await updateDoc(sellerRegistrationRef, {
        status: 'rejected',
        rejectedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      
      // Close dialog and refresh data
      setIsDialogOpen(false);
      fetchSellerRegistrations();
    } catch (error) {
      console.error('Error rejecting seller:', error);
      setError('Failed to reject seller. Please try again later.');
    } finally {
      setProcessingAction(false);
    }
  };

  const handleApproveCategoryRequest = async (requestId: string) => {
    try {
      setProcessingAction(true);
      
      // Get the request data
      const requestRef = doc(db, 'category-requests', requestId);
      const requestDoc = await getDoc(requestRef);
      const requestData = requestDoc.data() as CategoryRequest;
      
      if (!requestData) throw new Error('Request not found');
      
      // Determine categories to add (supports multiple)
      const requestedList: string[] = Array.isArray((requestData as any).categories) && (requestData as any).categories.length
        ? (requestData as any).categories
        : [requestData.categoryName];
      const categoriesToAdd = requestedList
        .filter(Boolean)
        .map((c) => (c || '').toString().toLowerCase().replace(/\s+/g, '-'));
      
      // Update request status
      await updateDoc(requestRef, {
        status: 'approved',
        approvedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      
      // If sellerId exists, update seller's departments in seller-profiles
      if (requestData.requestedBy) {
        const sellerProfileRef = doc(db, 'seller-profiles', requestData.requestedBy);
        const sellerProfileDoc = await getDoc(sellerProfileRef);
        
        if (sellerProfileDoc.exists()) {
          // Update existing seller profile
          const sellerData = sellerProfileDoc.data();
          const currentDepartments = Array.isArray(sellerData.departments) 
            ? sellerData.departments 
            : [];
          
          // Merge all requested categories
          const updatedDepartments = Array.from(new Set([...currentDepartments, ...categoriesToAdd]));
          await updateDoc(sellerProfileRef, {
            departments: updatedDepartments,
            updatedAt: new Date().toISOString()
          });
          console.log('Updated seller departments:', updatedDepartments);
          
          // Also update the main sellers collection for backward compatibility
          const sellerRef = doc(db, 'sellers', requestData.requestedBy);
          const sellerDoc = await getDoc(sellerRef);
          
          if (sellerDoc.exists()) {
            const sellerData = sellerDoc.data();
            const currentSellerDepts = Array.isArray(sellerData.departments) 
              ? sellerData.departments 
              : [];
            const updatedSellerDepts = Array.from(new Set([...currentSellerDepts, ...categoriesToAdd]));
            await updateDoc(sellerRef, {
              departments: updatedSellerDepts,
              updatedAt: new Date().toISOString()
            });
          }
        } else {
          // Create new seller profile with the departments
          await setDoc(sellerProfileRef, {
            sellerId: requestData.requestedBy,
            sellerName: requestData.sellerName || '',
            sellerEmail: requestData.sellerEmail || '',
            departments: categoriesToAdd,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          });
          
          console.log('Created new seller profile with departments:', categoriesToAdd);
        }
      }
      
      // Refresh data and close dialog
      setIsRequestDialogOpen(false);
      fetchCategoryRequests();
      
    } catch (error) {
      console.error('Error approving category request:', error);
      setError('Failed to approve category request. Please try again later.');
    } finally {
      setProcessingAction(false);
    }
  };

  const handleRejectCategoryRequest = async (requestId: string) => {
    try {
      setProcessingAction(true);
      
      // Update category request status to rejected
      const categoryRequestRef = doc(db, 'category-requests', requestId);
      await updateDoc(categoryRequestRef, {
        status: 'rejected',
        rejectedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      });
      
      // Close dialog and refresh data
      setIsRequestDialogOpen(false);
      fetchCategoryRequests();
    } catch (error) {
      console.error('Error rejecting category request:', error);
      setError('Failed to reject category request. Please try again later.');
    } finally {
      setProcessingAction(false);
    }
  };

  const handleDeleteCategoryRequest = async () => {
    if (!selectedCategoryRequest) return;
    
    try {
      setProcessingAction(true);
      await deleteDoc(doc(db, 'category-requests', selectedCategoryRequest.id));
      
      // Remove from local state
      setCategoryRequests(prev => 
        prev.filter(req => req.id !== selectedCategoryRequest.id)
      );
      
      setShowDeleteDialog(false);
    } catch (error) {
      console.error('Error deleting category request:', error);
    } finally {
      setProcessingAction(false);
    }
  };

  const getFilteredRegistrations = (status: string) => {
    return sellerRegistrations.filter(seller => seller.status === status);
  };

  // Sorting helpers
  const getCreatedAtMs = (x: any): number => {
    try {
      const c = x?.createdAt;
      if (!c) return 0;
      if (typeof c?.toDate === 'function') return c.toDate().getTime();
      const t = new Date(c).getTime();
      return isNaN(t) ? 0 : t;
    } catch {
      return 0;
    }
  };
  const compareSeller = (a: any, b: any) => {
    const an = (a.name || a.businessName || '').toString().toLowerCase();
    const bn = (b.name || b.businessName || '').toString().toLowerCase();
    const aCreated = getCreatedAtMs(a);
    const bCreated = getCreatedAtMs(b);
    switch (sortBy) {
      case 'name_asc':
        return an.localeCompare(bn);
      case 'name_desc':
        return bn.localeCompare(an);
      case 'created_desc':
        return bCreated - aCreated || an.localeCompare(bn);
      case 'created_asc':
        return aCreated - bCreated || an.localeCompare(bn);
      default:
        return 0;
    }
  };

  useEffect(() => {
    const fetchSellerCategories = async () => {
      const newCategories: {[key: string]: string} = {};
      
      // Process seller registrations
      for (const request of sellerRegistrations) {
        if (request.sellerId && !sellerCategories[request.sellerId]) {
          try {
            const seller = await firestoreService.getSeller(request.sellerId);
            if (seller && seller.categories && seller.categories.length > 0) {
              newCategories[request.sellerId] = seller.categories[0];
            }
          } catch (error) {
            console.error('Error fetching seller data:', error);
          }
        }
      }
      
      // Process category requests
      for (const request of categoryRequests) {
        if (request.sellerId && !sellerCategories[request.sellerId]) {
          try {
            const seller = await firestoreService.getSeller(request.sellerId);
            if (seller && seller.categories && seller.categories.length > 0) {
              newCategories[request.sellerId] = seller.categories[0];
            }
          } catch (error) {
            console.error('Error fetching seller data:', error);
          }
        }
      }
      
      if (Object.keys(newCategories).length > 0) {
        setSellerCategories(prev => ({
          ...prev,
          ...newCategories
        }));
      }
    };
    
    fetchSellerCategories();
  }, [sellerRegistrations, categoryRequests]);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-gold" />
        <p className="mt-4 text-muted-foreground">Loading seller registrations...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <div className="bg-destructive/10 text-destructive p-4 rounded-md max-w-md text-center">
          <p>{error}</p>
          <Button 
            variant="outline" 
            className="mt-4"
            onClick={() => navigate('/')}
          >
            Return to Home
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold">Seller Approvals</h1>
          <p className="text-muted-foreground mt-1">
            Manage seller registration requests
          </p>
        </div>
        <div className="flex items-center gap-2">
          {/* Sort By */}
          {/* Sort By */}
          <div className="relative">
            <Button
              type="button"
              variant="outline"
              className="btn-hover border border-primary bg-transparent text-primary hover:bg-primary hover:text-primary-foreground h-10 px-4 py-2"
              aria-haspopup="listbox"
              aria-expanded={sortOpen}
              onClick={() => setSortOpen(o => !o)}
              onBlur={(e) => { if (!e.currentTarget.parentElement?.contains(e.relatedTarget as Node)) setSortOpen(false); }}
            >
              Sort By
            </Button>
            {sortOpen && (
              <div className="absolute right-0 mt-2 z-10 w-44 rounded-md border border-border/60 bg-background shadow-lg py-1">
                <ul role="listbox" aria-label="Sort by" className="max-h-64 overflow-auto text-sm">
                  <li>
                    <button
                      type="button"
                      role="option"
                      aria-selected={sortBy === 'name_asc'}
                      className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy === 'name_asc' ? 'font-medium' : ''}`}
                      onClick={() => { setSortBy('name_asc'); setSortOpen(false); }}
                      autoFocus
                    >
                      Name A → Z
                    </button>
                  </li>
                  <li>
                    <button
                      type="button"
                      role="option"
                      aria-selected={sortBy === 'name_desc'}
                      className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy === 'name_desc' ? 'font-medium' : ''}`}
                      onClick={() => { setSortBy('name_desc'); setSortOpen(false); }}
                    >
                      Name Z → A
                    </button>
                  </li>
                  <li>
                    <button
                      type="button"
                      role="option"
                      aria-selected={sortBy === 'created_desc'}
                      className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy === 'created_desc' ? 'font-medium' : ''}`}
                      onClick={() => { setSortBy('created_desc'); setSortOpen(false); }}
                    >
                      Newest
                    </button>
                  </li>
                  <li>
                    <button
                      type="button"
                      role="option"
                      aria-selected={sortBy === 'created_asc'}
                      className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy === 'created_asc' ? 'font-medium' : ''}`}
                      onClick={() => { setSortBy('created_asc'); setSortOpen(false); }}
                    >
                      Oldest
                    </button>
                  </li>
                </ul>
              </div>
            )}
          </div>
          <Button 
            variant="outline" 
            onClick={async () => {
              try {
                setProcessingAction(true);
                await balanceProjectCoverage();
                await fetchSellerRegistrations();
              } catch (e) {
                console.error('Coverage balance failed', e);
                setError('Failed to balance project coverage.');
              } finally {
                setProcessingAction(false);
              }
            }}
            className="flex items-center gap-2"
          >
            Ensure Project Coverage
          </Button>
          <Button 
            variant="outline" 
            onClick={fetchSellerRegistrations}
            className="flex items-center gap-2"
          >
            <RefreshCw className="h-4 w-4" />
            Refresh
          </Button>
        </div>
      </div>

      <Tabs 
        value={activeTab} 
        onValueChange={setActiveTab} 
        className="w-full"
      >
        <TabsList className="grid grid-cols-4 mb-8">
          <TabsTrigger value="pending" className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4" />
            Pending
            <Badge className={`ml-1 ${activeTab === 'pending' ? 'bg-gold text-black' : 'bg-transparent border border-border/60 text-muted-foreground'}`}>
              {getFilteredRegistrations('pending').length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="approved" className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4" />
            Approved
            <Badge className={`ml-1 ${activeTab === 'approved' ? 'bg-gold text-black' : 'bg-transparent border border-border/60 text-muted-foreground'}`}>
              {getFilteredRegistrations('approved').length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger value="rejected" className="flex items-center gap-2">
            <XCircle className="h-4 w-4" />
            Rejected
            <Badge className={`ml-1 ${activeTab === 'rejected' ? 'bg-gold text-black' : 'bg-transparent border border-border/60 text-muted-foreground'}`}>
              {getFilteredRegistrations('rejected').length}
            </Badge>
          </TabsTrigger>
          <TabsTrigger 
            value="category-requests" 
            className="flex items-center gap-2"
            onClick={() => {
              // Optional: Fetch category requests when tab is clicked
              // fetchCategoryRequests();
            }}
          >
            <ListPlus className="h-4 w-4" />
            Category Requests
            <Badge className={`ml-1 ${activeTab === 'category-requests' ? 'bg-gold text-black' : 'bg-transparent border border-border/60 text-muted-foreground'}`}>
              {categoryRequests.length}
            </Badge>
          </TabsTrigger>
        </TabsList>

        {['pending', 'approved', 'rejected'].map((status) => (
          <TabsContent key={status} value={status} className="space-y-4">
            {getFilteredRegistrations(status).length === 0 ? (
              <Card>
                <CardContent className="pt-6 text-center">
                  <p className="text-muted-foreground">No {status} seller registrations found.</p>
                </CardContent>
              </Card>
            ) : (
              <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[...getFilteredRegistrations(status)]
                  .sort(compareSeller)
                  .slice(regPage[status as 'pending'|'approved'|'rejected'] * pageSize, regPage[status as 'pending'|'approved'|'rejected'] * pageSize + pageSize)
                  .map((seller) => (
                  <Card key={seller.id}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{seller.name}</CardTitle>
                          {seller.sellerCode && (
                            <CardDescription className="mt-0.5">
                              <span className="text-xs text-muted-foreground">Seller Code:</span>{' '}
                              <span className="font-mono text-xs">{seller.sellerCode}</span>
                            </CardDescription>
                          )}
                        </div>
                        <Badge 
                          className={
                            seller.status === 'pending' 
                              ? 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100' 
                              : seller.status === 'approved' 
                              ? 'bg-green-100 text-green-800 hover:bg-green-100' 
                              : 'bg-red-100 text-red-800 hover:bg-red-100'
                          }
                        >
                          {seller.status.charAt(0).toUpperCase() + seller.status.slice(1)}
                        </Badge>
                      </div>
                      <CardDescription className="flex items-center gap-1">
                        <Mail className="h-3 w-3" />
                        {seller.email}
                      </CardDescription>
                      <CardDescription className="flex items-center gap-1">
                        <Phone className="h-3 w-3" />
                        {seller.phone}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <div className="flex items-center gap-1 text-sm text-muted-foreground mb-1">
                        <MapPin className="h-3 w-3" />
                        <span className="truncate">{seller.city}</span>
                        <span className="mx-1">•</span>
                        <Calendar className="h-3 w-3" />
                        <span>{new Date(seller.createdAt).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground mb-1">
                        <User className="h-3 w-3" />
                        {seller.businessCategory}
                      </div>
                      {seller.fssaiDetails && seller.fssaiDetails.fssaiNumber && (
                        <div className="flex items-center gap-1 text-sm text-muted-foreground mb-1">
                          <FileText className="h-3 w-3" />
                          <span>FSSAI: {seller.fssaiDetails.fssaiNumber}</span>
                        </div>
                      )}
                      <div className="flex flex-wrap gap-1 mt-2">
                        {seller.departments?.map((dept: string) => (
                          <Badge key={dept} variant="outline" className="text-xs">
                            {getDepartmentName(dept)}
                          </Badge>
                        ))}
                      </div>
                    </CardContent>
                    <CardFooter>
                      <Button 
                        variant="outline" 
                        className="w-full"
                        onClick={() => handleViewDetails(seller)}
                      >
                        <Eye className="mr-2 h-4 w-4" />
                        View Details
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
              <div className="flex items-center justify-between mt-2">
                <Button
                  variant="outline"
                  disabled={regPage[status as 'pending'|'approved'|'rejected'] <= 0}
                  onClick={() => setRegPage(p => ({ ...p, [status]: Math.max(0, p[status as keyof typeof p] - 1) }))}
                >Previous</Button>
                <div className="text-sm text-muted-foreground">
                  {(() => {
                    const total = getFilteredRegistrations(status).length;
                    const pages = Math.max(1, Math.ceil(total / pageSize));
                    const idx = regPage[status as 'pending'|'approved'|'rejected'] + 1;
                    return `Page ${idx} of ${pages}`;
                  })()}
                </div>
                <Button
                  variant="outline"
                  disabled={(regPage[status as 'pending'|'approved'|'rejected'] + 1) * pageSize >= getFilteredRegistrations(status).length}
                  onClick={() => setRegPage(p => ({ ...p, [status]: p[status as keyof typeof p] + 1 }))}
                >Next</Button>
              </div>
              </>
            )}
          </TabsContent>
        ))}

        <TabsContent value="category-requests" className="space-y-4">
          {loading ? (
            <div className="flex justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : categoryRequests.length === 0 ? (
            <div className="text-center p-6 text-muted-foreground">
              No category requests found.
            </div>
          ) : (
            <div className="space-y-4">
              <Tabs value={categoryTab} onValueChange={(v) => setCategoryTab(v as any)}>
                <TabsList className="grid grid-cols-3 rounded-md border border-gold/30 bg-gold/10 p-1">
                  <TabsTrigger value="pending" className="flex items-center gap-2 data-[state=active]:bg-gold data-[state=active]:text-black rounded-md">
                    Pending
                    <Badge className={`ml-1 ${categoryTab === 'pending' ? 'bg-gold text-black' : 'bg-transparent border border-border/60 text-muted-foreground'}`}>
                      {categoryRequests.filter(r => (r.status || 'pending') === 'pending').length}
                    </Badge>
                  </TabsTrigger>
                  <TabsTrigger value="approved" className="flex items-center gap-2 data-[state=active]:bg-gold data-[state=active]:text-black rounded-md">
                    Approved
                    <Badge className={`ml-1 ${categoryTab === 'approved' ? 'bg-gold text-black' : 'bg-transparent border border-border/60 text-muted-foreground'}`}>
                      {categoryRequests.filter(r => (r.status || 'pending') === 'approved').length}
                    </Badge>
                  </TabsTrigger>
                  <TabsTrigger value="rejected" className="flex items-center gap-2 data-[state=active]:bg-gold data-[state=active]:text-black rounded-md">
                    Rejected
                    <Badge className={`ml-1 ${categoryTab === 'rejected' ? 'bg-gold text-black' : 'bg-transparent border border-border/60 text-muted-foreground'}`}>
                      {categoryRequests.filter(r => (r.status || 'pending') === 'rejected').length}
                    </Badge>
                  </TabsTrigger>
                </TabsList>

                {(['pending','approved','rejected'] as const).map(stat => (
                  <TabsContent key={stat} value={stat} className="space-y-4">
                    {categoryRequests.filter(r => (r.status || 'pending') === stat).length === 0 ? (
                      <div className="text-center p-6 text-muted-foreground">
                        No {stat} requests.
                      </div>
                    ) : (
                      <>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {categoryRequests
                          .filter(r => (r.status || 'pending') === stat)
                          .slice(catPage[stat] * pageSize, catPage[stat] * pageSize + pageSize)
                          .map((request) => (
                            <Card key={request.id} className="overflow-hidden">
                              <CardHeader className="pb-2">
                                <div className="flex justify-between items-start">
                                  <div>
                                    <CardTitle className="text-lg">
                                      {request.sellerName || 'Unknown Seller'}
                                    </CardTitle>
                                  </div>
                                  <Badge 
                                    variant={request.status === 'pending' ? 'outline' : 
                                            request.status === 'approved' ? 'default' : 'destructive'}
                                  >
                                    {request.status}
                                  </Badge>
                                </div>
                                
                                <div className="space-y-1 mt-2">
                                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                                    <Mail className="h-3 w-3" />
                                    <span className="truncate">{request.sellerEmail || 'No email'}</span>
                                  </div>
                                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                                    <Phone className="h-3 w-3" />
                                    <span className="truncate">{request.phoneNumber || 'No phone number'}</span>
                                  </div>
                                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                                    <MapPin className="h-3 w-3" />
                                    <span className="truncate">{request.sellerLocation || 'Location not specified'}</span>
                                  </div>
                                  {request.fssaiNumber && (
                                    <div className="flex items-center gap-1 text-sm text-muted-foreground">
                                      <FileText className="h-3 w-3" />
                                      <span className="truncate">FSSAI: {request.fssaiNumber}</span>
                                      {request.fssaiLicenseUrl && (
                                        <button
                                          className="ml-2 text-xs text-blue-500 underline"
                                          onClick={(e) => { e.stopPropagation(); window.open(request.fssaiLicenseUrl!, '_blank'); }}
                                        >
                                          View License
                                        </button>
                                      )}
                                    </div>
                                  )}
                                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                                    <Calendar className="h-3 w-3" />
                                    <span>
                                      {request.createdAt 
                                        ? new Date(
                                            typeof request.createdAt === 'number' 
                                              ? request.createdAt 
                                              : request.createdAt.seconds * 1000
                                          ).toLocaleDateString('en-US', { 
                                            year: 'numeric', 
                                            month: 'long', 
                                            day: 'numeric',
                                            hour: '2-digit',
                                            minute: '2-digit'
                                          })
                                        : 'N/A'
                                      }
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-2 pt-1 flex-wrap">
                                    {sellerCategories[request.sellerId || ''] && (
                                      <Badge variant="outline" className="text-xs">
                                        {getDepartmentName(sellerCategories[request.sellerId || ''])}
                                      </Badge>
                                    )}
                                    {(Array.isArray(request.categories) && request.categories.length > 0
                                      ? request.categories
                                      : (request.newCategory ? [request.newCategory] : [])
                                    ).map((c) => (
                                      <Badge key={c} className="bg-foreground text-background hover:bg-foreground/90 text-xs">
                                        {c}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              </CardHeader>
                              
                              <CardFooter className="flex justify-end gap-2 border-t pt-3">
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  className="text-destructive hover:bg-destructive/10 hover:text-destructive"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedCategoryRequest(request);
                                    setShowDeleteDialog(true);
                                  }}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  className="flex items-center gap-1"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedRequest(request);
                                    setIsRequestDialogOpen(true);
                                  }}
                                >
                                  <Eye className="h-4 w-4" />
                                  <span>View Details</span>
                                </Button>
                              </CardFooter>
                            </Card>
                          ))}
                      </div>
                      <div className="flex items-center justify-between mt-2">
                        <Button
                          variant="outline"
                          disabled={catPage[stat] <= 0}
                          onClick={() => setCatPage(p => ({ ...p, [stat]: Math.max(0, p[stat] - 1) }))}
                        >Previous</Button>
                        <div className="text-sm text-muted-foreground">
                          {(() => {
                            const total = categoryRequests.filter(r => (r.status || 'pending') === stat).length;
                            const pages = Math.max(1, Math.ceil(total / pageSize));
                            const idx = catPage[stat] + 1;
                            return `Page ${idx} of ${pages}`;
                          })()}
                        </div>
                        <Button
                          variant="outline"
                          disabled={(catPage[stat] + 1) * pageSize >= categoryRequests.filter(r => (r.status || 'pending') === stat).length}
                          onClick={() => setCatPage(p => ({ ...p, [stat]: p[stat] + 1 }))}
                        >Next</Button>
                      </div>
                      </>
                    )}
                  </TabsContent>
                ))}
              </Tabs>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Seller Details Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-4xl p-0">
          {selectedSeller && (
            <div
              className="h-[90vh] overflow-y-auto overscroll-contain px-6 py-4"
              tabIndex={0}
              data-lenis-prevent
              onWheelCapture={(e) => {
                e.preventDefault();
                e.stopPropagation();
                const el = e.currentTarget;
                el.scrollTop += e.deltaY;
              }}
            >
              <DialogHeader className="mb-6">
                <div className="flex items-start justify-between">
                  <div>
                    <DialogTitle className="text-2xl">
                      {selectedSeller.businessName || selectedSeller.name}
                    </DialogTitle>
                    <DialogDescription>
                      {selectedSeller.sellerCode && (
                        <span className="block">Seller Code: {selectedSeller.sellerCode}</span>
                      )}
                      <span className={cn(
                        "inline-block px-2 py-0.5 rounded-full text-xs mt-1",
                        selectedSeller.status === 'approved' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-yellow-100 text-yellow-800'
                      )}>
                        {selectedSeller.status === 'approved' ? 'Approved' : 'Pending Approval'}
                      </span>
                    </DialogDescription>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    <p>Registered on: {new Date(selectedSeller.createdAt).toLocaleDateString()}</p>
                  </div>
                </div>
              </DialogHeader>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Contact Information */}
                <div>
                  <div className="flex items-center mb-4">
                    <User className="h-5 w-5 text-blue-600 mr-2" />
                    <h3 className="font-medium text-lg">Contact Information</h3>
                  </div>
                  <div>
                    <div className="space-y-4">
                      <div className="border-b pb-2">
                        <p className="text-xs uppercase text-gray-500 mb-1">FULL NAME</p>
                        <p className="font-medium">
                          {selectedSeller.ownerName || selectedSeller.name || 'Not provided'}
                        </p>
                      </div>
                      
                      <div className="border-b pb-2">
                        <p className="text-xs uppercase text-gray-500 mb-1">EMAIL</p>
                        <p className="font-medium flex items-center gap-1">
                          <Mail className="h-4 w-4 text-gray-500" />
                          {selectedSeller.email}
                        </p>
                      </div>
                      
                      <div className="border-b pb-2">
                        <p className="text-xs uppercase text-gray-500 mb-1">PHONE</p>
                        <p className="font-medium flex items-center gap-1">
                          <Phone className="h-4 w-4 text-gray-500" />
                          {selectedSeller.phone}
                        </p>
                      </div>
                      
                      <div className="border-b pb-2">
                        <p className="text-xs uppercase text-gray-500 mb-1">BUSINESS ADDRESS</p>
                        <p className="font-medium">
                          {selectedSeller.businessAddress?.addressLine1 ? 
                            selectedSeller.businessAddress.addressLine1 : 
                            selectedSeller.address || 'Not provided'}
                        </p>
                      </div>
                      
                      <div className="border-b pb-2">
                        <p className="text-xs uppercase text-gray-500 mb-1">CITY</p>
                        <p className="font-medium flex items-center gap-1">
                          <MapPin className="h-4 w-4 text-gray-500" />
                          {selectedSeller.businessAddress?.city || selectedSeller.city || 'Not provided'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Bank Details */}
                <div>
                  <div className="flex items-center mb-4">
                    <CreditCard className="h-5 w-5 text-green-600 mr-2" />
                    <h3 className="font-medium text-lg">Bank Details</h3>
                  </div>
                  <div>
                    <div className="space-y-4">
                      <div className="border-b pb-2">
                        <p className="text-xs uppercase text-gray-500 mb-1">ACCOUNT HOLDER NAME</p>
                        <p className="font-medium">
                          {selectedSeller.bankDetails?.accountHolderName || selectedSeller.bankAccountName || 'Not provided'}
                        </p>
                      </div>
                      
                      <div className="border-b pb-2">
                        <p className="text-xs uppercase text-gray-500 mb-1">ACCOUNT NUMBER</p>
                        <p className="font-medium">
                          {selectedSeller.bankDetails?.accountNumber 
                            ? selectedSeller.bankDetails.accountNumber
                            : selectedSeller.bankAccountNumber 
                              ? selectedSeller.bankAccountNumber
                              : 'Not provided'}
                        </p>
                      </div>
                      
                      <div className="border-b pb-2">
                        <p className="text-xs uppercase text-gray-500 mb-1">BANK NAME</p>
                        <p className="font-medium">
                          {selectedSeller.bankDetails?.bankName || selectedSeller.bankName || 'Not provided'}
                        </p>
                      </div>
                      
                      <div className="border-b pb-2">
                        <p className="text-xs uppercase text-gray-500 mb-1">IFSC CODE</p>
                        <p className="font-medium">
                          {selectedSeller.bankDetails?.ifscCode || selectedSeller.ifscCode || 'Not provided'}
                        </p>
                      </div>
                      
                      {(selectedSeller.bankDetails?.upiId || selectedSeller.upiId) && (
                        <div className="border-b pb-2">
                          <p className="text-xs uppercase text-gray-500 mb-1">UPI ID</p>
                          <p className="font-medium">
                            {selectedSeller.bankDetails?.upiId || selectedSeller.upiId}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Business Categories */}
                <div>
                  <div className="flex items-center mb-4">
                    <ListPlus className="h-5 w-5 text-purple-600 mr-2" />
                    <h3 className="font-medium text-lg">Business Categories</h3>
                  </div>
                  <div>
                    <div className="space-y-4">
                      <div className="border-b pb-2">
                        <p className="text-xs uppercase text-gray-500 mb-1">DEPARTMENTS</p>
                        <div className="flex flex-wrap gap-2">
                          {selectedSeller.departments?.length > 0 ? (
                            selectedSeller.departments.map((dept: string) => (
                              <span key={dept} className="text-purple-800 text-xs">
                                {getDepartmentName(dept) || dept}
                              </span>
                            ))
                          ) : (
                            <span className="text-gray-500 italic">No departments selected</span>
                          )}
                        </div>
                      </div>
                      
                      {/* FSSAI Information */}
                      {selectedSeller.fssaiDetails && (
                        <div className="border-b pb-2">
                          <p className="text-xs uppercase text-gray-500 mb-1">FSSAI DETAILS</p>
                          <div className="space-y-2">
                            <p className="text-sm">
                              <span className="font-medium">License Number:</span> {selectedSeller.fssaiDetails.fssaiNumber}
                            </p>
                            <p className="text-sm">
                              <span className="font-medium">Verification Status:</span> {selectedSeller.fssaiDetails.verified ? 'Verified' : 'Not Verified'}
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Documents Section */}
              <div className="mt-8">
                <div className="flex items-center mb-4">
                  <FileText className="h-5 w-5 text-yellow-500 mr-2" />
                  <h3 className="font-medium text-lg">Seller Documents</h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Left column - Identity Documents */}
                  <div>
                    <div className="mb-3 border-b pb-2">
                      <p className="text-xs uppercase text-gray-500">IDENTITY DOCUMENTS</p>
                    </div>
                    
                    <div>
                      {/* Passport Photo */}
                      <DocumentCard 
                        title="Passport Photo"
                        url={selectedSeller.passportPhotoUrl}
                        documentType="passport"
                      />
                      
                      {/* Address Proof */}
                      <DocumentCard 
                        title="Address Proof"
                        url={selectedSeller.addressProofUrl}
                        documentType="address"
                      />
                    </div>
                  </div>
                  
                  {/* Right column - Business & Verification Documents */}
                  <div>
                    <div className="mb-3 border-b pb-2">
                      <p className="text-xs uppercase text-gray-500">BUSINESS & VERIFICATION DOCUMENTS</p>
                    </div>
                    
                    <div>
                      {/* FSSAI Certificate */}
                      {(selectedSeller.fssaiCertificateUrl || (selectedSeller.fssaiDetails && selectedSeller.fssaiDetails.fssaiCertificateUrl)) && (
                        <DocumentCard 
                          title="FSSAI Certificate"
                          url={selectedSeller.fssaiCertificateUrl || (selectedSeller.fssaiDetails && selectedSeller.fssaiDetails.fssaiCertificateUrl)}
                          documentType="fssai"
                        />
                      )}
                      
                      {/* Signature */}
                      <DocumentCard 
                        title="E-Signature"
                        url={selectedSeller.signatureUrl}
                        documentType="signature"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              {selectedSeller.status === 'pending' && (
                <div className="mt-8 pt-4 border-t sticky bottom-0 bg-black">
                  <div className="flex flex-col md:flex-row justify-between items-center gap-4 px-4 py-3">
                    <div className="text-sm text-yellow-500 flex items-center gap-2">
                      <AlertTriangle className="h-4 w-4" />
                      <span>Please review all documents carefully before making a decision.</span>
                    </div>
                    
                    <div className="flex gap-3 w-full md:w-auto">
                      <Button
                        variant="outline"
                        className="bg-white border border-red-500 text-red-600 hover:bg-red-50 rounded-md px-4 py-2 h-auto flex-1 md:flex-none"
                        onClick={() => handleReject(selectedSeller.id)}
                        disabled={processingAction}
                      >
                        {processingAction ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                          <XCircle className="mr-2 h-4 w-4" />
                        )}
                        Reject Application
                      </Button>
                      
                      <Button
                        className="bg-green-600 hover:bg-green-700 text-white rounded-md px-4 py-2 h-auto flex-1 md:flex-none"
                        onClick={() => handleApprove(selectedSeller.id)}
                        disabled={processingAction}
                      >
                        {processingAction ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                          <CheckCircle className="mr-2 h-4 w-4" />
                        )}
                        Approve Application
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Category Request Dialog */}
      <Dialog modal open={isRequestDialogOpen} onOpenChange={setIsRequestDialogOpen}>
        {/* Background interaction/scroll blocker (below content, above page) */}
        {isRequestDialogOpen && (
          <div
            className="fixed inset-0 z-[90]"
            // Block all interactions and scrolling on the background
            onWheel={(e) => { e.preventDefault(); e.stopPropagation(); }}
            onWheelCapture={(e) => { e.preventDefault(); e.stopPropagation(); }}
            onScroll={(e) => { e.preventDefault(); e.stopPropagation(); }}
            onTouchMove={(e) => { e.preventDefault(); e.stopPropagation(); }}
            onTouchStart={(e) => { e.preventDefault(); e.stopPropagation(); }}
            onMouseDown={(e) => { e.preventDefault(); e.stopPropagation(); }}
            onClick={(e) => { e.preventDefault(); e.stopPropagation(); }}
          />
        )}
        <DialogContent 
          className="max-w-3xl p-0 overflow-hidden touch-none z-[100]"
          data-lenis-prevent
          ref={requestDialogRef}
          onWheel={(e) => {
            // Prevent bubbling to background even in bubble phase
            e.stopPropagation();
          }}
          onKeyDown={(e) => {
            // Contain keyboard scroll keys to the dialog
            const keys = ['ArrowUp','ArrowDown','PageUp','PageDown','Home','End',' '];
            if (keys.includes(e.key)) {
              e.stopPropagation();
            }
          }}
        >
          {selectedRequest && (
            <div
              ref={requestScrollRef}
              className="max-h-[85vh] overflow-y-auto overscroll-contain px-6 py-4"
              onWheelCapture={(e) => {
                const el = requestScrollRef.current;
                if (!el) return;
                // Scroll this wrapper and contain the event
                el.scrollTop += e.deltaY;
                e.preventDefault();
                e.stopPropagation();
              }}
            >
              <DialogHeader>
                <DialogTitle className="text-2xl flex items-center gap-2">
                  <PlusCircle className="h-5 w-5" />
                  {/* Show all requested categories as badges; fallback to single name */}
                  <span className="flex flex-wrap gap-2">
                    {(Array.isArray(selectedRequest.categories) && selectedRequest.categories.length > 0
                      ? selectedRequest.categories
                      : (selectedRequest.categoryName ? [selectedRequest.categoryName] : [])
                    ).map((c) => (
                      <Badge key={c} className="bg-foreground text-background hover:bg-foreground/90 text-xs">
                        {c}
                      </Badge>
                    ))}
                  </span>
                </DialogTitle>
                <DialogDescription>
                  Category Request Details
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-4">
                <div>
                  <h3 className="font-medium mb-2">Request Information</h3>
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Requested Categories</p>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {(Array.isArray(selectedRequest.categories) && selectedRequest.categories.length > 0
                          ? selectedRequest.categories
                          : (selectedRequest.newCategory || selectedRequest.categoryName ? [selectedRequest.newCategory || selectedRequest.categoryName] : [])
                        ).map((c) => (
                          <Badge key={c} variant="outline" className="text-xs">
                            {c}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Description</p>
                      <p>{selectedRequest.description || 'No description provided'}</p>
                    </div>
                    {selectedRequest.fssaiNumber && (
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">FSSAI License Number</p>
                        <p>{selectedRequest.fssaiNumber}</p>
                      </div>
                    )}
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Seller Name</p>
                      <p>{selectedRequest.sellerName || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Seller Email</p>
                      <p>{selectedRequest.sellerEmail || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Location</p>
                      <p>{selectedRequest.sellerLocation || 'N/A'}</p>
                    </div>
                    {selectedRequest.fssaiLicenseUrl && (
                      <div className="pt-1">
                        <DocumentCard 
                          title="FSSAI License"
                          url={selectedRequest.fssaiLicenseUrl}
                          documentType="fssai"
                        />
                      </div>
                    )}
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-2">Request Status</h3>
                  <div className="space-y-2">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Status</p>
                      <Badge 
                        variant={selectedRequest.status === 'pending' ? 'outline' : 
                                selectedRequest.status === 'approved' ? 'default' : 'destructive'}
                      >
                        {selectedRequest.status}
                      </Badge>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Request Date</p>
                      <p>{
                        selectedRequest.createdAt 
                          ? new Date(
                              typeof selectedRequest.createdAt === 'number' 
                                ? selectedRequest.createdAt 
                                : selectedRequest.createdAt.seconds * 1000
                            ).toLocaleDateString('en-US', { 
                              year: 'numeric', 
                              month: 'long', 
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })
                          : 'N/A'
                      }</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              {selectedRequest.status === 'pending' && (
                <div className="mt-8 pt-6 border-t flex justify-end space-x-4">
                  <Button
                    variant="outline"
                    className="border-red-500 text-red-500 hover:bg-red-50 hover:text-red-600"
                    onClick={() => handleRejectCategoryRequest(selectedRequest.id)}
                    disabled={processingAction}
                  >
                    {processingAction ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <XCircle className="mr-2 h-4 w-4" />
                    )}
                    Reject
                  </Button>
                  <Button
                    className="bg-green-600 hover:bg-green-700"
                    onClick={() => handleApproveCategoryRequest(selectedRequest.id)}
                    disabled={processingAction}
                  >
                    {processingAction ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <CheckCircle className="mr-2 h-4 w-4" />
                    )}
                    Approve
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Category Request Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Category Request</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this category request? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDeleteCategoryRequest}
              disabled={processingAction}
            >
              {processingAction ? 'Deleting...' : 'Delete'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
