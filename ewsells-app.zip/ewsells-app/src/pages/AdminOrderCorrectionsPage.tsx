import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Search, Loader2, CheckCircle, XCircle } from 'lucide-react';
import { auth, db } from '@/lib/firebase';
import { collection, doc, getDoc, getDocs, orderBy, query, serverTimestamp, updateDoc } from 'firebase/firestore';
import { useToast } from '@/components/ui/toast-context';

export default function AdminOrderCorrectionsPage() {
  const [loading, setLoading] = useState(true);
  const [requests, setRequests] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [statusTab, setStatusTab] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const { showToast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [adminChecked, setAdminChecked] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [chosenStatusMap, setChosenStatusMap] = useState<Record<string, string>>({});
  // client-side pagination
  const [pageIndex, setPageIndex] = useState<number>(0);
  const pageSize = 12;
  // sorting UI state (only time-based options kept)
  const [sortBy, setSortBy] = useState<'created_desc' | 'created_asc'>('created_desc');
  const [sortOpen, setSortOpen] = useState(false);

  // Verify admin
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const currentUser = auth.currentUser;
        if (!currentUser) {
          navigate('/admin-login');
          return;
        }
        const userRef = doc(db, 'users', currentUser.uid);
        const snap = await getDoc(userRef);
        if (!snap.exists() || snap.data()?.role !== 'admin') {
          try { await auth.signOut(); } catch {}
          navigate('/admin-login');
          return;
        }
        if (!cancelled) setAdminChecked(true);
      } catch (e) {
        console.error('Admin check failed in AdminOrderCorrectionsPage:', e);
        navigate('/admin-login');
      }
    })();
    return () => { cancelled = true; };
  }, [navigate]);

  // Accept initial tab from navigation state or query param
  useEffect(() => {
    const stateTab = (location.state as any)?.tab as 'all' | 'pending' | 'approved' | 'rejected' | undefined;
    const queryTab = new URLSearchParams(location.search).get('tab') as 'all' | 'pending' | 'approved' | 'rejected' | null;
    const desired = stateTab || queryTab || null;
    if (desired === 'all' || desired === 'pending' || desired === 'approved' || desired === 'rejected') {
      setStatusTab(desired as any);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // reset pagination on tab switch
  useEffect(() => {
    setPageIndex(0);
  }, [statusTab]);

  // Load requests
  useEffect(() => {
    if (!adminChecked) return;
    let cancelled = false;
    (async () => {
      try {
        setLoading(true);
        const q = query(collection(db, 'order-status-corrections'), orderBy('createdAt', 'desc'));
        const snap = await getDocs(q);
        if (cancelled) return;
        setRequests(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      } catch (e) {
        console.error('Failed to load order status correction requests:', e);
        showToast({ message: 'Failed to load correction requests', type: 'error' });
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [adminChecked, showToast]);

  const norm = (s: string) => (s || '').toLowerCase();
  const matches = (r: any) => !search ||
    norm(r.orderId).includes(norm(search)) ||
    norm(r.userId).includes(norm(search)) ||
    norm(r.reason).includes(norm(search)) ||
    norm(r.id).includes(norm(search));

  const byStatus = (r: any) => statusTab === 'all' ? true : (r.status || 'pending') === statusTab;
  const visible = requests.filter(byStatus).filter(matches);
  const counts = {
    all: requests.length,
    pending: requests.filter(r => (r.status || 'pending') === 'pending').length,
    approved: requests.filter(r => r.status === 'approved').length,
    rejected: requests.filter(r => r.status === 'rejected').length,
  };
  // reset pagination when sort changes
  useEffect(() => { setPageIndex(0); }, [sortBy]);

  // sorting helpers and sorted list
  const getCreatedMs = (r: any): number => {
    try {
      const v = r?.createdAt;
      if (!v) return 0;
      if (typeof v?.toDate === 'function') return v.toDate().getTime();
      const t = new Date(v).getTime();
      return Number.isFinite(t) ? t : 0;
    } catch { return 0; }
  };
  const compareReq = (a: any, b: any) => {
    switch (sortBy) {
      case 'created_desc':
        return getCreatedMs(b) - getCreatedMs(a);
      case 'created_asc':
        return getCreatedMs(a) - getCreatedMs(b);
      default:
        return 0;
    }
  };
  const sortedVisible = [...visible].sort(compareReq);
  const pageTotal = Math.max(1, Math.ceil(sortedVisible.length / pageSize));
  const pageRows = sortedVisible.slice(pageIndex * pageSize, pageIndex * pageSize + pageSize);

  const applyOrderStatusIfAny = async (r: any) => {
    const nextStatus = (chosenStatusMap[r.id] || '').trim();
    if (!nextStatus) return;
    try {
      await updateDoc(doc(db, 'orders', r.orderId), {
        status: nextStatus,
        updatedAt: serverTimestamp(),
      });
    } catch (e) {
      console.warn('Failed to update order status for', r.orderId, e);
      showToast({ message: 'Order status update failed, but request status will be saved', type: 'error' });
    }
  };

  const updateRequestStatus = async (r: any, next: 'approved' | 'rejected') => {
    try {
      setBusyId(r.id);
      if (next === 'approved') {
        await applyOrderStatusIfAny(r);
      }
      await updateDoc(doc(db, 'order-status-corrections', r.id), {
        status: next,
        updatedAt: serverTimestamp(),
      });
      setRequests(prev => prev.map(x => x.id === r.id ? { ...x, status: next } : x));
      showToast({ message: `Request ${next}`, type: 'success' });
    } catch (e) {
      console.error('Failed to update correction request', e);
      showToast({ message: 'Failed to update request', type: 'error' });
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 mb-4">
        <div>
          <h1 className="text-3xl font-bold mb-1">Order Status Corrections</h1>
          <p className="text-muted-foreground">Review user-submitted correction requests and optionally adjust order status</p>
        </div>
        {/* Sort By aligned to right of title */}
        <div className="relative">
          <Button
            type="button"
            variant="outline"
            className="btn-hover h-10 px-4 py-2"
            aria-haspopup="listbox"
            aria-expanded={sortOpen}
            onClick={() => setSortOpen(o => !o)}
            onBlur={(e) => { if (!e.currentTarget.parentElement?.contains(e.relatedTarget as Node)) setSortOpen(false); }}
          >
            Sort By
          </Button>
          {sortOpen && (
            <div className="absolute right-0 mt-2 z-10 w-56 rounded-md border border-border/60 bg-background shadow-lg py-1">
              <ul role="listbox" aria-label="Sort by" className="max-h-64 overflow-auto text-sm">
                <li><button type="button" role="option" aria-selected={sortBy==='created_desc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='created_desc'?'font-medium':''}`} onClick={() => { setSortBy('created_desc'); setSortOpen(false); }} autoFocus>Newest</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='created_asc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='created_asc'?'font-medium':''}`} onClick={() => { setSortBy('created_asc'); setSortOpen(false); }}>Oldest</button></li>
              </ul>
            </div>
          )}
        </div>
      </div>

      { !adminChecked ? (
        <div className="flex items-center gap-2 text-muted-foreground py-10"><Loader2 className="h-5 w-5 animate-spin"/>Verifying admin…</div>
      ) : (
        <>
          <div className="mb-4 flex flex-col md:flex-row md:items-center gap-3">
            <div className="flex items-center gap-2">
              <Button
                variant={statusTab === 'pending' ? 'default' : 'ghost'}
                className={statusTab === 'pending' ? 'bg-gold text-black hover:bg-gold/90' : ''}
                onClick={() => setStatusTab('pending')}
              >
                <span>Pending</span>
                <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${statusTab === 'pending' ? 'bg-black/20 text-black' : 'bg-gold/20 text-gold'}`}>{counts.pending}</span>
              </Button>
              <Button
                variant={statusTab === 'approved' ? 'default' : 'ghost'}
                className={statusTab === 'approved' ? 'bg-gold text-black hover:bg-gold/90' : ''}
                onClick={() => setStatusTab('approved')}
              >
                <span>Approved</span>
                <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${statusTab === 'approved' ? 'bg-black/20 text-black' : 'bg-gold/20 text-gold'}`}>{counts.approved}</span>
              </Button>
              <Button
                variant={statusTab === 'rejected' ? 'default' : 'ghost'}
                className={statusTab === 'rejected' ? 'bg-gold text-black hover:bg-gold/90' : ''}
                onClick={() => setStatusTab('rejected')}
              >
                <span>Rejected</span>
                <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${statusTab === 'rejected' ? 'bg-black/20 text-black' : 'bg-gold/20 text-gold'}`}>{counts.rejected}</span>
              </Button>
              <Button
                variant={statusTab === 'all' ? 'default' : 'ghost'}
                className={statusTab === 'all' ? 'bg-gold text-black hover:bg-gold/90' : ''}
                onClick={() => setStatusTab('all')}
              >
                <span>All</span>
                <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${statusTab === 'all' ? 'bg-black/20 text-black' : 'bg-gold/20 text-gold'}`}>
                  {counts.all}
                </span>
              </Button>
            </div>
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by orderId, userId, reason, or id…"
                className="w-full pl-8 pr-3 py-2 rounded-md bg-muted/40 outline-none border border-border/60 focus:border-gold"
              />
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Correction Requests</CardTitle>
              <CardDescription>Incoming and processed order status corrections</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center gap-2 text-muted-foreground py-10"><Loader2 className="h-5 w-5 animate-spin"/>Loading…</div>
              ) : sortedVisible.length === 0 ? (
                <div className="text-muted-foreground">No correction requests found.</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full text-sm">
                    <thead className="text-left text-muted-foreground">
                      <tr>
                        <th className="py-2 pr-4">Order</th>
                        <th className="py-2 pr-4">User</th>
                        <th className="py-2 pr-4">Current Status</th>
                        <th className="py-2 pr-4">Reason</th>
                        <th className="py-2 pr-4">Requested</th>
                        <th className="py-2 pr-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pageRows.map((r) => (
                        <tr key={r.id} className="border-t border-border/60 align-top">
                          <td className="py-2 pr-4 max-w-xs">
                            <div className="font-mono text-xs break-all">{r.orderId || '-'}</div>
                            <div className="text-[10px] text-muted-foreground break-all">{r.id}</div>
                          </td>
                          <td className="py-2 pr-4">
                            <div className="font-mono text-xs break-all">{r.userId || '-'}</div>
                          </td>
                          <td className="py-2 pr-4">{r.currentStatus || '-'}</td>
                          <td className="py-2 pr-4 max-w-md">
                            <div className="text-xs whitespace-pre-wrap break-words">{r.reason || '-'}</div>
                          </td>
                          <td className="py-2 pr-4">{r.createdAt?.toDate ? r.createdAt.toDate().toLocaleString() : (r.createdAt || '-')}</td>
                          <td className="py-2 pr-4">
                            <div className="flex items-center gap-2 flex-wrap">
                              <select
                                className="border bg-background rounded px-2 py-1 text-xs"
                                value={chosenStatusMap[r.id] || ''}
                                onChange={(e) => setChosenStatusMap(m => ({ ...m, [r.id]: e.target.value }))}
                              >
                                <option value="">No change</option>
                                <option value="pending">pending</option>
                                <option value="processing">processing</option>
                                <option value="shipped">shipped</option>
                                <option value="delivered">delivered</option>
                                <option value="cancelled">cancelled</option>
                              </select>
                              <Button
                                size="sm"
                                variant="outline"
                                disabled={busyId === r.id || (r.status || 'pending') === 'approved'}
                                className={(r.status || 'pending') === 'approved' ? 'bg-gold text-black hover:bg-gold/90 border-gold' : ''}
                                onClick={() => updateRequestStatus(r, 'approved')}
                              >
                                <CheckCircle className="h-4 w-4 mr-1"/>
                                Approve
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                disabled={busyId === r.id || r.status === 'rejected'}
                                className={r.status === 'rejected' ? 'ring-2 ring-destructive/60' : ''}
                                onClick={() => updateRequestStatus(r, 'rejected')}
                              >
                                <XCircle className="h-4 w-4 mr-1"/>
                                Reject
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {/* Pagination */}
                  <div className="mt-4 flex items-center justify-between">
                    <Button type="button" variant="outline" disabled={pageIndex <= 0} onClick={() => setPageIndex(i => Math.max(0, i - 1))}>Previous</Button>
                    <div className="text-sm text-muted-foreground">Page {pageIndex + 1} of {pageTotal}</div>
                    <Button type="button" variant="outline" disabled={(pageIndex + 1) >= pageTotal} onClick={() => setPageIndex(i => i + 1)}>Next</Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
