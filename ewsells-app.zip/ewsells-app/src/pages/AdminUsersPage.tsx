import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/toast-context';
import { db } from '@/lib/firebase';
import { getStorage, ref as storageRef, listAll, deleteObject } from 'firebase/storage';
import { doc, getDoc, deleteDoc, updateDoc, collection, query, where, getDocs, getCountFromServer } from 'firebase/firestore';
import { Users, CheckSquare, Loader2, Ban, Trash2, Eye, Package, Search } from 'lucide-react';

export default function AdminUsersPage() {
  const [activeTab, setActiveTab] = useState<'users' | 'sellers'>('users');
  const [loading, setLoading] = useState(true);
  const [usersCount, setUsersCount] = useState<number>(0);
  const [sellersCount, setSellersCount] = useState<number>(0);
  const [users, setUsers] = useState<any[]>([]);
  const [sellers, setSellers] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const { showToast } = useToast();
  const [actionBusyId, setActionBusyId] = useState<string | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<any | null>(null);
  const [viewingUser, setViewingUser] = useState<any>(null);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  // Cache of products-bought counts per user id
  const [productsBoughtMap, setProductsBoughtMap] = useState<Record<string, number | 'loading'>>({});
  // Cache of Seller Dashboard allowed categories (departments) per seller id
  const [sellerDashboardCatsMap, setSellerDashboardCatsMap] = useState<Record<string, string[] | 'loading'>>({});
  // Cache of published product categories per seller id
  const [sellerPublishedCatsMap, setSellerPublishedCatsMap] = useState<Record<string, string[] | 'loading'>>({});
  // Category delete dialog state and busy flag
  const [catDeleteDialog, setCatDeleteDialog] = useState<{ open: boolean; sellerId: string; category: string }>(
    { open: false, sellerId: '', category: '' }
  );
  const [deletingCat, setDeletingCat] = useState<boolean>(false);
  const [catDialogProductCount, setCatDialogProductCount] = useState<number | 'loading'>(0);
  const location = useLocation();
  const navigate = useNavigate();
  // pagination per tab
  const [usersPage, setUsersPage] = useState(0);
  const [sellersPage, setSellersPage] = useState(0);
  const pageSize = 12;
  // sorting
  const [sortBy, setSortBy] = useState<string>('name_asc');
  const [sortOpen, setSortOpen] = useState<boolean>(false);

  useEffect(() => {
    // Accept tab from navigation state or from ?tab= query parameter
    const stateTab = (location.state as any)?.tab as 'users' | 'sellers' | undefined;
    const queryTab = new URLSearchParams(location.search).get('tab') as 'users' | 'sellers' | null;
    const desired = stateTab || queryTab || null;
    if (desired === 'users' || desired === 'sellers') {
      setActiveTab(desired);
    }
    // We only want to run this on mount/first render
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // reset pagination on tab, search, or sort change
  useEffect(() => {
    if (activeTab === 'users') setUsersPage(0);
    if (activeTab === 'sellers') setSellersPage(0);
  }, [activeTab, search, sortBy]);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        setLoading(true);
        const usersRef = collection(db, 'users');
        // Sellers tab should reflect users whose role === 'seller'
        const sellersOnlyQ = query(usersRef, where('role', '==', 'seller'));

        // count only users with role=='user'
        const usersOnlyQ = query(usersRef, where('role', '==', 'user'));

        const [usersCntSnap, sellersCntSnap, usersSnap, sellersSnap] = await Promise.all([
          getCountFromServer(usersOnlyQ),
          getCountFromServer(sellersOnlyQ),
          getDocs(usersRef),
          getDocs(sellersOnlyQ),
        ]);

        if (cancelled) return;
        setUsersCount(usersCntSnap.data().count);
        setSellersCount(sellersCntSnap.data().count);
        setUsers(usersSnap.docs.map(d => ({ id: d.id, ...d.data() })));

        // Merge sellerCode from seller profile or registration if not present in user doc
        const sellerIds = sellersSnap.docs.map(d => d.id);
        const sellerCodeMap: Record<string, string | null> = {};
        await Promise.all(sellerIds.map(async (sid) => {
          try {
            // Try sellers profile collection first
            const profRef = doc(db, 'sellers', sid);
            const profSnap = await getDoc(profRef);
            if (profSnap.exists()) {
              const data: any = profSnap.data();
              sellerCodeMap[sid] = data?.sellerCode ?? data?.code ?? null;
              return;
            }
          } catch {}
          try {
            // Fallback to seller-registrations collection
            const regRef = doc(db, 'seller-registrations', sid);
            const regSnap = await getDoc(regRef);
            if (regSnap.exists()) {
              const data: any = regSnap.data();
              sellerCodeMap[sid] = data?.sellerCode ?? data?.code ?? null;
            }
          } catch {}
        }));

        setSellers(
          sellersSnap.docs.map(d => {
            const base: any = { id: d.id, ...d.data() };
            return { ...base, sellerCode: base.sellerCode ?? sellerCodeMap[d.id] ?? null };
          })
        );
      } catch (e) {
        console.error('Failed to load users/sellers:', e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  const handleToggleBlock = async (u: any) => {
    try {
      if (!navigator.onLine) {
        showToast({ message: 'You appear to be offline. Cannot update user state.', type: 'error' });
        return;
      }
      setActionBusyId(u.id);
      const ref = doc(db, 'users', u.id);
      console.log('[Admin] Updating blocked ->', !u.blocked, 'for', u.id);

      // Warn if it stalls
      const stallTimer = setTimeout(() => {
        console.warn('[Admin] updateDoc seems to be stalling for', u.id);
        showToast({ message: 'Update taking longer than expected…', type: 'error' });
      }, 7000);

      try {
        // Prefer updateDoc, but fall back to setDoc merge if doc might not exist
        await updateDoc(ref, { blocked: !u.blocked });
      } catch (err: any) {
        if (err?.code === 'not-found') {
          console.warn('[Admin] updateDoc not-found, retrying with setDoc merge');
          const { setDoc } = await import('firebase/firestore');
          await setDoc(ref, { blocked: !u.blocked }, { merge: true });
        } else {
          throw err;
        }
      } finally {
        clearTimeout(stallTimer);
      }

      console.log('[Admin] Update success for', u.id);
      setUsers(prev => prev.map(x => x.id === u.id ? { ...x, blocked: !u.blocked } : x));
      setSellers(prev => prev.map(x => x.id === u.id ? { ...x, blocked: !u.blocked } : x));
      showToast({ message: `${!u.blocked ? 'Blocked' : 'Unblocked'} ${u.displayName || u.email || 'user'}`, type: 'success' });
    } catch (e: any) {
      console.error('Toggle block failed', e?.code, e?.message, e);
      showToast({ message: `Failed to update user block state: ${e?.code || ''} ${e?.message || ''}`.trim(), type: 'error' });
    } finally {
      setActionBusyId(null);
    }
  };

  // Open category delete dialog and preload product count for the seller/category
  const openCatDeleteDialog = async (sellerId: string, category: string) => {
    if (!sellerId || !category) return;
    setCatDeleteDialog({ open: true, sellerId, category });
    setCatDialogProductCount('loading');
    try {
      const prodsRef = collection(db, 'products');
      const qy = query(prodsRef, where('sellerId', '==', sellerId), where('category', '==', category));
      const cntSnap = await getCountFromServer(qy);
      const count = Number(cntSnap.data().count || 0);
      setCatDialogProductCount(count);
    } catch (e) {
      console.warn('Failed to count products for dialog', sellerId, category, e);
      setCatDialogProductCount(0);
    }
  };

  // Helper: remove category from seller profile/legacy/sellers collections
  const removeCategoryAssignments = async (sellerId: string, cat: string) => {
    try {
      // 1) Remove from seller-profiles departments (and legacy flags)
      try {
        const profRef = doc(db, 'seller-profiles', sellerId);
        const profSnap = await getDoc(profRef);
        if (profSnap.exists()) {
          const data: any = profSnap.data();
          let depts: string[] = Array.isArray(data?.departments) ? data.departments : [];
          const norm = (val: string) => val ? (/[A-Z]/.test(val) ? val.replace(/([A-Z])/g, '-$1').toLowerCase() : val.toLowerCase()) : '';
          const filtered = depts.filter((d) => norm(d) !== cat.toLowerCase());
          const updates: any = { departments: filtered };
          // Legacy flag off (camelCase)
          const camel = cat.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
          if (camel in data) updates[camel] = false;
          await updateDoc(profRef, updates);
        }
      } catch (e) {
        console.warn('Failed updating seller-profiles for category removal', sellerId, cat, e);
      }

      // 2) Remove from sellers collection departments if present
      try {
        const sellerRef = doc(db, 'sellers', sellerId);
        const sellerSnap = await getDoc(sellerRef);
        if (sellerSnap.exists()) {
          const sdata: any = sellerSnap.data();
          const depts: string[] = Array.isArray(sdata?.departments) ? sdata.departments : [];
          const filtered = depts.filter((d) => d && d.toLowerCase() !== cat.toLowerCase());
          await updateDoc(sellerRef, { departments: filtered });
        }
      } catch (e) {
        console.warn('Failed updating sellers collection for category removal', sellerId, cat, e);
      }
    } catch (e) {
      console.warn('removeCategoryAssignments error', e);
    }
  };

  // Helper: delete all products for seller in a category and try to remove storage files
  const deleteProductsAndStorageForCategory = async (sellerId: string, cat: string) => {
    try {
      // Delete Firestore product docs and referenced images (by URL if available)
      try {
        const prodsRef = collection(db, 'products');
        const qDel = query(prodsRef, where('sellerId', '==', sellerId), where('category', '==', cat));
        const snap = await getDocs(qDel);
        const storage = getStorage();
        // Helper: extract storage path from Firebase download URL
        const urlToStoragePath = (url: string): string | null => {
          try {
            // Expecting forms like https://firebasestorage.googleapis.com/v0/b/<bucket>/o/<encodedPath>?...
            const idx = url.indexOf('/o/');
            if (idx === -1) return null;
            const rest = url.substring(idx + 3); // after '/o/'
            const pathEnc = rest.split('?')[0];
            const decoded = decodeURIComponent(pathEnc);
            return decoded || null;
          } catch {
            return null;
          }
        };
        await Promise.all(snap.docs.map(async (dref) => {
          try {
            const data: any = dref.data();
            // Delete known image fields if present
            const urls: string[] = [];
            if (data?.imageUrl) urls.push(String(data.imageUrl));
            if (Array.isArray(data?.imageUrls)) urls.push(...data.imageUrls.map((x: any) => String(x))); 
            if (Array.isArray(data?.images)) urls.push(...data.images.map((x: any) => String(x)));
            await Promise.all(urls.map(async (u) => {
              try {
                const isHttp = /^https?:\/\//i.test(u) || /^gs:\/\//i.test(u);
                if (isHttp) {
                  const path = urlToStoragePath(u);
                  if (path) {
                    await deleteObject(storageRef(storage, path));
                  }
                } else {
                  await deleteObject(storageRef(storage, u));
                }
              } catch (err) {
                // Ignore per-file errors (e.g., unauthorized); continue cleanup
                console.warn('Storage delete skipped for', u, err);
              }
            }));
            await deleteDoc(doc(db, 'products', dref.id));
          } catch (e) {
            console.warn('Failed to delete product or its images', dref.id, e);
          }
        }));
      } catch (e) {
        console.warn('Failed deleting products for category', sellerId, cat, e);
      }
      // Try to delete any residual images under sellers/<sellerId>/<cat> path
      try {
        const storage = getStorage();
        const base = storageRef(storage, `sellers/${sellerId}/${cat}`);
        const deleteFolderRecursive = async (folderRef: any): Promise<void> => {
          const res = await listAll(folderRef);
          await Promise.all(res.items.map((item: any) => deleteObject(item)));
          // Delete in subfolders
          await Promise.all(res.prefixes.map((sub: any) => deleteFolderRecursive(sub)));
        };
        await deleteFolderRecursive(base);
      } catch (e) {
        // Likely due to Storage Rules (unauthorized) when running from client. Safe to ignore.
        console.warn('Failed to clean storage folder for', sellerId, cat, e);
      }
    } catch (e) {
      console.warn('deleteProductsAndStorageForCategory error', e);
    }
  };

  // Execute delete flow depending on includeProducts flag
  const executeDeleteSellerCategory = async (sellerId: string, category: string, includeProducts: boolean) => {
    const cat = (category || '').toString();
    if (!sellerId || !cat) return;
    setDeletingCat(true);
    try {
      // Remove assignments first
      await removeCategoryAssignments(sellerId, cat);
      // Optionally delete products + storage
      if (includeProducts) {
        await deleteProductsAndStorageForCategory(sellerId, cat);
      }
      // Update caches
      setSellerDashboardCatsMap((m) => {
        const prev = m[sellerId];
        if (!Array.isArray(prev)) return m;
        return { ...m, [sellerId]: prev.filter((c) => c.toLowerCase() !== cat.toLowerCase()) };
      });
      setSellerPublishedCatsMap((m) => {
        const prev = m[sellerId];
        if (!Array.isArray(prev)) return m;
        return { ...m, [sellerId]: prev.filter((c) => c.toLowerCase() !== cat.toLowerCase()) };
      });
      showToast({ message: includeProducts
        ? `Deleted category "${cat}" and all its products.`
        : `Removed category "${cat}" from seller dashboard.`, type: 'success' });
    } catch (e: any) {
      console.error('executeDeleteSellerCategory failed', e);
      showToast({ message: `Delete failed: ${e?.message || 'Unknown error'}` , type: 'error' });
    } finally {
      setDeletingCat(false);
      setCatDeleteDialog({ open: false, sellerId: '', category: '' });
    }
  };

  const handleDelete = async (u: any) => {
    try {
      if (!navigator.onLine) {
        showToast({ message: 'You appear to be offline. Cannot delete user.', type: 'error' });
        return;
      }
      // Confirm BEFORE setting busy, so cancel doesn't freeze buttons
      setActionBusyId(u.id);
      console.log('[Admin] Deleting user doc', u.id);

      const ref = doc(db, 'users', u.id);
      const stallTimer = setTimeout(() => {
        console.warn('[Admin] deleteDoc seems to be stalling for', u.id);
        showToast({ message: 'Delete taking longer than expected…', type: 'error' });
      }, 7000);

      // Optional: ensure doc exists to provide clearer errors
      try {
        const snap = await getDoc(ref);
        if (!snap.exists()) {
          console.warn('[Admin] Doc not found before delete', u.id);
        }
        await deleteDoc(ref);
        // Also remove any face authentication data for this user
        try {
          await deleteDoc(doc(db, 'faceAuth', u.id));
          console.log('[Admin] Deleted faceAuth doc for', u.id);
        } catch (faErr) {
          console.warn('[Admin] faceAuth doc delete failed or not found for', u.id, faErr);
        }
      } finally {
        clearTimeout(stallTimer);
      }

      setUsers(prev => prev.filter(x => x.id !== u.id));
      setSellers(prev => prev.filter(x => x.id !== u.id));
      // adjust counts based on role if present
      if ((u.role ?? 'user') === 'user') setUsersCount(c => Math.max(0, c - 1));
      if ((u.role ?? '') === 'seller') setSellersCount(c => Math.max(0, c - 1));
      showToast({ message: 'User record deleted', type: 'success' });
    } catch (e: any) {
      console.error('Delete failed', e?.code, e?.message, e);
      showToast({ message: `Failed to delete user record: ${e?.code || ''} ${e?.message || ''}`.trim(), type: 'error' });
    } finally {
      setActionBusyId(null);
    }
  };

  const confirmDelete = async () => {
    if (!pendingDelete) return;
    try {
      await handleDelete(pendingDelete);
    } finally {
      setConfirmOpen(false);
      setPendingDelete(null);
    }
  };

  const handleViewUser = (user: any) => {
    setViewingUser(user);
    setIsViewerOpen(true);
    // Fetch products bought count lazily when viewing
    if (!user?.id) return;
    const uid = user.id;
    if (productsBoughtMap[uid] === undefined) {
      setProductsBoughtMap((m) => ({ ...m, [uid]: 'loading' }));
      (async () => {
        try {
          const ordersRef = collection(db, 'orders');
          const q1 = query(ordersRef, where('userId', '==', uid));
          const q2 = query(ordersRef, where('uid', '==', uid));
          const [snap1, snap2] = await Promise.all([getDocs(q1), getDocs(q2)]);
          // Avoid double-counting in case both fields exist on same order
          const seen = new Set<string>();
          let total = 0;
          const addFromSnap = (snap: any) => {
            snap.forEach((d: any) => {
              const oid = d.id as string;
              if (seen.has(oid)) return;
              seen.add(oid);
              const data: any = d.data();
              const items: any[] = Array.isArray(data?.items) ? data.items : [];
              if (items.length === 0) return;
              total += items.reduce((sum, it) => sum + (Number(it?.quantity ?? 1) || 1), 0);
            });
          };
          addFromSnap(snap1);
          addFromSnap(snap2);
          setProductsBoughtMap((m) => ({ ...m, [uid]: total }));
        } catch (e) {
          console.warn('Failed fetching products-bought count for', uid, e);
          setProductsBoughtMap((m) => ({ ...m, [uid]: 0 }));
        }
      })();
    }
    // If viewing a seller, mark as seller and fetch published categories snapshot for tooltips/UI
    const isSeller = (user.role || 'user') === 'seller' || (activeTab === 'sellers');
    if (isSeller && sellerPublishedCatsMap[uid] === undefined) {
      setSellerPublishedCatsMap((m) => ({ ...m, [uid]: 'loading' }));
      (async () => {
        try {
          const prodsRef = collection(db, 'products');
          const qPub = query(prodsRef, where('sellerId', '==', uid), where('published', '==', true));
          const snapPub = await getDocs(qPub);
          const catsSet = new Set<string>();
          snapPub.forEach((d: any) => {
            const data: any = d.data();
            const cat = (data?.category || '').toString().trim().toLowerCase();
            if (cat) catsSet.add(cat);
          });
          const cats = Array.from(catsSet).sort((a, b) => a.localeCompare(b));
          setSellerPublishedCatsMap((m) => ({ ...m, [uid]: cats }));
        } catch (e) {
          console.warn('Failed fetching seller published categories for', uid, e);
          setSellerPublishedCatsMap((m) => ({ ...m, [uid]: [] }));
        }
      })();
    }
    // If viewing a seller, lazily fetch Seller Dashboard categories (allowed departments)
    if (isSeller && sellerDashboardCatsMap[uid] === undefined) {
      setSellerDashboardCatsMap((m) => ({ ...m, [uid]: 'loading' }));
      (async () => {
        try {
          // 1. Try seller-profiles document
          const profRef = doc(db, 'seller-profiles', uid);
          const profSnap = await getDoc(profRef);
          let depts: string[] = [];
          if (profSnap.exists()) {
            const data: any = profSnap.data();
            depts = Array.isArray(data?.departments) ? data.departments : [];
            if (depts.length === 0) {
              // Fallback to legacy flags if no departments array
              const flags = [
                'scrapStore','organicStore','charityCraft','scrapBooks','momsMadeUnited','greenCupChallenge',
                'charityBakes','homeDecor','packedFood','homePlants','beautyHomemade','homemadeHouseholds','birthdayGifts'
              ];
              depts = flags.filter((f) => data?.[f] === true);
            }
          }
          // 2. If still empty, try sellers collection
          if (depts.length === 0) {
            const sellerRef = doc(db, 'sellers', uid);
            const sellerSnap = await getDoc(sellerRef);
            if (sellerSnap.exists()) {
              const sdata: any = sellerSnap.data();
              depts = Array.isArray(sdata?.departments) ? sdata.departments : [];
            }
          }
          // 3. Normalize to kebab-case
          const norm = (val: string) => {
            if (!val) return '';
            if (/[A-Z]/.test(val)) {
              return val.replace(/([A-Z])/g, '-$1').toLowerCase();
            }
            return val.toLowerCase();
          };
          const finalCats = Array.from(new Set((depts || []).map(norm))).filter(Boolean).sort((a, b) => a.localeCompare(b));
          setSellerDashboardCatsMap((m) => ({ ...m, [uid]: finalCats }));
        } catch (e) {
          console.warn('Failed fetching seller dashboard categories for', uid, e);
          setSellerDashboardCatsMap((m) => ({ ...m, [uid]: [] }));
        }
      })();
    }
  };

  // Filter rows for Users tab: only role === 'user'
  const usersOnly = users.filter(u => (u.role ?? 'user') === 'user');

  // Apply search to the currently visible dataset
  const norm = (s: string) => s.toLowerCase();
  const matchesSearch = (val: string | undefined) => norm(val || '').includes(norm(search));
  const visibleUsers = usersOnly.filter(u =>
    !search || matchesSearch(u.displayName) || matchesSearch(u.email) || matchesSearch(u.id)
  );
  const visibleSellers = sellers.filter(s =>
    !search || matchesSearch(s.displayName) || matchesSearch(s.email) || matchesSearch(s.id) || matchesSearch((s as any).sellerCode)
  );
  // Sorting helpers
  const getCreatedAtMs = (x: any): number => {
    try {
      if (!x?.createdAt) return 0;
      if (typeof x.createdAt?.toDate === 'function') return x.createdAt.toDate().getTime();
      const t = new Date(x.createdAt).getTime();
      return isNaN(t) ? 0 : t;
    } catch {
      return 0;
    }
  };
  const compare = (a: any, b: any) => {
    const an = (a.displayName || a.email || '').toString().toLowerCase();
    const bn = (b.displayName || b.email || '').toString().toLowerCase();
    const aCreated = getCreatedAtMs(a);
    const bCreated = getCreatedAtMs(b);
    switch (sortBy) {
      case 'name_asc':
        return an.localeCompare(bn);
      case 'name_desc':
        return bn.localeCompare(an);
      case 'status_active':
        return Number(!!a.blocked) - Number(!!b.blocked) || an.localeCompare(bn);
      case 'status_blocked':
        return Number(!!b.blocked) - Number(!!a.blocked) || an.localeCompare(bn);
      case 'created_desc':
        return bCreated - aCreated || an.localeCompare(bn);
      case 'created_asc':
        return aCreated - bCreated || an.localeCompare(bn);
      default:
        return 0;
    }
  };
  const sortedUsers = [...visibleUsers].sort(compare);
  const sortedSellers = [...visibleSellers].sort(compare);
  const usersPageTotal = Math.max(1, Math.ceil(sortedUsers.length / pageSize));
  const sellersPageTotal = Math.max(1, Math.ceil(sortedSellers.length / pageSize));
  const usersRows = sortedUsers.slice(usersPage * pageSize, usersPage * pageSize + pageSize);
  const sellersRows = sortedSellers.slice(sellersPage * pageSize, sellersPage * pageSize + pageSize);

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold">User Management</h1>
          <p className="text-muted-foreground">Manage users and sellers</p>
        </div>
        {/* Sort By near title */}
        <div className="relative">
          <Button
            type="button"
            variant="outline"
            className="btn-hover h-10 px-4 py-2 border-gold/70 text-foreground"
            aria-haspopup="listbox"
            aria-expanded={sortOpen}
            onClick={() => setSortOpen((o) => !o)}
            onBlur={(e) => {
              if (!e.currentTarget.parentElement?.contains(e.relatedTarget as Node)) {
                setSortOpen(false);
              }
            }}
          >
            Sort By
          </Button>
          {sortOpen && (
            <div className="absolute right-0 mt-2 z-10 w-44 rounded-md border border-border/60 bg-background shadow-lg py-1">
              <ul role="listbox" aria-label="Sort by" className="max-h-64 overflow-auto text-sm">
                <li>
                  <button type="button" role="option" aria-selected={sortBy === 'name_asc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy === 'name_asc' ? 'font-medium' : ''}`} onClick={() => { setSortBy('name_asc'); setSortOpen(false); }} autoFocus>
                    Name A → Z
                  </button>
                </li>
                <li>
                  <button type="button" role="option" aria-selected={sortBy === 'name_desc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy === 'name_desc' ? 'font-medium' : ''}`} onClick={() => { setSortBy('name_desc'); setSortOpen(false); }}>
                    Name Z → A
                  </button>
                </li>
                <li>
                  <button type="button" role="option" aria-selected={sortBy === 'status_active'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy === 'status_active' ? 'font-medium' : ''}`} onClick={() => { setSortBy('status_active'); setSortOpen(false); }}>
                    Status: Active
                  </button>
                </li>
                <li>
                  <button type="button" role="option" aria-selected={sortBy === 'status_blocked'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy === 'status_blocked' ? 'font-medium' : ''}`} onClick={() => { setSortBy('status_blocked'); setSortOpen(false); }}>
                    Status: Blocked
                  </button>
                </li>
                <li>
                  <button type="button" role="option" aria-selected={sortBy === 'created_desc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy === 'created_desc' ? 'font-medium' : ''}`} onClick={() => { setSortBy('created_desc'); setSortOpen(false); }}>
                    Newest
                  </button>
                </li>
                <li>
                  <button type="button" role="option" aria-selected={sortBy === 'created_asc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy === 'created_asc' ? 'font-medium' : ''}`} onClick={() => { setSortBy('created_asc'); setSortOpen(false); }}>
                    Oldest
                  </button>
                </li>
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Tabs + Search */}
      <div className="flex items-center gap-2 mb-4">
        <Button
          variant={activeTab === 'users' ? 'default' : 'ghost'}
          className={activeTab === 'users' ? 'bg-gold text-black hover:bg-gold/90' : ''}
          onClick={() => setActiveTab('users')}
        >
          <Users className="h-4 w-4 mr-2" />
          <span>Users</span>
          <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${activeTab === 'users' ? 'bg-white text-black' : 'bg-gold/20 text-gold'}`}>
            {usersCount}
          </span>
        </Button>
        <Button
          variant={activeTab === 'sellers' ? 'default' : 'ghost'}
          className={activeTab === 'sellers' ? 'bg-gold text-black hover:bg-gold/90' : ''}
          onClick={() => setActiveTab('sellers')}
        >
          <CheckSquare className="h-4 w-4 mr-2" />
          <span>Sellers</span>
          <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${activeTab === 'sellers' ? 'bg-white text-black' : 'bg-gold/20 text-gold'}`}>
            {sellersCount}
          </span>
        </Button>

        {/* Search */}
        <div className="ml-auto relative w-full max-w-sm">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={activeTab === 'users' ? 'Search users…' : 'Search sellers…'}
            className="w-full pl-8 pr-3 py-2 rounded-md bg-muted/40 outline-none border border-border/60 focus:border-gold"
          />
        </div>

        {/* Sort By moved to header */}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{activeTab === 'users' ? 'Users' : 'Sellers'}</CardTitle>
          <CardDescription>
            {activeTab === 'users' ? 'Registered platform users' : 'Approved seller profiles'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center gap-2 text-muted-foreground py-10"><Loader2 className="h-5 w-5 animate-spin"/>Loading…</div>
          ) : activeTab === 'users' ? (
            visibleUsers.length === 0 ? (
              <div className="text-muted-foreground">No users found.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm">
                  <thead className="text-left text-muted-foreground">
                    <tr>
                      <th className="py-2 pr-4">Name</th>
                      <th className="py-2 pr-4">ID</th>
                      <th className="py-2 pr-4">Status</th>
                      <th className="py-2 pr-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {usersRows.map((u) => (
                      <tr key={u.id} className="border-t border-border/60">
                        <td className="py-2 pr-4">{u.displayName || '-'}</td>
                        <td className="py-2 pr-4 font-mono text-xs break-all">{u.id}</td>
                        <td className="py-2 pr-4">{u.blocked ? 'Blocked' : 'Active'}</td>
                        <td className="py-2 pr-4">
                          <div className="flex items-center gap-2">
                            <Button type="button" variant="outline" size="sm" disabled={actionBusyId === u.id} onClick={() => { console.log('[Admin] Toggle block clicked', u.id); handleToggleBlock(u); }}>
                              <Ban className="h-4 w-4 mr-1" />
                              {u.blocked ? 'Unblock' : 'Block'}
                            </Button>
                            <Button
                              type="button"
                              variant="destructive"
                              size="sm"
                              disabled={actionBusyId === u.id}
                              onClick={() => {
                                console.log('[Admin] Delete clicked', u.id);
                                setPendingDelete(u);
                                setConfirmOpen(true);
                              }}
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Delete
                            </Button>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              disabled={actionBusyId === u.id}
                              onClick={() => handleViewUser(u)}
                            >
                              <Eye className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <div className="mt-4 flex items-center justify-between">
                  <Button type="button" variant="outline" disabled={usersPage <= 0} onClick={() => setUsersPage(p => Math.max(0, p - 1))}>Previous</Button>
                  <div className="text-sm text-muted-foreground">Page {usersPage + 1} of {usersPageTotal}</div>
                  <Button type="button" variant="outline" disabled={(usersPage + 1) >= usersPageTotal} onClick={() => setUsersPage(p => p + 1)}>Next</Button>
                </div>
              </div>
            )
          ) : (
            visibleSellers.length === 0 ? (
              <div className="text-muted-foreground">No sellers found.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full text-sm">
                  <thead className="text-left text-muted-foreground">
                    <tr>
                      <th className="py-2 pr-4">Name</th>
                      <th className="py-2 pr-4">Seller Code</th>
                      <th className="py-2 pr-4">ID</th>
                      <th className="py-2 pr-4">Status</th>
                      <th className="py-2 pr-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sellersRows.map((s) => (
                      <tr key={s.id} className="border-t border-border/60">
                        <td className="py-2 pr-4">{s.displayName || '-'}</td>
                        <td className="py-2 pr-4 font-mono text-xs break-all">{s.sellerCode || '-'}</td>
                        <td className="py-2 pr-4 font-mono text-xs break-all">{s.id}</td>
                        <td className="py-2 pr-4">{s.blocked ? 'Blocked' : 'Active'}</td>
                        <td className="py-2 pr-4">
                          <div className="flex items-center gap-2">
                            <Button type="button" variant="outline" size="sm" disabled={actionBusyId === s.id} onClick={() => { console.log('[Admin] Toggle block clicked (seller)', s.id); handleToggleBlock(s); }}>
                              <Ban className="h-4 w-4 mr-1" />
                              {s.blocked ? 'Unblock' : 'Block'}
                            </Button>
                            <Button
                              type="button"
                              variant="destructive"
                              size="sm"
                              disabled={actionBusyId === s.id}
                              onClick={() => {
                                console.log('[Admin] Delete clicked (seller)', s.id);
                                setPendingDelete(s);
                                setConfirmOpen(true);
                              }}
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Delete
                            </Button>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              disabled={actionBusyId === s.id}
                              onClick={() => handleViewUser(s)}
                            >
                              <Eye className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <div className="mt-4 flex items-center justify-between">
                  <Button type="button" variant="outline" disabled={sellersPage <= 0} onClick={() => setSellersPage(p => Math.max(0, p - 1))}>Previous</Button>
                  <div className="text-sm text-muted-foreground">Page {sellersPage + 1} of {sellersPageTotal}</div>
                  <Button type="button" variant="outline" disabled={(sellersPage + 1) >= sellersPageTotal} onClick={() => setSellersPage(p => p + 1)}>Next</Button>
                </div>
              </div>
            )
          )}
        </CardContent>
      </Card>

      {/* Delete confirmation modal */}
      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete this record?</DialogTitle>
            <DialogDescription>
              This removes the document from the <code>users</code> collection and their face data from <code>faceAuth</code>. It does not delete their Firebase Auth account.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 text-sm">
            <div><span className="text-muted-foreground">Name:</span> {pendingDelete?.displayName || '-'}</div>
            <div><span className="text-muted-foreground">ID:</span> {pendingDelete?.id || '-'}</div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setConfirmOpen(false)}>
              Cancel
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={confirmDelete}
              disabled={!!(pendingDelete && actionBusyId === pendingDelete.id)}
            >
              {pendingDelete && actionBusyId === pendingDelete.id ? (
                <span className="inline-flex items-center"><Loader2 className="h-4 w-4 mr-1 animate-spin"/>Deleting…</span>
              ) : (
                'Delete'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* User viewer modal */}
      <Dialog open={isViewerOpen} onOpenChange={setIsViewerOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>User Details</DialogTitle>
            <DialogDescription className="break-all">ID: {viewingUser?.id}</DialogDescription>
          </DialogHeader>
          {viewingUser && (
            <div className="space-y-4 py-2">
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-muted-foreground">Name</p>
                  <p className="font-medium">{viewingUser.displayName || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="font-medium">{viewingUser.email || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Role</p>
                  <p className={`font-medium ${viewingUser.role || (activeTab === 'sellers' ? 'seller' : 'user')}`}>
                    {viewingUser.role || (activeTab === 'sellers' ? 'seller' : 'user')}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Products Bought</p>
                  <p className="font-medium">
                    {productsBoughtMap[viewingUser.id] === 'loading' || productsBoughtMap[viewingUser.id] === undefined
                      ? 'Loading…'
                      : (productsBoughtMap[viewingUser.id] as number)}
                  </p>
                </div>
                {(activeTab === 'sellers' || viewingUser.role === 'seller') && (
                  <div>
                    <p className="text-sm text-muted-foreground">Seller Code</p>
                    <p className="font-medium font-mono break-all">{viewingUser.sellerCode || '-'}</p>
                  </div>
                )}
                {/* Hide raw product-derived Categories section per request */}
                {(activeTab === 'sellers' || viewingUser.role === 'seller') && (
                  <div>
                    <p className="text-sm text-muted-foreground">Seller Dashboard Categories</p>
                    <div className="flex flex-wrap gap-2 pt-1">
                      {sellerDashboardCatsMap[viewingUser.id] === 'loading' || sellerDashboardCatsMap[viewingUser.id] === undefined ? (
                        <span className="text-sm text-muted-foreground">Loading…</span>
                      ) : (sellerDashboardCatsMap[viewingUser.id] as string[]).length === 0 ? (
                        <span className="text-sm text-muted-foreground">No categories assigned</span>
                      ) : (
                        (() => {
                          const published = sellerPublishedCatsMap[viewingUser.id];
                          const pubSet = Array.isArray(published) ? new Set(published) : new Set<string>();
                          return (sellerDashboardCatsMap[viewingUser.id] as string[]).map((c) => {
                            const key = c.toLowerCase();
                            const hasPub = pubSet.has(key);
                            const title = hasPub ? 'Has published products' : 'No published products yet';
                            return (
                              <span key={c} className="inline-flex items-center gap-1">
                                <Badge variant={hasPub ? 'secondary' : 'outline'} title={title}>
                                  {c}
                                </Badge>
                                <Button
                                  type="button"
                                  size="icon"
                                  variant="ghost"
                                  title={`Delete ${c}`}
                                  disabled={deletingCat}
                                  onClick={() => openCatDeleteDialog(viewingUser.id, c)}
                                  className="h-6 w-6"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </Button>
                              </span>
                            );
                          });
                        })()
                      )}
                    </div>
                  </div>
                )}
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <p className={`font-medium ${viewingUser.blocked ? 'text-destructive' : 'text-green-600'}`}>
                    {viewingUser.blocked ? 'Blocked' : 'Active'}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Account Created</p>
                  <p className="font-medium">
                    {viewingUser.createdAt?.toDate 
                      ? viewingUser.createdAt.toDate().toLocaleString() 
                      : (viewingUser.createdAt || 'N/A')}
                  </p>
                </div>
                {activeTab === 'sellers' && (
                  <div className="pt-2">
                    <Button
                      variant="default"
                      className="w-full bg-gold text-black hover:bg-gold/90"
                      onClick={() => {
                        navigate(`/admin/sellers/${viewingUser.id}/products`);
                        setIsViewerOpen(false);
                      }}
                    >
                      <Package className="h-4 w-4 mr-2" />
                      View Seller's Products
                    </Button>
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Seller Category Delete confirmation dialog */}
      <Dialog open={catDeleteDialog.open} onOpenChange={(open) => setCatDeleteDialog((d) => ({ ...d, open }))}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Category</DialogTitle>
            <DialogDescription>
              {catDialogProductCount === 'loading' ? (
                'Checking products…'
              ) : catDialogProductCount > 0 ? (
                <>
                  You are about to modify the seller's category: <code>{catDeleteDialog.category}</code>.
                  Choose an option below.
                </>
              ) : (
                <>
                  Remove category <code>{catDeleteDialog.category}</code> from the seller dashboard?
                </>
              )}
            </DialogDescription>
          </DialogHeader>
          {catDialogProductCount === 'loading' ? (
            <div className="py-2 text-sm text-muted-foreground">Please wait…</div>
          ) : catDialogProductCount > 0 ? (
            <>
              <div className="space-y-2 text-sm">
                <p>
                  <strong>Option 1:</strong> Remove category assignment only. Products remain intact.
                </p>
                <p>
                  <strong>Option 2:</strong> Delete the category <em>and</em> all products under it, including files in storage.
                </p>
              </div>
              <DialogFooter className="flex flex-col sm:flex-row gap-2 sm:justify-end">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setCatDeleteDialog({ open: false, sellerId: '', category: '' })}
                  disabled={deletingCat}
                >
                  Cancel
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => executeDeleteSellerCategory(catDeleteDialog.sellerId, catDeleteDialog.category, false)}
                  disabled={deletingCat || !catDeleteDialog.sellerId || !catDeleteDialog.category}
                >
                  {deletingCat ? (
                    <span className="inline-flex items-center"><Loader2 className="h-4 w-4 mr-2 animate-spin"/>Removing…</span>
                  ) : (
                    'Remove Category Only'
                  )}
                </Button>
                <Button
                  type="button"
                  variant="destructive"
                  onClick={() => executeDeleteSellerCategory(catDeleteDialog.sellerId, catDeleteDialog.category, true)}
                  disabled={deletingCat || !catDeleteDialog.sellerId || !catDeleteDialog.category}
                >
                  {deletingCat ? (
                    <span className="inline-flex items-center"><Loader2 className="h-4 w-4 mr-2 animate-spin"/>Deleting…</span>
                  ) : (
                    'Delete Category + Products'
                  )}
                </Button>
              </DialogFooter>
            </>
          ) : (
            <DialogFooter className="flex flex-col sm:flex-row gap-2 sm:justify-end">
              <Button
                type="button"
                variant="outline"
                onClick={() => setCatDeleteDialog({ open: false, sellerId: '', category: '' })}
                disabled={deletingCat}
              >
                Cancel
              </Button>
              <Button
                type="button"
                variant="destructive"
                onClick={() => executeDeleteSellerCategory(catDeleteDialog.sellerId, catDeleteDialog.category, false)}
                disabled={deletingCat || !catDeleteDialog.sellerId || !catDeleteDialog.category}
              >
                {deletingCat ? (
                  <span className="inline-flex items-center"><Loader2 className="h-4 w-4 mr-2 animate-spin"/>Removing…</span>
                ) : (
                  'Remove Category'
                )}
              </Button>
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
