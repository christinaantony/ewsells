import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Check, Loader2, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { db, auth } from '@/lib/firebase';
import { doc, getDoc, updateDoc, setDoc } from 'firebase/firestore';

export function SellerAgreement() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [agreementAccepted, setAgreementAccepted] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const agreementScrollRef = useRef<HTMLDivElement>(null);

  // Ensure mouse wheel scrolls the agreement area even if parent has custom scroll handling
  const handleAgreementWheel: React.WheelEventHandler<HTMLDivElement> = (e) => {
    const el = agreementScrollRef.current;
    if (!el) return;
    // Manually scroll the element and prevent default to avoid body/parent scroll hijacking
    el.scrollTop += e.deltaY;
    e.preventDefault();
    e.stopPropagation();
  };
  
  // Check if the seller registration is approved
  useEffect(() => {
    const checkApprovalStatus = async () => {
      try {
        const currentUser = auth.currentUser;
        if (!currentUser) {
          setError('You must be logged in to view this page');
          setIsLoading(false);
          return;
        }
        
        // Check seller profile for pending_agreement status
        const sellerProfileRef = doc(db, 'seller-profiles', currentUser.uid);
        const sellerProfileDoc = await getDoc(sellerProfileRef);
        
        if (!sellerProfileDoc.exists()) {
          setError('You need to complete seller registration first');
          setIsLoading(false);
          return;
        }
        
        const profileData = sellerProfileDoc.data();
        if (profileData.status === 'pending_agreement') {
          // Seller approved and pending agreement; allow showing agreement content
        } else if (profileData.status === 'active') {
          // Guard against inconsistent data: only redirect if agreementAccepted is true on registration
          const regRef = doc(db, 'seller-registrations', currentUser.uid);
          const regSnap = await getDoc(regRef);
          const regData = regSnap.exists() ? regSnap.data() as any : null;
          const hasAccepted = !!regData?.agreementAccepted;
          if (hasAccepted) {
            navigate('/seller-dashboard');
            return;
          }
          // If agreement not accepted but profile is active, allow the agreement page to render so the user can proceed.
        } else {
          setError('Your seller registration is still pending approval');
        }
        
        setIsLoading(false);
      } catch (err: any) {
        console.error('Error checking approval status:', err);
        setError(err.message || 'An error occurred while checking your approval status');
        setIsLoading(false);
      }
    };
    
    checkApprovalStatus();
  }, [navigate]);
  
  // Handle agreement acceptance
  const handleAcceptAgreement = async () => {
    setIsLoading(true);
    
    try {
      const currentUser = auth.currentUser;
      if (!currentUser) {
        throw new Error('You must be logged in to accept the agreement');
      }
      
      // Update seller registration document with agreement acceptance
      const sellerRegistrationRef = doc(db, 'seller-registrations', currentUser.uid);
      await updateDoc(sellerRegistrationRef, {
        agreementAccepted: true,
        agreementAcceptedAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      
      // Create/Update seller profile document
      const sellerProfileRef = doc(db, 'seller-profiles', currentUser.uid);
      const sellerRegistrationDoc = await getDoc(sellerRegistrationRef);
      const sellerData = sellerRegistrationDoc.data();
      
      if (!sellerData) {
        throw new Error('Seller registration data not found');
      }
      
      await setDoc(sellerProfileRef, {
        userId: currentUser.uid,
        name: sellerData.name,
        email: sellerData.email,
        phone: sellerData.phone,
        address: sellerData.address,
        city: sellerData.city,
        departments: sellerData.departments,
        profilePictureUrl: sellerData.passportPhotoUrl,
        status: 'active',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }, { merge: true });

      // Also update the user's role to 'seller'
      const userRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userRef, {
        role: 'seller',
        updatedAt: new Date().toISOString(),
      });
      
      setAgreementAccepted(true);
      setShowSuccessModal(true);
    } catch (err: any) {
      console.error('Error accepting agreement:', err);
      setError(err.message || 'An error occurred while accepting the agreement');
    } finally {
      setIsLoading(false);
    }
  };
  
  // EW SELLS Seller Agreement and Organisation Terms & Conditions
  const agreementText = `
# EW SELLS | Charity Store Beyond | Seller Agreement

SELLER AGREEMENT FOR JOINING AS A SELLER IN INDIA'S FIRST ONLINE HOME CHARITY STORE

## Seller Agreement
This Seller Agreement ("Agreement") is entered into by and between Expectation Walkers, a Non-Profit Organization governed by the laws of India ("Organisation"), and you, the applicant ("Seller"). The Organisation’s registered office is at 1st Floor, Room No 482, Thachapilly Complex, Thelappilly Junction, Thrissur, Kerala, PIN 680712.

WHEREAS, the Organisation operates EW SELLS, an online home charity store; and whereas, the Seller is willing to provide services and/or list and sell products in accordance with the terms and conditions set forth herein; and whereas, the Organisation, having considered the Seller’s proposal, agrees to appoint the Seller on the terms and conditions as hereinafter appearing.

NOW THEREFORE, in consideration of the foregoing recitals and the mutual covenants herein contained, the parties agree as follows:

The Organisation engages the Seller and the Seller accepts such engagement upon the terms and conditions set forth herein, for the period commencing on the Effective Date specified hereinabove and ending upon the Organisation’s acceptance of the Seller’s completed services and deliverables, unless earlier terminated pursuant to the terms of this Agreement.

## Term
The Agreement shall remain in force for an initial period of 12 months from the Effective Date and may be renewed for subsequent periods upon mutual agreement of the parties.

## Services and Deliverables
This Agreement binds the parties with respect to the services the Seller shall perform and the deliverables the Seller shall provide (collectively, the "Services"). The Services and any associated deliverables shall adhere to the particulars, specifications, and timelines communicated by the Organisation from time to time. Any change impacting cost or timeline shall be mutually agreed in writing by both parties.

## Seller Rights
- The Seller may appoint sub-dealers, salesmen, commission agents, or other sales personnel on salary, commission, or any other basis, provided such appointments comply with this Agreement and do not harm the interests of the Organisation, the Seller, or the collective interests of both.
- In performing the Services, the Seller acts as an independent contractor and not as an employee or agent of the Organisation. The Seller is not an employee of the Organisation, nor are any of the Seller’s employees or its contract personnel employees of the Organisation.
- The Seller may provide services for others. The Seller retains the right to control and direct the means, methods, and manner by which the Services are performed, consistent with the terms of this Agreement.
- The Seller is responsible for payment of any taxes, withholdings, and other statutory or contractual obligations arising in connection with the Services. The Seller has no authority to create or assume any obligation on behalf of the Organisation without prior written consent.
- The Seller shall not attach its name or trademarks, logos, or trade names to the Services and/or deliverables provided to the Organisation, except as authorised.
- The Seller shall not use the Organisation’s name, trademarks, or logos except as set forth in this Agreement and in accordance with any brand guidelines shared by the Organisation.
- During the Term and subject to this Agreement, the Seller may not reference the Organisation as a “Client” or use any other expression referring to the Organisation as a client of the Seller in press releases, case studies, or promotional materials ("Promotional Materials") unless the Seller: (a) informs the Organisation in advance of any intended use; (b) submits the Promotional Materials for review; and (c) receives written approval from the Organisation authorising such use. The Organisation may impose additional conditions on such use.
- The existence of any claim or cause of action by the Seller against the Organisation shall not constitute a defence to enforcement by the Organisation of the covenants and agreements of this clause.

## Terms and Conditions of the Organisation for the Seller
1. A particular amount or percentage from each product sold by the Seller is added and allocated for charity.
2. The Organisation provides free shipping for products weighing less than 500 grams. For other products, Sellers may be required to contribute to shipping charges. If the free-shipping slab cost is high, shipping contributions payable by Sellers will typically range from Rs. 65 to Rs. 100 (subject to carrier revisions).
3. The Seller is responsible for repairing or replacing any product damaged in transit if reported within 3 days of delivery. If damage is reported within this period, the Seller shall promptly replace or repair the product.
4. The Seller must double-check the quality of products before shipping. Appropriate action will be taken if valid complaints are received against the Seller regarding quality.
5. The sale proceeds will be remitted to the Seller’s designated account within a minimum of 4 days and a maximum of 2 weeks after delivery confirmation, net of COD and shipping charges and any platform fees notified in advance.
6. Bake sellers may sell their products only with a relevant food safety certificate from the applicable authority or at their own risk. The Organisation will not be responsible for any issues arising from products they sell without required approvals.
7. Bake sellers should deliver their own products and may set reasonable delivery charges for such orders, in line with local norms.
8. Bake sellers may cancel orders up to 3 hours before the scheduled delivery time by contacting the EW SELLS team.
9. Bake sellers must remit the earmarked charity amount to the Organisation’s account each week, as communicated by EW SELLS.
10. Sellers must not conduct any personal or unrelated business using the EW SELLS platform.

## Payments and Fees
- Any platform or service fees, including commissions, will be communicated by EW SELLS and deducted from payouts. Current standard commission, if applicable, will be displayed in the Seller Dashboard or communicated separately.
- All payments are subject to KYC/AML checks and applicable laws. Settlement timelines may vary due to bank holidays or compliance checks.

## Compliance
The Seller shall comply with all applicable laws and regulations, including but not limited to consumer protection, GST and other tax obligations, FSSAI/food safety norms for edible products, packaging and labelling requirements, and any local permits required to produce, store, or sell listed items.

## Intellectual Property
All EW SELLS/Expectation Walkers names, logos, trademarks, and brand assets are proprietary to the Organisation. No license is granted except as expressly provided herein or with prior written approval.

## Data Protection and Privacy
The Seller shall handle customer information with care and use it solely for order fulfilment and after-sales support as permitted by law and EW SELLS policies. The Seller shall not misuse or sell customer data.

## Termination
Either party may terminate this Agreement for convenience with 30 days’ written notice. The Organisation may suspend or terminate immediately for material breach, illegal activity, or actions that harm the safety, trust, or reputation of the platform or its beneficiaries.

## Arbitration
Where any controversy, dispute, or disagreement arises between the Parties regarding interpretation or application of any terms of this Agreement or the performance hereof and cannot be resolved by good-faith discussions, the Parties agree to refer the matter to arbitration under the provisions of the Arbitration and Conciliation Act, 1996. The venue for arbitration shall be Thrissur, Kerala. The award may be enforced by any court of competent jurisdiction.

## Miscellaneous
- This Agreement shall be governed by and construed in accordance with the laws of India. Courts at Thrissur, Kerala, shall have jurisdiction, subject to the arbitration clause.
- If any provision is held invalid or unenforceable, the remaining provisions shall remain in full force and effect.
- This Agreement, together with any policy updates communicated via the Seller Dashboard or official communications, constitutes the entire understanding between the Parties regarding the subject matter.
`;
  
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-12"
    >
      <div className="container mx-auto px-4 max-w-3xl">
        <div className="bg-card rounded-xl shadow-md p-6 md:p-8">
          <h1 className="text-3xl font-bold mb-2">Seller Agreement</h1>
          
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
              <p className="text-muted-foreground">Loading agreement...</p>
            </div>
          ) : error ? (
            <div className="bg-amber-50 border border-amber-200 text-amber-700 px-4 py-6 rounded mb-6 flex flex-col items-center">
              <AlertTriangle className="h-12 w-12 text-amber-500 mb-4" />
              <h2 className="text-xl font-semibold mb-2">Access Restricted</h2>
              <p className="text-center mb-4">{error}</p>
              <Button
                onClick={() => navigate('/seller-registration')}
                className="bg-gold hover:bg-gold/90 text-black"
              >
                Go to Seller Registration
              </Button>
            </div>
          ) : (
            <>
              <p className="text-muted-foreground mb-6">
                Please review the seller agreement carefully before accepting.
              </p>
              
              <div
                ref={agreementScrollRef}
                onWheel={handleAgreementWheel}
                className="border border-input rounded-md p-4 mb-6 max-h-[70vh] overflow-y-auto overscroll-contain bg-muted/30"
              >
                <div className="prose prose-sm max-w-none">
                  {agreementText.split('\n').map((line, index) => {
                    if (line.startsWith('# ')) {
                      return <h1 key={index} className="text-2xl font-bold mt-2 mb-4">{line.substring(2)}</h1>;
                    } else if (line.startsWith('## ')) {
                      return <h2 key={index} className="text-xl font-semibold mt-4 mb-2">{line.substring(3)}</h2>;
                    } else if (line.startsWith('- ')) {
                      return <li key={index} className="ml-4">{line.substring(2)}</li>;
                    } else if (line === '') {
                      return <br key={index} />;
                    } else {
                      return <p key={index} className="mb-2">{line}</p>;
                    }
                  })}
                </div>
              </div>
              
              <div className="flex items-center mb-6">
                <input
                  type="checkbox"
                  id="accept-agreement"
                  checked={agreementAccepted}
                  onChange={() => setAgreementAccepted(!agreementAccepted)}
                  className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                />
                <label htmlFor="accept-agreement" className="ml-2 text-sm">
                  I have read and agree to the terms and conditions of the Seller Agreement
                </label>
              </div>
              
              <Button
                onClick={handleAcceptAgreement}
                className="w-full bg-gold hover:bg-gold/90 text-black"
                disabled={!agreementAccepted || isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  'Accept Agreement'
                )}
              </Button>
            </>
          )}
        </div>
      </div>
      
      {/* Success Modal */}
      {showSuccessModal && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-card rounded-xl shadow-xl max-w-md w-full p-6 text-center"
          >
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="h-8 w-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Agreement Accepted!</h2>
            <p className="text-muted-foreground mb-6">
              You have successfully accepted the seller agreement. You can now access the seller dashboard.
            </p>
            <Button
              onClick={() => navigate('/seller-dashboard')}
              className="w-full bg-gold hover:bg-gold/90 text-black"
            >
              Go to Seller Dashboard
            </Button>
          </motion.div>
        </motion.div>
      )}
    </motion.div>
  );
}
