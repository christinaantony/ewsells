import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { ArrowLeft, ShoppingCart, Heart, Share2, Star } from 'lucide-react';

interface ProductPageProps {}

interface Product {
  id: string;
  name?: string;
  description?: string;
  category?: string;
  price?: number;
  imageUrl?: string;
  tags?: string[];
  brand?: string;
  stock?: number;
  rating?: number;
}

const ProductPage: React.FC<ProductPageProps> = () => {
  const { productId } = useParams<{ productId: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProduct = async () => {
      if (!productId) {
        setError('Product ID is missing');
        setLoading(false);
        return;
      }

      try {
        const productRef = doc(db, 'products', productId);
        const productSnap = await getDoc(productRef);

        if (productSnap.exists()) {
          setProduct({ id: productSnap.id, ...productSnap.data() as Omit<Product, 'id'> });
        } else {
          setError('Product not found');
        }
      } catch (err) {
        console.error('Error fetching product:', err);
        setError('Failed to load product details');
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [productId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-surface to-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gold"></div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-surface to-background p-6">
        <div className="container mx-auto max-w-4xl">
          <div className="bg-card/80 backdrop-blur-sm border border-border/50 rounded-2xl p-8 text-center">
            <h1 className="text-2xl font-bold text-foreground mb-4">
              {error || 'Product not found'}
            </h1>
            <p className="text-muted-foreground mb-6">
              We couldn't find the product you're looking for.
            </p>
            <Link
              to="/"
              className="inline-flex items-center gap-2 bg-gradient-to-r from-gold to-amber-400 text-black py-2 px-4 rounded-xl hover:opacity-90 transition-all"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-surface to-background">
      <div className="container mx-auto max-w-6xl px-4 py-8">
        {/* Breadcrumb */}
        <div className="mb-6">
          <div className="flex items-center text-sm text-muted-foreground">
            <Link to="/" className="hover:text-gold transition-colors">Home</Link>
            <span className="mx-2">/</span>
            <Link to={`/category/${product.category}`} className="hover:text-gold transition-colors">
              {product.category || 'Products'}
            </Link>
            <span className="mx-2">/</span>
            <span className="text-foreground">{product.name}</span>
          </div>
        </div>

        {/* Product Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Product Image */}
          <div className="bg-card/50 backdrop-blur-sm border border-border/50 rounded-2xl overflow-hidden">
            <div className="aspect-square relative">
              {product.imageUrl ? (
                <img 
                  src={product.imageUrl} 
                  alt={product.name} 
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-100 to-gray-200">
                  <span className="text-gray-400">No image available</span>
                </div>
              )}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              {product.brand && (
                <div className="text-sm text-gold font-medium mb-1">{product.brand}</div>
              )}
              <h1 className="text-3xl font-bold text-foreground mb-2">{product.name}</h1>
              
              {/* Rating */}
              <div className="flex items-center gap-1 mb-4">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star 
                    key={star}
                    className={`h-4 w-4 ${star <= (product.rating || 0) ? 'text-gold fill-gold' : 'text-gray-300'}`}
                  />
                ))}
                <span className="text-sm text-muted-foreground ml-2">
                  {product.rating || 0} out of 5
                </span>
              </div>

              {/* Price */}
              <div className="text-2xl font-bold text-foreground mb-2">
                ₹{product.price || 0}
              </div>

              {/* Stock */}
              <div className="text-sm mb-6">
                {product.stock && product.stock > 0 ? (
                  <span className="text-green-500">In Stock ({product.stock} available)</span>
                ) : (
                  <span className="text-red-500">Out of Stock</span>
                )}
              </div>
            </div>

            {/* Description */}
            <div>
              <h2 className="text-lg font-semibold text-foreground mb-2">Description</h2>
              <p className="text-muted-foreground">
                {product.description || 'No description available.'}
              </p>
            </div>

            {/* Tags */}
            {product.tags && product.tags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {product.tags.map((tag, index) => (
                  <span 
                    key={index}
                    className="bg-card/80 border border-border/50 px-3 py-1 rounded-full text-xs text-muted-foreground"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            )}

            {/* Actions */}
            <div className="flex flex-col gap-4">
              <button 
                className="w-full bg-gradient-to-r from-gold to-amber-400 text-black py-3 px-6 rounded-xl hover:opacity-90 transition-all flex items-center justify-center gap-2 font-medium"
                disabled={!product.stock || product.stock <= 0}
              >
                <ShoppingCart className="h-5 w-5" />
                Add to Cart
              </button>
              
              <div className="flex gap-4">
                <button className="flex-1 border border-border/50 bg-card/50 backdrop-blur-sm text-foreground py-2 px-4 rounded-xl hover:bg-card/80 transition-all flex items-center justify-center gap-2">
                  <Heart className="h-5 w-5" />
                  Wishlist
                </button>
                <button className="flex-1 border border-border/50 bg-card/50 backdrop-blur-sm text-foreground py-2 px-4 rounded-xl hover:bg-card/80 transition-all flex items-center justify-center gap-2">
                  <Share2 className="h-5 w-5" />
                  Share
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductPage;
