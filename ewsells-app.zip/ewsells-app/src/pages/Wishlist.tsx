import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { formatCurrency } from '@/lib/utils';
import { db } from '@/lib/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { Heart } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { Link } from 'react-router-dom';
import ProductImageCarousel from '@/components/ProductImageCarousel';
import { RatingPill } from '@/components/RatingPill';

// Minimal product shape used by category pages
type ProductDoc = {
  id: string;
  name: string;
  description?: string;
  price: number;
  category?: string;
  imageUrl?: string;
  imageUrls?: string[];
  images?: string[];
  badges?: string[];
  published?: boolean;
};

export default function WishlistPage() {
  const { wishlist, isWishlisted, toggleWishlist, user } = useStore();
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<ProductDoc[]>([]);

  useEffect(() => {
    let cancelled = false;
    async function loadProducts() {
      setLoading(true);
      try {
        // Fetch each product by ID; Firestore 'in' has 10-item limit, so individual reads are simpler here
        const snapshots = await Promise.all(
          (wishlist || []).map((id) => getDoc(doc(db, 'products', id)))
        );
        if (cancelled) return;
        const rows: ProductDoc[] = snapshots
          .filter((snap) => snap.exists())
          .map((snap) => ({ id: snap.id, ...(snap.data() as any) }));
        setProducts(rows);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    // Only load products when the user is signed in
    if (!user) {
      setProducts([]);
      setLoading(false);
      return () => { cancelled = true; };
    }

    if (wishlist.length > 0) {
      loadProducts();
    } else {
      setProducts([]);
      setLoading(false);
    }

    return () => {
      cancelled = true;
    };
  }, [wishlist, user]);

  useEffect(() => {
    document.title = 'Wishlist | ewsells';
  }, []);

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Your <span className="text-gold">Wishlist</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Items you saved for later.
          </p>
        </motion.div>

        {loading ? (
          <motion.div
            className="text-center py-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <p className="text-muted-foreground">Loading wishlist…</p>
          </motion.div>
        ) : products.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products.map((product) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="h-full flex flex-col overflow-hidden">
                  <div className="relative w-full">
                    <ProductImageCarousel
                      images={
                        (product.images && product.images.length > 0)
                          ? product.images
                          : (product.imageUrls && product.imageUrls.length > 0)
                            ? product.imageUrls
                            : (product.imageUrl ? [product.imageUrl] : [])
                      }
                      alt={product.name}
                      className="w-full"
                      aspect="square"
                    />
                    <Button
                      size="icon"
                      variant="ghost"
                      className="absolute top-2 right-2 bg-black/50 hover:bg-black/70 text-white h-8 w-8 rounded-full"
                      onClick={() => toggleWishlist(product.id)}
                      aria-label="Remove from wishlist"
                    >
                      <Heart className="w-4 h-4 fill-red-500 text-red-500" />
                    </Button>
                  </div>
                  <CardContent className="p-4 flex-1 flex flex-col">
                    <h3 className="font-semibold text-lg mb-1">{product.name}</h3>
                    {product.category && (
                      <span className="text-sm text-muted-foreground mb-2">
                        {product.category}
                      </span>
                    )}
                    {/* Star rating from Firebase */}
                    <div className="mb-2">
                      <RatingPill productId={product.id} docData={product as any} />
                    </div>
                    <div className="mt-auto pt-2">
                      <div className="text-xl font-bold text-gold">
                        {formatCurrency(product.price)}
                      </div>
                      <Button className="w-full mt-3" onClick={() => {}}>
                        Add to Cart
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        ) : (
          <motion.div
            className="text-center py-16"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <p className="text-muted-foreground mb-6">
              {user ? 'Your wishlist is empty.' : 'Your wishlist is empty. Sign in to save items for later.'}
            </p>
            {!user && (
              <Link to="/login?mode=face">
                <Button className="bg-gold hover:bg-gold/90 text-black">Sign in</Button>
              </Link>
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
}
