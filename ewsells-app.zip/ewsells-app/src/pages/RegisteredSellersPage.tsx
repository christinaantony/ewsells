import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Search, 
  Loader2, 
  MapPin, 
  Calendar, 
  Mail, 
  Phone, 
  User, 
  Building2,
  Star,
  Filter
} from 'lucide-react';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useToast } from '@/components/ui/toast-context';

interface SellerData {
  id: string;
  name: string;
  businessName?: string;
  email: string;
  phone?: string;
  city?: string;
  state?: string;
  businessAddress?: {
    city?: string;
    state?: string;
    addressLine1?: string;
  };
  departments?: string[];
  businessCategory?: string;
  category?: string;
  sellerCode?: string;
  status: string;
  createdAt?: any;
  approvedAt?: any;
  assignedProject?: {
    projectTitle?: string;
    focusArea?: string;
  };
  passportPhotoUrl?: string;
  about?: string;
  description?: string;
}

export default function RegisteredSellersPage() {
  const [loading, setLoading] = useState(true);
  const [sellers, setSellers] = useState<SellerData[]>([]);
  const [filteredSellers, setFilteredSellers] = useState<SellerData[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'approved' | 'pending'>('all');
  const [departments, setDepartments] = useState<Record<string, string>>({});
  const { showToast } = useToast();

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const sellersPerPage = 12;

  useEffect(() => {
    fetchDepartments();
    fetchSellers();
  }, []);

  useEffect(() => {
    filterSellers();
  }, [sellers, searchTerm, statusFilter]);

  const fetchDepartments = async () => {
    try {
      const departmentsRef = collection(db, 'departments');
      const snapshot = await getDocs(departmentsRef);
      const deptMap: Record<string, string> = {};
      
      snapshot.forEach(doc => {
        deptMap[doc.id] = doc.data().name;
      });
      
      setDepartments(deptMap);
    } catch (error) {
      console.error('Error fetching departments:', error);
    }
  };

  const fetchSellers = async () => {
    try {
      setLoading(true);
      
      // Fetch from seller-profiles collection (has public read access)
      const sellersRef = collection(db, 'seller-profiles');
      const q = query(sellersRef, orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      
      const sellersData: SellerData[] = [];
      
      snapshot.forEach(doc => {
        const data = doc.data();
        // Only include approved sellers for public display
        if (data.status === 'approved' || data.status === 'active') {
          sellersData.push({
            id: doc.id,
            name: data.name || data.businessName || data.ownerName || 'Unknown',
            businessName: data.businessName,
            email: data.email || '',
            phone: data.phone || data.phoneNumber,
            city: data.city || data.businessAddress?.city,
            state: data.state || data.businessAddress?.state,
            businessAddress: data.businessAddress,
            departments: data.departments || [],
            businessCategory: data.businessCategory || data.category,
            sellerCode: data.sellerCode,
            status: data.status || 'approved',
            createdAt: data.createdAt,
            approvedAt: data.approvedAt,
            assignedProject: data.assignedProject,
            passportPhotoUrl: data.profilePictureUrl || data.passportPhotoUrl,
            about: data.about || data.description || data.bio
          });
        }
      });
      
      setSellers(sellersData);
      console.log('Fetched sellers:', sellersData.length);
    } catch (error) {
      console.error('Error fetching sellers:', error);
      showToast({
        message: 'Failed to load sellers. Please try again.',
        type: 'error'
      });
    } finally {
      setLoading(false);
    }
  };

  const filterSellers = () => {
    let filtered = sellers;

    // Filter by status
    if (statusFilter !== 'all') {
      filtered = filtered.filter(seller => seller.status === statusFilter);
    }

    // Filter by search term
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(seller =>
        seller.name.toLowerCase().includes(term) ||
        seller.businessName?.toLowerCase().includes(term) ||
        seller.email.toLowerCase().includes(term) ||
        seller.city?.toLowerCase().includes(term) ||
        seller.sellerCode?.toLowerCase().includes(term) ||
        seller.businessCategory?.toLowerCase().includes(term)
      );
    }

    setFilteredSellers(filtered);
    setCurrentPage(1); // Reset to first page when filtering
  };

  const getDepartmentName = (deptId: string) => {
    return departments[deptId] || deptId || '';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800 hover:bg-green-100';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-100';
      case 'rejected':
        return 'bg-red-100 text-red-800 hover:bg-red-100';
      default:
        return 'bg-gray-100 text-gray-800 hover:bg-gray-100';
    }
  };

  const formatDate = (timestamp: any) => {
    if (!timestamp) return 'N/A';
    
    try {
      const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch {
      return 'N/A';
    }
  };

  // Pagination calculations
  const totalPages = Math.ceil(filteredSellers.length / sellersPerPage);
  const startIndex = (currentPage - 1) * sellersPerPage;
  const endIndex = startIndex + sellersPerPage;
  const currentSellers = filteredSellers.slice(startIndex, endIndex);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (loading) {
    return (
      <div className="min-h-screen pt-20 pb-12 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-gold mx-auto mb-4" />
          <p className="text-muted-foreground">Loading registered sellers...</p>
        </div>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-12"
    >
      <div className="container mx-auto px-4 max-w-7xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-gold via-amber-400 to-gold bg-clip-text text-transparent">
            Registered Sellers
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Discover our community of verified sellers offering quality products and services
          </p>
        </div>

        {/* Filters */}
        <div className="mb-8 space-y-4">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Search */}
            <div className="relative w-full md:w-96">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search sellers by name, email, city, or code..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-3 py-2 border border-border rounded-md bg-background text-foreground"
              >
                <option value="all">All Status</option>
                <option value="approved">Approved</option>
                <option value="pending">Pending</option>
              </select>
            </div>
          </div>

          {/* Stats */}
          <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
            <span>Total: {sellers.length}</span>
            <span>Approved: {sellers.filter(s => s.status === 'approved').length}</span>
            <span>Pending: {sellers.filter(s => s.status === 'pending').length}</span>
            {searchTerm && <span>Filtered: {filteredSellers.length}</span>}
          </div>
        </div>

        {/* Sellers Grid */}
        {filteredSellers.length === 0 ? (
          <div className="text-center py-12">
            <Building2 className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">No sellers found</h3>
            <p className="text-muted-foreground">
              {searchTerm ? 'Try adjusting your search criteria' : 'No registered sellers available'}
            </p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
              {currentSellers.map((seller, index) => (
                <motion.div
                  key={seller.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-lg transition-all duration-300 hover:scale-105 border-border/60 hover:border-gold/30">
                    <CardHeader className="pb-3">
                      <div className="flex flex-col items-center text-center mb-4">
                        {seller.passportPhotoUrl ? (
                          <img
                            src={seller.passportPhotoUrl}
                            alt={seller.name}
                            className="w-20 h-20 rounded-full object-cover border-3 border-gold/30 shadow-lg mb-3"
                          />
                        ) : (
                          <div className="w-20 h-20 rounded-full bg-gradient-to-r from-gold/20 to-amber-400/20 flex items-center justify-center border-3 border-gold/30 shadow-lg mb-3">
                            <User className="h-10 w-10 text-gold" />
                          </div>
                        )}
                        <div className="w-full">
                          <CardTitle className="text-lg leading-tight mb-1">
                            {seller.name}
                          </CardTitle>
                          {seller.sellerCode && (
                            <CardDescription className="text-xs font-mono text-gold/80 mb-2">
                              {seller.sellerCode}
                            </CardDescription>
                          )}
                          <Badge className={`${getStatusColor(seller.status)} text-xs`}>
                            {seller.status}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-4 pt-0">
                      {/* Business Name */}
                      {seller.businessName && seller.businessName !== seller.name && (
                        <div className="text-center">
                          <div className="inline-flex items-center gap-2 px-3 py-1 bg-muted/50 rounded-full text-sm">
                            <Building2 className="h-4 w-4 text-muted-foreground" />
                            <span className="truncate">{seller.businessName}</span>
                          </div>
                        </div>
                      )}

                      {/* Location - Only City/State */}
                      {(seller.city || seller.state) && (
                        <div className="text-center">
                          <div className="inline-flex items-center gap-2 px-3 py-1 bg-green-50 dark:bg-green-950/30 rounded-full text-sm text-green-700 dark:text-green-300">
                            <MapPin className="h-3 w-3" />
                            <span className="truncate">
                              {[seller.city, seller.state].filter(Boolean).join(', ')}
                            </span>
                          </div>
                        </div>
                      )}

                      {/* Departments */}
                      {seller.departments && seller.departments.length > 0 && (
                        <div className="flex flex-wrap gap-2 justify-center">
                          {seller.departments.slice(0, 3).map((dept) => (
                            <Badge key={dept} variant="outline" className="text-xs bg-purple-50 dark:bg-purple-950/30 border-purple-200 dark:border-purple-800 text-purple-700 dark:text-purple-300">
                              {getDepartmentName(dept)}
                            </Badge>
                          ))}
                          {seller.departments.length > 3 && (
                            <Badge variant="outline" className="text-xs bg-gray-50 dark:bg-gray-950/30">
                              +{seller.departments.length - 3} more
                            </Badge>
                          )}
                        </div>
                      )}

                      {/* Assigned Project */}
                      {seller.assignedProject?.projectTitle && (
                        <div className="text-center">
                          <div className="inline-flex items-center gap-2 px-3 py-1 bg-gradient-to-r from-gold/10 to-amber-400/10 border border-gold/20 rounded-full text-xs">
                            <Star className="h-3 w-3 text-gold" />
                            <span className="text-gold truncate font-medium">
                              {seller.assignedProject.projectTitle}
                            </span>
                          </div>
                        </div>
                      )}

                      {/* Registration Date */}
                      <div className="text-center pt-3 border-t border-border/40">
                        <div className="inline-flex items-center gap-2 text-xs text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          <span>Member since {formatDate(seller.createdAt)}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2">
                <Button
                  variant="outline"
                  disabled={currentPage === 1}
                  onClick={() => handlePageChange(currentPage - 1)}
                >
                  Previous
                </Button>
                
                <div className="flex gap-1">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                    <Button
                      key={page}
                      variant={currentPage === page ? "default" : "outline"}
                      className={currentPage === page ? "bg-gold text-black hover:bg-gold/90" : ""}
                      onClick={() => handlePageChange(page)}
                    >
                      {page}
                    </Button>
                  ))}
                </div>

                <Button
                  variant="outline"
                  disabled={currentPage === totalPages}
                  onClick={() => handlePageChange(currentPage + 1)}
                >
                  Next
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </motion.div>
  );
}
