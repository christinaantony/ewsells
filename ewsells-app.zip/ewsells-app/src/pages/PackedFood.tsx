import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Search, SlidersHorizontal, Grid2X2, List, Heart, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useStore } from '@/store/useStore';
import { formatCurrency } from '@/lib/utils';
import { useCart } from '@/contexts/CartContext';
import { useAuthGate } from '@/hooks/useAuthGate';
import { useNavigate } from 'react-router-dom';
import ProductImageCarousel from '@/components/ProductImageCarousel';
import { RatingPill } from '@/components/RatingPill';

interface ProductDoc {
  id: string;
  name: string;
  description?: string;
  price: number;
  sellerPrice?: number;
  finalPrice?: number;
  category?: string;
  imageUrl?: string;
  images?: string[];
  imageUrls?: string[];
  customizable?: boolean;
}

export function PackedFoodPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<ProductDoc[]>([]);
  const { toggleWishlist, isWishlisted } = useStore();
  const { addToCart } = useCart();
  const { runOrLogin } = useAuthGate();
  const navigate = useNavigate();
  // Filters state
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [priceFilter, setPriceFilter] = useState<'all' | 'under25' | '25to50' | '50to100' | 'over100'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'priceAsc' | 'priceDesc' | 'impact' | 'popular'>('newest');

  useEffect(() => {
    const q = query(
      collection(db, 'products'),
      where('category', '==', 'packed-food'),
      where('published', '==', true)
    );
    const unsub = onSnapshot(q, (snap) => {
      const rows: ProductDoc[] = snap.docs.map((d) => {
        const data = d.data() as any;
        const images: string[] = Array.isArray(data.images)
          ? data.images
          : Array.isArray(data.imageUrls)
          ? data.imageUrls
          : data.imageUrl
          ? [data.imageUrl]
          : [];
        return {
          id: d.id,
          name: data.name,
          description: data.description,
          imageUrl: data.imageUrl,
          images,
          category: data.category,
          price: typeof data.price === 'number' ? data.price : Number(data.price || 0),
          sellerPrice: typeof data.sellerPrice === 'number' ? data.sellerPrice : (data.sellerPrice != null ? Number(data.sellerPrice) : undefined),
          finalPrice: typeof data.finalPrice === 'number' ? data.finalPrice : (data.finalPrice != null ? Number(data.finalPrice) : undefined),
          customizable: !!data.customizable,
        };
      });

      setProducts(rows);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();

    const priceInRange = (price: number) => {
      switch (priceFilter) {
        case 'under25':
          return price < 25;
        case '25to50':
          return price >= 25 && price <= 50;
        case '50to100':
          return price > 50 && price <= 100;
        case 'over100':
          return price > 100;
        default:
          return true;
      }
    };

    const displayPrice = (p: ProductDoc) => (p.finalPrice ?? p.sellerPrice ?? p.price ?? 0);
    const impactScore = (p: ProductDoc) => {
      const finalP = Number(p.finalPrice ?? p.price ?? 0);
      const sellerP = Number(p.sellerPrice ?? 0);
      return (finalP - sellerP) / 2;
    };

    let list = products.filter((p) => {
      const matchesSearch = !q || (p.name || '').toLowerCase().includes(q) || (p.description || '').toLowerCase().includes(q);
      return matchesSearch && priceInRange(displayPrice(p));
    });

    switch (sortBy) {
      case 'priceAsc':
        list = [...list].sort((a, b) => displayPrice(a) - displayPrice(b));
        break;
      case 'priceDesc':
        list = [...list].sort((a, b) => displayPrice(b) - displayPrice(a));
        break;
      case 'impact':
        list = [...list].sort((a, b) => impactScore(b) - impactScore(a));
        break;
      case 'popular':
        // No popularity metric yet; leave as-is for now
        break;
      case 'newest':
      default:
        // No createdAt available; keep Firestore default order
        break;
    }

    return list;
  }, [products, searchQuery, priceFilter, sortBy]);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  const getDisplayPrice = (product: ProductDoc) => {
    return product.finalPrice ?? product.sellerPrice ?? product.price ?? 0;
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-12"
    >
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Packed <span className="text-gold">Food</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Browse quality packed foods from trusted local sellers.
          </p>
        </div>

        <div className="mb-8">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between mb-6">
            {/* Search Bar */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search packed foods..."
                value={searchQuery}
                onChange={handleSearch}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 pl-10"
              />
            </div>

            {/* Filter and View Options */}
            <div className="flex items-center gap-2 relative">
              <Button
                variant="outline"
                size="sm"
                className="flex items-center gap-2"
                onClick={() => setFiltersOpen((o) => !o)}
              >
                <SlidersHorizontal className="h-4 w-4" />
                Filters
              </Button>

              {filtersOpen && (
                <div className="absolute top-12 right-0 z-40 w-80 sm:w-[28rem] bg-background border border-border rounded-md shadow-lg p-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Price Range</label>
                    <div className="space-y-2">
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === 'all' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setPriceFilter('all')}
                      >
                        All Prices
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === 'under25' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setPriceFilter('under25')}
                      >
                        Under ₹25
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === '25to50' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setPriceFilter('25to50')}
                      >
                        ₹25 - ₹50
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === '50to100' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setPriceFilter('50to100')}
                      >
                        ₹50 - ₹100
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === 'over100' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setPriceFilter('over100')}
                      >
                        Over ₹100
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Sort By</label>
                    <div className="space-y-2">
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'newest' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setSortBy('newest')}
                      >
                        Newest First
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'priceAsc' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setSortBy('priceAsc')}
                      >
                        Price: Low to High
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'priceDesc' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setSortBy('priceDesc')}
                      >
                        Price: High to Low
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'impact' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setSortBy('impact')}
                      >
                        Highest Impact
                      </button>
                      <button
                        className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'popular' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                        onClick={() => setSortBy('popular')}
                      >
                        Most Popular
                      </button>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="border rounded-md flex">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Grid2X2 className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Results Count */}
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">
              {filteredProducts.length} items found
            </p>
            <p className="text-sm text-muted-foreground">
              Sorted by {sortBy.charAt(0).toUpperCase() + sortBy.slice(1)}
            </p>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading packed foods…</p>
          </div>
        ) : (
          <>
            {/* Product Grid */}
            <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4' : 'grid-cols-1'} gap-6`}>
              {filteredProducts.map(product => (
                <Card
                  key={product.id}
                  className="overflow-hidden group cursor-pointer"
                  onClick={() => navigate(`/product/${product.id}`)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      navigate(`/product/${product.id}`);
                    }
                  }}
                >
                  <div className="relative">
                    <div className="overflow-hidden h-48 w-full">
                      <ProductImageCarousel
                        images={product.images && product.images.length ? product.images : (product.imageUrl ? [product.imageUrl] : [])}
                        alt={product.name}
                        className="w-full h-full object-cover"
                        aspect="free"
                      />
                    </div>
                    {product.category && (
                      <Badge className="absolute top-2 left-2 bg-gold text-black text-xs">{product.category}</Badge>
                    )}
                    {product.customizable && (
                      <Badge className="absolute top-2 left-2 translate-y-7 bg-emerald-500/90 text-white text-[10px]">Customizable</Badge>
                    )}
                    <Button
                      size="icon"
                      variant="ghost"
                      className="absolute top-1 right-1 bg-black/50 hover:bg-black/70 text-white h-8 w-8"
                      onClick={(e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        toggleWishlist(product.id);
                      }}
                      aria-pressed={isWishlisted(product.id)}
                      aria-label={isWishlisted(product.id) ? 'Remove from wishlist' : 'Add to wishlist'}
                    >
                      <Heart className={`h-3.5 w-3.5 ${isWishlisted(product.id) ? 'fill-red-500 text-red-500' : ''}`} />
                    </Button>
                  </div>
                  
                  <CardContent className="p-3">
                    <h3 className="font-semibold text-base mb-1 group-hover:text-gold transition-colors line-clamp-1">
                      {product.name}
                    </h3>
                    {product.description && (
                      <p className="text-muted-foreground text-xs mb-2 line-clamp-2 h-10">
                        {product.description}
                      </p>
                    )}
                    {/* Ratings pill above price/add button */}
                    <div className="mb-2">
                      <RatingPill productId={product.id} docData={product as any} />
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-base">
                        {formatCurrency(Number(product.finalPrice ?? product.sellerPrice ?? product.price ?? 0))}
                      </span>
                      <Button
                        className="bg-gold hover:bg-amber-500 text-black border border-amber-300 rounded-md px-3 py-1.5 h-8 text-sm font-medium transition-colors shadow-sm hover:shadow flex items-center gap-1.5 whitespace-nowrap"
                        onClick={async (e) => {
                          e.stopPropagation();
                          e.preventDefault();
                          const price = Number(product.finalPrice ?? product.sellerPrice ?? product.price ?? 0);
                          const cartProduct = {
                            id: product.id,
                            name: product.name,
                            price,
                            imageUrl: (product.images?.[0] || product.imageUrl || '/images/placeholder-item.jpg'),
                            category: product.category || 'packed-food',
                          };
                          runOrLogin(() => {
                            addToCart(cartProduct);
                          });
                        }}
                      >
                        <ShoppingCart className="h-3.5 w-3.5" />
                        <span>Add to Cart</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className="text-center py-12">
                {products.length === 0 && !searchQuery ? (
                  <p className="text-muted-foreground">No packed foods available at the moment.</p>
                ) : (
                  <p className="text-muted-foreground">No packed foods found matching your search.</p>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </motion.div>
  );
}
