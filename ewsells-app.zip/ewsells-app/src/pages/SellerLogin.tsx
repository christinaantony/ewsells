import { useState } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Eye, EyeOff, LogIn } from 'lucide-react';
import { authService } from '@/services/auth';
import { db } from '@/lib/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { useStore } from '@/store/useStore';

export default function SellerLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { setUser } = useStore();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    try {
      const user = await authService.login(email, password);
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      const userData = userDoc.exists() ? (userDoc.data() as any) : {};

      const completeUser = {
        id: user.uid,
        email: user.email || userData.email || '',
        displayName: user.displayName || userData.displayName || '',
        photoURL: user.photoURL || userData.photoURL || '',
        role: userData.role || 'user',
        createdAt: userData.createdAt || new Date(),
        updatedAt: new Date()
      };
      setUser(completeUser);

      // Persist for session continuity
      localStorage.setItem('currentUser', JSON.stringify({
        uid: user.uid,
        email: completeUser.email,
        displayName: completeUser.displayName,
        photoURL: completeUser.photoURL,
        role: completeUser.role,
        lastLogin: new Date().toISOString()
      }));

      if (completeUser.role !== 'seller') {
        setError('Your account is not a seller. Please complete seller registration.');
        return;
      }

      // Mark entry via seller portal and navigate to intended seller route
      sessionStorage.setItem('sellerPortalEntry', '1');
      const intended = sessionStorage.getItem('sellerIntended') || '/seller';
      navigate(intended, { replace: true });
    } catch (err: any) {
      setError(err.message || 'Failed to sign in. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // If user arrived here without coming from /seller-portal, still allow but show note
  const fromPortal = location.pathname.startsWith('/seller-portal');

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="w-full max-w-md z-20"
      >
        <div className="bg-card/80 backdrop-blur-md shadow-xl rounded-2xl p-8 border border-white/10">
          <div className="text-center mb-6">
            <div className="inline-flex items-center px-3 py-1 rounded-full bg-white/10 border border-white/15 text-xs uppercase tracking-wide text-gray-200/90 mb-3">
              Seller Portal Login
            </div>
            <h1 className="text-2xl font-bold">Sign in as Seller</h1>
            {!fromPortal && (
              <p className="text-xs text-muted-foreground mt-1">You are accessing the dedicated seller sign-in.</p>
            )}
          </div>

          {error && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-destructive/20 text-destructive p-3 rounded-lg mb-4 text-sm">
              {error}
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium mb-1">Email</label>
              <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" required />
            </div>
            <div>
              <label htmlFor="password" className="block text-sm font-medium mb-1">Password</label>
              <div className="relative">
                <Input id="password" type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" required className="w-full pr-10" />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500">
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>
            <Button type="submit" disabled={isLoading} className="w-full bg-gold text-black hover:bg-gold/90">
              {isLoading ? (
                <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="mr-2 h-4 w-4 border-2 border-black border-t-transparent rounded-full" />
              ) : (
                <LogIn className="mr-2 h-4 w-4" />
              )}
              {isLoading ? 'Signing In...' : 'Sign In'}
            </Button>
          </form>

          <div className="mt-6 text-center text-sm">
            <p>
              Back to{' '}
              <Link to="/seller-portal" className="text-primary hover:underline">
                Seller Portal
              </Link>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
