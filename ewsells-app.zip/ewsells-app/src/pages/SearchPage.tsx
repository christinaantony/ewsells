import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Search, Grid, Package, Loader2 } from 'lucide-react';
import { SearchResult, searchItems } from '@/services/searchService';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { RelatedProducts } from '@/components/search/RelatedProducts';
import { ProductCarousel } from '@/components/ui/ProductCarousel';
import { formatCurrency } from '@/lib/utils';

export default function SearchPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [categories, setCategories] = useState<SearchResult[]>([]);
  
  // Extract query from URL
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const query = params.get('q') || '';
    setSearchQuery(query);
    
    if (query) {
      performSearch(query);
    }
  }, [location.search]);
  
  // Handle search form submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };
  
  // Perform search
  const performSearch = async (query: string) => {
    setIsLoading(true);
    try {
      // Get more results for the search page
      const searchResults = await searchItems(query, 50, true, 4);
      setResults(searchResults);
      
      // Extract categories from results
      const categoryResults = searchResults.filter(result => result.type === 'category');
      setCategories(categoryResults);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Filter results by category
  const filteredResults = activeCategory
    ? results.filter(result => 
        result.type === 'product' && 
        (result.categoryId === activeCategory || result.category === activeCategory)
      )
    : results.filter(result => result.type === 'product');
    
  // Collect all related items from products for a common section
  const allRelatedItems = filteredResults
    .flatMap(result => result.relatedItems || [])
    .filter((item, index, self) => 
      // Remove duplicates based on id
      index === self.findIndex(t => t.id === item.id)
    )
    // Limit to 10 related items
    .slice(0, 10);
  
  // Group products by category
  const productsByCategory: Record<string, SearchResult[]> = {};
  
  results
    .filter(result => result.type === 'product' && result.category)
    .forEach(product => {
      const category = product.category || 'Other';
      if (!productsByCategory[category]) {
        productsByCategory[category] = [];
      }
      productsByCategory[category].push(product);
    });
  
  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-4">Search Results</h1>
        
        {/* Search form */}
        <form onSubmit={handleSearch} className="flex gap-2 max-w-xl">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button type="submit">Search</Button>
        </form>
      </div>
      
      {isLoading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-gold" />
        </div>
      ) : (
        <>
          {/* Categories section */}
          {categories.length > 0 && (
            <div className="mb-8">
              <h2 className="text-lg font-semibold mb-3">Categories</h2>
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={activeCategory === null ? "default" : "outline"}
                  size="sm"
                  onClick={() => setActiveCategory(null)}
                >
                  All Results
                </Button>
                
                {categories.map(category => (
                  <Button
                    key={category.id}
                    variant={activeCategory === category.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setActiveCategory(category.id)}
                    className="flex items-center gap-2"
                  >
                    <Grid className="h-4 w-4" />
                    {category.title}
                  </Button>
                ))}
              </div>
              
              {/* Show products from selected category */}
              {activeCategory && categories.find(c => c.id === activeCategory)?.relatedItems && (
                <div className="mt-4">
                  <RelatedProducts 
                    items={categories.find(c => c.id === activeCategory)?.relatedItems || []}
                    title={`Products in ${categories.find(c => c.id === activeCategory)?.title}`}
                  />
                </div>
              )}
            </div>
          )}
          
          {/* Results count */}
          <div className="mb-4 text-sm text-muted-foreground">
            {filteredResults.length} {filteredResults.length === 1 ? 'product' : 'products'} found for "{searchQuery}"
          </div>
          
          {/* Results list */}
          {filteredResults.length > 0 ? (
            <div className="flex flex-col space-y-4">
              {filteredResults.map(result => (
                <div 
                  key={result.id}
                  className="border border-border rounded-lg overflow-hidden hover:border-gold/50 transition-colors flex flex-col md:flex-row shadow-sm hover:shadow-md"
                  onClick={() => navigate(result.url)}
                  role="button"
                >
                  <div className="md:w-48 lg:w-56 h-48 md:h-auto bg-muted relative flex-shrink-0">
                    {result.image ? (
                      <img
                        src={result.image}
                        alt={result.title}
                        className="h-full w-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://via.placeholder.com/300x200?text=Product';
                        }}
                      />
                    ) : (
                      <div className="h-full w-full flex items-center justify-center bg-muted">
                        <Package className="h-12 w-12 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                  
                  <div className="p-4 flex-grow flex flex-col justify-between">
                    <div>
                      <h3 className="font-medium text-lg">{result.title}</h3>
                      
                      {result.category && (
                        <div className="text-xs text-muted-foreground mt-1 flex items-center">
                          <Grid className="h-3 w-3 mr-1" />
                          {result.category}
                        </div>
                      )}
                      
                      {result.description && (
                        <p className="text-sm text-muted-foreground mt-3 line-clamp-2">
                          {result.description}
                        </p>
                      )}
                    </div>
                    
                    <div className="mt-4 flex items-center justify-between">
                      {result.price !== undefined && (
                        <div className="text-gold font-medium text-lg">
                          {formatCurrency(result.price)}
                        </div>
                      )}
                      
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="border-gold/30 hover:border-gold hover:bg-gold/10"
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-12 text-center">
              <p className="text-lg text-muted-foreground">No products found for "{searchQuery}"</p>
              <Button 
                variant="link" 
                className="mt-2 text-gold"
                onClick={() => navigate('/')}
              >
                Browse all products
              </Button>
            </div>
          )}
          
          {/* Group products by category */}
          {!activeCategory && Object.keys(productsByCategory).length > 0 && (
            <div className="mt-12">
              <h2 className="text-xl font-semibold mb-6">Browse by Category</h2>
              
              {Object.entries(productsByCategory).map(([category, products]) => (
                <div key={category} className="mb-8">
                  <h3 className="text-lg font-medium mb-3 flex items-center">
                    <Grid className="h-5 w-5 mr-2" />
                    {category}
                  </h3>
                  
                  <ProductCarousel items={products.slice(0, 10)} showTitle={false} />
                </div>
              ))}
            </div>
          )}
          
          {/* Common Similar Products section */}
          {allRelatedItems && allRelatedItems.length > 0 && (
            <div className="mt-12 border-t border-border pt-8">
              <h2 className="text-xl font-semibold mb-6">You May Also Like</h2>
              <ProductCarousel 
                items={allRelatedItems} 
                showTitle={false}
              />
            </div>
          )}
        </>
      )}
    </div>
  );
}
