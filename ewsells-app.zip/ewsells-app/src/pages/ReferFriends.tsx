import React, { useMemo, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Copy, Share2, MessageCircle, Send, Twitter, Facebook, Linkedin, Mail, Check } from 'lucide-react';
import { useStore } from '@/store/useStore';

export default function ReferFriends() {
  const { user } = useStore();
  const [copied, setCopied] = useState(false);
  const [shared, setShared] = useState<string | null>(null);

  const referText = 'Join me on EWSELLS |CHARITY STORE BEYOND| — where every purchase makes a difference!';
  const referralUrl = useMemo(() => {
    const origin = typeof window !== 'undefined' ? window.location.origin : 'https://ewsells.org';
    const ref = user?.id || 'friend';
    return `${origin}/?ref=${encodeURIComponent(ref)}`;
  }, [user]);

  const encodedUrl = encodeURIComponent(referralUrl);
  const encodedText = encodeURIComponent(referText);

  const links = [
    {
      name: 'WhatsApp',
      href: `https://wa.me/?text=${encodedText}%20${encodedUrl}`,
      icon: MessageCircle,
    },
    {
      name: 'Telegram',
      href: `https://t.me/share/url?url=${encodedUrl}&text=${encodedText}`,
      icon: Send,
    },
    {
      name: 'X (Twitter)',
      href: `https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`,
      icon: Twitter,
    },
    {
      name: 'Facebook',
      href: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
      icon: Facebook,
    },
    {
      name: 'LinkedIn',
      href: `https://www.linkedin.com/shareArticle?mini=true&url=${encodedUrl}&title=${encodedText}`,
      icon: Linkedin,
    },
    {
      name: 'Email',
      href: `mailto:?subject=${encodeURIComponent('Check this out: EWSELLS')}&body=${encodedText}%0A%0A${encodedUrl}`,
      icon: Mail,
    },
  ];

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(`${referText}\n\n${referralUrl}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {}
  };

  const handleSelectAndCopy = async (e: React.MouseEvent<HTMLInputElement>) => {
    const input = e.currentTarget;
    input.select();
    try {
      await navigator.clipboard.writeText(referralUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 1200);
    } catch {}
  };

  const handleWebShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title: 'EWSELLS', text: referText, url: referralUrl });
        setShared('Shared');
        setTimeout(() => setShared(null), 1500);
      } catch {}
    } else {
      handleCopy();
    }
  };

  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-24 pb-12"
    >
      <div className="container mx-auto px-4 max-w-3xl">
        {/* removed back link per request */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">
            Refer <span className="text-gold">Friends</span>
          </h1>
          <p className="text-muted-foreground">Share EWSELLS with your friends on your favorite apps.</p>
        </div>

        <div className="bg-card/80 backdrop-blur-md border border-white/10 rounded-2xl p-6 md:p-8 shadow-xl space-y-5">
          <div>
            <p className="text-sm text-muted-foreground mb-2">Your referral link</p>
            <div className="flex items-center gap-2">
              <input
                className="w-full h-12 rounded-full border border-transparent bg-gradient-to-r from-black/70 to-zinc-900/50 text-white pl-10 pr-4 text-sm shadow-inner focus:outline-none focus:ring-2 focus:ring-gold/80 transition-colors duration-200 placeholder:text-muted-foreground/70 font-mono tracking-tight selection:bg-gold/30"
                value={referralUrl}
                readOnly
                aria-label="Referral link"
                onFocus={(e) => e.currentTarget.select()}
                onClick={handleSelectAndCopy}
                title={referralUrl}
              />
              <Button
                type="button"
                onClick={handleCopy}
                aria-label="Copy referral link"
                variant="outline"
                className="h-10 px-4 rounded-md"
              >
                {copied ? (
                  <>
                    <Check className="h-4 w-4 mr-2" /> Copied
                  </>
                ) : (
                  <>
                    <Copy className="h-4 w-4 mr-2" /> Copy
                  </>
                )}
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {links.map(({ name, href, icon: Icon }) => (
              <a
                key={name}
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 h-11 rounded-full border border-border bg-muted/30 px-3 text-sm hover:bg-gold/10 hover:text-gold transition-colors"
                aria-label={`Share via ${name}`}
              >
                <Icon className="h-4 w-4" />
                <span>{name}</span>
              </a>
            ))}

            <button
              type="button"
              onClick={handleWebShare}
              className="flex items-center justify-center gap-2 h-11 rounded-full border border-border bg-muted/30 px-3 text-sm hover:bg-gold/10 hover:text-gold transition-colors"
              aria-label="Share via system share"
            >
              <Share2 className="h-4 w-4" />
              <span>{shared ? shared : 'Share (Device)'}</span>
            </button>

            {/* Instagram note */}
            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center justify-center gap-2 h-11 rounded-full border border-border bg-muted/30 px-3 text-sm hover:bg-gold/10 hover:text-gold transition-colors"
              aria-label="Copy for Instagram"
            >
              <Copy className="h-4 w-4" />
              <span>Instagram (Copy Text)</span>
            </button>
          </div>

          <p className="text-xs text-muted-foreground/80">Tip: Instagram on web doesn’t support direct sharing links. Use the Copy option, then paste into Instagram DMs or stories.</p>
        </div>
      </div>
    </motion.main>
  );
}
