import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Grid2X2, List, X, Heart, SlidersHorizontal, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useStore } from '@/store/useStore';
import { formatCurrency } from '@/lib/utils';
import { calculateUplift } from '@/lib/utils';
import { useCart } from '@/contexts/CartContext';
import { useNavigate } from 'react-router-dom';
import { useAuthGate } from '@/hooks/useAuthGate';
import ProductImageCarousel from '@/components/ProductImageCarousel';
import { RatingPill } from '@/components/RatingPill';

// Firestore product shape mapped for this page
interface MomsProductDoc {
  id: string;
  title: string;
  description?: string;
  price: number; // legacy price kept
  imageUrl?: string;
  images?: string[];
  imageUrls?: string[];
  badge?: string; // optional if present in doc
  rating?: number; // optional
  reviews?: number; // optional
  sellerPrice?: number; // seller-set
  finalPrice?: number; // admin-set
  customizable?: boolean;
}

const badgeOptions = ['all', 'handmade', 'food', 'eco-friendly', 'personal-care', 'home-decor'] as const;
const priceRanges = [
  { label: 'All', min: 0, max: Infinity },
  { label: 'Under ₹10', min: 0, max: 10 },
  { label: '₹10 - ₹20', min: 10, max: 20 },
  { label: '₹20 - ₹40', min: 20, max: 40 },
];

export function MomsMadeUnitedPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedBadge, setSelectedBadge] = useState<(typeof badgeOptions)[number]>('all');
  const [showFilters, setShowFilters] = useState(false);
  const [priceFilter, setPriceFilter] = useState<'all' | 'under25' | '25-50' | '50-100' | 'over100'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'price-asc' | 'price-desc' | 'impact' | 'popular'>('newest');
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<MomsProductDoc[]>([]);
  const { toggleWishlist, isWishlisted } = useStore();
  const { addToCart } = useCart();
  const navigate = useNavigate();
  const { runOrLogin } = useAuthGate();

  useEffect(() => {
    const q = query(
      collection(db, 'products'),
      where('category', '==', 'moms-made-united'),
      where('published', '==', true)
    );
    const unsub = onSnapshot(q, (snap) => {
      const rows: MomsProductDoc[] = snap.docs.map((d) => {
        const data = d.data() as any;
        const images: string[] = Array.isArray(data.images)
          ? data.images
          : Array.isArray(data.imageUrls)
          ? data.imageUrls
          : data.imageUrl
          ? [data.imageUrl]
          : [];
        return {
          id: d.id,
          title: data.name || 'Untitled',
          description: data.description,
          // keep legacy price and also surface sellerPrice/finalPrice

          price: typeof data.price === 'number' ? data.price : Number(data.price || 0),
          imageUrl: data.imageUrl,
          images,
          badge: data.badge,
          rating: data.rating,
          reviews: data.reviews,
          sellerPrice: typeof data.sellerPrice === 'number' ? data.sellerPrice : (data.sellerPrice != null ? Number(data.sellerPrice) : undefined),
          finalPrice: typeof data.finalPrice === 'number' ? data.finalPrice : (data.finalPrice != null ? Number(data.finalPrice) : undefined),
          customizable: !!data.customizable,
        };
      });
      setProducts(rows);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const filteredProducts = useMemo(() => {
    const getDisplayPrice = (p: MomsProductDoc) => (p.finalPrice ?? p.sellerPrice ?? p.price ?? 0) as number;
    // Filter by search and type (badge)
    let result = products.filter((p) => {
      const matchesSearch =
        !searchQuery ||
        (p.title || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (p.description || '').toLowerCase().includes(searchQuery.toLowerCase());
      const matchesBadge = selectedBadge === 'all' || (p.badge && p.badge === selectedBadge);
      return matchesSearch && matchesBadge;
    });

    // Price Range filter (₹)
    result = result.filter((p) => {
      const price = getDisplayPrice(p);
      switch (priceFilter) {
        case 'under25':
          return price < 25;
        case '25-50':
          return price >= 25 && price <= 50;
        case '50-100':
          return price >= 50 && price <= 100;
        case 'over100':
          return price > 100;
        default:
          return true;
      }
    });

    // Sorting
    result.sort((a, b) => {
      const priceA = getDisplayPrice(a);
      const priceB = getDisplayPrice(b);
      if (sortBy === 'price-asc') return priceA - priceB;
      if (sortBy === 'price-desc') return priceB - priceA;
      if (sortBy === 'impact') {
        const baseA = (a.sellerPrice ?? a.price ?? 0) as number;
        const baseB = (b.sellerPrice ?? b.price ?? 0) as number;
        const percA = baseA > 0 && a.finalPrice != null ? ((a.finalPrice - baseA) / baseA) * 100 : 0;
        const percB = baseB > 0 && b.finalPrice != null ? ((b.finalPrice - baseB) / baseB) * 100 : 0;
        const { charityAmount: charityA } = calculateUplift(baseA, percA);
        const { charityAmount: charityB } = calculateUplift(baseB, percB);
        return charityB - charityA;
      }
      if (sortBy === 'popular') {
        const popA = (typeof a.reviews === 'number' ? a.reviews : 0);
        const popB = (typeof b.reviews === 'number' ? b.reviews : 0);
        return popB - popA;
      }
      return 0; // newest: keep Firestore order
    });

    return result;
  }, [products, searchQuery, selectedBadge, priceFilter, sortBy]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-12"
    >
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Moms Made <span className="text-gold">United</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover heartfelt creations by moms—handcrafted goods, homemade treats, and eco-friendly essentials.
          </p>
        </div>

        {/* Search + Controls */}
        <div className="mb-8">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between mb-6">
            {/* Search Bar */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 pl-10"
              />
            </div>

            {/* Filters + View */}
            <div className="flex items-center gap-2">
              <div className="relative">
                <Button
                  type="button"
                  onClick={() => setShowFilters((s) => !s)}
                  size="sm"
                  className="flex items-center gap-2"
                >
                  <SlidersHorizontal className="h-4 w-4" />
                  Filters
                </Button>
                {showFilters && (
                  <div className="absolute top-12 right-0 z-40 w-80 sm:w-[28rem] bg-background border border-border rounded-md shadow-lg p-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Price Range</label>
                      <div className="space-y-2">
                        <button className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === 'all' ? 'bg-gold text-black' : 'hover:bg-muted'}`} onClick={() => setPriceFilter('all')}>All Prices</button>
                        <button className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === 'under25' ? 'bg-gold text-black' : 'hover:bg-muted'}`} onClick={() => setPriceFilter('under25')}>Under ₹25</button>
                        <button className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === '25-50' ? 'bg-gold text-black' : 'hover:bg-muted'}`} onClick={() => setPriceFilter('25-50')}>₹25 - ₹50</button>
                        <button className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === '50-100' ? 'bg-gold text-black' : 'hover:bg-muted'}`} onClick={() => setPriceFilter('50-100')}>₹50 - ₹100</button>
                        <button className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === 'over100' ? 'bg-gold text-black' : 'hover:bg-muted'}`} onClick={() => setPriceFilter('over100')}>Over ₹100</button>
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">Sort By</label>
                      <div className="space-y-2">
                        <button className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'newest' ? 'bg-gold text-black' : 'hover:bg-muted'}`} onClick={() => setSortBy('newest')}>Newest First</button>
                        <button className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'price-asc' ? 'bg-gold text-black' : 'hover:bg-muted'}`} onClick={() => setSortBy('price-asc')}>Price: Low to High</button>
                        <button className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'price-desc' ? 'bg-gold text-black' : 'hover:bg-muted'}`} onClick={() => setSortBy('price-desc')}>Price: High to Low</button>
                        <button className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'impact' ? 'bg-gold text-black' : 'hover:bg-muted'}`} onClick={() => setSortBy('impact')}>Highest Impact</button>
                        <button className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'popular' ? 'bg-gold text-black' : 'hover:bg-muted'}`} onClick={() => setSortBy('popular')}>Most Popular</button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="border rounded-md flex">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Grid2X2 className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Active filters */}
          <div className="flex flex-wrap gap-2">
            {selectedBadge !== 'all' && (
              <Badge variant="secondary" className="gap-1">
                {selectedBadge}
                <button onClick={() => setSelectedBadge('all')}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            {priceFilter !== 'all' && (
              <Badge variant="secondary" className="gap-1">
                {priceFilter === 'under25' ? 'Under ₹25' : priceFilter === '25-50' ? '₹25 - ₹50' : priceFilter === '50-100' ? '₹50 - ₹100' : 'Over ₹100'}
                <button onClick={() => setPriceFilter('all')}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            {searchQuery && (
              <Badge variant="secondary" className="gap-1">
                "{searchQuery}"
                <button onClick={() => setSearchQuery('')}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
          </div>
        </div>

        {/* Results Count */}
        <div className="flex justify-between items-center text-sm text-muted-foreground mb-6">
          <p>{filteredProducts.length} products found</p>
          <p>Sorted by {sortBy === 'newest' ? 'Newest First' : sortBy === 'price-asc' ? 'Price: Low to High' : sortBy === 'price-desc' ? 'Price: High to Low' : sortBy === 'impact' ? 'Highest Impact' : 'Most Popular'}</p>
        </div>

        {/* Loading / Product Grid/List */}
        {loading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading products…</p>
          </div>
        ) : (
          <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4' : 'grid-cols-1'} gap-6`}>
            {filteredProducts.map((product) => (
              <Card
                key={product.id}
                className="overflow-hidden group cursor-pointer focus:outline-none focus:ring-2 focus:ring-gold h-full flex flex-col"
                role="button"
                tabIndex={0}
                onClick={() => navigate(`/product/${product.id}`)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    navigate(`/product/${product.id}`);
                  }
                }}
              >
                <div className="relative h-48 w-full overflow-hidden bg-gray-100">
                  <ProductImageCarousel
                    images={product.images && product.images.length ? product.images : (product.imageUrl ? [product.imageUrl] : [])}
                    alt={product.title}
                    className="w-full h-full object-cover"
                    aspect="free"
                  />
                  {product.badge && (
                    <Badge className="absolute top-2 left-2 bg-gold text-black text-xs">{product.badge}</Badge>
                  )}
                  {product.customizable && (
                    <Badge className="absolute top-2 left-2 translate-y-7 bg-emerald-500/90 text-white text-[10px]">Customizable</Badge>
                  )}
                  <Button
                    size="icon"
                    variant="ghost"
                    className="absolute top-2 right-2 bg-black/50 hover:bg-black/70 text-white h-8 w-8 rounded-full"
                    onClick={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      toggleWishlist(product.id);
                    }}
                    aria-pressed={isWishlisted(product.id)}
                    aria-label={isWishlisted(product.id) ? 'Remove from wishlist' : 'Add to wishlist'}
                  >
                    <Heart className={`h-4 w-4 ${isWishlisted(product.id) ? 'fill-red-500' : ''}`} />
                  </Button>
                </div>
                <CardContent className="p-3 flex-1 flex flex-col">
                  <h3 className="text-base font-medium mb-1 line-clamp-2">{product.title}</h3>
                  {product.description && (
                    <p className="text-xs text-muted-foreground mb-3 line-clamp-2 flex-1">{product.description}</p>
                  )}
                  {/* Ratings pill above price row */}
                  <div className="mb-2">
                    <RatingPill productId={product.id} docData={product as any} />
                  </div>
                  <div className="flex items-center justify-between mt-auto">
                    <span className="text-base font-bold">
                      {product.price > 0 ? formatCurrency(product.price) : 'Price on request'}
                    </span>
                    {product.price > 0 && (
                      <Button
                        className="bg-gold hover:bg-amber-500 text-black border border-amber-300 rounded-md px-3 py-1.5 h-8 text-sm font-medium transition-colors shadow-sm hover:shadow flex items-center gap-1.5 whitespace-nowrap"
                        onClick={(e) => {
                          e.stopPropagation();
                          e.preventDefault();
                          const price = Number(product.price ?? 0);
                          const cartProduct = {
                            id: product.id,
                            name: product.title,
                            price,
                            imageUrl: (product.images?.[0] || product.imageUrl || '/images/placeholder-item.jpg'),
                            category: 'moms-made-united',
                          };
                          runOrLogin(() => {
                            addToCart(cartProduct);
                          });
                        }}
                      >
                        <ShoppingCart className="h-3.5 w-3.5" />
                        <span>Add to Cart</span>
                      </Button>
                    )}
                  </div>
                  {product.price <= 0 && (
                    <Button
                      className="w-full mt-3 bg-gold hover:bg-amber-500 text-black h-9"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/product/${product.id}`);
                      }}
                    >
                      View Details
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {!loading && filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No products found. Adjust filters or search.</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}

export default MomsMadeUnitedPage;
