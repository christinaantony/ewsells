import { useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Search, HeartHandshake, Loader2, CheckCircle, XCircle } from 'lucide-react';
import { auth, db } from '@/lib/firebase';
import { collection, doc, getDoc, getDocs, orderBy, query, serverTimestamp, updateDoc } from 'firebase/firestore';
import { useToast } from '@/components/ui/toast-context';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';

export default function AdminHelpingHandsPage() {
  const [loading, setLoading] = useState(true);
  const [requests, setRequests] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [statusTab, setStatusTab] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const { showToast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [adminChecked, setAdminChecked] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [approveOpen, setApproveOpen] = useState(false);
  const [approveTarget, setApproveTarget] = useState<any | null>(null);
  const [approveAmount, setApproveAmount] = useState('');
  const [certOpen, setCertOpen] = useState(false);
  const [certUrl, setCertUrl] = useState<string | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [detailsTarget, setDetailsTarget] = useState<any | null>(null);
  const [bankOpen, setBankOpen] = useState(false);
  const [bankTarget, setBankTarget] = useState<any | null>(null);
  const [mediaOpen, setMediaOpen] = useState(false);
  const [mediaTarget, setMediaTarget] = useState<any | null>(null);
  // Sorting state for requests list
  const [sortBy, setSortBy] = useState<'name_asc' | 'name_desc' | 'created_desc' | 'created_asc' | 'amount_desc' | 'amount_asc'>('name_asc');
  const [sortOpen, setSortOpen] = useState<boolean>(false);
  const detailsScrollRef = useRef<HTMLDivElement>(null);
  const handleDetailsWheel: React.WheelEventHandler<HTMLDivElement> = (e) => {
    const el = detailsScrollRef.current;
    if (!el) return;
    el.scrollTop += e.deltaY;
    e.preventDefault();
    e.stopPropagation();
  };
  // client-side pagination
  const [pageIndex, setPageIndex] = useState<number>(0);
  const pageSize = 12;

  // Verify admin
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const currentUser = auth.currentUser;
        if (!currentUser) {
          navigate('/admin-login');
          return;
        }
        const userRef = doc(db, 'users', currentUser.uid);
        const snap = await getDoc(userRef);
        if (!snap.exists() || snap.data()?.role !== 'admin') {
          try { await auth.signOut(); } catch {}
          navigate('/admin-login');
          return;
        }
        if (!cancelled) setAdminChecked(true);
      } catch (e) {
        console.error('Admin check failed in AdminHelpingHandsPage:', e);
        navigate('/admin-login');
      }
    })();
    return () => { cancelled = true; };
  }, [navigate]);

  // Accept initial tab from navigation state or query param
  useEffect(() => {
    const stateTab = (location.state as any)?.tab as 'all' | 'pending' | 'approved' | 'rejected' | undefined;
    const queryTab = new URLSearchParams(location.search).get('tab') as 'all' | 'pending' | 'approved' | 'rejected' | null;
    const desired = stateTab || queryTab || null;
    if (desired === 'all' || desired === 'pending' || desired === 'approved' || desired === 'rejected') {
      setStatusTab(desired as any);
    }
    // run once on mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // reset pagination when tab, search, or sort changes
  useEffect(() => {
    setPageIndex(0);
  }, [statusTab, search, sortBy]);

  // Load requests
  useEffect(() => {
    if (!adminChecked) return;
    let cancelled = false;
    (async () => {
      try {
        setLoading(true);
        const q = query(collection(db, 'helping-hands-requests'), orderBy('createdAt', 'desc'));
        const snap = await getDocs(q);
        if (cancelled) return;
        setRequests(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      } catch (e) {
        console.error('Failed to load helping hands requests:', e);
        showToast({ message: 'Failed to load requests', type: 'error' });
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [adminChecked, showToast]);

  const norm = (s: string) => (s || '').toLowerCase();
  const matches = (r: any) => {
    if (!search) return true;
    const s = norm(search);
    return (
      norm(r.fullName).includes(s) ||
      norm(r.email).includes(s) ||
      norm(r.phone).includes(s) ||
      norm(r.id).includes(s) ||
      norm(r.uid).includes(s) ||
      norm(r.requestId).includes(s) ||
      norm(r.address).includes(s) ||
      norm(r?.medical?.condition || '').includes(s)
    );
  };

  const byStatus = (r: any) => statusTab === 'all' ? true : (r.status || 'pending') === statusTab;

  const visible = requests.filter(byStatus).filter(matches);
  // Sorting helpers
  const getCreatedAtMs = (x: any): number => {
    try {
      const c = x?.createdAt;
      if (!c) return 0;
      if (typeof c?.toDate === 'function') return c.toDate().getTime();
      const t = new Date(c).getTime();
      return isNaN(t) ? 0 : t;
    } catch {
      return 0;
    }
  };
  const compareRequest = (a: any, b: any) => {
    const an = (a.fullName || '').toString().toLowerCase();
    const bn = (b.fullName || '').toString().toLowerCase();
    const aCreated = getCreatedAtMs(a);
    const bCreated = getCreatedAtMs(b);
    const aAmt = typeof a.amountGiven === 'number' ? a.amountGiven : -Infinity;
    const bAmt = typeof b.amountGiven === 'number' ? b.amountGiven : -Infinity;
    switch (sortBy) {
      case 'name_asc':
        return an.localeCompare(bn);
      case 'name_desc':
        return bn.localeCompare(an);
      case 'created_desc':
        return bCreated - aCreated || an.localeCompare(bn);
      case 'created_asc':
        return aCreated - bCreated || an.localeCompare(bn);
      case 'amount_desc':
        return (isFinite(bAmt) ? bAmt : -Infinity) - (isFinite(aAmt) ? aAmt : -Infinity) || an.localeCompare(bn);
      case 'amount_asc':
        return (isFinite(aAmt) ? aAmt : Infinity) - (isFinite(bAmt) ? bAmt : Infinity) || an.localeCompare(bn);
      default:
        return 0;
    }
  };
  const sortedVisible = [...visible].sort(compareRequest);
  const pageTotal = Math.max(1, Math.ceil(sortedVisible.length / pageSize));
  const pageRows = sortedVisible.slice(pageIndex * pageSize, pageIndex * pageSize + pageSize);

  const counts = {
    all: requests.length,
    pending: requests.filter(r => (r.status || 'pending') === 'pending').length,
    approved: requests.filter(r => r.status === 'approved').length,
    rejected: requests.filter(r => r.status === 'rejected').length,
  };

  const updateStatus = async (r: any, next: 'approved' | 'rejected', withAmount?: number) => {
    try {
      setBusyId(r.id);
      const payload: any = { status: next, updatedAt: serverTimestamp() };
      if (typeof withAmount === 'number' && !Number.isNaN(withAmount)) {
        payload.amountGiven = withAmount;
      }
      await updateDoc(doc(db, 'helping-hands-requests', r.id), payload);
      setRequests(prev => prev.map(x => x.id === r.id ? { ...x, status: next } : x));
      showToast({ message: `Marked as ${next}`, type: 'success' });
    } catch (e) {
      console.error('Failed to update status', e);
      showToast({ message: 'Failed to update status', type: 'error' });
    } finally {
      setBusyId(null);
    }
  };

  const beginApprove = (r: any) => {
    setApproveTarget(r);
    setApproveAmount('');
    setApproveOpen(true);
  };

  const confirmApprove = async () => {
    if (!approveTarget) return;
    const amt = Number(approveAmount);
    if (!Number.isFinite(amt) || amt < 0) {
      showToast({ message: 'Enter a valid non-negative amount', type: 'error' });
      return;
    }
    await updateStatus(approveTarget, 'approved', amt);
    setApproveOpen(false);
  };

  const isPdf = (url: string) => /\.pdf($|\?)/i.test(url);

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 mb-4">
        <div>
          <h1 className="text-3xl font-bold mb-1">Helping Hand Requests</h1>
          <p className="text-muted-foreground">Review and manage assistance requests submitted by users</p>
        </div>
        {/* Sort By aligned to right of title */}
        <div className="relative">
          <Button
            type="button"
            variant="outline"
            className="btn-hover h-10 px-4 py-2"
            aria-haspopup="listbox"
            aria-expanded={sortOpen}
            onClick={() => setSortOpen(o => !o)}
            onBlur={(e) => { if (!e.currentTarget.parentElement?.contains(e.relatedTarget as Node)) setSortOpen(false); }}
          >
            Sort By
          </Button>
          {sortOpen && (
            <div className="absolute right-0 mt-2 z-10 w-44 rounded-md border border-border/60 bg-background shadow-lg py-1">
              <ul role="listbox" aria-label="Sort by" className="max-h-64 overflow-auto text-sm">
                <li><button type="button" role="option" aria-selected={sortBy==='name_asc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='name_asc'?'font-medium':''}`} onClick={() => { setSortBy('name_asc'); setSortOpen(false); }} autoFocus>Name A → Z</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='name_desc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='name_desc'?'font-medium':''}`} onClick={() => { setSortBy('name_desc'); setSortOpen(false); }}>Name Z → A</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='created_desc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='created_desc'?'font-medium':''}`} onClick={() => { setSortBy('created_desc'); setSortOpen(false); }}>Newest</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='created_asc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='created_asc'?'font-medium':''}`} onClick={() => { setSortBy('created_asc'); setSortOpen(false); }}>Oldest</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='amount_desc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='amount_desc'?'font-medium':''}`} onClick={() => { setSortBy('amount_desc'); setSortOpen(false); }}>Amount: High → Low</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='amount_asc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='amount_asc'?'font-medium':''}`} onClick={() => { setSortBy('amount_asc'); setSortOpen(false); }}>Amount: Low → High</button></li>
              </ul>
            </div>
          )}
        </div>
      </div>

      { !adminChecked ? (
        <div className="flex items-center gap-2 text-muted-foreground py-10"><Loader2 className="h-5 w-5 animate-spin"/>Verifying admin…</div>
      ) : (
        <>
          {/* Tabs + Search + Sort */}
          <div className="mb-4 flex flex-col md:flex-row md:items-center gap-3">
            <div className="flex items-center gap-2">
              <Button
                variant={statusTab === 'pending' ? 'default' : 'ghost'}
                className={statusTab === 'pending' ? 'bg-gold text-black hover:bg-gold/90' : ''}
                onClick={() => setStatusTab('pending')}
              >
                <span>Pending</span>
                <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${statusTab === 'pending' ? 'bg-black/20 text-black' : 'bg-gold/20 text-gold'}`}>{counts.pending}</span>
              </Button>
              <Button
                variant={statusTab === 'approved' ? 'default' : 'ghost'}
                className={statusTab === 'approved' ? 'bg-gold text-black hover:bg-gold/90' : ''}
                onClick={() => setStatusTab('approved')}
              >
                <span>Approved</span>
                <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${statusTab === 'approved' ? 'bg-black/20 text-black' : 'bg-gold/20 text-gold'}`}>{counts.approved}</span>
              </Button>
              <Button
                variant={statusTab === 'rejected' ? 'default' : 'ghost'}
                className={statusTab === 'rejected' ? 'bg-gold text-black hover:bg-gold/90' : ''}
                onClick={() => setStatusTab('rejected')}
              >
                <span>Rejected</span>
                <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${statusTab === 'rejected' ? 'bg-black/20 text-black' : 'bg-gold/20 text-gold'}`}>{counts.rejected}</span>
              </Button>
              <Button
                variant={statusTab === 'all' ? 'default' : 'ghost'}
                className={statusTab === 'all' ? 'bg-gold text-black hover:bg-gold/90' : ''}
                onClick={() => setStatusTab('all')}
              >
                <span>All</span>
                <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${statusTab === 'all' ? 'bg-black/20 text-black' : 'bg-gold/20 text-gold'}`}>
                  {counts.all}
                </span>
              </Button>
            </div>
            <div className="relative w-full max-w-sm md:ml-auto">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name, email, phone, or id…"
                className="w-full pl-8 pr-3 py-2 rounded-md bg-muted/40 outline-none border border-border/60 focus:border-gold"
              />
            </div>
            <Button
              variant="outline"
              className="rounded-full"
              onClick={() => {
                const header = ['Full Name','Email','Phone','Status','Amount Given','Created At','UID','Request ID','Address','Medical Condition','Bank UPI'];
                const rows = visible.map((r: any) => [
                  r.fullName || '',
                  r.email || '',
                  r.phone || '',
                  r.status || 'pending',
                  typeof r.amountGiven === 'number' ? String(r.amountGiven) : '',
                  r.createdAt?.toDate ? r.createdAt.toDate().toISOString() : (r.createdAt || ''),
                  r.uid || '',
                  r.requestId || '',
                  r.address || '',
                  (r?.medical?.condition || ''),
                  (r?.bank?.upiId || ''),
                ]);
                const csv = [header, ...rows]
                  .map(row => row.map(v => '"' + String(v).replace(/"/g,'""') + '"').join(','))
                  .join('\n');
                const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `helping-hands-${new Date().toISOString().slice(0,10)}.csv`;
                a.click();
                URL.revokeObjectURL(url);
              }}
            >
              Export CSV
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><HeartHandshake className="h-5 w-5"/>Requests</CardTitle>
              <CardDescription>Incoming and processed requests</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center gap-2 text-muted-foreground py-10"><Loader2 className="h-5 w-5 animate-spin"/>Loading…</div>
              ) : visible.length === 0 ? (
                <div className="text-muted-foreground">No requests found.</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full text-sm">
                    <thead className="text-left text-muted-foreground">
                      <tr>
                        <th className="py-2 pr-4">Applicant</th>
                        <th className="py-2 pr-4">Contact</th>
                        <th className="py-2 pr-4">Bank</th>
                        <th className="py-2 pr-4">Medical</th>
                        <th className="py-2 pr-4">Media</th>
                        <th className="py-2 pr-4">Status</th>
                        <th className="py-2 pr-4">Created</th>
                        <th className="py-2 pr-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pageRows.map((r) => (
                        <tr key={r.id} className="border-t border-border/60 align-top">
                          <td className="py-2 pr-4 max-w-xs">
                            <div className="font-medium truncate" title={r.fullName || ''}>{r.fullName || '-'}</div>
                            <div className="text-[10px] text-muted-foreground font-mono break-all">{r.uid || r.id || '-'}</div>
                          </td>
                          <td className="py-2 pr-4 break-all">
                            <div>{r.phone || '-'}</div>
                            <div className="text-xs text-muted-foreground break-all">{r.email || ''}</div>
                          </td>
                          <td className="py-2 pr-4">
                            <Button size="sm" variant="outline" className="rounded-full" onClick={() => { setBankTarget(r); setBankOpen(true); }}>View</Button>
                          </td>
                          <td className="py-2 pr-4 max-w-sm">
                            <div className="text-xs whitespace-pre-wrap line-clamp-2" title={r?.medical?.condition || ''}>
                              {r?.medical?.condition || '-'}
                            </div>
                            {r.certificateUrl || r?.medical?.certificateUrl ? (
                              <button className="text-xs text-gold underline" onClick={(e) => { e.preventDefault(); const url = r.certificateUrl || r?.medical?.certificateUrl; if (url) window.open(url, '_blank', 'noopener'); }}>View certificate</button>
                            ) : null}
                          </td>
                          <td className="py-2 pr-4">
                            {(r.photoUrl || r.identityProofUrl) ? (
                              <Button size="sm" variant="outline" className="rounded-full" onClick={() => { setMediaTarget(r); setMediaOpen(true); }}>View</Button>
                            ) : '-'}
                          </td>
                          <td className="py-2 pr-4 capitalize">{String(r?.status || 'pending').toLowerCase()} {typeof r.amountGiven === 'number' ? `(₹ ${r.amountGiven})` : ''}</td>
                          <td className="py-2 pr-4">{r.createdAt?.toDate ? r.createdAt.toDate().toLocaleString() : (r.createdAt || '-')}</td>
                          <td className="py-2 pr-4">
                            <div className="flex items-center gap-2 flex-wrap">
                              <Button size="sm" className="bg-gold text-black hover:bg-gold/90 rounded-full" disabled={busyId === r.id || (r.status || 'pending') === 'approved'} onClick={() => beginApprove(r)}>
                                <CheckCircle className="h-4 w-4 mr-1"/>
                                Approve
                              </Button>
                              <Button size="sm" variant="destructive" disabled={busyId === r.id || r.status === 'rejected'} className={`rounded-full ${r.status === 'rejected' ? 'ring-2 ring-destructive/60' : ''}`} onClick={() => updateStatus(r, 'rejected')}>
                                <XCircle className="h-4 w-4 mr-1"/>
                                Reject
                              </Button>
                              <Button size="sm" variant="outline" className="rounded-full" onClick={() => { setDetailsTarget(r); setDetailsOpen(true); }}>
                                View Full Details
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <div className="mt-4 flex items-center justify-between">
                    <Button type="button" variant="outline" disabled={pageIndex <= 0} onClick={() => setPageIndex(i => Math.max(0, i - 1))}>Previous</Button>
                    <div className="text-sm text-muted-foreground">Page {pageIndex + 1} of {pageTotal}</div>
                    <Button type="button" variant="outline" disabled={(pageIndex + 1) >= pageTotal} onClick={() => setPageIndex(i => i + 1)}>Next</Button>
                  </div>
                </div>
              )}
            </CardContent>
        </Card>

        {/* Approve with amount dialog */}
        <Dialog open={approveOpen} onOpenChange={setApproveOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Approve request</DialogTitle>
              <DialogDescription>
                Enter the amount to grant for {approveTarget?.fullName || 'this request'}.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-2">
              <label className="text-sm text-muted-foreground" htmlFor="approve-amount">Amount Given (₹)</label>
              <Input
                id="approve-amount"
                type="number"
                min="0"
                step="0.01"
                value={approveAmount}
                onChange={(e) => setApproveAmount(e.target.value)}
                placeholder="e.g. 1500"
              />
            </div>
            <DialogFooter className="mt-4">
              <Button variant="ghost" onClick={() => setApproveOpen(false)}>Cancel</Button>
              <Button disabled={busyId === approveTarget?.id} onClick={confirmApprove}>
                {busyId === approveTarget?.id ? (<><Loader2 className="h-4 w-4 mr-1 animate-spin"/>Saving…</>) : 'Confirm Approve'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

       

        {/* Bank Dialog */}
        <Dialog open={bankOpen} onOpenChange={setBankOpen}>
          <DialogContent className="max-w-xl">
            <DialogHeader>
              <DialogTitle>Bank Details</DialogTitle>
              <DialogDescription>Provided for assistance disbursal.</DialogDescription>
            </DialogHeader>
            {bankTarget && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <div className="text-muted-foreground">Account Holder</div>
                  <div>{bankTarget?.bank?.accountName || '-'}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Account Number</div>
                  <div className="font-mono break-all">{bankTarget?.bank?.accountNumber || '-'}</div>
                </div>
                
                <div>
                  <div className="text-muted-foreground">IFSC / SWIFT</div>
                  <div className="font-mono break-all">{bankTarget?.bank?.ifsc || '-'}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">Bank Name</div>
                  <div>{bankTarget?.bank?.bankName || '-'}</div>
                </div>
                <div className="md:col-span-2">
                  <div className="text-muted-foreground">Branch</div>
                  <div>{bankTarget?.bank?.branch || '-'}</div>
                </div>
                <div>
                  <div className="text-muted-foreground">UPI ID</div>
                  <div className="font-mono break-all">{bankTarget?.bank?.upiId || '-'}</div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Media Dialog (Photo + Identity Proof) */}
        <Dialog open={mediaOpen} onOpenChange={(o) => { setMediaOpen(o); if (!o) setMediaTarget(null); }}>
          <DialogContent className="sm:max-w-[70vw] max-w-[95vw] w-[70vw] max-h-[80vh] p-4 overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Media</DialogTitle>
              <DialogDescription>View the uploaded photo and identity proof.</DialogDescription>
            </DialogHeader>
            {mediaTarget && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border border-border/60 rounded-md p-3 bg-muted/20">
                  <div className="mb-2 flex items-center justify-between">
                    <div className="font-medium">User Photo</div>
                    {mediaTarget.photoUrl ? (
                      <Button size="sm" variant="outline" onClick={() => window.open(mediaTarget.photoUrl, '_blank', 'noopener')}>Open</Button>
                    ) : null}
                  </div>
                  {mediaTarget.photoUrl ? (
                    <img src={mediaTarget.photoUrl} alt="User" className="w-full h-56 object-contain bg-black/5 rounded" />
                  ) : (
                    <div className="text-sm text-muted-foreground">No photo</div>
                  )}
                </div>
                <div className="border border-border/60 rounded-md p-3 bg-muted/20">
                  <div className="mb-2 flex items-center justify-between">
                    <div className="font-medium">Identity Proof</div>
                    {mediaTarget.identityProofUrl ? (
                      <Button size="sm" variant="outline" onClick={() => window.open(mediaTarget.identityProofUrl, '_blank', 'noopener')}>Open</Button>
                    ) : null}
                  </div>
                  {mediaTarget.identityProofUrl ? (
                    /\.pdf($|\?)/i.test(String(mediaTarget.identityProofUrl)) ? (
                      <div className="h-56 w-full">
                        <iframe src={`${mediaTarget.identityProofUrl}#toolbar=1&zoom=page-fit`} title="id-proof" className="h-full w-full" />
                      </div>
                    ) : (
                      <img src={mediaTarget.identityProofUrl} alt="Identity proof" className="w-full h-56 object-contain bg-black/5 rounded" />
                    )
                  ) : (
                    <div className="text-sm text-muted-foreground">No identity proof</div>
                  )}
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Full Details Dialog with export */}
        <Dialog open={detailsOpen} onOpenChange={(o) => { setDetailsOpen(o); if (!o) setDetailsTarget(null); }}>
          <DialogContent className="sm:max-w-[65vw] max-w-[95vw] w-[65vw] p-0">
            <DialogHeader>
              <DialogTitle>Full Details</DialogTitle>
              <DialogDescription>All submitted fields for this request.</DialogDescription>
            </DialogHeader>
            {detailsTarget && (
              <div ref={detailsScrollRef} onWheel={handleDetailsWheel} className="px-4 pb-4 max-h-[70vh] overflow-y-auto space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="border border-border/60 rounded-md p-3 bg-muted/20">
                    <div className="text-xs text-muted-foreground">Full Name</div>
                    <div className="font-medium">{detailsTarget.fullName || '-'}</div>
                  </div>
                  <div className="border border-border/60 rounded-md p-3 bg-muted/20">
                    <div className="text-xs text-muted-foreground">UID</div>
                    <div className="font-mono break-all">{detailsTarget.uid || '-'}</div>
                  </div>
                  <div className="border border-border/60 rounded-md p-3 bg-muted/20">
                    <div className="text-xs text-muted-foreground">Request ID</div>
                    <div className="font-mono break-all">{detailsTarget.requestId || '-'}</div>
                  </div>
                  <div className="border border-border/60 rounded-md p-3 bg-muted/20">
                    <div className="text-xs text-muted-foreground">Email</div>
                    <div className="break-all">{detailsTarget.email || '-'}</div>
                  </div>
                  <div className="border border-border/60 rounded-md p-3 bg-muted/20">
                    <div className="text-xs text-muted-foreground">Phone</div>
                    <div className="break-all">{detailsTarget.phone || '-'}</div>
                  </div>
                  <div className="border border-border/60 rounded-md p-3 bg-muted/20 md:col-span-2">
                    <div className="text-xs text-muted-foreground">Address</div>
                    <div className="break-words">{detailsTarget.address || '-'}</div>
                  </div>
                  <div className="border border-border/60 rounded-md p-3 bg-muted/20">
                    <div className="text-xs text-muted-foreground">DOB</div>
                    <div>{detailsTarget.dob || '-'}</div>
                  </div>
                  <div className="border border-border/60 rounded-md p-3 bg-muted/20">
                    <div className="text-xs text-muted-foreground">Gender</div>
                    <div>{detailsTarget.gender || '-'}</div>
                  </div>
                  <div className="border border-border/60 rounded-md p-3 bg-muted/20 md:col-span-2">
                    <div className="text-xs text-muted-foreground">Medical Condition</div>
                    <div className="whitespace-pre-wrap">{detailsTarget?.medical?.condition || '-'}</div>
                  </div>

                  {/* Files (Photo, Identity Proof, Certificate) */}
                  <div className="border border-border/60 rounded-md p-3 bg-muted/20 md:col-span-2">
                    <div className="font-medium mb-2">Files</div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      {/* Photo */}
                      <div className="border border-border/60 rounded p-2">
                        <div className="mb-2 flex items-center justify-between">
                          <div className="text-sm">User Photo</div>
                          {detailsTarget.photoUrl ? (
                            <Button size="sm" variant="outline" onClick={() => window.open(detailsTarget.photoUrl, '_blank', 'noopener')}>Open</Button>
                          ) : null}
                        </div>
                        {detailsTarget.photoUrl ? (
                          <img src={detailsTarget.photoUrl} alt="User" className="w-full h-40 object-contain bg-black/5 rounded" />
                        ) : (
                          <div className="text-xs text-muted-foreground">No photo</div>
                        )}
                      </div>

                      {/* Identity Proof */}
                      <div className="border border-border/60 rounded p-2">
                        <div className="mb-2 flex items-center justify-between">
                          <div className="text-sm">Identity Proof</div>
                          {detailsTarget.identityProofUrl ? (
                            <Button size="sm" variant="outline" onClick={() => window.open(detailsTarget.identityProofUrl, '_blank', 'noopener')}>Open</Button>
                          ) : null}
                        </div>
                        {detailsTarget.identityProofUrl ? (
                          /\.pdf($|\?)/i.test(String(detailsTarget.identityProofUrl)) ? (
                            <div className="h-40 w-full">
                              <iframe src={`${detailsTarget.identityProofUrl}#toolbar=1&zoom=page-fit`} title="id-proof" className="h-full w-full" />
                            </div>
                          ) : (
                            <img src={detailsTarget.identityProofUrl} alt="Identity" className="w-full h-40 object-contain bg-black/5 rounded" />
                          )
                        ) : (
                          <div className="text-xs text-muted-foreground">No identity proof</div>
                        )}
                      </div>

                      {/* Medical Certificate */}
                      <div className="border border-border/60 rounded p-2">
                        <div className="mb-2 flex items-center justify-between">
                          <div className="text-sm">Medical Certificate</div>
                          {detailsTarget?.medical?.certificateUrl ? (
                            <Button size="sm" variant="outline" onClick={() => window.open(detailsTarget.medical.certificateUrl, '_blank', 'noopener')}>Open</Button>
                          ) : null}
                        </div>
                        {detailsTarget?.medical?.certificateUrl ? (
                          /\.pdf($|\?)/i.test(String(detailsTarget.medical.certificateUrl)) ? (
                            <div className="h-40 w-full">
                              <iframe src={`${detailsTarget.medical.certificateUrl}#toolbar=1&zoom=page-fit`} title="certificate" className="h-full w-full" />
                            </div>
                          ) : (
                            <img src={detailsTarget.medical.certificateUrl} alt="Certificate" className="w-full h-40 object-contain bg-black/5 rounded" />
                          )
                        ) : (
                          <div className="text-xs text-muted-foreground">No certificate</div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Bank details section */}
                  <div className="border border-border/60 rounded-md p-3 bg-muted/20 md:col-span-2">
                    <div className="font-medium mb-2">Bank Details</div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                      <div><div className="text-xs text-muted-foreground">Account Holder</div><div>{detailsTarget?.bank?.accountName || '-'}</div></div>
                      <div><div className="text-xs text-muted-foreground">Account Number</div><div className="font-mono break-all">{detailsTarget?.bank?.accountNumber || '-'}</div></div>
                      <div><div className="text-xs text-muted-foreground">IFSC / SWIFT</div><div className="font-mono break-all">{detailsTarget?.bank?.ifsc || '-'}</div></div>
                      <div><div className="text-xs text-muted-foreground">Bank Name</div><div>{detailsTarget?.bank?.bankName || '-'}</div></div>
                      <div className="md:col-span-2"><div className="text-xs text-muted-foreground">Branch</div><div>{detailsTarget?.bank?.branch || '-'}</div></div>
                    </div>
                  </div>

                  <div className="border border-border/60 rounded-md p-3 bg-muted/20">
                    <div className="text-xs text-muted-foreground">Status</div>
                    <div className="capitalize">{String(detailsTarget?.status || 'pending').toLowerCase()}</div>
                  </div>
                  <div className="border border-border/60 rounded-md p-3 bg-muted/20">
                    <div className="text-xs text-muted-foreground">Amount Given</div>
                    <div>{typeof detailsTarget.amountGiven === 'number' ? `₹ ${detailsTarget.amountGiven}` : '-'}</div>
                  </div>
                  <div className="border border-border/60 rounded-md p-3 bg-muted/20 md:col-span-2">
                    <div className="text-xs text-muted-foreground">Created</div>
                    <div>{detailsTarget.createdAt?.toDate ? detailsTarget.createdAt.toDate().toLocaleString() : (detailsTarget.createdAt || '-')}</div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Button size="sm" variant="outline" onClick={() => {
                    const o = detailsTarget;
                    const csvRows: string[] = [];
                    const pushKV = (k: string, v: any) => csvRows.push(`"${k.replace(/"/g,'""')}" , "${String(v ?? '').replace(/"/g,'""')}"`);
                    pushKV('fullName', o.fullName);
                    pushKV('uid', o.uid);
                    pushKV('requestId', o.requestId);
                    pushKV('email', o.email);
                    pushKV('phone', o.phone);
                    pushKV('address', o.address);
                    pushKV('dob', o.dob);
                    pushKV('gender', o.gender);
                    pushKV('medical.condition', o?.medical?.condition);
                    pushKV('medical.certificateUrl', o?.medical?.certificateUrl);
                    pushKV('photoUrl', o.photoUrl);
                    pushKV('identityProofUrl', o.identityProofUrl);
                    // bank fields
                    pushKV('bank.accountName', o?.bank?.accountName);
                    pushKV('bank.accountNumber', o?.bank?.accountNumber);
                    pushKV('bank.upiId', o?.bank?.upiId);
                    pushKV('bank.ifsc', o?.bank?.ifsc);
                    pushKV('bank.bankName', o?.bank?.bankName);
                    pushKV('bank.branch', o?.bank?.branch);
                    pushKV('status', o.status);
                    pushKV('amountGiven', o.amountGiven);
                    pushKV('createdAt', o.createdAt?.toDate ? o.createdAt.toDate().toISOString() : o.createdAt);
                    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url; a.download = `hh-request-${o.id || o.requestId || 'details'}.csv`; a.click(); URL.revokeObjectURL(url);
                  }}>Export CSV</Button>
                  <Button size="sm" variant="outline" onClick={() => {
                    const o = detailsTarget;
                    const json = JSON.stringify(o, (_k, v) => (v && typeof v.toDate === 'function') ? v.toDate().toISOString() : v, 2);
                    const blob = new Blob([json], { type: 'application/json;charset=utf-8;' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url; a.download = `hh-request-${o.id || o.requestId || 'details'}.json`; a.click(); URL.revokeObjectURL(url);
                  }}>Export JSON</Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Certificate Lightbox */}
        <Dialog open={certOpen} onOpenChange={(open) => { setCertOpen(open); if (!open) setCertUrl(null); }}>
          <DialogContent className="sm:max-w-[98vw] max-w-[98vw] w-[98vw] h-[95vh] p-0 overflow-hidden">
            <DialogHeader className="px-3 py-2 flex items-center justify-between gap-2">
              <DialogTitle className="text-sm">Certificate preview</DialogTitle>
              {certUrl ? (
                <div className="flex items-center gap-2">
                  <Button size="sm" variant="outline" onClick={() => window.open(certUrl!, '_blank', 'noopener')}>Open in new tab</Button>
                </div>
              ) : null}
            </DialogHeader>
            <div className="relative bg-black h-[calc(95vh-44px)] overflow-auto">
              {certUrl ? (
                isPdf(certUrl) ? (
                  <div className="h-full w-full">
                    <iframe
                      src={`${certUrl}#toolbar=1&zoom=page-fit`}
                      title="certificate-pdf"
                      className="h-full w-full"
                    />
                    {/* Fallback for browsers that block iframe rendering */}
                    <embed src={certUrl} type="application/pdf" className="h-full w-full" />
                  </div>
                ) : (
                  <img
                    src={certUrl}
                    alt="Medical certificate"
                    className="h-full w-full object-contain bg-black block"
                  />
                )
              ) : null}
            </div>
          </DialogContent>
        </Dialog>
      </>
    )}
  </div>
);
}
