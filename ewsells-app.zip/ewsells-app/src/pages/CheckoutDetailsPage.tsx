import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { db, auth } from '@/lib/firebase';
import { doc, getDoc, updateDoc, addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { useStore } from '@/store/useStore';
import { useCart } from '@/contexts/CartContext';
import { initiatePhonePePayment } from '@/services/phonepe';

interface AddressForm {
  fullName: string;
  phone: string;
  email: string;
  line1: string;
  city: string;
  state: string;
  pincode: string;
}

type Method = 'card' | 'upi' | 'cod';

export default function CheckoutDetailsPage() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const orderId = params.get('orderId') || '';
  const amount = Number(params.get('amount') || 0);
  const method = (params.get('method') as Method) || 'card';
  const addressId = params.get('addressId') || '';
  const showCardFields = useMemo(() => method === 'card', [method]);
  const showUpiFields = useMemo(() => method === 'upi', [method]);

  const { user } = useStore();
  const { clearCart, cartItems } = useCart();

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [form, setForm] = useState<AddressForm>({
    fullName: '',
    phone: '',
    email: '',
    line1: '',
    city: '',
    state: '',
    pincode: '',
  });
  const [addressLoaded, setAddressLoaded] = useState(false);
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState(''); // MM/YY
  const [cvv, setCvv] = useState('');
  const [upiPhone, setUpiPhone] = useState('');
  const [upiVpa, setUpiVpa] = useState(''); // e.g., name@bank
  const [successId, setSuccessId] = useState<string | null>(null);

  const [createdOrderId, setCreatedOrderId] = useState<string>('');

  useEffect(() => {
    // Try to prime contact fields from order or auth user (optional)
    (async () => {
      if (!orderId) return;
      try {
        const ref = doc(db, 'orders', orderId);
        const snap = await getDoc(ref);
        if (snap.exists()) {
          const data: any = snap.data();
          setForm((f) => ({
            ...f,
            fullName: data?.contact?.name || f.fullName,
            phone: data?.contact?.phone || f.phone,
            email: data?.contact?.email || f.email,
          }));
        }
      } catch (_) {}
    })();
  }, [orderId]);
  
  // Load address from addressId parameter
  useEffect(() => {
    const loadSelectedAddress = async () => {
      if (!addressId || !user?.addresses) return;
      
      // Find the address in user's saved addresses
      const selectedAddress = user.addresses.find(addr => addr.id === addressId);
      if (!selectedAddress) return;
      
      // Update form with the selected address
      setForm({
        fullName: selectedAddress.name,
        phone: selectedAddress.phoneNumber,
        email: user.email || '',
        line1: `${selectedAddress.addressLine1}${selectedAddress.addressLine2 ? ', ' + selectedAddress.addressLine2 : ''}`,
        city: selectedAddress.city,
        state: selectedAddress.state,
        pincode: selectedAddress.postalCode,
      });
      
      setAddressLoaded(true);
      toast({ 
        title: 'Address loaded', 
        description: 'Using your selected delivery address.' 
      });
    };
    
    loadSelectedAddress();
  }, [addressId, user?.addresses, user?.email]);

  const useProfileAddress = async () => {
    const uid = auth.currentUser?.uid;
    if (!uid) {
      toast({ title: 'Sign in required', description: 'Please sign in to pick your saved address.', variant: 'destructive' });
      navigate('/login');
      return;
    }
    try {
      const uref = doc(db, 'users', uid);
      const usnap = await getDoc(uref);
      const data: any = usnap.exists() ? usnap.data() : null;
      const addr = data?.shippingAddress || data?.address;
      if (!addr || !addr.line1 || !addr.city || !addr.state || !addr.pincode || !addr.phone || !addr.email || !addr.fullName) {
        toast({ title: 'No saved address', description: 'Add your delivery address in your profile first.', variant: 'destructive' });
        navigate('/profile');
        return;
      }
      setForm({
        fullName: addr.fullName,
        phone: addr.phone,
        email: addr.email,
        line1: addr.line1,
        city: addr.city,
        state: addr.state,
        pincode: addr.pincode,
      });
      setAddressLoaded(true);
      toast({ title: 'Address selected', description: 'Using your saved delivery address.' });
    } catch (e: any) {
      toast({ title: 'Failed to load address', description: e?.message || 'Could not load saved address', variant: 'destructive' });
    }
  };

  const validateAddress = () => {
    // Soft validation: prefer full address but don't block COD when absent
    const ok = !!(form.fullName && form.phone && form.email);
    if (!ok) {
      toast({ title: 'Contact details missing', description: 'We will place the order without a saved address. You may add it later in profile.' });
    }
    return true;
  };

  const validateCard = () => {
    const digits = cardNumber.replace(/\s+/g, '');
    if (digits.length < 12 || digits.length > 19) {
      toast({ title: 'Invalid card number', description: 'Please check your card number.', variant: 'destructive' });
      return false;
    }
    if (!/^\d{2}\/\d{2}$/.test(expiry)) {
      toast({ title: 'Invalid expiry', description: 'Use MM/YY format.', variant: 'destructive' });
      return false;
    }
    if (!/^\d{3,4}$/.test(cvv)) {
      toast({ title: 'Invalid CVV', description: 'CVV should be 3 or 4 digits.', variant: 'destructive' });
      return false;
    }
    return true;
  };

  const validateUpi = () => {
    // Require a 10-digit mobile or a valid-ish VPA
    const mobileOk = /^\d{10}$/.test(upiPhone.trim());
    const vpaOk = upiVpa.trim() === '' || /^[\w.-]{2,}@[\w.-]{2,}$/.test(upiVpa.trim());
    if (!mobileOk) {
      toast({ title: 'PhonePe mobile required', description: 'Enter a valid 10-digit mobile number for PhonePe.', variant: 'destructive' });
      return false;
    }
    if (!vpaOk) {
      toast({ title: 'Invalid UPI ID', description: 'UPI ID should look like name@bank (optional).', variant: 'destructive' });
      return false;
    }
    return true;
  };

  // removed unused helper updateOrderWithAddress

  const ensureOrder = async (): Promise<string> => {
    if (orderId) return orderId;
    if (createdOrderId) return createdOrderId;
    const uid = auth.currentUser?.uid || user?.uid || (user as any)?.id || null;
    if (!uid) throw new Error('User not authenticated');
    const items = (cartItems || []).map((it: any) => ({
      productId: it.productId || it.id,
      id: it.id,
      name: it.name,
      price: Number(it.price || 0),
      quantity: Number(it.quantity || 1),
      imageUrl: it.imageUrl || null,
      category: it.category || null,
      sellerId: it.sellerId || null,
    }));
    const sellerIds = Array.from(new Set((items || []).map((i: any) => i?.sellerId).filter(Boolean)));
    const ref = await addDoc(collection(db, 'orders'), {
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      userId: uid,
      contact: {
        name: form.fullName || '',
        phone: form.phone || '',
        email: form.email || '',
      },
      shippingAddress: null,
      paymentMethod: method,
      paymentStatus: 'initiated',
      amount,
      status: 'created',
      items,
      sellerIds,
    });
    setCreatedOrderId(ref.id);
    return ref.id;
  };

   // Decrement stock for each ordered item. If stock hits 0, mark outOfStock and unpublish.
   const updateStockAfterOrder = async (items: Array<{ productId?: string; id: string; quantity: number }>) => {
    try {
      await Promise.all(items.map(async (it) => {
        const prodId = it.productId || it.id;
        if (!prodId) return;
        const pref = doc(db, 'products', prodId);
        const snap = await getDoc(pref);
        if (!snap.exists()) return;
        const data: any = snap.data();
        const current = Number(data?.stock ?? 0);
        const qty = Number(it.quantity || 1);
        const newStock = Math.max(0, current - (Number.isFinite(qty) ? qty : 1));
        const payload: any = {
          stock: newStock,
          outOfStock: newStock === 0 ? true : false,
          updatedAt: serverTimestamp(),
        };
        if (newStock === 0) payload.published = false;
        await updateDoc(pref, payload);
      }));
    } catch (e) {
      // Best-effort: we won't block the UX on failures here
      console.warn('updateStockAfterOrder failed (non-fatal):', e);
    }
  };


  const onSubmit = async () => {
    const uid = auth.currentUser?.uid;
    if (!uid) {
      toast({ title: 'Sign in required', description: 'Please sign in to place your order.', variant: 'destructive' });
      navigate('/login');
      return;
    }
    if (!validateAddress()) return;

    setIsSubmitting(true);
    try {
      if (method === 'cod') {
        const contact = {
          name: form.fullName || auth.currentUser?.displayName || 'Customer',
          phone: form.phone || '',
          email: form.email || auth.currentUser?.email || '',
        };
        const hasAddress = !!(form.line1 && form.city && form.state && form.pincode);
        const items = (cartItems || []).map((it: any) => ({
          productId: it.productId || it.id,
          id: it.id,
          name: it.name,
          price: Number(it.price || 0),
          quantity: Number(it.quantity || 1),
          imageUrl: it.imageUrl || null,
          category: it.category || null,
          sellerId: it.sellerId || null,
        }));
        const sellerIds = Array.from(new Set((items || []).map((i: any) => i?.sellerId).filter(Boolean)));
        const payload: any = {
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
          userId: uid,
          contact,
          shippingAddress: hasAddress
            ? {
                fullName: contact.name,
                phone: contact.phone,
                email: contact.email,
                line1: form.line1,
                city: form.city,
                state: form.state,
                pincode: form.pincode,
              }
            : null,
          paymentMethod: 'cod',
          paymentStatus: 'pending',
          amount,
          status: 'placed',
          items,
          sellerIds,
        };
        const newRef = await addDoc(collection(db, 'orders'), payload);
        
        // Best-effort stock decrement for COD order
        await updateStockAfterOrder(items);
        await clearCart();
        const placedId = newRef.id;
        setSuccessId(placedId);
        toast({ title: 'Order placed', description: `Your COD order ${placedId} is confirmed.` });
        setTimeout(() => {
          navigate(`/orders?highlight=${placedId}`);
        }, 1200);
        return;
      }

      const ensuredId = await ensureOrder();
      const ref = doc(db, 'orders', ensuredId);
      await updateDoc(ref, {
        shippingAddress: {
          fullName: form.fullName,
          phone: form.phone,
          email: form.email,
          line1: form.line1,
          city: form.city,
          state: form.state,
          pincode: form.pincode,
        },
        updatedAt: serverTimestamp(),
        userId: uid,
      });

      if (method === 'card') {
        if (!validateCard()) { setIsSubmitting(false); return; }
        await updateDoc(ref, {
          paymentMethod: 'card',
          paymentStatus: 'processing',
          cardLast4: cardNumber.replace(/\s+/g, '').slice(-4),
        });
        await new Promise((r) => setTimeout(r, 1200));
        await updateDoc(ref, { paymentStatus: 'paid' });
        // Decrement stock after successful payment
        try {
          const snap = await getDoc(ref);
          const data: any = snap.exists() ? snap.data() : null;
          const items = Array.isArray(data?.items) ? data.items : [];
          await updateStockAfterOrder(items);
        } catch (_) {}
       
        await clearCart();
        navigate(`/order-confirmation?orderId=${ensuredId}&method=card`);
        return;
      }

      if (method === 'upi') {
        if (!validateUpi()) { setIsSubmitting(false); return; }
        await updateDoc(ref, {
          paymentMethod: 'upi',
          paymentStatus: 'initiated',
          upi: {
            phone: upiPhone.trim(),
            vpa: upiVpa.trim() || null,
          },
        });
        const paymentResponse = await initiatePhonePePayment({
          amount,
          userId: user?.uid || user?.id || '',
          orderId: ensuredId,
          userPhone: upiPhone.trim() || (user as any)?.phoneNumber || '',
          userName: user?.displayName || '',
          email: user?.email || '',
        });
        if (paymentResponse.success && paymentResponse.redirectUrl) {
          await updateDoc(ref, { paymentStatus: 'pending' });
          window.location.href = paymentResponse.redirectUrl;
          return;
        }
        throw new Error(paymentResponse.error || 'Payment initiation failed');
      }
    } catch (e: any) {
      toast({ title: 'Checkout failed', description: e?.message || 'Could not complete checkout', variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <motion.div
      className="min-h-screen pt-20 pb-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <div className="container mx-auto px-4 max-w-3xl">
        <h1 className="text-3xl font-bold mb-6">Checkout Details</h1>
        <p className="text-muted-foreground mb-6">Order ID: <span className="font-mono">{orderId || '—'}</span> • Amount: ₹{amount.toFixed(2)} • Method: <span className="uppercase font-medium">{method}</span></p>

        <div className="grid gap-6">
          <Card>
            <CardContent className="p-6 grid gap-4">
              <h2 className="text-xl font-semibold">Delivery Address</h2>
              {!addressLoaded ? (
                <Button className="w-full bg-gold hover:bg-gold/90 text-black" onClick={useProfileAddress}>
                  Use saved address
                </Button>
              ) : (
                <div className="text-sm grid gap-1 bg-black/30 rounded p-3">
                  <div className="font-medium">{form.fullName} <span className="text-muted-foreground">• {form.phone}</span></div>
                  <div>{form.email}</div>
                  <div>{form.line1}</div>
                  <div>{form.city}, {form.state} {form.pincode}</div>
                  <div className="mt-2">
                    <Button variant="secondary" onClick={() => setAddressLoaded(false)}>Change address</Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {showCardFields && (
            <Card>
              <CardContent className="p-6 grid gap-4">
                <h2 className="text-xl font-semibold">Card Details</h2>
                <input className="input bg-black text-white placeholder-gray-400 border-white/20" placeholder="Card number" value={cardNumber} onChange={(e) => setCardNumber(e.target.value)} />
                <div className="grid grid-cols-2 gap-4">
                  <input className="input bg-black text-white placeholder-gray-400 border-white/20" placeholder="MM/YY" value={expiry} onChange={(e) => setExpiry(e.target.value)} />
                  <input className="input bg-black text-white placeholder-gray-400 border-white/20" placeholder="CVV" value={cvv} onChange={(e) => setCvv(e.target.value)} />
                </div>
              </CardContent>
            </Card>
          )}

          {showUpiFields && (
            <Card>
              <CardContent className="p-6 grid gap-4">
                <h2 className="text-xl font-semibold">PhonePe Details</h2>
                <input
                  className="input bg-black text-white placeholder-gray-400 border-white/20"
                  placeholder="PhonePe mobile number (10 digits)"
                  inputMode="numeric"
                  value={upiPhone}
                  onChange={(e) => setUpiPhone(e.target.value)}
                />
                <input
                  className="input bg-black text-white placeholder-gray-400 border-white/20"
                  placeholder="UPI ID (optional, e.g., name@bank)"
                  value={upiVpa}
                  onChange={(e) => setUpiVpa(e.target.value)}
                />
              </CardContent>
            </Card>
          )}

          <Button className="w-full bg-gold hover:bg-gold/90 text-black" size="lg" onClick={onSubmit} disabled={isSubmitting}>
            {isSubmitting ? 'Processing…' : method === 'card' ? `Pay ₹${amount.toFixed(2)}` : method === 'upi' ? 'Continue to PhonePe' : 'Place Order (COD)'}
          </Button>
        </div>
      </div>

      {/* Success overlay */}
      {successId && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70">
          <div className="bg-black border border-white/10 rounded-xl p-6 w-[92%] max-w-md text-center">
            <div className="mx-auto mb-3 h-12 w-12 rounded-full bg-green-600/20 grid place-items-center">
              <span className="text-green-500 text-2xl">✓</span>
            </div>
            <h3 className="text-xl font-semibold">Order placed successfully</h3>
            <p className="text-sm text-muted-foreground mt-1">Order ID: <span className="font-mono">{successId}</span></p>
            <p className="text-xs text-muted-foreground mt-2">Redirecting to your Orders…</p>
          </div>
        </div>
      )}
    </motion.div>
  );
}
