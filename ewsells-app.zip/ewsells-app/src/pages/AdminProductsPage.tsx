import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Loader2, Pencil, X, ChevronLeft, ChevronRight, Trash2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { auth, db } from '@/lib/firebase';
import { collection, deleteDoc, doc, getDoc, getDocs, serverTimestamp, updateDoc } from 'firebase/firestore';
import { useToast } from '@/components/ui/toast-context';

// Tiny inline carousel for admin tables
function MiniCarousel({ images, className }: { images: string[]; className?: string }) {
  const valid = Array.isArray(images) ? images.filter(Boolean) : [];
  const [idx, setIdx] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  if (valid.length === 0) {
    return <div className={`h-14 w-14 rounded border bg-muted ${className || ''}`} />;
  }
  const go = (delta: number) => setIdx((i) => (i + delta + valid.length) % valid.length);
  const openLightbox = () => setLightboxOpen(true);
  const closeLightbox = () => setLightboxOpen(false);
  const setIndex = (i: number) => setIdx(((i % valid.length) + valid.length) % valid.length);
  return (
    <div className={`relative h-14 w-14 ${className || ''}`}>
      <img
        src={valid[idx]}
        alt="item"
        className="h-14 w-14 object-cover rounded border cursor-zoom-in"
        onClick={(e) => { e.stopPropagation(); openLightbox(); }}
      />
      {valid.length > 1 && (
        <>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); go(-1); }}
            className="absolute left-0 top-1/2 -translate-y-1/2 h-6 w-6 flex items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/70"
            aria-label="Previous image"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); go(1); }}
            className="absolute right-0 top-1/2 -translate-y-1/2 h-6 w-6 flex items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/70"
            aria-label="Next image"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 mb-0.5 px-1.5 py-0.5 rounded bg-black/50 text-white">
            {idx + 1}/{valid.length}
          </div>
        </>
      )}

      {/* Lightbox Dialog */}
      <Dialog open={lightboxOpen} onOpenChange={setLightboxOpen}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden">
          <DialogHeader className="sr-only">
            <DialogTitle>Image Preview</DialogTitle>
          </DialogHeader>
          <div className="relative bg-black">
            {/* Large Image */}
            <img
              src={valid[idx]}
              alt={`preview-${idx + 1}`}
              className="max-h-[80vh] w-full object-contain bg-black"
              onClick={(e) => { e.stopPropagation(); closeLightbox(); }}
            />
            {/* Controls */}
            {valid.length > 1 && (
              <>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); go(-1); }}
                  className="absolute left-2 top-1/2 -translate-y-1/2 h-9 w-9 flex items-center justify-center rounded-full bg-white/20 text-white hover:bg-white/30"
                  aria-label="Previous"
                >
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); go(1); }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-9 w-9 flex items-center justify-center rounded-full bg-white/20 text-white hover:bg-white/30"
                  aria-label="Next"
                >
                  <ChevronRight className="h-5 w-5" />
                </button>
                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-white text-xs bg-black/40 rounded px-2 py-0.5">
                  {idx + 1} / {valid.length}
                </div>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function AdminProductsPage() {
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);
  const { showToast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [activeTab, setActiveTab] = useState<'published' | 'unpublished'>('unpublished');
  const [adminChecked, setAdminChecked] = useState(false);
  const [editingDescriptionId, setEditingDescriptionId] = useState<string | null>(null);
  const [editedDescription, setEditedDescription] = useState('');
  // Pagination
  const [pageIndex, setPageIndex] = useState(0);
  const pageSize = 12;
  // Sorting UI
  const [sortBy, setSortBy] = useState<'default' | 'name_asc' | 'name_desc' | 'price_desc' | 'price_asc' | 'stock_desc' | 'stock_asc' | 'created_desc' | 'created_asc'>('default');
  const [sortOpen, setSortOpen] = useState(false);
  // Final price edit buffer to avoid mutating the main list while typing
  const [finalPriceEdits, setFinalPriceEdits] = useState<Record<string, string>>({});
  // Track first successful load to avoid flashing the loader on subsequent refreshes
  const hasLoadedOnceRef = useRef(false);

  const handleSaveDescription = async (product: any) => {
    if (!editedDescription.trim()) {
      showToast({ message: 'Description cannot be empty', type: 'error' });
      return;
    }
    setBusyId(product.id);
    try {
      await updateDoc(doc(db, 'products', product.id), { 
        description: editedDescription.trim(),
        updatedAt: serverTimestamp() 
      });
      updateLocal(product.id, { description: editedDescription.trim() });
      showToast({ message: 'Description updated', type: 'success' });
      setEditingDescriptionId(null);
    } catch (error) {
      console.error('Error updating description:', error);
      showToast({ message: 'Failed to update description', type: 'error' });
    } finally {
      setBusyId(null);
    }
  };

  // Verify admin before loading any products
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const currentUser = auth.currentUser;
        if (!currentUser) {
          navigate('/admin-login');
          return;
        }
        const userRef = doc(db, 'users', currentUser.uid);
        const userDoc = await getDoc(userRef);
        if (!userDoc.exists() || userDoc.data()?.role !== 'admin') {
          try { await auth.signOut(); } catch {}
          navigate('/admin-login');
          return;
        }
        if (!cancelled) setAdminChecked(true);
      } catch (e) {
        console.error('Admin check failed in AdminProductsPage:', e);
        navigate('/admin-login');
      }
    })();
    return () => { cancelled = true; };
  }, [navigate]);

  // Accept tab from navigation state or from ?tab= query parameter
  useEffect(() => {
    const stateTab = (location.state as any)?.tab as 'published' | 'unpublished' | undefined;
    const queryTab = new URLSearchParams(location.search).get('tab') as 'published' | 'unpublished' | null;
    const desired = stateTab || queryTab || null;
    if (desired === 'published' || desired === 'unpublished') {
      setActiveTab(desired);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Reset pagination on tab change, search change, or sort change
  useEffect(() => {
    setPageIndex(0);
  }, [activeTab, search, sortBy]);

  useEffect(() => {
    if (!adminChecked) return; // wait for admin verification
    let cancelled = false;
    async function load() {
      try {
        if (!hasLoadedOnceRef.current) setLoading(true);
        const snap = await getDocs(collection(db, 'products'));
        if (cancelled) return;
        const docs = snap.docs.map(d => ({ id: d.id, ...d.data() }));

        // Backfill/migrate pricing fields: price -> sellerPrice, and ensure finalPrice exists
        const migrated = docs.map((p: any) => {
          const sellerPrice = p.sellerPrice ?? p.price ?? null;
          const finalPrice = p.finalPrice ?? sellerPrice ?? null;
          // Fire-and-forget backfill writes if needed
          (async () => {
            const needsSeller = p.sellerPrice === undefined && p.price !== undefined;
            const needsFinal = p.finalPrice === undefined && (sellerPrice !== null && sellerPrice !== undefined);
            if (needsSeller || needsFinal) {
              try {
                const payload: any = {};
                if (needsSeller) payload.sellerPrice = Number(sellerPrice);
                if (needsFinal) payload.finalPrice = Number(finalPrice);
                payload.updatedAt = serverTimestamp();
                await updateDoc(doc(db, 'products', p.id), payload);
              } catch (e) {
                console.warn('Backfill pricing fields failed for', p.id, e);
              }
            }
          })();
          return { ...p, sellerPrice, finalPrice };
        });

        // Enrich with sellerCode if missing by looking up seller profile/registration by sellerId
        const uniqueSellerIds = Array.from(new Set(migrated.map((p: any) => String(p.sellerId || '')).filter(Boolean)));
        const sellerCodes: Record<string, string | null> = {};
        await Promise.all(uniqueSellerIds.map(async (sid) => {
          try {
            const profRef = doc(db, 'sellers', sid);
            const profSnap = await getDoc(profRef);
            if (profSnap.exists()) {
              const data: any = profSnap.data();
              sellerCodes[sid] = data?.sellerCode ?? data?.code ?? null;
              return;
            }
          } catch {}
          try {
            const regRef = doc(db, 'seller-registrations', sid);
            const regSnap = await getDoc(regRef);
            if (regSnap.exists()) {
              const data: any = regSnap.data();
              sellerCodes[sid] = data?.sellerCode ?? data?.code ?? null;
            }
          } catch {}
        }));

        const enriched = migrated.map((p: any) => ({
          ...p,
          sellerCode: p.sellerCode ?? (p.sellerId ? sellerCodes[String(p.sellerId)] ?? null : null),
        }));

        setProducts(enriched);
        hasLoadedOnceRef.current = true;
      } catch (e) {
        console.error('Failed to load products', e);
        showToast({ message: 'Failed to load products', type: 'error' });
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, [showToast, adminChecked]);

  const norm = (s: string) => (s || '').toLowerCase();
  const matches = (p: any) => !search ||
    norm(p.name).includes(norm(search)) ||
    norm(p.category).includes(norm(search)) ||
    norm(p.sellerId).includes(norm(search)) ||
    norm(p.sellerCode || '').includes(norm(search)) ||
    norm(p.id).includes(norm(search));
  const publishedCount = products.filter(p => !!p.published).length;
  const unpublishedCount = products.filter(p => !p.published).length;
  const ts = (v: any): number => {
    if (!v) return 0;
    if (typeof v === 'number') return v;
    if (typeof v?.toDate === 'function') return v.toDate().getTime();
    const parsed = Date.parse(v);
    return Number.isNaN(parsed) ? 0 : parsed;
  };

  const filteredProducts = useMemo(() => {
    const matchesInner = (p: any) => !search ||
      norm(p.name).includes(norm(search)) ||
      norm(p.category).includes(norm(search)) ||
      norm(p.sellerId).includes(norm(search)) ||
      norm(p.sellerCode || '').includes(norm(search)) ||
      norm(p.id).includes(norm(search));
    const arr = products
      .filter(p => (activeTab === 'published' ? !!p.published : !p.published))
      .filter(matchesInner);

    const getName = (p: any): string => String(p?.name || '').toLowerCase();
    const getFinal = (p: any): number => Number(p?.finalPrice ?? p?.sellerPrice ?? 0) || 0;
    const getStock = (p: any): number => Number.isFinite(Number(p?.stock)) ? Number(p.stock) : -Infinity;
    const getCreated = (p: any): number => activeTab === 'published'
      ? ts(p.publishedAt || p.updatedAt || p.createdAt)
      : ts(p.createdAt);

    const cmp = (a: any, b: any) => {
      switch (sortBy) {
        case 'name_asc':
          return getName(a).localeCompare(getName(b));
        case 'name_desc':
          return getName(b).localeCompare(getName(a));
        case 'price_desc':
          return getFinal(b) - getFinal(a) || getName(a).localeCompare(getName(b));
        case 'price_asc':
          return getFinal(a) - getFinal(b) || getName(a).localeCompare(getName(b));
        case 'stock_desc':
          return getStock(b) - getStock(a) || getName(a).localeCompare(getName(b));
        case 'stock_asc':
          return getStock(a) - getStock(b) || getName(a).localeCompare(getName(b));
        case 'created_desc':
          return getCreated(b) - getCreated(a) || getName(a).localeCompare(getName(b));
        case 'created_asc':
          return getCreated(a) - getCreated(b) || getName(a).localeCompare(getName(b));
        case 'default':
        default:
          if (activeTab === 'unpublished') return getCreated(a) - getCreated(b); // oldest first
          return getCreated(b) - getCreated(a); // newest first
      }
    };
    return arr.sort(cmp);
  }, [products, search, activeTab, sortBy]);

  const visible = filteredProducts;
  const pageTotal = Math.max(1, Math.ceil(visible.length / pageSize));
  const pageRows = visible.slice(pageIndex * pageSize, pageIndex * pageSize + pageSize);

  const updateLocal = (id: string, patch: any) => setProducts(prev => prev.map(p => p.id === id ? { ...p, ...patch } : p));

  const saveFinalPrice = async (p: any) => {
    try {
      if (busyId === p.id) return;
      const raw = finalPriceEdits[p.id] ?? p.finalPrice;
      if (raw === undefined || raw === null || raw === '') {
        showToast({ message: 'Enter a valid final price', type: 'error' });
        return;
      }
      if (Number.isNaN(Number(raw))) {
        showToast({ message: 'Enter a valid final price', type: 'error' });
        return;
      }
      setBusyId(p.id);
      const numeric = Number(raw);
      await updateDoc(doc(db, 'products', p.id), { finalPrice: numeric, updatedAt: serverTimestamp() });
      // Update local state immediately and clear edit buffer for this row
      updateLocal(p.id, { finalPrice: numeric });
      setFinalPriceEdits(prev => { const { [p.id]: _omit, ...rest } = prev; return rest; });
      showToast({ message: 'Final price updated', type: 'success' });
    } catch (e) {
      console.error('Failed to save final price', e);
      showToast({ message: 'Failed to save final price', type: 'error' });
    } finally {
      setBusyId(null);
    }
  };
  const saveStock = async (p: any) => {
    try {
      const val = Number(p.stock);
      if (!Number.isFinite(val) || val < 0 || !Number.isInteger(val)) {
        showToast({ message: 'Enter a valid stock (non-negative integer)', type: 'error' });
        return;
      }
      setBusyId(p.id);
      const payload: any = { stock: val, updatedAt: serverTimestamp() };
      // If stock is zero, ensure not published
      if (val === 0) {
        payload.published = false;
        payload.outOfStock = true;
      } else {
        payload.outOfStock = false;
      }
      await updateDoc(doc(db, 'products', p.id), payload);
      updateLocal(p.id, { stock: val, ...(val === 0 ? { published: false, outOfStock: true } : { outOfStock: false }) });
      showToast({ message: 'Stock updated', type: 'success' });
    } catch (e) {
      console.error('Failed to save stock', e);
      showToast({ message: 'Failed to save stock', type: 'error' });
    } finally {
      setBusyId(null);
    }
  };

  const containerRef = useRef<HTMLDivElement>(null);
  const saveScrollPos = () => {
    const pos = containerRef.current?.scrollTop;
    sessionStorage.setItem('adminProductsScrollPos', String(pos));
  };

  const restoreScrollPos = () => {
    const pos = sessionStorage.getItem('adminProductsScrollPos');
    if (pos && containerRef.current) {
      containerRef.current.scrollTop = Number(pos);
    }
  };

  const togglePublish = async (p: any) => {
    try {
      saveScrollPos();
      if ((!p.published) && (Number(p.stock) === 0)) {
        showToast({ message: 'Cannot publish: stock is 0', type: 'error' });
        return;
      }
      setBusyId(p.id);
      const next = !!p.published ? false : true;
      const payload: any = { published: next, updatedAt: serverTimestamp() };
      if (next) payload.publishedAt = serverTimestamp();
      await updateDoc(doc(db, 'products', p.id), payload);
      updateLocal(p.id, { published: next });
      showToast({ message: next ? 'Product published' : 'Product unpublished', type: 'success' });
    } catch (e) {
      console.error('Failed to toggle publish', e);
      showToast({ message: 'Failed to update publish state', type: 'error' });
    } finally {
      setBusyId(null);
      restoreScrollPos();
    }
  };

  const deleteProduct = async (p: any) => {
    try {
      setBusyId(p.id);
      await deleteDoc(doc(db, 'products', p.id));
      setProducts(prev => prev.filter(x => x.id !== p.id));
      showToast({ message: 'Product deleted', type: 'success' });
    } catch (e) {
      console.error('Failed to delete product', e);
      showToast({ message: 'Failed to delete product', type: 'error' });
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-2">
        <div>
          <h1 className="text-3xl font-bold">Products</h1>
          <p className="text-muted-foreground">Review seller uploads, edit prices, and publish to storefront</p>
        </div>
        {/* Sort By near title */}
        <div className="relative">
          <Button
            type="button"
            variant="outline"
            className="btn-hover h-10 px-4 py-2"
            aria-haspopup="listbox"
            aria-expanded={sortOpen}
            onClick={() => setSortOpen(o => !o)}
            onBlur={(e) => { if (!e.currentTarget.parentElement?.contains(e.relatedTarget as Node)) setSortOpen(false); }}
          >
            Sort By
          </Button>
          {sortOpen && (
            <div className="absolute right-0 mt-2 z-10 w-48 rounded-md border border-border/60 bg-background shadow-lg py-1">
              <ul role="listbox" aria-label="Sort by" className="max-h-64 overflow-auto text-sm">
                <li><button type="button" role="option" aria-selected={sortBy==='name_asc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='name_asc'?'font-medium':''}`} onClick={() => { setSortBy('name_asc'); setSortOpen(false); }} autoFocus>Name A → Z</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='name_desc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='name_desc'?'font-medium':''}`} onClick={() => { setSortBy('name_desc'); setSortOpen(false); }}>Name Z → A</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='price_desc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='price_desc'?'font-medium':''}`} onClick={() => { setSortBy('price_desc'); setSortOpen(false); }}>Final Price: High → Low</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='price_asc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='price_asc'?'font-medium':''}`} onClick={() => { setSortBy('price_asc'); setSortOpen(false); }}>Final Price: Low → High</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='stock_desc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='stock_desc'?'font-medium':''}`} onClick={() => { setSortBy('stock_desc'); setSortOpen(false); }}>Stock: High → Low</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='stock_asc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='stock_asc'?'font-medium':''}`} onClick={() => { setSortBy('stock_asc'); setSortOpen(false); }}>Stock: Low → High</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='created_desc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='created_desc'?'font-medium':''}`} onClick={() => { setSortBy('created_desc'); setSortOpen(false); }}>Newest</button></li>
                <li><button type="button" role="option" aria-selected={sortBy==='created_asc'} className={`w-full text-left px-2 py-1.5 hover:bg-muted ${sortBy==='created_asc'?'font-medium':''}`} onClick={() => { setSortBy('created_asc'); setSortOpen(false); }}>Oldest</button></li>
              </ul>
            </div>
          )}
        </div>
      </div>

      { !adminChecked ? (
        <div className="flex items-center gap-2 text-muted-foreground py-10"><Loader2 className="h-5 w-5 animate-spin"/>Verifying admin…</div>
      ) : (
        <>
          {/* Tabs + Search */}
          <div className="mb-4 flex flex-col md:flex-row md:items-center gap-3">
            <div className="flex items-center gap-2">
              <Button
                variant={activeTab === 'unpublished' ? 'default' : 'ghost'}
                className={activeTab === 'unpublished' ? 'bg-gold text-black hover:bg-gold/90' : ''}
                onClick={() => setActiveTab('unpublished')}
              >
                <span>Unpublished</span>
                <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${activeTab === 'unpublished' ? 'bg-white text-black' : 'bg-gold/20 text-gold'}`}>
                  {unpublishedCount}
                </span>
              </Button>
              <Button
                variant={activeTab === 'published' ? 'default' : 'ghost'}
                className={activeTab === 'published' ? 'bg-gold text-black hover:bg-gold/90' : ''}
                onClick={() => setActiveTab('published')}
              >
                <span>Published</span>
                <span className={`ml-2 inline-flex items-center justify-center rounded-full text-xs px-2 py-0.5 ${activeTab === 'published' ? 'bg-white text-black' : 'bg-gold/20 text-gold'}`}>
                  {publishedCount}
                </span>
              </Button>
            </div>
            <div className="relative w-full max-w-sm md:ml-auto">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search by name, category, seller, or id…"
                className="w-full pl-8 pr-3 py-2 rounded-md bg-muted/40 outline-none border border-border/60 focus:border-gold"
              />
            </div>
          </div>

          <Card ref={containerRef}>
            <CardHeader>
              <CardTitle>Seller Products</CardTitle>
              <CardDescription>Items submitted by sellers in the products collection</CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex items-center gap-2 text-muted-foreground py-10"><Loader2 className="h-5 w-5 animate-spin"/>Loading…</div>
              ) : visible.length === 0 ? (
                <div className="text-muted-foreground">No products found.</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full text-sm">
                    <thead className="text-left text-muted-foreground">
                      <tr>
                        <th className="py-2 pr-4">Image</th>
                        <th className="py-2 pr-4">Name</th>
                        <th className="py-2 pr-4">Category</th>
                        <th className="py-2 pr-4">Seller</th>
                        <th className="py-2 pr-4">Seller Price</th>
                        <th className="py-2 pr-4">Stock</th>
                        <th className="py-2 pr-4">Description</th>
                        <th className="py-2 pr-4">Final Price</th>
                        <th className="py-2 pr-4">Published</th>
                        <th className="py-2 pr-4">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {pageRows.map((p) => (
                        <tr key={p.id} className="border-t border-border/60 align-top">
                          <td className="py-2 pr-4">
                            {(() => {
                              const imgs = Array.isArray(p.imageUrls)
                                ? p.imageUrls
                                : Array.isArray(p.images)
                                  ? p.images
                                  : (p.imageUrl ? [p.imageUrl] : []);
                              return <MiniCarousel images={imgs} />;
                            })()}
                          </td>
                          <td className="py-2 pr-4 max-w-xs">
                            <div className="flex items-center gap-2">
                              <div className="font-medium truncate" title={p.name}>{p.name || '-'}</div>
                              {p.needsReview && (
                                <span className="inline-flex items-center rounded-full bg-yellow-100 px-2.5 py-0.5 text-xs font-medium text-yellow-800">
                                  Review
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-muted-foreground break-all">{p.productCode || p.id}</div>
                          </td>
                          <td className="py-2 pr-4">{p.category || '-'}</td>
                          <td className="py-2 pr-4">
                            <div className="text-sm font-medium">{p.sellerCode || '-'}</div>
                            <div className="text-[10px] text-muted-foreground font-mono break-all">{p.sellerId || ''}</div>
                          </td>
                          <td className="py-2 pr-4">
                            {p.sellerPrice !== undefined && p.sellerPrice !== null 
                              ? `₹ ${Number(p.sellerPrice).toLocaleString()}` 
                              : '-'}
                          </td>
                          <td className="py-2 pr-4">
                            {typeof p.stock === 'number' ? p.stock : '-'}
                            {p.stock === 0 && (
                              <div className="text-xs text-red-500">Out of stock</div>
                            )}
                          </td>
                          <td className="py-2 pr-4 max-w-xs">
                            {editingDescriptionId === p.id ? (
                              <div className="flex items-center gap-2">
                                <Input
                                  type="text"
                                  value={editedDescription}
                                  onChange={(e) => setEditedDescription(e.target.value)}
                                  className="min-w-[200px]"
                                  autoFocus
                                />
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  onClick={() => handleSaveDescription(p)}
                                  disabled={busyId === p.id}
                                  className="h-8 px-2"
                                >
                                  {busyId === p.id ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : 'Save'}
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  onClick={() => setEditingDescriptionId(null)}
                                  disabled={busyId === p.id}
                                  className="h-8 w-8 p-0"
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2">
                                <div className="text-sm line-clamp-2 flex-1" title={p.description}>
                                  {p.description || 'No description'}
                                </div>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="h-6 w-6 p-0"
                                  onClick={() => {
                                    setEditingDescriptionId(p.id);
                                    setEditedDescription(p.description || '');
                                  }}
                                >
                                  <Pencil className="h-3 w-3" />
                                </Button>
                              </div>
                            )}
                          </td>
                          <td className="py-2 pr-4">
                            {activeTab === 'unpublished' ? (
                              <div className="flex items-center gap-2">
                                <Input
                                  type="number"
                                  step="0.01"
                                  className="w-28"
                                  value={(finalPriceEdits[p.id] ?? (p.finalPrice ?? '')).toString()}
                                  onChange={(e) => setFinalPriceEdits(prev => ({ ...prev, [p.id]: e.target.value }))}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); saveFinalPrice(p); }
                                    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); setFinalPriceEdits(prev => { const { [p.id]: _omit, ...rest } = prev; return rest; }); }
                                  }}
                                />
                                <Button size="sm" variant="outline" disabled={busyId === p.id} onClick={(e) => { e.preventDefault(); e.stopPropagation(); saveFinalPrice(p); }}>
                                  {busyId === p.id ? (
                                    <span className="inline-flex items-center">
                                      <Loader2 className="h-4 w-4 mr-1 animate-spin"/>Saving
                                    </span>
                                  ) : 'Save'}
                                </Button>
                              </div>
                            ) : (
                              p.finalPrice !== undefined && p.finalPrice !== null 
                                ? `₹ ${Number(p.finalPrice).toLocaleString()}` 
                                : '-'
                            )}
                          </td>
                          <td className="py-2 pr-4">{p.published ? 'Yes' : 'No'}</td>
                          <td className="py-2 pr-4">
                            <div className="flex items-center gap-2">
                              <Button size="sm" className="bg-gold text-black hover:bg-gold/90" disabled={busyId === p.id} onClick={() => togglePublish(p)}>
                                {p.published ? 'Unpublish' : 'Publish'}
                              </Button>
                              <Button size="sm" variant="destructive" disabled={busyId === p.id} onClick={() => deleteProduct(p)}>
                                <Trash2 className="h-4 w-4 mr-1" />
                                Delete
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {/* Pagination */}
                  <div className="mt-4 flex items-center justify-between">
                    <Button type="button" variant="outline" disabled={pageIndex <= 0} onClick={() => setPageIndex(i => Math.max(0, i - 1))}>Previous</Button>
                    <div className="text-sm text-muted-foreground">Page {pageIndex + 1} of {pageTotal}</div>
                    <Button type="button" variant="outline" disabled={(pageIndex + 1) >= pageTotal} onClick={() => setPageIndex(i => i + 1)}>Next</Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
