import { useEffect, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { db } from '@/lib/firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';

interface AddressForm {
  fullName: string;
  phone: string;
  email: string;
  line1: string;
  city: string;
  state: string;
  pincode: string;
}

export default function CardPaymentPage() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const orderId = params.get('orderId') || '';
  const amount = Number(params.get('amount') || 0);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [form, setForm] = useState<AddressForm>({
    fullName: '',
    phone: '',
    email: '',
    line1: '',
    city: '',
    state: '',
    pincode: '',
  });
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState(''); // MM/YY
  const [cvv, setCvv] = useState('');

  useEffect(() => {
    // Prefill from order contact if available
    (async () => {
      if (!orderId) return;
      try {
        const ref = doc(db, 'orders', orderId);
        const snap = await getDoc(ref);
        if (snap.exists()) {
          const data: any = snap.data();
          setForm((f) => ({
            ...f,
            fullName: data?.contact?.name || f.fullName,
            phone: data?.contact?.phone || f.phone,
            email: data?.contact?.email || f.email,
          }));
        }
      } catch (_) {
        // optional
      }
    })();
  }, [orderId]);

  const validate = () => {
    if (!orderId) {
      toast({ title: 'Invalid order', description: 'Missing orderId', variant: 'destructive' });
      return false;
    }
    if (!form.fullName || !form.phone || !form.email || !form.line1 || !form.city || !form.state || !form.pincode) {
      toast({ title: 'Missing details', description: 'Please fill all address fields.' });
      return false;
    }
    const digits = cardNumber.replace(/\s+/g, '');
    if (digits.length < 12 || digits.length > 19) {
      toast({ title: 'Invalid card number', description: 'Please check your card number.', variant: 'destructive' });
      return false;
    }
    if (!/^\d{2}\/(\d{2})$/.test(expiry)) {
      toast({ title: 'Invalid expiry', description: 'Use MM/YY format.', variant: 'destructive' });
      return false;
    }
    if (!/^\d{3,4}$/.test(cvv)) {
      toast({ title: 'Invalid CVV', description: 'CVV should be 3 or 4 digits.', variant: 'destructive' });
      return false;
    }
    return true;
  };

  const onSubmit = async () => {
    if (!validate()) return;
    setIsSubmitting(true);
    try {
      const ref = doc(db, 'orders', orderId);
      await updateDoc(ref, {
        shippingAddress: {
          fullName: form.fullName,
          phone: form.phone,
          email: form.email,
          line1: form.line1,
          city: form.city,
          state: form.state,
          pincode: form.pincode,
        },
        paymentMethod: 'card',
        paymentStatus: 'processing',
        cardLast4: cardNumber.replace(/\s+/g, '').slice(-4),
      });

      // Simulate payment success. Replace with real gateway integration later.
      await new Promise((r) => setTimeout(r, 1200));
      await updateDoc(ref, { paymentStatus: 'paid' });

      navigate(`/order-confirmation?orderId=${orderId}&method=card`);
    } catch (e: any) {
      toast({ title: 'Payment failed', description: e?.message || 'Could not process payment', variant: 'destructive' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <motion.div
      className="min-h-screen pt-20 pb-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <div className="container mx-auto px-4 max-w-3xl">
        <h1 className="text-3xl font-bold mb-6">Card Payment</h1>
        <p className="text-muted-foreground mb-6">Order ID: <span className="font-mono">{orderId || '—'}</span> • Amount: ₹{amount.toFixed(2)}</p>

        <div className="grid gap-6">
          <Card>
            <CardContent className="p-6 grid gap-4">
              <h2 className="text-xl font-semibold">Shipping Address</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input className="input" placeholder="Full name" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
                <input className="input" placeholder="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                <input className="input md:col-span-2" placeholder="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                <input className="input md:col-span-2" placeholder="Address line" value={form.line1} onChange={(e) => setForm({ ...form, line1: e.target.value })} />
                <input className="input" placeholder="City" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
                <input className="input" placeholder="State" value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} />
                <input className="input md:col-span-2" placeholder="Pincode" value={form.pincode} onChange={(e) => setForm({ ...form, pincode: e.target.value })} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 grid gap-4">
              <h2 className="text-xl font-semibold">Card Details</h2>
              <input className="input" placeholder="Card number" value={cardNumber} onChange={(e) => setCardNumber(e.target.value)} />
              <div className="grid grid-cols-2 gap-4">
                <input className="input" placeholder="MM/YY" value={expiry} onChange={(e) => setExpiry(e.target.value)} />
                <input className="input" placeholder="CVV" value={cvv} onChange={(e) => setCvv(e.target.value)} />
              </div>
              <Button className="w-full bg-gold hover:bg-gold/90 text-black" size="lg" onClick={onSubmit} disabled={isSubmitting || !orderId}>
                {isSubmitting ? 'Processing…' : `Pay ₹${amount.toFixed(2)}`}
              </Button>
              <p className="text-xs text-muted-foreground text-center">Your card will be charged securely.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </motion.div>
  );
}
