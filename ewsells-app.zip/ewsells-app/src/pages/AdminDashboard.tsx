import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { AlertTriangle, ArrowLeft, BarChart2, CheckSquare, DollarSign, Heart, HeartHandshake, Loader2, Package, Users, Search, ShoppingBag, Ban, Trash2, CheckCircle, XCircle, ExternalLink, ChevronLeft, ChevronRight, TrendingUp, TrendingDown, Minus, Wrench, Eye, Pencil, X } from 'lucide-react';
import { auth, db } from '@/lib/firebase';
import { doc, getDoc, collection, getCountFromServer, getDocs, query, where, updateDoc, deleteDoc, orderBy, Timestamp, startAfter, limit, serverTimestamp, documentId } from 'firebase/firestore';
import { useStore } from '@/store/useStore';
import { useToast } from '@/components/ui/toast-context';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { bucketByDay, dateRangeKeys, toDateKey } from '@/utils/analytics';

// Tiny inline carousel for admin tables
function MiniCarousel({ images, className }: { images: string[]; className?: string }) {
  const valid = Array.isArray(images) ? images.filter(Boolean) : [];
  const [idx, setIdx] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  if (valid.length === 0) {
    return <div className={`h-14 w-14 rounded border bg-muted ${className || ''}`} />;
  }
  const go = (delta: number) => setIdx((i) => (i + delta + valid.length) % valid.length);
  const openLightbox = () => setLightboxOpen(true);
  const closeLightbox = () => setLightboxOpen(false);
  const setIndex = (i: number) => setIdx(((i % valid.length) + valid.length) % valid.length);
  return (
    <div className={`relative h-14 w-14 ${className || ''}`}>
      <img
        src={valid[idx]}
        alt="item"
        className="h-14 w-14 object-cover rounded border cursor-zoom-in"
        onClick={(e) => { e.stopPropagation(); openLightbox(); }}
      />
      {valid.length > 1 && (
        <>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); go(-1); }}
            className="absolute left-0 top-1/2 -translate-y-1/2 h-6 w-6 flex items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/70"
            aria-label="Previous image"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); go(1); }}
            className="absolute right-0 top-1/2 -translate-y-1/2 h-6 w-6 flex items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/70"
            aria-label="Next image"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 mb-0.5 px-1.5 py-0.5 rounded bg-black/50 text-white">
            {idx + 1}/{valid.length}
          </div>
        </>
      )}

      {/* Lightbox Dialog */}
      <Dialog open={lightboxOpen} onOpenChange={setLightboxOpen}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden">
          <DialogHeader className="sr-only">
            <DialogTitle>Image Preview</DialogTitle>
          </DialogHeader>
          <div className="relative bg-black">
            {/* Large Image */}
            <img
              src={valid[idx]}
              alt={`preview-${idx + 1}`}
              className="max-h-[80vh] w-full object-contain bg-black"
              onClick={(e) => { e.stopPropagation(); closeLightbox(); }}
            />
            {/* Controls */}
            {valid.length > 1 && (
              <>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); go(-1); }}
                  className="absolute left-2 top-1/2 -translate-y-1/2 h-9 w-9 flex items-center justify-center rounded-full bg-white/20 text-white hover:bg-white/30"
                  aria-label="Previous"
                >
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); go(1); }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-9 w-9 flex items-center justify-center rounded-full bg-white/20 text-white hover:bg-white/30"
                  aria-label="Next"
                >
                  <ChevronRight className="h-5 w-5" />
                </button>
                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-white text-xs bg-black/40 rounded px-2 py-0.5">
                  {idx + 1} / {valid.length}
                </div>
              </>
            )}
          </div>

          {/* Thumbnails row (only if multiple) */}
          {valid.length > 1 && (
            <div className="flex gap-2 p-3 bg-background">
              {valid.map((src, i) => (
                <button
                  key={src + i}
                  type="button"
                  onClick={(e) => { e.stopPropagation(); setIndex(i); }}
                  className={`h-16 w-16 rounded border overflow-hidden ${i === idx ? 'ring-2 ring-gold' : ''}`}
                  aria-label={`Go to image ${i + 1}`}
                >
                  <img src={src} alt={`thumb-${i + 1}`} className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

export function AdminDashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useStore();
  const { showToast } = useToast();
  const [greeted, setGreeted] = useState(false);
  const [metricsLoading, setMetricsLoading] = useState(true);
  const [metrics, setMetrics] = useState({
    totalUsers: 0,
    totalSellers: 0,
    totalHelpingHands: 0,
    totalOrders: 0,
    totalDonations: 0,
    totalProductsPending: 0,
    totalProductsPublished: 0,
    approvedHelpingHands: 0,
    pendingHelpingHands: 0,
    hhAmountGiven: 0,
    productsCollected: 0,
    pendingSellerApprovals: 0,
    correctionsPending: 0,
  });

  useEffect(() => {
    const checkAdminStatus = async () => {
      try {
        setLoading(true);
        
        // Check if user is logged in
        const currentUser = auth.currentUser;
        if (!currentUser) {
          // If no user is logged in, redirect to admin login
          navigate('/admin-login');
          return;
        }
        
        // Check if user is an admin
        const userRef = doc(db, 'users', currentUser.uid);
        const userDoc = await getDoc(userRef);
        
        if (!userDoc.exists() || userDoc.data().role !== 'admin') {
          // If user is not an admin, redirect to admin login
          console.log('Non-admin user attempted to access admin dashboard');
          await auth.signOut(); // Sign out non-admin user
          navigate('/admin-login');
          return;
        }

        // Show welcome only right after admin login (navigated with state.justLoggedIn)
        const justLoggedIn = (location.state as any)?.justLoggedIn;
        if (justLoggedIn && !greeted) {
          const data = userDoc.data();
          const name = data?.displayName || currentUser.displayName || data?.email || 'Admin';
          showToast({ message: `Welcome, ${name}! 👋`, type: 'success', duration: 4000 });
          setGreeted(true);
          // Clear the navigation state so revisiting dashboard won't retrigger toast
          navigate('/admin-dashboard', { replace: true, state: {} });
        }
        
        setLoading(false);
      } catch (error) {
        console.error('Error checking admin status:', error);
        setError('Failed to verify admin privileges. Please try again later.');
        setLoading(false);
      }
    };

    checkAdminStatus();
  }, [navigate, showToast, greeted, location]);

  // Fetch metrics once admin check passes
  useEffect(() => {
    if (loading || error) return;
    let cancelled = false;
    async function fetchMetrics() {
      try {
        setMetricsLoading(true);
        const usersRef = collection(db, 'users');
        // Count regular users based on role in users collection
        const usersQ = query(usersRef, where('role', '==', 'user'));
        // Count sellers based on role in users collection
        const sellersQ = query(usersRef, where('role', '==', 'seller'));
        const helpingHandsRef = collection(db, 'helping-hands-requests');
        const ordersRef = collection(db, 'orders');
        const productsRef = collection(db, 'products');
        const publishedProductsQ = query(productsRef, where('published', '==', true));
        const approvedHHQ = query(helpingHandsRef, where('status', '==', 'approved'));
        const pendingHHQ = query(helpingHandsRef, where('status', '==', 'pending'));
        const sellerRegsRef = collection(db, 'seller-registrations');
        const pendingSellerRegsQ = query(sellerRegsRef, where('status', '==', 'pending'));
        const correctionsRef = collection(db, 'order-status-corrections');
        const corrPendingQ = query(correctionsRef, where('status', '==', 'pending'));

        const [
          usersCntSnap, 
          sellersCntSnap, 
          helpingCntSnap, 
          ordersCntSnap, 
          productsTotalCntSnap, 
          productsPublishedCntSnap, 
          pendingSellerRegsCntSnap, 
          corrPendingCntSnap,
          pendingHHCntSnap
        ] = await Promise.all([
          getCountFromServer(usersQ),
          getCountFromServer(sellersQ),
          getCountFromServer(helpingHandsRef),
          getCountFromServer(ordersRef),
          getCountFromServer(productsRef),
          getCountFromServer(publishedProductsQ),
          getCountFromServer(pendingSellerRegsQ),
          getCountFromServer(corrPendingQ),
          getCountFromServer(pendingHHQ)
        ]);

        // Sum donations from delivered orders
        const completedOrdersSnap = await getDocs(query(ordersRef, where('status', '==', 'delivered')));
        let donations = 0;
        completedOrdersSnap.forEach(d => {
          const val = (d.data() as any)?.donationFromUplift;
          if (typeof val === 'number' && !Number.isNaN(val)) donations += val;
        });

        // People helped (approved requests) and amount given from Helping Hands
        const approvedHHSnap = await getDocs(approvedHHQ);
        let hhAmount = 0;
        approvedHHSnap.forEach(docSnap => {
          const data: any = docSnap.data();
          const amt = data?.amountGiven;
          if (typeof amt === 'number' && !Number.isNaN(amt)) hhAmount += amt;
        });

        // Amount collected from products: sum over delivered orders of (item.price - sellerPrice) * quantity
        let collected = 0;
        try {
          // Load qualifying orders
          const qualifyingOrdersSnap = await getDocs(query(ordersRef, where('status', '==', 'delivered')));
          // Gather unique productIds from order items
          const productIdsSet = new Set<string>();
          const ordersData: any[] = [];
          qualifyingOrdersSnap.forEach(o => {
            const data: any = o.data();
            ordersData.push(data);
            const items = Array.isArray(data?.items) ? data.items : [];
            items.forEach((it: any) => {
              const pid = it?.productId || it?.id;
              if (pid && typeof pid === 'string') productIdsSet.add(pid);
            });
          });

          // Batch fetch product docs to get sellerPrice
          const productIds = Array.from(productIdsSet);
          const sellerPriceById = new Map<string, number>();
          for (let i = 0; i < productIds.length; i += 10) {
            const chunk = productIds.slice(i, i + 10);
            const chunkSnap = await getDocs(query(collection(db, 'products'), where(documentId(), 'in', chunk)));
            chunkSnap.forEach(d => {
              const pdata: any = d.data();
              const sp = Number(pdata?.sellerPrice ?? pdata?.price);
              if (Number.isFinite(sp)) sellerPriceById.set(d.id, sp);
            });
          }

          // Sum uplift across all order items
          ordersData.forEach((order: any) => {
            const items = Array.isArray(order?.items) ? order.items : [];
            items.forEach((it: any) => {
              const pid = it?.productId || it?.id;
              const qty = Number(it?.quantity ?? 1) || 1;
              const finalPriceItem = Number(it?.price ?? it?.finalPrice ?? 0);
              const sellerPriceItem = sellerPriceById.get(String(pid)) ?? Number(it?.sellerPrice ?? 0);
              if (Number.isFinite(finalPriceItem) && Number.isFinite(sellerPriceItem)) {
                const uplift = (finalPriceItem - sellerPriceItem) * qty;
                if (Number.isFinite(uplift)) collected += uplift;
              }
            });
          });
        } catch (e) {
          console.warn('Failed to compute collected from orders; falling back to 0', e);
        }

        if (!cancelled) {
          const pendingProducts = Math.max(0, (productsTotalCntSnap.data().count || 0) - (productsPublishedCntSnap.data().count || 0));
          setMetrics({
            totalUsers: usersCntSnap.data().count,
            totalSellers: sellersCntSnap.data().count,
            totalHelpingHands: helpingCntSnap.data().count,
            totalOrders: ordersCntSnap.data().count,
            totalDonations: Math.round(donations * 100) / 100,
            totalProductsPending: pendingProducts,
            totalProductsPublished: productsPublishedCntSnap.data().count || 0,
            approvedHelpingHands: approvedHHSnap.size || 0,
            pendingHelpingHands: pendingHHCntSnap.data().count || 0,
            hhAmountGiven: Math.round(hhAmount * 100) / 100,
            productsCollected: Math.round(collected * 100) / 100,
            pendingSellerApprovals: pendingSellerRegsCntSnap.data().count || 0,
            correctionsPending: corrPendingCntSnap.data().count || 0,
          });
        }
      } catch (e) {
        console.error('Failed to load dashboard metrics:', e);
      } finally {
        if (!cancelled) setMetricsLoading(false);
      }
    }
    fetchMetrics();
    return () => { cancelled = true; };
  }, [loading, error]);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-gold" />
        <p className="mt-4 text-muted-foreground">Loading admin dashboard...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <div className="bg-destructive/10 text-destructive p-4 rounded-md max-w-md text-center">
          <p>{error}</p>
          <Button 
            variant="outline" 
            className="mt-4"
            onClick={() => navigate('/')}
          >
            Return to Home
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Manage your platform and users
          </p>
        </div>
      </div>

      {/* Metrics overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card 
          className="h-full flex flex-col cursor-pointer transition hover:shadow-md"
          onClick={() => navigate('/admin/seller-approvals', { state: { tab: 'pending' } })}
        >
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-base">
                <AlertTriangle className="h-4 w-4 text-amber-500" />
                Seller Approvals
              </CardTitle>
              {!metricsLoading && (
                <div className="text-xs text-muted-foreground">
                  {metrics.pendingSellerApprovals} pending
                </div>
              )}
            </div>
            <CardDescription className="text-xs">Manage seller applications</CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            {metricsLoading ? (
              <div className="flex items-center justify-center h-16">
                <Loader2 className="h-4 w-4 animate-spin" />
              </div>
            ) : (
              <div className="text-2xl font-bold bg-gradient-to-r from-amber-500 to-yellow-500 bg-clip-text text-transparent">
                {metrics.pendingSellerApprovals}
              </div>
            )}
          </CardContent>
        </Card>
        <Card className="h-full flex flex-col">
          <div 
            className="cursor-pointer"
            onClick={() => navigate('/admin/users')}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Users className="h-4 w-4 text-indigo-500" />
                  Users
                </CardTitle>
                {!metricsLoading && (
                  <div className="text-xs text-muted-foreground">
                    {metrics.totalUsers + metrics.totalSellers} total
                  </div>
                )}
              </div>
              <CardDescription className="text-xs">Manage platform users and sellers</CardDescription>
            </CardHeader>
          </div>
          <div className="grid grid-cols-2 gap-0.5 px-0.5 pb-0.5">
            {/* Platform Users Section */}
            <div 
              className="p-3 cursor-pointer transition hover:bg-muted/30 rounded-md"
              onClick={() => navigate('/admin/users', { state: { tab: 'users' } })}
            >
              <div className="flex items-center gap-2 mb-1">
                <div className="p-1.5 rounded-full bg-indigo-100 dark:bg-indigo-900/30">
                  <Users className="h-3.5 w-3.5 text-indigo-500" />
                </div>
                <h3 className="text-sm font-medium">Users</h3>
              </div>
              {metricsLoading ? (
                <div className="h-6 flex items-center">
                  <Loader2 className="h-3.5 w-3.5 animate-spin mx-auto" />
                </div>
              ) : (
                <div className="text-xl font-bold text-indigo-500">
                  {metrics.totalUsers}
                </div>
              )}
            </div>

            {/* Approved Sellers Section */}
            <div 
              className="p-3 cursor-pointer transition hover:bg-muted/30 rounded-md"
              onClick={() => navigate('/admin/users', { state: { tab: 'sellers' } })}
            >
              <div className="flex items-center gap-2 mb-1">
                <div className="p-1.5 rounded-full bg-emerald-100 dark:bg-emerald-900/30">
                  <CheckSquare className="h-3.5 w-3.5 text-emerald-500" />
                </div>
                <h3 className="text-sm font-medium">Sellers</h3>
              </div>
              {metricsLoading ? (
                <div className="h-6 flex items-center">
                  <Loader2 className="h-3.5 w-3.5 animate-spin mx-auto" />
                </div>
              ) : (
                <div className="text-xl font-bold text-emerald-500">
                  {metrics.totalSellers}
                </div>
              )}
            </div>
          </div>
        </Card>

        <Card className="h-full flex flex-col">
          <div 
            className="cursor-pointer"
            onClick={() => navigate('/admin/helping-hands')}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-base">
                  <HeartHandshake className="h-4 w-4 text-rose-500" />
                  Helping Hands
                </CardTitle>
                {!metricsLoading && (
                  <div className="text-xs text-muted-foreground">
                    {metrics.pendingHelpingHands + metrics.approvedHelpingHands} total
                  </div>
                )}
              </div>
              <CardDescription className="text-xs">Manage helping hand requests</CardDescription>
            </CardHeader>
          </div>
          <div className="grid grid-cols-2 gap-0.5 px-0.5 pb-0.5">
            {/* Pending Requests Section */}
            <div 
              className="p-3 cursor-pointer transition hover:bg-muted/30 rounded-md"
              onClick={() => navigate('/admin/helping-hands', { state: { tab: 'pending' } })}
            >
              <div className="flex items-center gap-2 mb-1">
                <div className="p-1.5 rounded-full bg-amber-100 dark:bg-amber-900/30">
                  <AlertTriangle className="h-3.5 w-3.5 text-amber-500" />
                </div>
                <h3 className="text-sm font-medium">Pending</h3>
              </div>
              {metricsLoading ? (
                <div className="h-6 flex items-center">
                  <Loader2 className="h-3.5 w-3.5 animate-spin mx-auto" />
                </div>
              ) : (
                <div className="text-xl font-bold text-amber-500">
                  {metrics.pendingHelpingHands}
                </div>
              )}
            </div>

            {/* Approved Requests Section */}
            <div 
              className="p-3 cursor-pointer transition hover:bg-muted/30 rounded-md"
              onClick={() => navigate('/admin/helping-hands', { state: { tab: 'approved' } })}
            >
              <div className="flex items-center gap-2 mb-1">
                <div className="p-1.5 rounded-full bg-emerald-100 dark:bg-emerald-900/30">
                  <CheckSquare className="h-3.5 w-3.5 text-emerald-500" />
                </div>
                <h3 className="text-sm font-medium">Approved</h3>
              </div>
              {metricsLoading ? (
                <div className="h-6 flex items-center">
                  <Loader2 className="h-3.5 w-3.5 animate-spin mx-auto" />
                </div>
              ) : (
                <div className="text-xl font-bold text-emerald-500">
                  {metrics.approvedHelpingHands}
                </div>
              )}
            </div>
          </div>
        </Card>

        <Card className="h-full flex flex-col">
          <div 
            className="cursor-pointer"
            onClick={() => navigate('/admin/products')}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Package className="h-4 w-4 text-cyan-500" />
                  Products
                </CardTitle>
                {!metricsLoading && (
                  <div className="text-xs text-muted-foreground">
                    {metrics.totalProductsPending + metrics.totalProductsPublished} total
                  </div>
                )}
              </div>
              <CardDescription className="text-xs">Manage product listings</CardDescription>
            </CardHeader>
          </div>
          <div className="grid grid-cols-2 gap-0.5 px-0.5 pb-0.5">
            {/* Pending Products Section */}
            <div 
              className="p-3 cursor-pointer transition hover:bg-muted/30 rounded-md"
              onClick={() => navigate('/admin/products', { state: { tab: 'unpublished' } })}
            >
              <div className="flex items-center gap-2 mb-1">
                <div className="p-1.5 rounded-full bg-amber-100 dark:bg-amber-900/30">
                  <Package className="h-3.5 w-3.5 text-amber-500" />
                </div>
                <h3 className="text-sm font-medium">Pending</h3>
              </div>
              {metricsLoading ? (
                <div className="h-6 flex items-center">
                  <Loader2 className="h-3.5 w-3.5 animate-spin mx-auto" />
                </div>
              ) : (
                <div className="text-xl font-bold text-amber-500">
                  {metrics.totalProductsPending}
                </div>
              )}
            </div>

            {/* Published Products Section */}
            <div 
              className="p-3 cursor-pointer transition hover:bg-muted/30 rounded-md"
              onClick={() => navigate('/admin/products', { state: { tab: 'published' } })}
            >
              <div className="flex items-center gap-2 mb-1">
                <div className="p-1.5 rounded-full bg-emerald-100 dark:bg-emerald-900/30">
                  <Package className="h-3.5 w-3.5 text-emerald-500" />
                </div>
                <h3 className="text-sm font-medium">Published</h3>
              </div>
              {metricsLoading ? (
                <div className="h-6 flex items-center">
                  <Loader2 className="h-3.5 w-3.5 animate-spin mx-auto" />
                </div>
              ) : (
                <div className="text-xl font-bold text-emerald-500">
                  {metrics.totalProductsPublished}
                </div>
              )}
            </div>
          </div>
        </Card>


        <Card
          className="cursor-pointer transition hover:shadow-md bg-gradient-to-br from-card to-card/80"
          role="button"
          onClick={() => navigate('/admin/helping-hands', { state: { tab: 'approved' } })}
        >
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Heart className="h-5 w-5 text-rose-500" />
              People Helped
            </CardTitle>
            <CardDescription className="text-sm">Approved assistance requests</CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            {metricsLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                Loading…
              </div>
            ) : (
              <div className="space-y-2">
                <div className="text-3xl font-bold bg-gradient-to-r from-rose-500 to-pink-500 bg-clip-text text-transparent">
                  {metrics.approvedHelpingHands}
                </div>
                <div className="text-sm text-muted-foreground">
                  <span>Lives impacted through our platform</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card
          className="cursor-pointer transition hover:shadow-md bg-gradient-to-br from-card to-card/80"
          role="button"
          onClick={() => navigate('/admin/helping-hands', { state: { tab: 'approved' } })}
        >
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-lg">
              <span className="text-emerald-500 font-mono text-xl">₹</span>
              Amount Given
            </CardTitle>
            <CardDescription className="text-sm">Total assistance provided</CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            {metricsLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                Loading…
              </div>
            ) : (
              <div className="space-y-2">
                <div className="text-3xl font-bold bg-gradient-to-r from-emerald-500 to-teal-500 bg-clip-text text-transparent">
                  ₹{metrics.hhAmountGiven.toLocaleString()}
                </div>
                <div className="text-sm text-muted-foreground">
                  <span>Total financial assistance provided</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card
          className="cursor-pointer transition hover:shadow-md bg-gradient-to-br from-card to-card/80"
          role="button"
          onClick={() => navigate('/admin/products')}
        >
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Package className="h-5 w-5 text-cyan-500" />
              Collected from Products
            </CardTitle>
            <CardDescription className="text-sm">(final - seller) across delivered orders</CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            {metricsLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin"/>
                Loading…
              </div>
            ) : (
              <div className="space-y-2">
                <div className="text-3xl font-bold bg-gradient-to-r from-cyan-500 to-blue-500 bg-clip-text text-transparent">
                  ₹{metrics.productsCollected.toLocaleString()}
                </div>
                <div className="text-sm text-muted-foreground">
                  <span>From {metrics.totalProductsPublished} published products</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card
          className="cursor-pointer transition hover:shadow-md bg-gradient-to-br from-card to-card/80"
          role="button"
          onClick={() => navigate('/admin/orders')}
        >
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-lg">
              <ShoppingBag className="h-5 w-5 text-amber-500" />
              Total Orders
            </CardTitle>
            <CardDescription className="text-sm">All orders in the system</CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            {metricsLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                Loading…
              </div>
            ) : (
              <div className="space-y-2">
                <div className="text-3xl font-bold bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent">
                  {metrics.totalOrders}
                </div>
                <div className="text-sm text-muted-foreground">
                  <span>Track and manage all orders</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card
          className="cursor-pointer transition hover:shadow-md bg-gradient-to-br from-card to-card/80"
          role="button"
          onClick={() => navigate('/admin/order-corrections', { state: { tab: 'pending' } })}
        >
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Wrench className="h-5 w-5 text-violet-500" />
              Order Corrections
            </CardTitle>
            <CardDescription className="text-sm">User-submitted fixes</CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            {metricsLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                Loading…
              </div>
            ) : (
              <div className="space-y-2">
                <div className="text-3xl font-bold bg-gradient-to-r from-violet-500 to-purple-500 bg-clip-text text-transparent">
                  {metrics.correctionsPending}
                </div>
                <div className="text-sm text-muted-foreground">
                  <span>Pending resolution</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card
          className="bg-gradient-to-br from-rose-50 to-rose-50/70 dark:from-rose-900/20 dark:to-rose-900/10 hover:from-rose-100 hover:to-rose-100/70 dark:hover:from-rose-900/30 dark:hover:to-rose-900/20 transition-all duration-200 cursor-pointer border border-rose-100 dark:border-rose-900/30 shadow-sm hover:shadow-md"
          onClick={() => navigate('/admin/orders', { state: { status: 'delivered' } })}
        >
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-lg">
                <div className="p-2 rounded-lg bg-rose-100 dark:bg-rose-900/30">
                  <Heart className="h-5 w-5 text-rose-600 dark:text-rose-400" />
                </div>
                <span>Total Donations</span>
              </CardTitle>
              <div className="text-sm text-muted-foreground">
                {metricsLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                ) : (
                  <span>Sum from delivered orders</span>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="flex items-end justify-between">
              <div className="text-3xl font-bold text-rose-700 dark:text-rose-300">
                {metricsLoading ? (
                  <div className="h-10 w-32 bg-muted rounded animate-pulse"></div>
                ) : (
                  `₹${metrics.totalDonations?.toLocaleString('en-IN', { maximumFractionDigits: 0 }) || '0'}` 
                )}
              </div>
              {!metricsLoading && (
                <div className="text-sm text-muted-foreground flex items-center gap-1">
                  <span className="text-emerald-500">
                    <TrendingUp className="h-4 w-4 inline" />
                  </span>
                  <span>Last 30d</span>
                </div>
              )}
            </div>
            {!metricsLoading && (
              <div className="mt-2 text-xs text-muted-foreground">
                {metrics.totalDonations > 0 ? (
                  <span>Click to view all delivered orders</span>
                ) : (
                  <span>No donations yet</span>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="sm:col-span-2 lg:col-span-1 bg-gradient-to-br from-card to-card/80">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2"><BarChart2 className="h-5 w-5"/>Profit / Loss</CardTitle>
            <CardDescription className="text-sm">Collected − Amount Given (goal: neutral)</CardDescription>
          </CardHeader>
          <CardContent className="pt-0">
            {metricsLoading ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin"/>
                Loading…
              </div>
            ) : (
              (() => {
                const net = metrics.productsCollected - metrics.hhAmountGiven;
                const isProfit = net > 0;
                const isLoss = net < 0;
                const gradient = isProfit 
                  ? 'from-emerald-500 to-green-500' 
                  : isLoss 
                    ? 'from-red-500 to-rose-500' 
                    : 'from-muted-foreground to-muted-foreground';
                const label = isProfit ? 'Profit' : isLoss ? 'Loss' : 'Neutral';
                
                return (
                  <div className="space-y-2">
                    <div className={`text-3xl font-bold bg-gradient-to-r ${gradient} bg-clip-text text-transparent`}>
                      ₹{Math.abs(net).toLocaleString()}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="inline-flex items-center">
                        <span className="w-2 h-2 rounded-full bg-cyan-400 mr-1.5"></span>
                        <span>₹{metrics.productsCollected.toLocaleString()} collected</span>
                      </span>
                      <span className="inline-flex items-center">
                        <span className="w-2 h-2 rounded-full bg-pink-400 mr-1.5"></span>
                        <span>₹{metrics.hhAmountGiven.toLocaleString()} given</span>
                      </span>
                    </div>
                  </div>
                );
              })()
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// AdminOrdersPage moved to its own file at src/pages/AdminOrdersPage.tsx
// AdminAnalyticsPage moved to its own file at src/pages/AdminAnalyticsPage.tsx
// AdminHelpingHandsPage moved to its own file at src/pages/AdminHelpingHandsPage.tsx
// AdminOrderCorrectionsPage moved to its own file at src/pages/AdminOrderCorrectionsPage.tsx
// AdminProductsPage moved to its own file at src/pages/AdminProductsPage.tsx
