import { useEffect, useMemo, useRef, useState } from 'react';
import { useParams, useSearchParams, Link, useNavigate } from 'react-router-dom';
import { collection, onSnapshot, doc, getDoc, setDoc, addDoc, serverTimestamp, query, orderBy, updateDoc, where, getDocs } from 'firebase/firestore';
import { db, auth, storage } from '@/lib/firebase';
import { ref as storageRef, uploadBytes, getDownloadURL } from 'firebase/storage';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Check, CheckCheck } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { useStore } from '@/store/useStore';

interface ChatDoc {
  id: string;
  orderId: string;
  productId: string;
  buyerId: string;
  sellerId: string;
  createdAt?: any;
  lastReadBuyerAt?: any;
  lastReadSellerAt?: any;
  typingBuyer?: boolean;
  typingSeller?: boolean;
}

interface MessageDoc {
  id: string;
  text: string;
  senderId: string;
  createdAt?: any;
}

export default function CustomizeChat() {
  const { productId = '' } = useParams();
  const [params] = useSearchParams();
  const orderId = params.get('orderId') || '';
  const from = params.get('from') || '';
  const { user } = useStore();
  const navigate = useNavigate();

  const [chat, setChat] = useState<ChatDoc | null>(null);
  const [messages, setMessages] = useState<MessageDoc[]>([]);
  const [input, setInput] = useState('');
  const [files, setFiles] = useState<FileList | null>(null);
  const [redactionNotice, setRedactionNotice] = useState<string | null>(null);
  const [permError, setPermError] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const listRef = useRef<HTMLDivElement | null>(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showNewMsgBanner, setShowNewMsgBanner] = useState(false);
  const [otherTyping, setOtherTyping] = useState(false);
  const typingTimer = useRef<number | null>(null);
  const [isWindowFocused, setIsWindowFocused] = useState(true);

  const uid = auth.currentUser?.uid || user?.uid || (user as any)?.id || null;
  const isBuyer = useMemo(() => {
    if (!uid || !chat) return null;
    return uid === chat.buyerId ? true : (uid === chat.sellerId ? false : null);
  }, [uid, chat]);

  // Auto-scroll
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  // Track window focus for notification heuristics
  useEffect(() => {
    const onFocus = () => setIsWindowFocused(true);
    const onBlur = () => setIsWindowFocused(false);
    window.addEventListener('focus', onFocus);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('focus', onFocus);
      window.removeEventListener('blur', onBlur);
    };
  }, []);

  const formatDateLabel = (ts: any) => {
    const d = ts?.toDate ? ts.toDate() : new Date();
    const today = new Date();
    const yday = new Date();
    yday.setDate(today.getDate() - 1);
    const sameDay = (a: Date, b: Date) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
    if (sameDay(d, today)) return 'Today';
    if (sameDay(d, yday)) return 'Yesterday';
    return d.toDateString();
  };

  // Guard: require login and required params
  useEffect(() => {
    if (!uid) return; // App router already has login flows elsewhere; we keep this simple
    if (!productId || !orderId) return;

    let unsub: (() => void) | undefined;

    (async () => {
      try {
        // Load product to determine seller
        const productSnap = await getDoc(doc(db, 'products', productId));
        const sellerIdFromProduct = (productSnap.exists() ? (productSnap.data() as any)?.sellerId : null) || '';
        if (!sellerIdFromProduct) {
          console.warn('Product or seller not found or missing sellerId on product');
        }

        // Validate order belongs to current user (client-side check for clearer messaging)
        const orderSnap = await getDoc(doc(db, 'orders', orderId));
        const orderData = orderSnap.exists() ? (orderSnap.data() as any) : null;
        const orderUserId = orderData?.userId ?? null;
        if (!orderSnap.exists()) {
          setPermError('Order not found. Open customization from your Orders page.');
          return;
        }
        if (orderUserId !== uid) {
          setPermError('This order does not belong to your account.');
          return;
        }
        // Fallback: try to resolve sellerId from the order item if product is missing sellerId
        const itemFromOrder = Array.isArray(orderData?.items) ? orderData.items.find((it: any) => it?.productId === productId) : null;
        const sellerIdFromOrder = itemFromOrder?.sellerId || (Array.isArray(orderData?.sellerIds) ? orderData.sellerIds[0] : '');
        const resolvedSellerId = sellerIdFromProduct || sellerIdFromOrder || '';

        if (!resolvedSellerId) {
          setPermError('Unable to determine seller for this product/order. Please contact support.');
          return;
        }

        console.debug('CustomizeChat init', { uid, orderId, productId, sellerIdFromProduct, sellerIdFromOrder, resolvedSellerId });

        // Deterministic chat id (buyer-product-order) to avoid duplicates
        const chatId = `${orderId}_${productId}_${uid}`;
        const chatRef = doc(db, 'customizationChats', chatId);
        const existing = await getDoc(chatRef);
        if (!existing.exists()) {
          await setDoc(chatRef, {
            orderId,
            productId,
            buyerId: uid,
            sellerId: resolvedSellerId,
            createdAt: serverTimestamp(),
          });
        }

        // Subscribe to chat
        unsub = onSnapshot(chatRef, (snap) => {
          if (snap.exists()) {
            setChat({ id: snap.id, ...(snap.data() as any) });
          }
        }, (err) => {
          console.error('Chat subscribe error', err);
          setPermError('You do not have access to this customization chat. Make sure you opened it from your purchased order.');
        });

        // Subscribe to messages
        const msgsQ = query(collection(chatRef, 'messages'), orderBy('createdAt', 'asc'));
        const unsubMsgs = onSnapshot(msgsQ, (snap) => {
          const list: MessageDoc[] = [];
          snap.forEach((d) => list.push({ id: d.id, ...(d.data() as any) }));
          setMessages(list);
          // If a new message from the other party arrives and not focused or not at bottom, show banner
          const last = list[list.length - 1];
          const isFromOther = last && uid && last.senderId !== uid;
          const nearBottom = (() => {
            const el = listRef.current;
            if (!el) return true;
            const threshold = 80; // px
            return el.scrollHeight - el.scrollTop - el.clientHeight < threshold;
          })();
          if (last && isFromOther && (!isWindowFocused || !nearBottom)) {
            setShowNewMsgBanner(true);
          }
        }, (err) => {
          console.error('Messages subscribe error', err);
          setPermError('You do not have access to this customization chat.');
        });

        // Cleanup
        return () => {
          try { unsub && unsub(); } catch {}
          try { unsubMsgs && unsubMsgs(); } catch {}
        };
      } catch (e: any) {
        console.error('Failed to initialize customization chat', e);
        setPermError('Permission denied. You can request customization only for orders you purchased.');
      }
    })();

    return () => {
      try { unsub && unsub(); } catch {}
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [uid, productId, orderId]);

  const canSend = useMemo(
    () => {
      const hasImages = files ? Array.from(files).some(f => f.type?.startsWith('image/')) : false;
      return Boolean(uid && chat && (input.trim().length > 0 || hasImages));
    },
    [uid, chat, input, files]
  );

  // Redact sensitive info from outbound messages
  const sanitizeMessage = (raw: string) => {
    let text = raw;
    let redacted = false;
    const replacements: Array<{ pattern: RegExp; desc: string }> = [
      // Emails
      { pattern: /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, desc: 'email' },
      // URLs
      { pattern: /(https?:\/\/\S+|www\.[^\s]+)/gi, desc: 'url' },
      // Phone-like sequences (10+ digits possibly separated)
      { pattern: /\+?\d[\d\s\-().]{8,}\d/gi, desc: 'phone' },
      // Long digit sequences (cards, account numbers)
      { pattern: /\b\d{10,}\b/g, desc: 'long-number' },
      // Common UPI/payment handles
      { pattern: /\b[\w.-]+@(okicici|okaxis|ybl|ibl|upi|paytm|sbi|axisbank|icici|ibl|axl)\b/gi, desc: 'upi' },
    ];
    for (const { pattern } of replacements) {
      if (pattern.test(text)) {
        redacted = true;
        text = text.replace(pattern, '[redacted]');
      }
    }
    return { text: text.trim(), redacted };
  };

  const send = async () => {
    if (!canSend || !chat) return;
    const { text, redacted } = sanitizeMessage(input);
    setInput('');
    try {
      // Handle attachments upload if any
      let attachments: Array<{ url: string; name: string; contentType?: string; size?: number }> = [];
      if (files && files.length > 0) {
        const imageFiles = Array.from(files).filter((f) => f.type?.startsWith('image/'));
        if (imageFiles.length !== files.length) {
          setRedactionNotice('Only images can be attached. Non-image files were ignored.');
          setTimeout(() => setRedactionNotice(null), 3500);
        }
        const uploads = imageFiles.map(async (f) => {
          const path = `customizationChats/${chat.id}/${uid}/${Date.now()}_${f.name}`;
          const r = storageRef(storage, path);
          const snap = await uploadBytes(r, f, { contentType: f.type });
          const url = await getDownloadURL(snap.ref);
          return { url, name: f.name, contentType: f.type || undefined, size: f.size };
        });
        attachments = await Promise.all(uploads);
      }
      // Clear selected files after successful upload preparation
      setFiles(null);
      await addDoc(collection(db, 'customizationChats', chat.id, 'messages'), {
        text,
        senderId: uid,
        createdAt: serverTimestamp(),
        ...(attachments.length > 0 ? { attachments } : {}),
      });
      // Mark my side as typing false after send
      try {
        await updateDoc(doc(db, 'customizationChats', chat.id), {
          [isBuyer ? 'typingBuyer' : 'typingSeller']: false,
        } as any);
      } catch {}
      if (redacted) {
        setRedactionNotice('Some sensitive info (phone/email/URL/payment handle) was removed to protect your privacy.');
        setTimeout(() => setRedactionNotice(null), 3500);
      }
    } catch (e) {
      console.error('Failed to send message', e);
    }
  };

  // Update read receipts when viewing chat or focusing window
  const markRead = useMemo(() => async () => {
    if (!chat || isBuyer === null) return;
    try {
      await updateDoc(doc(db, 'customizationChats', chat.id), {
        [isBuyer ? 'lastReadBuyerAt' : 'lastReadSellerAt']: serverTimestamp(),
      } as any);
      setUnreadCount(0);
      setShowNewMsgBanner(false);
    } catch {}
  }, [chat, isBuyer]);

  useEffect(() => {
    if (!chat || isBuyer === null) return;
    // Listener to compute unread count for current user
    const lastReadField = isBuyer ? 'lastReadBuyerAt' : 'lastReadSellerAt';
    const otherId = isBuyer ? chat.sellerId : chat.buyerId;
    const doCount = async () => {
      try {
        const chatRef = doc(db, 'customizationChats', chat.id);
        const c = await getDoc(chatRef);
        const lastRead = (c.exists() ? (c.data() as any)[lastReadField] : null);
        const col = collection(db, 'customizationChats', chat.id, 'messages');
        let q = query(col, where('senderId', '==', otherId));
        if (lastRead?.toMillis) {
          // Firestore can compare timestamps directly; but since we cannot combine inequality with equality easily without index here,
          // fallback to client-side filter after fetch ordered by createdAt desc limited
          q = query(col, where('senderId', '==', otherId), orderBy('createdAt', 'desc'));
        } else {
          q = query(col, where('senderId', '==', otherId), orderBy('createdAt', 'desc'));
        }
        const snap = await getDocs(q);
        let count = 0;
        snap.forEach((d) => {
          const data = d.data() as any;
          if (!lastRead || (data.createdAt && lastRead && data.createdAt.toMillis && data.createdAt.toMillis() > lastRead.toMillis())) {
            count += 1;
          }
        });
        setUnreadCount(count);
      } catch (e) {
        // silent
      }
    };
    doCount();
  }, [chat, isBuyer]);

  // Mark read on focus and when scrolled near bottom
  useEffect(() => {
    if (!listRef.current) return;
    const el = listRef.current;
    const onScroll = () => {
      const threshold = 60;
      const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < threshold;
      if (nearBottom) {
        markRead();
      }
    };
    el.addEventListener('scroll', onScroll);
    return () => el.removeEventListener('scroll', onScroll);
  }, [markRead]);

  useEffect(() => {
    if (isWindowFocused) markRead();
  }, [isWindowFocused, markRead]);

  // Typing indicator: update my typing flag and watch other party typing
  useEffect(() => {
    if (!chat || isBuyer === null) return;
    const otherField = isBuyer ? 'typingSeller' : 'typingBuyer';
    // Subscribe to chat to observe other typing flag
    const chatRef = doc(db, 'customizationChats', chat.id);
    const unsub = onSnapshot(chatRef, (snap) => {
      const data = snap.data() as any;
      setOtherTyping(Boolean(data?.[otherField]));
    });
    return () => { try { unsub(); } catch {} };
  }, [chat, isBuyer]);

  const handleInputChange = async (val: string) => {
    setInput(val);
    if (!chat || isBuyer === null) return;
    const field = isBuyer ? 'typingBuyer' : 'typingSeller';
    try {
      await updateDoc(doc(db, 'customizationChats', chat.id), { [field]: true } as any);
    } catch {}
    if (typingTimer.current) window.clearTimeout(typingTimer.current);
    typingTimer.current = window.setTimeout(async () => {
      try {
        await updateDoc(doc(db, 'customizationChats', chat.id), { [field]: false } as any);
      } catch {}
    }, 1200);
  };

  if (!productId || !orderId) {
    return (
      <div className="min-h-screen pt-20 pb-12 container mx-auto px-4">
        <Card className="p-6">
          <h1 className="text-xl font-semibold mb-2">Customization</h1>
          <p className="text-sm text-muted-foreground">Missing product or order information.</p>
        </Card>
      </div>
    );
  }

  // Basic route guard: if not signed in, prompt to login
  if (!uid) {
    return (
      <div className="min-h-screen pt-20 pb-12 container mx-auto px-4">
        <Card className="p-6 space-y-4">
          <h1 className="text-xl font-semibold">Sign in required</h1>
          <p className="text-sm text-muted-foreground">Please sign in to request customization.</p>
          <Button onClick={() => navigate(`/login?redirect=/customize/${productId}?orderId=${orderId}`)} className="bg-gold text-black">Sign in</Button>
        </Card>
      </div>
    );
  }

  // Quick replies (buyer side)
  const quickReplies = [
    "Thanks for your quick response!",
    "Here are my preferred colors/sizes:",
    "I need this by next week, is that okay?",
    "Sharing a reference image/notes:",
  ];

  return (
    <div className="min-h-screen pt-20 pb-24 container mx-auto px-4">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold">Request customization</h1>
            {unreadCount > 0 && (
              <span className="inline-flex items-center justify-center text-xs bg-amber-500 text-black rounded-full px-2 py-0.5" title="Unread messages">
                {unreadCount} new
              </span>
            )}
          </div>
          {from === 'buyer-chats' ? (
            <Button asChild variant="outline">
              <Link to="/buyer/customizations">Back to chats</Link>
            </Button>
          ) : from === 'product' ? (
            <Button variant="outline" onClick={() => navigate(-1)}>Back</Button>
          ) : (
            <Button asChild variant="outline">
              <Link to={`/orders?highlight=${orderId}`}>Back to order</Link>
            </Button>
          )}
        </div>
        {permError && (
          <div className="mb-3 text-sm text-red-600 bg-red-50 border border-red-200 rounded p-2">
            {permError}
          </div>
        )}
        <Card className="p-0 overflow-hidden">
          <div
            ref={listRef}
            className="h-[60vh] overflow-y-auto overscroll-contain p-4 space-y-3 bg-muted/20"
            onWheel={(e) => {
              const el = listRef.current;
              if (!el) return;
              // If the container can scroll further, consume the wheel event so the page doesn't scroll
              const atTop = el.scrollTop === 0;
              const atBottom = Math.ceil(el.scrollTop + el.clientHeight) >= el.scrollHeight;
              if ((e.deltaY < 0 && !atTop) || (e.deltaY > 0 && !atBottom)) {
                e.preventDefault();
                e.stopPropagation();
                el.scrollTop += e.deltaY;
              }
            }}
          >
            {messages.map((m, idx) => {
              const prev = messages[idx - 1];
              const showDate = !prev || (prev.createdAt?.toDate?.() && m.createdAt?.toDate?.() && prev.createdAt.toDate().toDateString() !== m.createdAt.toDate().toDateString());
              const mine = m.senderId === uid;
              const timeStr = m.createdAt?.toDate ? new Date(m.createdAt.toDate()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
              const isSeenBySeller = (() => {
                if (!chat) return false;
                const otherRead = (chat as any)?.lastReadSellerAt;
                return Boolean(mine && otherRead && m.createdAt?.toMillis && otherRead?.toMillis && otherRead.toMillis() >= m.createdAt.toMillis());
              })();
              return (
                <div key={m.id}>
                  {showDate && (
                    <div className="flex justify-center my-2">
                      <span className="text-[11px] px-2 py-1 rounded-full bg-white border text-gray-700 dark:bg-gray-800 dark:text-gray-200">{formatDateLabel(m.createdAt)}</span>
                    </div>
                  )}
                  <div className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${mine ? 'ml-auto bg-gold text-black' : 'mr-auto bg-white text-gray-900 border dark:bg-gray-800 dark:text-gray-100'}`}>
                    <div>{m.text}</div>
                    {Array.isArray((m as any).attachments) && (m as any).attachments.length > 0 && (
                      <div className="mt-2 space-y-2">
                        {(m as any).attachments.map((att: any, i: number) => (
                          <div key={i}>
                            {att.contentType && att.contentType.startsWith('image/') ? (
                              <button type="button" onClick={() => setPreviewUrl(att.url)} className="focus:outline-none">
                                <img src={att.url} alt={att.name} className="max-h-48 rounded-md border" />
                              </button>
                            ) : (
                              <a href={att.url} target="_blank" rel="noreferrer" className="text-xs underline">
                                {att.name || 'Attachment'}
                              </a>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                    <div className={`mt-1 flex items-center gap-1 text-[10px] opacity-70 ${mine ? 'text-black/70 justify-end' : 'text-gray-600 dark:text-gray-300 justify-end'}`}>
                      <span>{timeStr}</span>
                      {mine && (isSeenBySeller ? <CheckCheck className="h-3 w-3" /> : <Check className="h-3 w-3" />)}
                    </div>
                  </div>
                </div>
              );
            })}
            <div ref={bottomRef} />
          </div>
          {otherTyping && (
            <div className="px-4 pb-2 text-xs text-muted-foreground">The other person is typing…</div>
          )}
          <div className="p-3 border-t flex items-center gap-2">
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={(e) => setFiles(e.target.files)}
              className="text-xs"
            />
            <input
              value={input}
              onChange={(e) => handleInputChange(e.target.value)}
              placeholder="Describe the customization you need..."
              className="flex-1 rounded-md border px-3 py-2 text-sm bg-background"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
            />
            <Button
              onClick={send}
              disabled={!canSend}
              className="bg-gold text-black"
              title={!canSend ? (chat ? 'Type a message or attach a file to send' : 'Chat not available') : undefined}
            >
              Send
            </Button>
          </div>
        </Card>
        {/* Image preview modal */}
        <Dialog open={!!previewUrl} onOpenChange={(o) => { if (!o) setPreviewUrl(null); }}>
          <DialogContent className="max-w-4xl p-2 bg-background/95">
            <DialogTitle className="sr-only">Image preview</DialogTitle>
            <DialogDescription className="sr-only">Full-size preview of the selected attachment image.</DialogDescription>
            {previewUrl && (
              <img src={previewUrl} alt="Preview" className="max-h-[80vh] w-auto mx-auto rounded-lg" />
            )}
          </DialogContent>
        </Dialog>
        {/* Quick replies */}
        <div className="mt-3 flex flex-wrap gap-2">
          {quickReplies.map((q, i) => (
            <button
              key={i}
              className="text-xs px-2 py-1 rounded-full border bg-white hover:bg-muted dark:bg-gray-800"
              onClick={() => setInput((p) => (p ? p + ' ' + q : q))}
            >
              {q}
            </button>
          ))}
        </div>
        {showNewMsgBanner && (
          <div className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-black/80 text-white text-xs px-3 py-2 rounded-full shadow" onClick={() => { setShowNewMsgBanner(false); bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }}>
            New message — tap to jump
          </div>
        )}
        {redactionNotice && (
          <p className="text-xs text-amber-600 mt-2">{redactionNotice}</p>
        )}
        <p className="text-xs text-muted-foreground mt-2">
          Avoid sharing phone numbers or payment details here. Our team may review these chats for safety.
        </p>
      </div>
    </div>
  );
}
