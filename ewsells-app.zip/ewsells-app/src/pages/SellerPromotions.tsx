import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useStore } from '@/store/useStore';
import { firestoreService } from '@/services/firebase';
import { db } from '@/lib/firebase';
import { collection, getDocs, query, where } from 'firebase/firestore';
import type { Product } from '@/types';

export default function SellerPromotionsPage() {
  const { user } = useStore();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<Product[]>([]);
  const [selected, setSelected] = useState<Record<string, boolean>>({});
  const [duration, setDuration] = useState<string>('7');
  const [submitting, setSubmitting] = useState(false);
  const [requests, setRequests] = useState<any[]>([]);
  const [queryText, setQueryText] = useState('');
  const [selectAll, setSelectAll] = useState(false);
  const [openIds, setOpenIds] = useState<Record<string, boolean>>({});
  const [requestsExpanded, setRequestsExpanded] = useState(false);
  const toMs = (v: any): number => {
    if (!v) return 0;
    if (typeof v?.toMillis === 'function') return v.toMillis();
    if (v instanceof Date) return v.getTime();
    const t = new Date(v).getTime();
    return Number.isFinite(t) ? t : 0;
  };

  useEffect(() => {
    if (!user) return;
    (async () => {
      try {
        setLoading(true);
        const list = await firestoreService.getSellerProducts(user.id);
        // Only show published products for promotion
        const publishedList = list.filter((p) => !!p.published);
        setProducts(publishedList);

        // Load current seller requests for context
        const reqQ = query(collection(db, 'promotion-requests'), where('sellerId', '==', user.id));
        const snap = await getDocs(reqQ);
        const reqList = snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
        const sorted = [...reqList].sort((a: any, b: any) => {
          const aMs = toMs(a.updatedAt) || toMs(a.createdAt);
          const bMs = toMs(b.updatedAt) || toMs(b.createdAt);
          return bMs - aMs;
        });
        setRequests(sorted);
        if (sorted.length > 0) {
          setOpenIds({ [sorted[0].id]: true });
        } else {
          setOpenIds({});
        }
      } catch (e) {
        console.error('Failed to load seller products or requests', e);
      } finally {
        setLoading(false);
      }
    })();
  }, [user?.id]);

  const selectedIds = useMemo(() => Object.keys(selected).filter((id) => selected[id]), [selected]);
  const filteredProducts = useMemo(() => {
    const q = queryText.trim().toLowerCase();
    if (!q) return products;
    return products.filter((p) =>
      (p.title || '').toLowerCase().includes(q) ||
      (p.category || '').toLowerCase().includes(q)
    );
  }, [products, queryText]);

  useEffect(() => {
    // keep select all in sync with filtered list
    if (filteredProducts.length === 0) {
      setSelectAll(false);
      return;
    }
    const allSelected = filteredProducts.every((p) => !!selected[p.id]);
    setSelectAll(allSelected);
  }, [filteredProducts, selected]);

  const submit = async () => {
    if (!user) return;
    if (selectedIds.length === 0) {
      alert('Please select at least one product to promote.');
      return;
    }
    // Use seller-chosen duration; amount is set by admin later (store 0 for now)
    const days = Number(duration);
    if (!days || days <= 0) {
      alert('Please enter a valid duration.');
      return;
    }

    try {
      setSubmitting(true);
      await firestoreService.createPromotionRequest({
        sellerId: user.id,
        productIds: selectedIds,
        amount: 0,
        durationDays: days,
      });
      // Refresh list
      const reqQ = query(collection(db, 'promotion-requests'), where('sellerId', '==', user.id));
      const snap = await getDocs(reqQ);
      const refreshed = snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
      const resorted = [...refreshed].sort((a: any, b: any) => {
        const aMs = toMs(a.updatedAt) || toMs(a.createdAt);
        const bMs = toMs(b.updatedAt) || toMs(b.createdAt);
        return bMs - aMs;
      });
      setRequests(resorted);
      if (resorted.length > 0) {
        setOpenIds({ [resorted[0].id]: true });
      } else {
        setOpenIds({});
      }
      setSelected({});
      alert('Promotion request sent to Admin. You will be able to checkout once Admin sets the amount.');
      navigate('/seller/promotions');
    } catch (e) {
      console.error('Failed to submit promotion', e);
      alert('Failed to submit promotion request.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container mx-auto px-6 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Promote Your Products</h1>
        <div className="mt-1 h-0.5 w-28 bg-gradient-to-r from-gold via-amber-400 to-gold rounded-full" />
        <p className="text-muted-foreground mt-3">Select products to feature as trending on the user home page. Your request will be reviewed by admin. A fee applies per campaign.</p>
      </div>

      {loading ? (
        <div>Loading...</div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {/* Toolbar */}
            <div className="mb-4 flex flex-col md:flex-row md:items-center gap-3">
              <div className="flex items-center gap-2">
                <Button
                  variant="default"
                  className={`btn-hover rounded-full ${selectAll ? 'bg-gold text-black hover:bg-gold/90' : ''}`}
                  onClick={() => {
                    const next = !selectAll;
                    const patch: Record<string, boolean> = { ...selected };
                    filteredProducts.forEach((p) => (patch[p.id] = next));
                    setSelected(patch);
                    setSelectAll(next);
                  }}
                >
                  {selectAll ? 'Unselect All (visible)' : 'Select All (visible)'}
                </Button>
                {selectedIds.length > 0 && (
                  <Button
                    variant="outline"
                    className="btn-hover"
                    onClick={() => setSelected({})}
                  >
                    Clear selection
                  </Button>
                )}
              </div>
              <div className="relative w-full max-w-sm">
                <input
                  type="text"
                  placeholder="Search products..."
                  className="w-full rounded-full bg-background/60 border border-white/10 px-4 py-2 pl-10 backdrop-blur-sm focus:outline-none focus:ring-2 focus:ring-amber-400/40"
                  value={queryText}
                  onChange={(e) => setQueryText(e.target.value)}
                />
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground"><circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.3-4.3"></path></svg>
              </div>
            </div>

            {/* Selected header */}
            <div className="mb-2 text-sm text-muted-foreground">
              Selected: <span className="text-foreground font-medium">{selectedIds.length}</span>
            </div>

            {/* Product grid */}
            {products.length === 0 ? (
              <Card className="p-6 bg-background/50 border-white/10 text-muted-foreground">No products yet. Please upload products first.</Card>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                {filteredProducts.map((p) => (
                  <Card
                    key={p.id}
                    className={`relative overflow-hidden card-hover bg-white/5 border-white/10 transition-all duration-200 h-full ${selected[p.id] ? 'ring-1 ring-gold/60 shadow-gold/20' : 'hover:shadow-lg hover:shadow-black/10'}`}
                  >
                    <button
                      onClick={() => setSelected((prev) => ({ ...prev, [p.id]: !prev[p.id] }))}
                      className="w-full text-left"
                      aria-pressed={!!selected[p.id]}
                    >
                      {/* Image */}
                      <div className="relative">
                        <div className="aspect-[4/3] w-full overflow-hidden bg-background/40">
                          <img src={p.images?.[0] || '/images/charity-background.svg'} alt={p.title} className="h-full w-full object-cover" />
                        </div>
                        {/* Custom selection indicator */}
                        <span className={`absolute top-2 left-2 inline-flex h-7 w-7 items-center justify-center rounded-full border ${selected[p.id] ? 'bg-gold text-black border-gold' : 'bg-background/80 text-muted-foreground border-white/20'} shadow-sm transition-colors`}>
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                            <path d="M20 6 9 17l-5-5" />
                          </svg>
                        </span>
                        <input type="checkbox" className="sr-only" tabIndex={-1} aria-hidden checked={!!selected[p.id]} readOnly />
                      </div>

                      {/* Content */}
                      <div className="p-3">
                        <div className="font-semibold truncate" title={p.title}>{p.title}</div>
                        <div className="mt-1">
                          <span className="text-xs bg-white/10 border border-white/10 px-2 py-0.5 rounded-full">{p.category || 'Uncategorized'}</span>
                        </div>
                      </div>
                    </button>
                  </Card>
                ))}
              </div>
            )}
          </div>

          <div className="lg:sticky lg:top-24 h-max">
            <Card className="p-4 space-y-4 bg-white/5 border-white/10 backdrop-blur-sm rounded-xl">
              <div className="font-semibold">Campaign Details</div>
              <div className="space-y-2">
                <label className="text-sm">Duration (days)</label>
                <input
                  type="number"
                  min={1}
                  className="w-full rounded-lg border border-white/10 bg-background/60 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-400/40"
                  value={duration}
                  onChange={(e) => setDuration(e.target.value)}
                />
              </div>
              <div className="text-xs text-muted-foreground">
                You have selected <span className="text-foreground font-medium">{selectedIds.length}</span> product{selectedIds.length === 1 ? '' : 's'}.
              </div>
              {selectedIds.length > 0 && (
                <div className="flex -space-x-2">
                  {selectedIds.slice(0, 5).map((id) => {
                    const p = products.find((x) => x.id === id);
                    if (!p) return null;
                    return <img key={id} src={p.images?.[0] || '/images/charity-background.svg'} className="w-8 h-8 rounded ring-2 ring-background" />;
                  })}
                  {selectedIds.length > 5 && (
                    <div className="w-8 h-8 rounded bg-muted text-xs flex items-center justify-center ring-2 ring-background">+{selectedIds.length - 5}</div>
                  )}
                </div>
              )}
              <Button disabled={submitting || selectedIds.length === 0} onClick={submit} className="w-full bg-gold text-black hover:bg-gold/90 rounded-full">
                {submitting ? 'Submitting...' : 'Send Request to Admin'}
              </Button>
            </Card>

            <div className="mt-6">
              <div className="mb-2 flex items-center justify-between">
                <div className="font-semibold">Your Requests</div>
                {requests.length > 0 && (
                  <button
                    onClick={() => setRequestsExpanded((v) => !v)}
                    className="btn-hover h-8 px-3 py-1 rounded-full text-xs border border-white/10 hover:bg-white/10"
                    aria-expanded={requestsExpanded}
                  >
                    {requestsExpanded ? 'Collapse list' : `Expand list (${requests.length})`}
                  </button>
                )}
              </div>
              {requests.length === 0 ? (
                <div className="text-sm text-muted-foreground">No promotion requests yet.</div>
              ) : (
                <div className="space-y-2">
                  {(requestsExpanded ? requests : [requests[0]]).map((r) => {
                    const isOpen = !!openIds[r.id];
                    const statusClass = r.status === 'approved'
                      ? 'bg-emerald-500/15 text-emerald-400'
                      : r.status === 'rejected'
                        ? 'bg-red-500/15 text-red-400'
                        : r.status === 'deleted'
                          ? 'bg-white/10 text-muted-foreground border-white/10'
                          : 'bg-amber-500/15 text-amber-400';
                    return (
                      <Card key={r.id} className="p-0 overflow-hidden bg-white/5 border-white/10">
                        <div className="flex items-center justify-between px-3 py-3">
                          <button
                            className="flex items-start gap-3 text-left"
                            onClick={() => setOpenIds((prev) => ({ ...prev, [r.id]: !prev[r.id] }))}
                            aria-expanded={isOpen}
                            aria-controls={`seller-req-${r.id}`}
                          >
                            <div className="flex flex-col">
                              <div className="flex items-center gap-2">
                                <div className="font-semibold">Amount: ₹{r.amount || 0}</div>
                                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs border ${statusClass}`}>{r.status}</span>
                                {(!r.amount || r.amount <= 0) && <span className="text-xs text-muted-foreground">Pricing pending</span>}
                              </div>
                              <div className="text-xs text-muted-foreground">Duration: {r.durationDays}d</div>
                            </div>
                          </button>
                          <div className="flex items-center gap-3">
                            <div className="text-muted-foreground">Products: {r.productIds?.length || 0}</div>
                            {r.amount > 0 && r.status === 'approved' && r.paymentStatus !== 'paid' && r.status !== 'deleted' && (
                              <Button
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const total = (Number(r.amount) || 0) * (r.productIds?.length || 0);
                                  navigate(`/seller/promotions/checkout?requestId=${encodeURIComponent(r.id)}&total=${encodeURIComponent(String(total))}`);
                                }}
                                className="bg-gold text-black hover:bg-gold/90"
                              >
                                Checkout
                              </Button>
                            )}
                          </div>
                          {/* Chevron removed to declutter */}
                        </div>
                        {isOpen && (
                          <div id={`seller-req-${r.id}`} className="px-3 pb-3 pt-1 border-t border-white/10 text-xs text-muted-foreground">
                            Request #{r.id} • Status: {r.status} • Payment: {r.paymentStatus || 'unpaid'}
                          </div>
                        )}
                      </Card>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
