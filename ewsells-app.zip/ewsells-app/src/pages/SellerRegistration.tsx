import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Upload, 
  Camera, 
  Check, 
  X, 
  ChevronDown, 
  Loader2,
  ArrowLeft,
  CheckCircle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { db, storage, auth } from '@/lib/firebase';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
// import { useStore } from '@/store/useStore';

// Department options for multi-select (must mirror seller dashboard categories)
const DEPARTMENTS = [
  { id: 'charity-craft', name: 'Charity Craft' },
  { id: 'organic-store', name: 'Organic Store' },
  { id: 'scrap-store', name: 'Scrap Store' },
  { id: 'scrap-books', name: 'Scrap Books' },
  { id: 'moms-made-united', name: 'Moms Made United' },
  { id: 'green-cup-challenge', name: 'Green Cup Challenge' },
  { id: 'charity-bakes', name: 'Charity Bakes' },
  { id: 'home-decor', name: 'Home Decor' },
  { id: 'packed-food', name: 'Packed Food' },
  { id: 'home-plants', name: 'Home Plants' },
  { id: 'beauty-homemade', name: 'Beauty Homemade' },
  { id: 'homemade-households', name: 'Homemade Households' },
  { id: 'birthday-gifts', name: 'Birthday Gifts' },
];

// Address proof options
const ADDRESS_PROOFS = [
  { id: 'aadhar', name: 'Aadhar Card' },
  { id: 'driving-license', name: 'Driving License' },
  { id: 'voter-id', name: 'Voter ID' },
  { id: 'passport', name: 'Passport' },
  { id: 'utility-bill', name: 'Utility Bill' },
];

export function SellerRegistration() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [existingStatus, setExistingStatus] = useState<'none'|'pending'|'approved'|'rejected'>('none');
  const [rejectionReason, setRejectionReason] = useState<string>('');

  // Form fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [bankName, setBankName] = useState('');
  const [accountHolderName, setAccountHolderName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [ifscCode, setIfscCode] = useState('');
  const [upiId, setUpiId] = useState('');
  const [addressProofType, setAddressProofType] = useState('');
  const [selectedDepartments, setSelectedDepartments] = useState<string[]>([]);
  const [showDepartmentDropdown, setShowDepartmentDropdown] = useState(false);

  // FSSAI fields
  const [fssaiNumber, setFssaiNumber] = useState('');
  const [fssaiCertificate, setFssaiCertificate] = useState<File | null>(null);
  const [fssaiCertificatePreview, setFssaiCertificatePreview] = useState<string | null>(null);

  // File uploads
  const [passportPhoto, setPassportPhoto] = useState<File | null>(null);
  const [passportPhotoPreview, setPassportPhotoPreview] = useState<string | null>(null);
  const [addressProof, setAddressProof] = useState<File | null>(null);
  const [signature, setSignature] = useState<string | null>(null);

  // Refs
  const signaturePadRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const addressProofInputRef = useRef<HTMLInputElement>(null);
  
  // Handle passport photo upload
  const handlePassportPhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setPassportPhoto(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setPassportPhotoPreview(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };
  
  // Handle FSSAI certificate upload
  const handleFssaiCertificateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setFssaiCertificate(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setFssaiCertificatePreview(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };
  
  // Check if FSSAI fields are required based on selected departments
  const isFssaiRequired = () => {
    return selectedDepartments.some(dept => 
      dept === 'charity-bakes' || dept === 'packed-food'
    );
  };

  // Handle address proof upload
  const handleAddressProofChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setAddressProof(file);
    }
  };
  
  // Handle department selection
  const toggleDepartment = (departmentId: string) => {
    setSelectedDepartments(prev => 
      prev.includes(departmentId)
        ? prev.filter(id => id !== departmentId)
        : [...prev, departmentId]
    );
  };
  
  // Handle signature pad
  const initSignaturePad = () => {
    const canvas = signaturePadRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#000000';
    
    let isDrawing = false;
    let lastX = 0;
    let lastY = 0;
    
    const startDrawing = (e: MouseEvent | TouchEvent) => {
      isDrawing = true;
      const { offsetX, offsetY } = getCoordinates(e);
      lastX = offsetX;
      lastY = offsetY;
    };
    
    const draw = (e: MouseEvent | TouchEvent) => {
      if (!isDrawing) return;
      const { offsetX, offsetY } = getCoordinates(e);
      
      ctx.beginPath();
      ctx.moveTo(lastX, lastY);
      ctx.lineTo(offsetX, offsetY);
      ctx.stroke();
      
      lastX = offsetX;
      lastY = offsetY;
    };
    
    const stopDrawing = () => {
      isDrawing = false;
      // Save signature as data URL
      setSignature(canvas.toDataURL());
    };
    
    const getCoordinates = (e: MouseEvent | TouchEvent) => {
      let offsetX, offsetY;
      
      if ('touches' in e) {
        const touch = e.touches[0];
        const rect = canvas.getBoundingClientRect();
        offsetX = touch.clientX - rect.left;
        offsetY = touch.clientY - rect.top;
      } else {
        offsetX = (e as MouseEvent).offsetX;
        offsetY = (e as MouseEvent).offsetY;
      }
      
      return { offsetX, offsetY };
    };
    
    // Add event listeners
    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseout', stopDrawing);
    
    // Touch events
    canvas.addEventListener('touchstart', startDrawing);
    canvas.addEventListener('touchmove', draw);
    canvas.addEventListener('touchend', stopDrawing);
    
    // Clear function
    return () => {
      canvas.removeEventListener('mousedown', startDrawing);
      canvas.removeEventListener('mousemove', draw);
      canvas.removeEventListener('mouseup', stopDrawing);
      canvas.removeEventListener('mouseout', stopDrawing);
      canvas.removeEventListener('touchstart', startDrawing);
      canvas.removeEventListener('touchmove', draw);
      canvas.removeEventListener('touchend', stopDrawing);
    };
  };
  
  // Clear signature
  const clearSignature = () => {
    const canvas = signaturePadRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setSignature(null);
  };
  
  // Initialize signature pad on component mount
  React.useEffect(() => {
    const cleanup = initSignaturePad();
    return cleanup;
  }, []);

  // Check for an existing registration to lock the form when needed
  React.useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const currentUser = auth.currentUser;
        if (!currentUser) return;
        const regRef = doc(db, 'seller-registrations', currentUser.uid);
        const snap = await getDoc(regRef);
        if (cancelled) return;
        if (!snap.exists()) { setExistingStatus('none'); return; }
        const data = snap.data() as any;
        const st = (data?.status as 'pending'|'approved'|'rejected') || 'none';
        setExistingStatus(st);
        if (st === 'rejected') {
          setRejectionReason(data?.rejectionReason || '');
        } else if (st === 'approved' && data?.sellerCode) {
          setRejectionReason(data.sellerCode); // Using rejectionReason to store seller code for display
        }
      } catch (e) {
        console.error('Error checking registration status:', e);
      }
    })();
    return () => { cancelled = true; };
  }, []);
  
  // State for success popup
  const [showSuccess, setShowSuccess] = useState(false);

  // State for approval modal
  const [showApprovalModal, setShowApprovalModal] = useState(false);

  // Close success popup and redirect
  const handleSuccessClose = () => {
    setShowSuccess(false);
    navigate('/');
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    // Validate form
    if (!name || !email || !phone || !address || !city || 
        !bankName || !accountHolderName || !accountNumber || !ifscCode || 
        !upiId || !addressProofType || !passportPhoto || !addressProof || 
        !signature || selectedDepartments.length === 0) {
      setError('Please fill in all required fields');
      return;
    }
    
    // Validate FSSAI fields if required
    if (isFssaiRequired()) {
      if (!fssaiNumber || !fssaiCertificate) {
        setError('FSSAI license number and certificate are required for the selected departments');
        return;
      }
      
      // Validate FSSAI number format (14 digits)
      const fssaiRegex = /^\d{14}$/;
      if (!fssaiRegex.test(fssaiNumber)) {
        setError('FSSAI license number must be 14 digits');
        return;
      }
    }
    
    setIsLoading(true);
    
    try {
      // Check if user is authenticated
      const currentUser = auth.currentUser;
      if (!currentUser) {
        throw new Error('You must be logged in to register as a seller');
      }
      
      // Upload passport photo
      const passportPhotoRef = ref(storage, `seller-registrations/${currentUser.uid}/passport-photo`);
      await uploadBytes(passportPhotoRef, passportPhoto);
      const passportPhotoUrl = await getDownloadURL(passportPhotoRef);
      
      // Upload address proof
      const addressProofRef = ref(storage, `seller-registrations/${currentUser.uid}/address-proof`);
      await uploadBytes(addressProofRef, addressProof);
      const addressProofUrl = await getDownloadURL(addressProofRef);
      
      // Save signature as image in storage
      const signatureRef = ref(storage, `seller-registrations/${currentUser.uid}/signature`);
      const signatureBlob = await (await fetch(signature)).blob();
      await uploadBytes(signatureRef, signatureBlob);
      const signatureUrl = await getDownloadURL(signatureRef);
      
      // Upload FSSAI certificate if required
      let fssaiCertificateUrl = '';
      if (isFssaiRequired() && fssaiCertificate) {
        const fssaiRef = ref(storage, `seller-registrations/${currentUser.uid}/fssai-certificate`);
        await uploadBytes(fssaiRef, fssaiCertificate);
        fssaiCertificateUrl = await getDownloadURL(fssaiRef);
      }
      
      // Prepare seller data
      const sellerData = {
        userId: currentUser.uid,
        name,
        email,
        phone,
        address,
        city,
        bankDetails: {
          bankName,
          accountHolderName,
          accountNumber,
          ifscCode,
        },
        upiId,
        addressProofType,
        departments: selectedDepartments,
        fssaiDetails: isFssaiRequired() ? {
          fssaiNumber,
          fssaiCertificateUrl,
          verified: false
        } : null,
        passportPhotoUrl,
        addressProofUrl,
        signatureUrl,
        status: 'pending',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      
      // Save seller registration data to Firestore
      await setDoc(doc(db, 'seller-registrations', currentUser.uid), sellerData);
      
      // Show approval modal
      setShowApprovalModal(true);
      
    } catch (err: any) {
      console.error('Error submitting seller registration:', err);
      setError(err.message || 'An error occurred while submitting your registration');
    } finally {
      setIsLoading(false);
    }
  };
  
  // Close approval modal and redirect
  const handleApprovalClose = () => {
    setShowApprovalModal(false);
    navigate('/');
  };
  
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-12"
    >
      {/* Success Modal */}
      {showSuccess && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <div className="text-center">
              <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-green-100">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="mt-3 text-lg font-medium text-gray-900">Registration Submitted Successfully!</h3>
              <div className="mt-2">
                <p className="text-sm text-gray-500">
                  Thank you for submitting your seller registration. Your application is under review.
                  You will be notified via email once it's approved.
                </p>
              </div>
              <div className="mt-4">
                <Button
                  type="button"
                  className="w-full justify-center bg-gold hover:bg-gold/90 text-black"
                  onClick={handleSuccessClose}
                >
                  Return to Home
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      <div className="container mx-auto px-4 max-w-3xl">
        <Button 
          type="button" 
          variant="ghost" 
          className="mb-6 -ml-2" 
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <div className="bg-card rounded-xl shadow-md p-6 md:p-8">
          <h1 className="text-3xl font-bold mb-2">Seller Registration</h1>
          <p className="text-muted-foreground mb-6">Fill out the form below to register as a seller on our platform.</p>

          {/* Status gates */}
          {existingStatus === 'pending' && (
            <div className="rounded-md border border-yellow-300 bg-yellow-50 text-yellow-800 p-4 mb-6">
              <div className="font-medium">Registration Pending</div>
              <p className="text-sm mt-1">Your application is under review. You will be notified when it’s approved.</p>
              <div className="mt-4 flex gap-2">
                <Button onClick={() => navigate('/')} variant="outline">Back to Home</Button>
              </div>
            </div>
          )}
          {existingStatus === 'approved' && (
            <div className="rounded-md border border-green-300 bg-green-50 text-green-800 p-4 mb-6">
              <div className="font-medium">Registration Approved</div>
              <p className="text-sm mt-1">Proceed to accept the Seller Agreement to activate your seller account.</p>
              <div className="mt-4 flex gap-2">
                <Button onClick={() => navigate('/seller-agreement')} className="bg-gold hover:bg-gold/90 text-black">Go to Seller Agreement</Button>
                <Button onClick={() => navigate('/')} variant="outline">Back to Home</Button>
              </div>
            </div>
          )}
          {existingStatus === 'rejected' && (
            <div className="rounded-md border border-red-300 bg-red-50 text-red-800 p-4 mb-6">
              <div className="font-medium">Previous Registration Rejected</div>
              {rejectionReason && <p className="text-sm mt-1">Reason: {rejectionReason}</p>}
              <p className="text-sm mt-1">You can correct details below and resubmit.</p>
            </div>
          )}
          {(existingStatus === 'none' || existingStatus === 'rejected') && (
            <form onSubmit={handleSubmit}>
              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded mb-6">{error}</div>
              )}
              <div className="space-y-6">
                {/* Personal Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label htmlFor="fullName" className="block text-sm font-medium mb-1">Full Name *</label>
                    <Input id="fullName" value={name} onChange={(e) => setName(e.target.value)} placeholder="Enter your full name" required />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-1">Email Address *</label>
                    <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="your@email.com" required />
                  </div>
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium mb-1">Phone Number *</label>
                    <Input id="phone" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Enter your phone number" required />
                  </div>
                  <div>
                    <label htmlFor="city" className="block text-sm font-medium mb-1">Nearest City with Pincode *</label>
                    <Input id="city" value={city} onChange={(e) => setCity(e.target.value)} placeholder="Enter city name with pincode (e.g., Mumbai 400001)" required />
                  </div>
                  <div className="md:col-span-2">
                    <label htmlFor="address" className="block text-sm font-medium mb-1">Full Address *</label>
                    <textarea id="address" value={address} onChange={(e) => setAddress(e.target.value)} placeholder="Enter your full address" className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2" rows={3} required />
                  </div>
                </div>

                {/* Passport Photo Upload */}
                <div>
                  <h2 className="text-xl font-semibold mb-4">Passport Size Photo</h2>
                  <div className="flex flex-col items-center border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center">
                    {passportPhotoPreview ? (
                      <div className="relative">
                        <img src={passportPhotoPreview} alt="Passport preview" className="h-40 w-40 object-cover rounded-md" />
                        <button type="button" onClick={() => { setPassportPhoto(null); setPassportPhotoPreview(null); }} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1">
                          <X size={16} />
                        </button>
                      </div>
                    ) : (
                      <>
                        <Camera className="h-10 w-10 text-muted-foreground mb-2" />
                        <p className="text-sm text-muted-foreground mb-2">Upload a passport size photo</p>
                        <Button type="button" onClick={() => fileInputRef.current?.click()} variant="outline" size="sm">
                          <Upload className="h-4 w-4 mr-2" />
                          Select Photo
                        </Button>
                      </>
                    )}
                    <input type="file" ref={fileInputRef} onChange={handlePassportPhotoChange} accept="image/*" className="hidden" />
                  </div>
                </div>

                {/* Bank Account Details */}
                <div>
                  <h2 className="text-xl font-semibold mb-4">Bank Account Details</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="bankName" className="block text-sm font-medium mb-1">Bank Name *</label>
                      <Input id="bankName" value={bankName} onChange={(e) => setBankName(e.target.value)} placeholder="Enter bank name" required />
                    </div>
                    <div>
                      <label htmlFor="accountHolderName" className="block text-sm font-medium mb-1">Account Holder Name *</label>
                      <Input id="accountHolderName" value={accountHolderName} onChange={(e) => setAccountHolderName(e.target.value)} placeholder="Enter account holder name" required />
                    </div>
                    <div>
                      <label htmlFor="accountNumber" className="block text-sm font-medium mb-1">Account Number *</label>
                      <Input id="accountNumber" value={accountNumber} onChange={(e) => setAccountNumber(e.target.value)} placeholder="Enter account number" required />
                    </div>
                    <div>
                      <label htmlFor="ifscCode" className="block text-sm font-medium mb-1">IFSC Code *</label>
                      <Input id="ifscCode" value={ifscCode} onChange={(e) => setIfscCode(e.target.value)} placeholder="Enter IFSC code" required />
                    </div>
                    <div>
                      <label htmlFor="upiId" className="block text-sm font-medium mb-1">UPI ID *</label>
                      <Input id="upiId" value={upiId} onChange={(e) => setUpiId(e.target.value)} placeholder="Enter UPI ID" required />
                    </div>
                  </div>
                </div>

                {/* Address Proof */}
                <div>
                  <h2 className="text-xl font-semibold mb-4">Address Proof</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="addressProofType" className="block text-sm font-medium mb-1">Address Proof Type *</label>
                      <select id="addressProofType" value={addressProofType} onChange={(e) => setAddressProofType(e.target.value)} className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2" required>
                        <option value="">Select Address Proof</option>
                        {ADDRESS_PROOFS.map((proof) => (
                          <option key={proof.id} value={proof.id}>{proof.name}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Upload Address Proof *</label>
                      <div className="flex items-center">
                        <Button type="button" onClick={() => addressProofInputRef.current?.click()} variant="outline" className="w-full">
                          <Upload className="h-4 w-4 mr-2" />
                          {addressProof ? 'Change File' : 'Select File'}
                        </Button>
                        <input type="file" ref={addressProofInputRef} onChange={handleAddressProofChange} accept="image/*,.pdf" className="hidden" />
                      </div>
                      {addressProof && (<p className="text-xs text-muted-foreground mt-1">{addressProof.name} ({Math.round(addressProof.size / 1024)} KB)</p>)}
                    </div>
                  </div>
                </div>

                {/* FSSAI Fields - Conditionally Rendered */}
                {isFssaiRequired() && (
                  <>
                    <div className="space-y-2">
                      <label className="block text-sm font-medium text-gray-700">
                        FSSAI License Number *
                      </label>
                      <Input
                        type="text"
                        placeholder="14-digit FSSAI license number"
                        value={fssaiNumber}
                        onChange={(e) => setFssaiNumber(e.target.value)}
                        maxLength={14}
                        className="w-full"
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        Enter your 14-digit FSSAI license number
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <label className="block text-sm font-medium text-gray-700">
                        FSSAI Certificate *
                      </label>
                      <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                        <div className="space-y-1 text-center">
                          {fssaiCertificatePreview ? (
                            <div className="relative">
                              <img
                                src={fssaiCertificatePreview}
                                alt="FSSAI Certificate Preview"
                                className="h-40 object-cover rounded"
                              />
                              <button
                                type="button"
                                onClick={() => {
                                  setFssaiCertificate(null);
                                  setFssaiCertificatePreview(null);
                                }}
                                className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1"
                              >
                                <X size={12} />
                              </button>
                            </div>
                          ) : (
                            <div className="flex flex-col items-center">
                              <Upload className="h-12 w-12 text-gray-400" />
                              <div className="mt-2 text-sm text-gray-600">
                                <label htmlFor="fssai-certificate" className="relative cursor-pointer rounded-md font-medium text-primary hover:text-primary/80">
                                  <span>Upload FSSAI Certificate</span>
                                  <input
                                    id="fssai-certificate"
                                    name="fssai-certificate"
                                    type="file"
                                    className="sr-only"
                                    accept="image/*,.pdf"
                                    onChange={handleFssaiCertificateChange}
                                    required={isFssaiRequired()}
                                  />
                                </label>
                                <p className="text-xs text-gray-500">
                                  PNG, JPG, PDF up to 5MB
                                </p>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </>
                )}

                {/* Department Selection */}
                <div>
                  <h2 className="text-xl font-semibold mb-4">Department Selection</h2>
                  <label className="block text-sm font-medium mb-1">Select Departments of Interest *</label>
                  <div className="relative">
                    <button type="button" onClick={() => setShowDepartmentDropdown(!showDepartmentDropdown)} className="w-full flex items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
                      <span>{selectedDepartments.length === 0 ? 'Select departments' : `${selectedDepartments.length} department(s) selected`}</span>
                      <ChevronDown size={16} />
                    </button>
                    {showDepartmentDropdown && (
                      <div className="absolute z-10 mt-1 w-full rounded-md border border-input bg-background shadow-lg">
                        <div className="p-2">
                          {DEPARTMENTS.map((department) => (
                            <div key={department.id} className="flex items-center px-2 py-1.5 hover:bg-muted rounded-md cursor-pointer" onClick={() => toggleDepartment(department.id)}>
                              <div className={`w-4 h-4 border rounded mr-2 flex items-center justify-center ${selectedDepartments.includes(department.id) ? 'bg-primary border-primary' : 'border-input'}`}>
                                {selectedDepartments.includes(department.id) && (<Check size={12} className="text-primary-foreground" />)}
                              </div>
                              <span>{department.name} {['charity-bakes', 'packed-food'].includes(department.id) && '(Requires FSSAI)'}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  {selectedDepartments.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {selectedDepartments.map((deptId) => (
                        <div key={deptId} className="bg-muted px-2 py-1 rounded-md text-xs flex items-center">
                          {DEPARTMENTS.find(d => d.id === deptId)?.name}
                          <button type="button" onClick={() => toggleDepartment(deptId)} className="ml-1 text-muted-foreground hover:text-foreground">
                            <X size={12} />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* E-Signature */}
                <div>
                  <h2 className="text-xl font-semibold mb-4">E-Signature</h2>
                  <p className="text-sm text-muted-foreground mb-2">Please sign in the box below using your mouse or touch screen</p>
                  <div className="border border-input rounded-md p-1 mb-2">
                    <canvas ref={signaturePadRef} width={600} height={150} className="w-full touch-none bg-white" />
                  </div>
                  <Button type="button" variant="outline" size="sm" onClick={clearSignature}>Clear Signature</Button>
                </div>

                {/* Submit Button and Status */}
                <div className="pt-4 space-y-3">
                  {/* Form submission status */}
                  {error && (
                    <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-md text-sm">
                      {error}
                    </div>
                  )}
                  
                  {/* Submit Button */}
                  <Button 
                    type="submit" 
                    className={`w-full ${isLoading ? 'opacity-80' : ''} transition-all`} 
                    variant={isLoading ? 'outline' : 'default'}
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      <div className="flex items-center justify-center gap-2">
                        <CheckCircle className="h-4 w-4" />
                        <span>Submit Registration</span>
                      </div>
                    )}
                  </Button>
                  
                  <p className="text-xs text-muted-foreground text-center">
                    By submitting, you agree to our Terms of Service and Privacy Policy
                  </p>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
      {/* Approval Modal */}
      {showApprovalModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <div className="text-center">
              <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-blue-100">
                <CheckCircle className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="mt-3 text-lg font-medium text-gray-900">Registration Under Review</h3>
              <div className="mt-2">
                <p className="text-sm text-gray-500">
                  Your seller registration has been submitted for approval.
                  You'll be notified via email once it's processed.
                </p>
              </div>
              <div className="mt-4">
                <Button
                  type="button"
                  className="w-full justify-center bg-gold hover:bg-gold/90 text-black"
                  onClick={handleApprovalClose}
                >
                  Close
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
}
