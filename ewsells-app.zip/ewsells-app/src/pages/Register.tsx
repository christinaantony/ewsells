import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, EyeOff, UserPlus, Camera, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { authService } from '@/services/auth';
import { FaceAuth } from '@/components/ui/face-auth';
import { faceAuthService } from '@/services/faceAuth';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';

export function Register() {
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [faceImage, setFaceImage] = useState<string | null>(null);
  const [showPasswordFields, setShowPasswordFields] = useState(true);
  const navigate = useNavigate();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!displayName.trim()) {
      setError('Name is required');
      return;
    }

    if (!email.trim()) {
      setError('Email is required');
      return;
    }

    // Require password always
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setIsLoading(true);

    try {
      // Suppress any welcome toast during the brief auto-login window after account creation
      localStorage.setItem('suppressWelcome', 'true');
      // Check internet connection first
      if (!navigator.onLine) {
        throw new Error('No internet connection. Please check your network and try again.');
      }

      // Add a small delay to ensure Firebase is ready
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Register with email and password first
      console.log('Creating user account with email:', email);
      
      // Try registration with retry logic
      let userData;
      let retryCount = 0;
      const maxRetries = 3;
      
      while (retryCount < maxRetries) {
        try {
          // Always register with explicit password
          userData = await authService.register(email, password, displayName);
          console.log('User account created successfully:', userData.uid);
          break; // Success, exit the retry loop
        } catch (regError: any) {
          retryCount++;
          console.warn(`Registration attempt ${retryCount} failed:`, regError.message);
          
          if (regError.code === 'auth/network-request-failed') {
            if (retryCount < maxRetries) {
              console.log(`Retrying in ${retryCount * 1000}ms...`);
              await new Promise(resolve => setTimeout(resolve, retryCount * 1000));
            } else {
              throw new Error('Network connection is unstable. Please check your internet connection and try again.');
            }
          } else if (regError.code === 'auth/email-already-in-use') {
            // If email already exists, try to log in instead
            try {
              console.log('Email already exists, attempting to log in...');
              await authService.login(email, password);
              console.log('Login successful, redirecting to login page');
              navigate('/login');
              return;
            } catch (loginError) {
              console.error('Login attempt failed:', loginError);
              throw new Error('This email is already registered. Please use a different email or try logging in.');
            }
          } else {
            // For other errors, just throw
            throw regError;
          }
        }
      }
      
      if (!userData) {
        throw new Error('Failed to create account after multiple attempts.');
      }
      
      // For face authentication users, attempt to save face data and enable flag
      if (faceImage) {
        try {
          // Register the face if captured
          console.log('Registering face for user:', userData.uid);
          const faceRegistered = await faceAuthService.registerFace(userData.uid, faceImage);

          if (faceRegistered) {
            console.log('Face registered successfully');
            // Verify document exists in faceAuth collection
            const verify = await getDoc(doc(db, 'faceAuth', userData.uid));
            if (!verify.exists()) {
              console.warn('FaceAuth doc not found after registration, retrying enable flag');
            }
            // Enable face auth flag on user
            await authService.enableFaceAuth(userData.uid);
          } else {
            console.warn('faceAuthService.registerFace returned false');
          }
        } catch (faceError: any) {
          console.error('Face registration error:', faceError);
          // Don't block the registration process if face registration fails
          // Just log the error and continue
        }
      }
      
      // Redirect to login page after successful registration
      console.log('Registration complete, redirecting to login page');
      // Important: Firebase auto-signs in the user on createUserWithEmailAndPassword.
      // We explicitly log out to ensure the app requires a manual sign-in afterwards.
      try {
        await authService.logout();
      } catch (e) {
        // Non-fatal: proceed to login page even if logout cleanup has minor issues
        console.warn('Post-registration logout encountered a minor issue:', e);
      }
      // Clear suppression when heading to login screen
      localStorage.removeItem('suppressWelcome');
      navigate('/login');
    } catch (err: any) {
      console.error('Registration error:', err);
      setError(err.message || 'Failed to register. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFaceCapture = async (imageData: string) => {
    try {
      setIsLoading(true);
      setError('');
      
      // Check if this face is already registered in the system
      const faceCheck = await faceAuthService.checkFaceExists(imageData);
      
      if (faceCheck.exists && faceCheck.userId) {
        setError('This face is already registered with another account. Please use a different face or log in with your existing account.');
        setFaceImage(null);
        setIsLoading(false);
        return;
      }
      
      // If face is not registered yet, allow registration
      setFaceImage(imageData);
      setIsLoading(false);
    } catch (err: any) {
      console.error('Error during face capture:', err);
      setError(err.message || 'Failed to process face image. Please try again.');
      setFaceImage(null);
      setIsLoading(false);
    }
  };

  const handleFaceError = (errorMessage: string) => {
    setError(errorMessage);
  };


  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      {/* Animated background dots */}
      <div className="absolute inset-0 z-15">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-gold/30 rounded-full"
            style={{
              left: `${20 + i * 15}%`,
              top: `${30 + i * 10}%`,
            }}
            animate={{
              y: [0, -20, 0],
              opacity: [0.3, 0.8, 0.3],
              scale: [1, 1.2, 1],
            }}
            transition={{
              duration: 3 + i * 0.5,
              repeat: Infinity,
              delay: i * 0.3,
            }}
          />
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md z-20"
      >
        <div className="bg-card/80 backdrop-blur-md shadow-xl rounded-2xl p-8 border border-white/10">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">Create Account</h1>
            <p className="text-muted-foreground">Sign up to get started</p>
          </div>

          <div className="flex items-center justify-center mb-6">
            <Button
              type="button"
              variant={!showPasswordFields ? "default" : "outline"}
              size="sm"
              onClick={() => setShowPasswordFields(false)}
              className={!showPasswordFields ? "bg-gold hover:bg-gold/90 text-black mr-2" : "mr-2"}
            >
              <Camera className="mr-2 h-4 w-4" />
              Face
            </Button>
            <Button
              type="button"
              variant={showPasswordFields ? "default" : "outline"}
              size="sm"
              onClick={() => setShowPasswordFields(true)}
              className={showPasswordFields ? "bg-gold hover:bg-gold/90 text-black" : ""}
            >
              <User className="mr-2 h-4 w-4" />
              Password
            </Button>
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-destructive/20 text-destructive p-3 rounded-lg mb-6 text-sm"
            >
              {error}
            </motion.div>
          )}

          <form onSubmit={handleRegister}>
            <div className="space-y-4">
              <div>
                <label htmlFor="displayName" className="block text-sm font-medium mb-1">
                  Full Name
                </label>
                <Input
                  id="displayName"
                  type="text"
                  placeholder="John Doe"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  required
                  className="w-full"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium mb-1">
                  Email
                </label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full"
                />
              </div>

              {/* Face Authentication (optional) */}
              <div className="mt-4 border border-border rounded-lg p-4">
                <h3 className="text-sm font-medium mb-3">Face Authentication Setup (Optional)</h3>
                <FaceAuth
                  onCapture={handleFaceCapture}
                  onError={handleFaceError}
                  isRegistration={true}
                />
              </div>

              {/* Password Fields (required) */}
              <div>
                <label htmlFor="password" className="block text-sm font-medium mb-1">
                  Password
                </label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full pr-10"
                    autoComplete="new-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Must be at least 6 characters
                </p>
              </div>

              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium mb-1">
                  Confirm Password
                </label>
                <Input
                  id="confirmPassword"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  className="w-full"
                  autoComplete="new-password"
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-gold hover:bg-gold/90 text-black"
                disabled={isLoading || (!showPasswordFields && !faceImage)}
              >
                {isLoading ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                    className="mr-2 h-4 w-4 border-2 border-black border-t-transparent rounded-full"
                  />
                ) : (
                  <UserPlus className="mr-2 h-4 w-4" />
                )}
                {isLoading ? 'Creating Account...' : 'Create Account'}
              </Button>
            </div>
          </form>

          <div className="mt-6 text-center text-sm">
            <p>
              Already have an account?{' '}
              <Link to="/login" className="text-primary hover:underline">
                Sign in
              </Link>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
