import { useEffect, useMemo, useRef, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { collection, onSnapshot, doc, getDoc, addDoc, serverTimestamp, query, orderBy, updateDoc } from 'firebase/firestore';
import { db, auth, storage } from '@/lib/firebase';
import { ref as storageRef, uploadBytes, getDownloadURL } from 'firebase/storage';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Card } from '@/components/ui/card';
import { Check, CheckCheck } from 'lucide-react';

interface ChatDoc {
  id: string;
  orderId: string;
  productId: string;
  buyerId: string;
  sellerId: string;
  createdAt?: any;
  lastReadBuyerAt?: any;
  lastReadSellerAt?: any;
  typingBuyer?: boolean;
  typingSeller?: boolean;
}

interface MessageDoc {
  id: string;
  text: string;
  senderId: string;
  createdAt?: any;
}

export default function SellerCustomizeChat() {
  const { chatId = '' } = useParams();
  const [chat, setChat] = useState<ChatDoc | null>(null);
  const [messages, setMessages] = useState<MessageDoc[]>([]);
  const [input, setInput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const listRef = useRef<HTMLDivElement | null>(null);
  const [showNewMsgBanner, setShowNewMsgBanner] = useState(false);
  const [otherTyping, setOtherTyping] = useState(false);
  const typingTimer = useRef<number | null>(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [files, setFiles] = useState<FileList | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const navigate = useNavigate();
  const uid = auth.currentUser?.uid || null;

  // Auto-scroll on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  useEffect(() => {
    if (!uid || !chatId) return;

    const chatRef = doc(db, 'customizationChats', chatId);
    let unsubMsgs: undefined | (() => void);
    let unsubChat: undefined | (() => void);

    (async () => {
      try {
        const snap = await getDoc(chatRef);
        if (!snap.exists()) {
          setError('Chat not found.');
          return;
        }
        const data = snap.data() as any;
        // Seller guard: must be the seller participant
        if (data.sellerId !== uid) {
          setError('You do not have access to this chat.');
          return;
        }
        setChat({ id: snap.id, ...data });

        const msgsQ = query(collection(chatRef, 'messages'), orderBy('createdAt', 'asc'));
        unsubMsgs = onSnapshot(msgsQ, (s) => {
          const list: MessageDoc[] = [];
          s.forEach((d) => list.push({ id: d.id, ...(d.data() as any) }));
          setMessages(list);
          const last = list[list.length - 1];
          const nearBottom = (() => {
            const el = listRef.current;
            if (!el) return true;
            const threshold = 80;
            return el.scrollHeight - el.scrollTop - el.clientHeight < threshold;
          })();
          if (last && last.senderId !== uid && !nearBottom) {
            setShowNewMsgBanner(true);
          }
        }, (err) => {
          console.error('Messages subscribe error', err);
          setError('Failed to load messages.');
        });

        // Observe chat for typing and lastRead updates
        unsubChat = onSnapshot(chatRef, (c) => {
          const cd = c.data() as any;
          // buyer is the other party for sellers
          setOtherTyping(Boolean(cd?.typingBuyer));
          // compute unread (messages from buyer after lastReadSellerAt)
          const lastRead = cd?.lastReadSellerAt;
          let count = 0;
          for (const m of messages) {
            const after = m.senderId !== uid && (!lastRead || (m.createdAt?.toMillis && lastRead?.toMillis && m.createdAt.toMillis() > lastRead.toMillis()));
            if (after) count++;
          }
          setUnreadCount(count);
        });
      } catch (e: any) {
        console.error('Failed to load chat', e);
        setError('Failed to load chat.');
      }
    })();

    return () => {
      try { unsubMsgs && unsubMsgs(); } catch {}
      try { unsubChat && unsubChat(); } catch {}
    };
  }, [uid, chatId]);

  const canSend = useMemo(() => {
    const hasImages = files ? Array.from(files).some(f => f.type?.startsWith('image/')) : false;
    return Boolean(uid && chat && (input.trim().length > 0 || hasImages));
  }, [uid, chat, input, files]);

  const send = async () => {
    if (!canSend || !chat) return;
    const text = input.trim();
    setInput('');
    try {
      let attachments: Array<{ url: string; name: string; contentType?: string; size?: number }> = [];
      if (files && files.length > 0) {
        const imageFiles = Array.from(files).filter((f) => f.type?.startsWith('image/'));
        const uploads = imageFiles.map(async (f) => {
          const path = `customizationChats/${chat.id}/${uid}/${Date.now()}_${f.name}`;
          const r = storageRef(storage, path);
          const snap = await uploadBytes(r, f, { contentType: f.type });
          const url = await getDownloadURL(snap.ref);
          return { url, name: f.name, contentType: f.type || undefined, size: f.size };
        });
        attachments = await Promise.all(uploads);
      }
      setFiles(null);
      await addDoc(collection(db, 'customizationChats', chat.id, 'messages'), {
        text,
        senderId: uid,
        createdAt: serverTimestamp(),
        ...(attachments.length > 0 ? { attachments } : {}),
      });
      try {
        await updateDoc(doc(db, 'customizationChats', chat.id), { typingSeller: false });
      } catch {}
    } catch (e) {
      console.error('Failed to send message', e);
    }
  };

  // Mark messages read when seller views near bottom
  const markRead = async () => {
    if (!chat) return;
    try {
      await updateDoc(doc(db, 'customizationChats', chat.id), { lastReadSellerAt: serverTimestamp() });
      setUnreadCount(0);
      setShowNewMsgBanner(false);
    } catch {}
  };

  useEffect(() => {
    if (!listRef.current) return;
    const el = listRef.current;
    const onScroll = () => {
      const threshold = 60;
      const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < threshold;
      if (nearBottom) {
        markRead();
      }
    };
    el.addEventListener('scroll', onScroll);
    return () => el.removeEventListener('scroll', onScroll);
  }, [chat]);

  const handleInputChange = async (val: string) => {
    setInput(val);
    if (!chat) return;
    try {
      await updateDoc(doc(db, 'customizationChats', chat.id), { typingSeller: true });
    } catch {}
    if (typingTimer.current) window.clearTimeout(typingTimer.current);
    typingTimer.current = window.setTimeout(async () => {
      try { await updateDoc(doc(db, 'customizationChats', chat.id), { typingSeller: false }); } catch {}
    }, 1200);
  };

  const formatDateKey = (ts: any) => {
    const d = ts?.toDate ? ts.toDate() : (ts instanceof Date ? ts : new Date());
    return d.toDateString();
  };

  const formatDateLabel = (ts: any) => {
    const d = ts?.toDate ? ts.toDate() : new Date();
    const today = new Date();
    const yday = new Date();
    yday.setDate(today.getDate() - 1);
    const sameDay = (a: Date, b: Date) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
    if (sameDay(d, today)) return 'Today';
    if (sameDay(d, yday)) return 'Yesterday';
    return d.toDateString();
  };

  const isSeenByBuyer = (m: MessageDoc) => {
    if (!chat) return false;
    const otherRead = chat.lastReadBuyerAt;
    return Boolean(otherRead && m.createdAt?.toMillis && otherRead?.toMillis && otherRead.toMillis() >= m.createdAt.toMillis());
  };

  const quickReplies = [
    'Thanks for your request! I\'m reviewing it now.',
    'Could you share preferred colors or sizes?',
    'I can deliver this by next week. Is that okay?',
    'Please share any reference image or notes.',
  ];

  if (!uid) {
    return (
      <div className="min-h-screen pt-20 pb-12 container mx-auto px-4">
        <Card className="p-6 space-y-3">
          <h1 className="text-xl font-semibold">Seller sign-in required</h1>
          <Button className="bg-gold text-black" onClick={() => navigate('/seller-login')}>Go to seller login</Button>
        </Card>
        {/* Image preview modal */}
        <Dialog open={!!previewUrl} onOpenChange={(o) => { if (!o) setPreviewUrl(null); }}>
          <DialogContent className="max-w-4xl p-2 bg-background/95 z-[60]">
            <DialogTitle className="sr-only">Image preview</DialogTitle>
            <DialogDescription className="sr-only">Full-size preview of the selected attachment image.</DialogDescription>
            {previewUrl && (
              <img src={previewUrl} alt="Preview" className="max-h-[80vh] w-auto mx-auto rounded-lg" />
            )}
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 pb-24 container mx-auto px-4">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold">Customization Chat</h1>
            {unreadCount > 0 && (
              <span className="inline-flex items-center justify-center text-xs bg-amber-500 text-black rounded-full px-2 py-0.5" title="Unread messages">
                {unreadCount} new
              </span>
            )}
          </div>
          <Button asChild variant="outline"><Link to="/seller/customizations">Back to list</Link></Button>
        </div>
        {error && (
          <div className="mb-3 text-sm text-red-600 bg-red-50 border border-red-200 rounded p-2">{error}</div>
        )}
        <Card className="p-0 overflow-hidden">
          <div
            ref={listRef}
            className="h-[60vh] overflow-y-auto overscroll-contain p-4 space-y-3 bg-muted/20"
            onWheel={(e) => {
              const el = listRef.current;
              if (!el) return;
              const atTop = el.scrollTop === 0;
              const atBottom = Math.ceil(el.scrollTop + el.clientHeight) >= el.scrollHeight;
              if ((e.deltaY < 0 && !atTop) || (e.deltaY > 0 && !atBottom)) {
                e.preventDefault();
                e.stopPropagation();
                el.scrollTop += e.deltaY;
              }
            }}
          >
            {/* Date separators like WhatsApp */}
            {messages.map((m, idx) => {
              const prev = messages[idx - 1];
              const showDate = !prev || formatDateKey(prev.createdAt) !== formatDateKey(m.createdAt);
              const mine = m.senderId === uid;
              const seen = mine && isSeenByBuyer(m);
              const timeStr = m.createdAt?.toDate ? new Date(m.createdAt.toDate()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
              return (
                <div key={m.id}>
                  {showDate && (
                    <div className="flex justify-center my-2">
                      <span className="text-[11px] px-2 py-1 rounded-full bg-white border text-gray-700 dark:bg-gray-800 dark:text-gray-200">{formatDateLabel(m.createdAt)}</span>
                    </div>
                  )}
                  <div className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${mine ? 'ml-auto bg-gold text-black' : 'mr-auto bg-white text-gray-900 border dark:bg-gray-800 dark:text-gray-100'}`}>
                    <div>{m.text}</div>
                    {Array.isArray((m as any).attachments) && (m as any).attachments.length > 0 && (
                      <div className="mt-2 space-y-2">
                        {(m as any).attachments.map((att: any, i: number) => (
                          <div key={i}>
                            {((att?.contentType && att.contentType.startsWith('image/')) || /\.(png|jpe?g|gif|webp|bmp|svg)$/i.test(att?.url || att?.name || '')) ? (
                              <button type="button" onClick={() => setPreviewUrl(att.url)} className="focus:outline-none" aria-label="Open image preview">
                                <img src={att.url} alt={att.name || 'Image'} className="max-h-48 rounded-md border" />
                              </button>
                            ) : (
                              <a href={att.url} target="_blank" rel="noreferrer" className="text-xs underline">
                                {att.name || 'Attachment'}
                              </a>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                    <div className={`mt-1 flex items-center gap-1 text-[10px] opacity-70 ${mine ? 'text-black/70 justify-end' : 'text-gray-600 dark:text-gray-300 justify-end'}`}>
                      <span>{timeStr}</span>
                      {mine && (seen ? <CheckCheck className="h-3 w-3" /> : <Check className="h-3 w-3" />)}
                    </div>
                  </div>
                </div>
              );
            })}
            <div ref={bottomRef} />
          </div>
          {otherTyping && (
            <div className="px-4 pb-2 text-xs text-muted-foreground">Buyer is typing…</div>
          )}
          <div className="p-3 border-t flex items-center gap-2">
            <input type="file" multiple accept="image/*" onChange={(e) => setFiles(e.target.files)} className="text-xs" />
            <input
              value={input}
              onChange={(e) => handleInputChange(e.target.value)}
              placeholder="Type your reply..."
              className="flex-1 rounded-md border px-3 py-2 text-sm bg-background"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
            />
            <Button onClick={send} disabled={!canSend} className="bg-gold text-black">Send</Button>
          </div>
        </Card>
        {/* Image preview modal */}
        <Dialog open={!!previewUrl} onOpenChange={(o) => { if (!o) setPreviewUrl(null); }}>
          <DialogContent className="max-w-4xl p-2 bg-background/95 z-[60]">
            <DialogTitle className="sr-only">Image preview</DialogTitle>
            <DialogDescription className="sr-only">Full-size preview of the selected attachment image.</DialogDescription>
            {previewUrl && (
              <img src={previewUrl} alt="Preview" className="max-h-[80vh] w-auto mx-auto rounded-lg" />
            )}
          </DialogContent>
        </Dialog>
        {/* Quick replies */}
        <div className="mt-3 flex flex-wrap gap-2">
          {quickReplies.map((q, i) => (
            <button key={i} className="text-xs px-2 py-1 rounded-full border bg-white hover:bg-muted dark:bg-gray-800" onClick={() => setInput((p) => (p ? p + ' ' + q : q))}>{q}</button>
          ))}
        </div>
        {showNewMsgBanner && (
          <div className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-black/80 text-white text-xs px-3 py-2 rounded-full shadow" onClick={() => { setShowNewMsgBanner(false); bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }}>
            New message — tap to jump
          </div>
        )}
      </div>
    </div>
  );
}
