import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, BarChart2, ShoppingBag } from 'lucide-react';
import { useToast } from '@/components/ui/toast-context';
import { db } from '@/lib/firebase';
import { collection, getDocs, query, where, Timestamp } from 'firebase/firestore';
import { bucketByDay, dateRangeKeys } from '@/utils/analytics';

export default function AdminAnalyticsPage() {
  const [range, setRange] = useState<'7d' | '30d' | '90d' | 'lifetime'>('30d');
  const [loading, setLoading] = useState(true);
  const [kpis, setKpis] = useState({ gmv: 0, orders: 0, aov: 0 });
  const [topProducts, setTopProducts] = useState<any[]>([]);
  const { showToast } = useToast();
  const [productsIndex, setProductsIndex] = useState<Record<string, { category?: string; sellerId?: string; name?: string }>>({});
  const [categories, setCategories] = useState<string[]>([]);
  const [sellers, setSellers] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSeller, setSelectedSeller] = useState<string>('all');
  const [seriesKeys, setSeriesKeys] = useState<string[]>([]);
  const [seriesValues, setSeriesValues] = useState<number[]>([]);

  // Load products for category/seller filters and lookup
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const snap = await getDocs(collection(db, 'products'));
        if (cancelled) return;
        const idx: Record<string, { category?: string; sellerId?: string; name?: string }> = {};
        const cats = new Set<string>();
        const sels = new Set<string>();
        snap.docs.forEach(d => {
          const p: any = d.data();
          const id = d.id;
          const cat = p?.category || '';
          const sellerId = p?.sellerId || '';
          const name = p?.name || '';
          idx[id] = { category: cat, sellerId, name };
          if (cat) cats.add(cat);
          if (sellerId) sels.add(sellerId);
        });
        setProductsIndex(idx);
        setCategories(['all', ...Array.from(cats).sort()]);
        setSellers(['all', ...Array.from(sels).sort()]);
      } catch (e) {
        console.warn('Failed to load products index for analytics', e);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  // Helper: derive start date from range
  const getStart = (r: typeof range): Date | null => {
    const now = new Date();
    if (r === 'lifetime') return null;
    const d = new Date(now);
    const days = r === '7d' ? 7 : r === '30d' ? 30 : 90;
    d.setDate(d.getDate() - days);
    d.setHours(0, 0, 0, 0);
    return d;
  };

  // Try to compute order amount robustly
  const computeOrderAmount = (o: any): number => {
    const direct = Number(o?.total);
    if (Number.isFinite(direct) && direct > 0) return direct;
    const items: any[] = Array.isArray(o?.items) ? o.items : [];
    if (items.length > 0) {
      return items.reduce((sum, it: any) => {
        const price = Number(it?.price ?? it?.finalPrice ?? it?.sellerPrice ?? 0);
        const qty = Number(it?.qty ?? it?.quantity ?? 1);
        return sum + (Number.isFinite(price) ? price : 0) * (Number.isFinite(qty) ? qty : 1);
      }, 0);
    }
    return 0;
  };

  // Load analytics from Firestore
  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        setLoading(true);
        const ordersRef = collection(db, 'orders');
        const start = getStart(range);
        const startTs = start ? Timestamp.fromDate(start) : null;

        // Prefer range query by createdAt to avoid composite index issues; filter status client-side
        let q = startTs
          ? query(ordersRef, where('createdAt', '>=', startTs))
          : query(ordersRef);

        const snap = await getDocs(q);
        if (cancelled) return;

        const completed = snap.docs
          .map(d => ({ id: d.id, ...(d.data() as any) } as any))
          .filter((o: any) => (o?.status || '').toLowerCase() === 'delivered');

        // Build revenue contributions per order respecting filters
        const byProduct: Record<string, { id: string; name: string; revenue: number; qty: number }> = {};
        let gmv = 0;
        let orders = 0;
        const contributions: Array<{ ts: Date | number | string; value: number }> = [];

        const createdAtOf = (o: any): Date | null => {
          const v = o?.createdAt || o?.created || o?.orderedAt;
          if (!v) return null;
          if (typeof v?.toDate === 'function') return v.toDate();
          if (v instanceof Date) return v;
          if (typeof v === 'number') return new Date(v);
          const parsed = Date.parse(v);
          return Number.isNaN(parsed) ? null : new Date(parsed);
        };

        for (const o of completed) {
          const items: any[] = Array.isArray(o?.items) ? o.items : [];
          let orderSum = 0;
          for (const it of items) {
            const pid = String(it?.productId ?? it?.id ?? 'unknown');
            const meta = productsIndex[pid] || {};
            const matchesCategory = selectedCategory === 'all' || (meta.category || '') === selectedCategory;
            const matchesSeller = selectedSeller === 'all' || (meta.sellerId || '') === selectedSeller;
            if (!matchesCategory || !matchesSeller) continue;

            const name = String(it?.name ?? it?.title ?? meta.name ?? 'Unknown');
            const price = Number(it?.price ?? it?.finalPrice ?? it?.sellerPrice ?? 0);
            const qty = Number(it?.qty ?? it?.quantity ?? 1);
            const revenue = (Number.isFinite(price) ? price : 0) * (Number.isFinite(qty) ? qty : 1);
            if (revenue <= 0) continue;
            if (!byProduct[pid]) byProduct[pid] = { id: pid, name, revenue: 0, qty: 0 };
            byProduct[pid].revenue += revenue;
            byProduct[pid].qty += Number.isFinite(qty) ? qty : 0;
            orderSum += revenue;
          }
          if (orderSum > 0) {
            gmv += orderSum;
            orders += 1;
            const ts = createdAtOf(o) || new Date();
            contributions.push({ ts, value: orderSum });
          }
        }

        const aov = orders > 0 ? gmv / orders : 0;
        const top = Object.values(byProduct).sort((a, b) => b.revenue - a.revenue).slice(0, 10);

        // Build daily series
        const buckets = bucketByDay(contributions);
        const now = new Date();
        const startDate = start || (() => {
          const keys = Object.keys(buckets);
          if (keys.length === 0) return new Date(now.getFullYear(), now.getMonth(), now.getDate());
          keys.sort();
          const [y, m, d] = keys[0].split('-').map(Number);
          return new Date(y, (m || 1) - 1, d || 1);
        })();
        const keys = dateRangeKeys(startDate, now);
        const values = keys.map(k => buckets[k] || 0);

        setKpis({ gmv, orders, aov });
        setTopProducts(top);
        setSeriesKeys(keys);
        setSeriesValues(values);
      } catch (e: any) {
        console.error('Failed to load analytics:', e);
        showToast({ message: 'Failed to load analytics', type: 'error' });
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, [range, selectedCategory, selectedSeller, productsIndex, showToast]);

  const fmtCurrency = (n: number) => `₹ ${Math.round(n).toLocaleString()}`;

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <h1 className="text-3xl font-bold mb-2">Platform Analytics</h1>
      <p className="text-muted-foreground mb-6">View platform performance metrics and insights</p>

      {/* Filters */}
      <div className="mb-6 flex flex-col md:flex-row md:items-center gap-3">
        {(['7d','30d','90d','lifetime'] as const).map(r => (
          <Button
            key={r}
            variant={range === r ? 'default' : 'ghost'}
            className={range === r ? 'bg-gold text-black hover:bg-gold/90' : ''}
            onClick={() => setRange(r)}
          >
            {r.toUpperCase()}
          </Button>
        ))}
        <div className="flex items-center gap-2">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2 rounded-md bg-muted/40 border border-border/60 outline-none"
          >
            {categories.map(c => <option key={c} value={c}>{c === 'all' ? 'All Categories' : c}</option>)}
          </select>
          <select
            value={selectedSeller}
            onChange={(e) => setSelectedSeller(e.target.value)}
            className="px-3 py-2 rounded-md bg-muted/40 border border-border/60 outline-none"
          >
            {sellers.map(s => <option key={s} value={s}>{s === 'all' ? 'All Sellers' : s}</option>)}
          </select>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><BarChart2 className="h-5 w-5"/>GMV</CardTitle>
            <CardDescription>Total revenue from delivered orders</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center gap-2 text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin"/>Loading…</div>
            ) : (
              <div className="text-3xl font-bold">{fmtCurrency(kpis.gmv)}</div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><ShoppingBag className="h-5 w-5"/>Orders</CardTitle>
            <CardDescription>Delivered orders</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center gap-2 text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin"/>Loading…</div>
            ) : (
              <div className="text-3xl font-bold">{kpis.orders}</div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><BarChart2 className="h-5 w-5"/>AOV</CardTitle>
            <CardDescription>Average order value</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center gap-2 text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin"/>Loading…</div>
            ) : (
              <div className="text-3xl font-bold">{fmtCurrency(kpis.aov)}</div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Revenue by Day (SVG) */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Revenue by Day</CardTitle>
          <CardDescription>Daily GMV for selected range and filters</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center gap-2 text-muted-foreground"><Loader2 className="h-5 w-5 animate-spin"/>Loading…</div>
          ) : (
            <div className="w-full">
              {(() => {
                const w = 640, h = 220, pad = 28;
                const n = Math.max(seriesValues.length, 1);
                const maxV = Math.max(0, ...seriesValues);
                const pts = seriesValues.map((v, i) => {
                  const x = pad + (n === 1 ? 0 : (i / (n - 1)) * (w - pad * 2));
                  const y = pad + (maxV === 0 ? (h - pad * 2) : (1 - v / maxV) * (h - pad * 2));
                  return `${x},${y}`;
                });
                const path = pts.length > 0 ? `M ${pts[0]} L ${pts.slice(1).join(' ')}` : '';
                const yTicks = 4;
                const tickVals = Array.from({ length: yTicks + 1 }, (_, i) => Math.round((maxV * i) / yTicks));
                return (
                  <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-[240px]">
                    {/* Axes */}
                    <line x1={pad} y1={h - pad} x2={w - pad} y2={h - pad} stroke="#ccc" strokeWidth={1} />
                    <line x1={pad} y1={pad} x2={pad} y2={h - pad} stroke="#ccc" strokeWidth={1} />
                    {/* Y Ticks */}
                    {tickVals.map((tv, i) => {
                      const y = pad + (maxV === 0 ? (h - pad * 2) : (1 - tv / maxV) * (h - pad * 2));
                      return (
                        <g key={i}>
                          <line x1={pad - 4} y1={y} x2={w - pad} y2={y} stroke="#eee" strokeWidth={1} />
                          <text x={4} y={y + 4} fontSize={10} fill="#666">₹ {tv.toLocaleString()}</text>
                        </g>
                      );
                    })}
                    {/* X Labels: start, mid, end */}
                    {seriesKeys.length > 0 && (
                      <>
                        <text x={pad} y={h - 6} fontSize={10} fill="#666" textAnchor="start">{seriesKeys[0]}</text>
                        <text x={w / 2} y={h - 6} fontSize={10} fill="#666" textAnchor="middle">{seriesKeys[Math.floor(seriesKeys.length / 2)]}</text>
                        <text x={w - pad} y={h - 6} fontSize={10} fill="#666" textAnchor="end">{seriesKeys[seriesKeys.length - 1]}</text>
                      </>
                    )}
                    {/* Line */}
                    <path d={path} fill="none" stroke="#d4af37" strokeWidth={2} />
                    {/* Dots */}
                    {seriesValues.map((v, i) => {
                      const x = pad + (seriesValues.length === 1 ? 0 : (i / (seriesValues.length - 1)) * (w - pad * 2));
                      const y = pad + (maxV === 0 ? (h - pad * 2) : (1 - v / maxV) * (h - pad * 2));
                      return <circle key={i} cx={x} cy={y} r={2.5} fill="#d4af37" />;
                    })}
                  </svg>
                );
              })()}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Top Products Table */}
      <Card>
        <CardHeader>
          <CardTitle>Top Products by Revenue</CardTitle>
          <CardDescription>Last {range === 'lifetime' ? 'lifetime' : range}</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center gap-2 text-muted-foreground py-10"><Loader2 className="h-5 w-5 animate-spin"/>Loading…</div>
          ) : topProducts.length === 0 ? (
            <div className="text-muted-foreground">No data for selected range.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm">
                <thead className="text-left text-muted-foreground">
                  <tr>
                    <th className="py-2 pr-4">Product</th>
                    <th className="py-2 pr-4">Qty</th>
                    <th className="py-2 pr-4">Revenue</th>
                    <th className="py-2 pr-4">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {topProducts.map(p => (
                    <tr key={p.id} className="border-t border-border/60">
                      <td className="py-2 pr-4 max-w-xs">
                        <div className="font-medium truncate" title={p.name}>{p.name}</div>
                        <div className="text-[10px] text-muted-foreground break-all">{p.productCode || p.id}</div>
                      </td>
                      <td className="py-2 pr-4">{p.qty}</td>
                      <td className="py-2 pr-4">{fmtCurrency(p.revenue)}</td>
                      <td className="py-2 pr-4">
                        <Link to="/admin/products" state={{ tab: 'published' }} className="text-gold hover:underline">View in Products</Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
