import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Grid2X2, List, Heart, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useStore } from '@/store/useStore';
import { formatCurrency } from '@/lib/utils';
import { useCart } from '@/contexts/CartContext';
import { useAuthGate } from '@/hooks/useAuthGate';
import { useNavigate } from 'react-router-dom';
import ProductImageCarousel from '@/components/ProductImageCarousel';
import { RatingPill } from '@/components/RatingPill';

interface ProductDoc {
  id: string;
  name: string;
  description?: string;
  price: number; // legacy price kept

  imageUrl?: string;
  images?: string[];
  imageUrls?: string[];
  category?: string;
  sellerPrice?: number; // seller-set
  finalPrice?: number; // admin-set
}

export function HomemadeHouseholdsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<ProductDoc[]>([]);
  const { toggleWishlist, isWishlisted } = useStore();
  const { addToCart } = useCart();
  const { runOrLogin } = useAuthGate();
  const navigate = useNavigate();

  // Filters state
  const [showFilters, setShowFilters] = useState(false);
  const [priceRange, setPriceRange] = useState<'all' | 'under25' | '25to50' | '50to100' | 'over100'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'priceAsc' | 'priceDesc' | 'impact' | 'popular'>('newest');

  useEffect(() => {
    const q = query(
      collection(db, 'products'),
      where('category', '==', 'homemade-households'),
      where('published', '==', true)
    );
    const unsub = onSnapshot(q, (snap) => {
      const rows: ProductDoc[] = snap.docs.map((d) => {
        const data = d.data() as any;
        const images: string[] = Array.isArray(data.images)
          ? data.images
          : Array.isArray(data.imageUrls)
          ? data.imageUrls
          : data.imageUrl
          ? [data.imageUrl]
          : [];
        return {
          id: d.id,
          name: data.name,
          description: data.description,
          imageUrl: data.imageUrl,
          images,
          category: data.category,
          price: typeof data.price === 'number' ? data.price : Number(data.price || 0),
          sellerPrice: typeof data.sellerPrice === 'number' ? data.sellerPrice : (data.sellerPrice != null ? Number(data.sellerPrice) : undefined),
          finalPrice: typeof data.finalPrice === 'number' ? data.finalPrice : (data.finalPrice != null ? Number(data.finalPrice) : undefined),
        };
      });

      setProducts(rows);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const getDisplayPrice = (p: ProductDoc) => {
    const v = p.finalPrice ?? p.sellerPrice ?? p.price ?? 0;
    return Number.isFinite(v as number) ? Number(v) : 0;
  };

  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    let list = !q
      ? products
      : products.filter((p) =>
          (p.name || '').toLowerCase().includes(q) || (p.description || '').toLowerCase().includes(q)
        );

    // Apply price filter
    list = list.filter((p) => {
      const price = getDisplayPrice(p);
      switch (priceRange) {
        case 'under25':
          return price < 25;
        case '25to50':
          return price >= 25 && price <= 50;
        case '50to100':
          return price > 50 && price <= 100;
        case 'over100':
          return price > 100;
        default:
          return true;
      }
    });

    // Sort
    if (sortBy === 'priceAsc') {
      list = [...list].sort((a, b) => getDisplayPrice(a) - getDisplayPrice(b));
    } else if (sortBy === 'priceDesc') {
      list = [...list].sort((a, b) => getDisplayPrice(b) - getDisplayPrice(a));
    } // 'newest' | 'impact' | 'popular' fall back to server/default order

    return list;
  }, [products, searchQuery, priceRange, sortBy]);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-12"
    >
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Homemade <span className="text-gold">Households</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore eco-friendly, handcrafted household goods from local makers.
          </p>
        </div>

        <div className="mb-8">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between mb-6">
            {/* Search Bar */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search household items..."
                value={searchQuery}
                onChange={handleSearch}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 pl-10"
              />
            </div>

            {/* Filter and View Options */}
            <div className="flex items-center gap-2 relative">
              {/* Filters trigger (matches provided DOM) */}
              <button
                type="button"
                onClick={() => setShowFilters((s) => !s)}
                className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 btn-hover btn-hover border border-primary bg-transparent text-primary hover:bg-primary hover:text-primary-foreground h-10 px-4 py-2 gap-2"
              >
                {/* inline svg to avoid extra imports and match visual */}
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-filter h-4 w-4"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon></svg>
                Filters
              </button>

              {showFilters && (
                <div className="absolute top-12 right-0 z-40 w-80 sm:w-[28rem] bg-background border border-border rounded-md shadow-lg p-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Price Range</label>
                    <div className="space-y-2">
                      <button onClick={() => setPriceRange('all')} className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceRange==='all' ? 'bg-gold text-black' : 'hover:bg-muted'}`}>All Prices</button>
                      <button onClick={() => setPriceRange('under25')} className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceRange==='under25' ? 'bg-gold text-black' : 'hover:bg-muted'}`}>Under ₹25</button>
                      <button onClick={() => setPriceRange('25to50')} className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceRange==='25to50' ? 'bg-gold text-black' : 'hover:bg-muted'}`}>₹25 - ₹50</button>
                      <button onClick={() => setPriceRange('50to100')} className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceRange==='50to100' ? 'bg-gold text-black' : 'hover:bg-muted'}`}>₹50 - ₹100</button>
                      <button onClick={() => setPriceRange('over100')} className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceRange==='over100' ? 'bg-gold text-black' : 'hover:bg-muted'}`}>Over ₹100</button>
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Sort By</label>
                    <div className="space-y-2">
                      <button onClick={() => setSortBy('newest')} className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy==='newest' ? 'bg-gold text-black' : 'hover:bg-muted'}`}>Newest First</button>
                      <button onClick={() => setSortBy('priceAsc')} className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy==='priceAsc' ? 'bg-gold text-black' : 'hover:bg-muted'}`}>Price: Low to High</button>
                      <button onClick={() => setSortBy('priceDesc')} className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy==='priceDesc' ? 'bg-gold text-black' : 'hover:bg-muted'}`}>Price: High to Low</button>
                      <button onClick={() => setSortBy('impact')} className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy==='impact' ? 'bg-gold text-black' : 'hover:bg-muted'}`}>Highest Impact</button>
                      <button onClick={() => setSortBy('popular')} className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy==='popular' ? 'bg-gold text-black' : 'hover:bg-muted'}`}>Most Popular</button>
                    </div>
                  </div>
                </div>
              )}
 
              <div className="border rounded-md flex">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Grid2X2 className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Results Count */}
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">
              {filteredProducts.length} items found
            </p>
            <p className="text-sm text-muted-foreground">
              Sorted by {sortBy === 'priceAsc' ? 'Price: Low to High' : sortBy === 'priceDesc' ? 'Price: High to Low' : sortBy === 'impact' ? 'Highest Impact' : sortBy === 'popular' ? 'Most Popular' : 'Newest First'}
            </p>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading household items…</p>
          </div>
        ) : (
          <>
            {/* Product Grid */}
            <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4' : 'grid-cols-1'} gap-6`}>
              {filteredProducts.map(product => (
                <Card
                  key={product.id}
                  className="overflow-hidden group cursor-pointer focus:outline-none focus:ring-2 focus:ring-gold"
                  role="button"
                  tabIndex={0}
                  onClick={() => navigate(`/product/${product.id}`)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      navigate(`/product/${product.id}`);
                    }
                  }}
                >
                  <div className="relative">
                    <div className="overflow-hidden h-48 w-full">
                      <ProductImageCarousel
                        images={product.images && product.images.length ? product.images : (product.imageUrl ? [product.imageUrl] : [])}
                        alt={product.name}
                        className="w-full h-full object-cover"
                        aspect="free"
                      />
                    </div>
                    {product.category && (
                      <Badge className="absolute top-2 left-2 bg-gold text-black text-xs">{product.category}</Badge>
                    )}
                    {/* Wishlist toggle */}
                    <Button
                      size="icon"
                      variant="ghost"
                      className="absolute top-1 right-1 bg-black/50 hover:bg-black/70 text-white h-8 w-8"
                      onClick={(e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        toggleWishlist(product.id);
                      }}
                      aria-pressed={isWishlisted(product.id)}
                      aria-label={isWishlisted(product.id) ? 'Remove from wishlist' : 'Add to wishlist'}
                    >
                      <Heart className={`h-3.5 w-3.5 ${isWishlisted(product.id) ? 'fill-red-500 text-red-500' : ''}`} />
                    </Button>
                  </div>
                  
                  <CardContent className="p-3">
                    <h3 className="font-semibold text-base mb-1 group-hover:text-gold transition-colors line-clamp-1">
                      {product.name}
                    </h3>
                    {product.description && (
                      <p className="text-muted-foreground text-xs mb-2 line-clamp-2 h-10">
                        {product.description}
                      </p>
                    )}
                    {/* Ratings pill above price/add button */}
                    <div className="mb-2">
                      <RatingPill productId={product.id} docData={product as any} />
                    </div>
                    <div className="flex justify-between items-center mt-2">
                      <span className="font-bold text-base">
                        {getDisplayPrice(product) > 0 ? formatCurrency(getDisplayPrice(product)) : 'Price on request'}
                      </span>
                      {getDisplayPrice(product) > 0 && (
                        <Button
                          className="bg-gold hover:bg-amber-500 text-black border border-amber-300 rounded-md px-3 py-1.5 h-8 text-sm font-medium transition-colors shadow-sm hover:shadow flex items-center gap-1.5 whitespace-nowrap"
                          onClick={async (e) => {
                            e.stopPropagation();
                            e.preventDefault();
                            const price = getDisplayPrice(product);
                            const cartProduct = {
                              id: product.id,
                              name: product.name,
                              price,
                              imageUrl: (product.images?.[0] || product.imageUrl || '/images/placeholder-item.jpg'),
                              category: 'homemade-households',
                            };
                            runOrLogin(() => {
                              addToCart(cartProduct);
                            });
                          }}
                        >
                          <ShoppingCart className="h-3.5 w-3.5" />
                          <span>Add to Cart</span>
                        </Button>
                      )}
                    </div>
                    {getDisplayPrice(product) <= 0 && (
                      <Button
                        className="w-full mt-3 bg-gold hover:bg-amber-500 text-black h-9"
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(`/product/${product.id}`);
                        }}
                      >
                        View Details
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className="text-center py-12">
                {products.length === 0 && !searchQuery ? (
                  <p className="text-muted-foreground">No household items available at the moment.</p>
                ) : (
                  <p className="text-muted-foreground">No household items found matching your search.</p>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </motion.div>
  );
}

export default HomemadeHouseholdsPage;
