import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  Filter, 
  Grid3X3, 
  List, 
  Heart,
  Star,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { ProductCardSkeleton } from '@/components/ui/loading';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';
import { firestoreService } from '@/services/firebase';
import { useStore } from '@/store/useStore';
import { useCart } from '@/contexts/CartContext';
import { formatCurrency, calculateUplift } from '@/lib/utils';
import type { Product } from '@/types';
import { auth } from '@/lib/firebase';
import placeholderImg from '@/assets/logo2.png';
import { useAuthGate } from '@/hooks/useAuthGate';
import ProductImageCarousel from '@/components/ProductImageCarousel';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '@/lib/firebase';

const categories = [
  'All Categories',
  'charity-craft',
  'organic-store', 
  'scrap-store',
  'moms-made-united',
  'charity-bakes',
  'home-plants',
  'beauty-homemade',
  'homemade-households',
  'birthday-gifts',
  'home-decor',
  'packed-food',
  'scrap-books',
  'green-cup-challenge'
];

const sortOptions = [
  { value: 'newest', label: 'Newest First' },
  { value: 'price-low', label: 'Price: Low to High' },
  { value: 'price-high', label: 'Price: High to Low' },
  { value: 'impact', label: 'Highest Impact' },
  { value: 'popular', label: 'Most Popular' }
];

const priceRanges = [
  { label: 'All Prices', min: 0, max: Infinity },
  { label: 'Under ₹25', min: 0, max: 25 },
  { label: '₹25 - ₹50', min: 25, max: 50 },
  { label: '₹50 - ₹100', min: 50, max: 100 },
  { label: 'Over ₹100', min: 100, max: Infinity }
];

interface ProductCardProps {
  product: Product;
  index: number;
  viewMode: 'grid' | 'list';
}

const ProductCard = React.forwardRef<HTMLDivElement, ProductCardProps>(({ product, index, viewMode = 'grid' }, ref) => {
  const { addToCart } = useCart();
  const { user, toggleWishlist, isWishlisted } = useStore();
  const navigate = useNavigate();
  const { runOrLogin } = useAuthGate();
  const wishlisted = isWishlisted(product.id);
  const isOut = product.outOfStock === true || (typeof product.stock === 'number' && product.stock <= 0);
  
  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isOut) return;
    const cartProduct = {
      id: product.id,
      name: product.title,
      price: product.basePriceSeller,
      imageUrl: product.images?.[0] || placeholderImg,
      category: product.category,
      sellerId: product.sellerId,
    };
    runOrLogin(async () => {
      await addToCart(cartProduct);
      // Stay on the same page after adding to cart
    });
  };

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    runOrLogin(() => {
      toggleWishlist(product.id);
    });
  };

  const handleOpen = () => {
    const target = `/product/${product.id}`;
    if (user) {
      navigate(target);
    } else {
      navigate('/login', { state: { from: target } });
    }
  };

  // Actual ratings from product document (no dummy)
  const ratingValue = useMemo(() => {
    const anyProd: any = product as any;
    const val = anyProd?.ratingAvg ?? anyProd?.avgRating ?? anyProd?.rating;
    return typeof val === 'number' ? val : undefined;
  }, [product]);

  const ratingCount = useMemo(() => {
    const anyProd: any = product as any;
    const val = anyProd?.ratingCount ?? anyProd?.reviewsCount;
    return typeof val === 'number' ? val : undefined;
  }, [product]);

  // If missing on product doc, compute from reviews collection
  const [fetchedAvg, setFetchedAvg] = useState<number | undefined>(undefined);
  const [fetchedCount, setFetchedCount] = useState<number | undefined>(undefined);
  useEffect(() => {
    let cancelled = false;
    async function loadAvg() {
      if (typeof ratingValue === 'number') return; // already present on product
      try {
        const reviewsRef = collection(db, 'products', product.id, 'reviews');
        const rs = await getDocs(reviewsRef);
        let sum = 0;
        let count = 0;
        rs.forEach((d) => {
          const r: any = d.data();
          const val = Number(r?.rating ?? 0);
          if (!Number.isNaN(val) && val > 0) { sum += val; count += 1; }
        });
        if (!cancelled) {
          setFetchedCount(count || undefined);
          setFetchedAvg(count > 0 ? Math.round((sum / count) * 10) / 10 : undefined);
        }
      } catch {
        if (!cancelled) {
          setFetchedAvg(undefined);
          setFetchedCount(undefined);
        }
      }
    }
    loadAvg();
    return () => { cancelled = true; };
  }, [product.id, ratingValue]);

  const productCardContent = (
    <>
      <div className={viewMode === 'list' ? 'relative w-48 h-48 flex-shrink-0' : 'relative'}>
        <div className="overflow-hidden h-48 w-full">
          <ProductImageCarousel
            images={product.images}
            alt={product.title}
            aspect="free"
            className="w-full h-full object-cover"
          />
        </div>
        
        <Button
          size="icon"
          variant="ghost"
          className={`absolute top-2 right-2 bg-black/50 hover:bg-black/70 text-white ${
            viewMode === 'list' ? 'opacity-100' : 'opacity-0 group-hover:opacity-100 transition-opacity'
          }`}
          onClick={handleWishlistToggle}
          aria-pressed={wishlisted}
          aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
        >
          <Heart className={`h-4 w-4 ${wishlisted ? 'fill-red-500 text-red-500' : ''}`} />
        </Button>
        
        {isOut && (
          <div className="absolute bottom-2 left-2">
            <Badge variant="secondary" className="bg-red-600 text-white">Out of stock</Badge>
          </div>
        )}
        
        {viewMode === 'grid' && (
          <div className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <Button onClick={handleAddToCart} className="w-full" size="sm" disabled={isOut} aria-disabled={isOut}>
              {isOut ? 'Out of stock' : 'Add to Cart'}
            </Button>
          </div>
        )}
      </div>
      
      <div className={viewMode === 'list' ? 'flex-1 p-4' : 'p-4'}>
        <div className="flex justify-between items-start mb-2">
          <h3 className={`font-semibold group-hover:text-gold transition-colors ${
            viewMode === 'list' ? 'text-lg' : 'line-clamp-2'
          }`}>
            {product.title}
          </h3>
        </div>
        
        {viewMode === 'list' && (
          <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
            {product.description}
          </p>
        )}
          {/* Category/Customizable chips */}
          <div className="flex items-center gap-2 my-2">
          <Badge 
            variant={viewMode === 'list' ? 'secondary' : 'outline'} 
            className="inline-flex items-center h-8 px-3 text-sm rounded-md border border-amber-300 bg-gold text-black shadow-sm hover:shadow-md hover:brightness-95 transition"
          >
            {product.category}
          </Badge>
          {product.customizable && (
            <Badge 
              className="inline-flex items-center h-8 px-3 text-sm rounded-md bg-emerald-500/20 text-emerald-700 border border-emerald-600/40 shadow-sm hover:shadow-md hover:bg-emerald-500/30 transition"
            >
              Customizable
            </Badge>
          )}
          {isOut && viewMode === 'grid' && (
            <Badge variant="secondary" className="inline-flex items-center h-8 px-3 text-sm rounded-md bg-red-600 text-white">
              Out of stock
            </Badge>
          )}
        </div>
        
        {/* Rating (star-only) below chips */}
        <div className="flex items-center gap-3 mt-2 mb-2">
          {/* Ratings: star-only, not a button. Uses real rating from product doc or computed from reviews. */}
          <div
            className="inline-flex items-center text-sm"
            title={(() => {
              const val = (typeof ratingValue === 'number' ? ratingValue : fetchedAvg);
              const cnt = (typeof ratingCount === 'number' ? ratingCount : fetchedCount);
              return val ? `Rating ${val.toFixed(1)} out of 5${cnt ? ` • ${cnt} ratings` : ''}` : 'Not yet rated';
            })()}
            aria-label={(() => {
              const val = (typeof ratingValue === 'number' ? ratingValue : fetchedAvg);
              return val ? `Rating ${val.toFixed(1)} out of 5` : 'Not yet rated';
            })()}
          >
            <Star className="h-4 w-4 text-amber-400 fill-amber-400" />
            {(() => {
              const val = (typeof ratingValue === 'number' ? ratingValue : fetchedAvg);
              return typeof val === 'number' ? (
                <span className="ml-1 text-xs text-muted-foreground">{val.toFixed(1)}</span>
              ) : null;
            })()}
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <span className="text-lg font-bold">{formatCurrency(product.basePriceSeller)}</span>
          {viewMode === 'list' && (
            <Button 
              onClick={handleAddToCart} 
              size="sm" 
              disabled={isOut} 
              aria-disabled={isOut}
              className="ml-2"
            >
              {isOut ? 'Out of stock' : 'Add to Cart'}
            </Button>
          )}
        </div>
      </div>
    </>
  );

  if (viewMode === 'list') {
    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, delay: index * 0.05 }}
        className="w-full"
      >
        <div
          role="button"
          tabIndex={0}
          onClick={handleOpen}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              handleOpen();
            }
          }}
          className="w-full"
        >
          <Card className="flex group card-hover">
            {productCardContent}
          </Card>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.05 }}
      className="w-full"
    >
      <div
        role="button"
        tabIndex={0}
        onClick={handleOpen}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleOpen();
          }
        }}
        className="cursor-pointer focus:outline-none focus:ring-2 focus:ring-gold h-full"
      >
        <Card className="overflow-hidden group card-hover h-full flex flex-col">
          {productCardContent}
        </Card>
      </div>
    </motion.div>
  );
});

ProductCard.displayName = 'ProductCard';

export function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [seeding, setSeeding] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [sortBy, setSortBy] = useState('newest');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [selectedPriceRange, setSelectedPriceRange] = useState(priceRanges[0]);
  const [searchQuery, setSearchQuery] = useState('');
  const [visibleCount, setVisibleCount] = useState(20);
  const [searchParams] = useSearchParams();
  const sellerId = searchParams.get('sellerId');
  const sellerCode = searchParams.get('sellerCode');

  const { ref: headerRef, isInView: headerInView } = useScrollAnimation();
  const { ref: productsRef } = useScrollAnimation();

  useEffect(() => {
    let unsub: (() => void) | null = null;
    (async () => {
      try {
        setLoading(true);
        // 1) One-time preload of all products
        const initial = await firestoreService.getProducts();
        if (initial?.length) setProducts(initial);
      } catch (e) {
        console.warn('Initial getProducts failed:', e);
      } finally {
        setLoading(false);
      }
      // 2) Real-time updates
      unsub = firestoreService.subscribeToProducts((items) => {
        setProducts(items);
      });
    })();
    return () => {
      if (typeof unsub === 'function') unsub();
    };
  }, []);

  useEffect(() => {
    if (products.length > 0) {
      const uniqueCategories = [...new Set(products.map(p => p.category))];
      console.log('=== PRODUCTS DEBUG ===');
      console.log('Total products:', products.length);
      console.log('Unique categories in products:', uniqueCategories);
      console.log('Sample product categories (first 5):', products.slice(0, 5).map(p => ({
        id: p.id,
        title: p.title,
        category: p.category,
        published: p.published
      })));
    }
  }, [products]);

  

  const filteredAndSortedProducts = useMemo(() => {
    console.log('=== FILTERING PRODUCTS ===');
    console.log('Selected category:', selectedCategory);
    
    let filtered = products.filter(product => {
      // Skip unpublished products
      if (product.published === false) {
        console.log(`Skipping ${product.id} - unpublished`);
        return false;
      }
      
      // Seller filter - only apply if sellerId is provided
      if (sellerId && product.sellerId !== sellerId) {
        return false;
      }
      
      // If seller filter is active, skip other filters
      if (sellerId) {
        return true;
      }
      
      // Category filter - only apply if no seller filter
      if (selectedCategory !== 'All Categories' && product.category !== selectedCategory) {
        return false;
      }
      
      // Price filter (use exact/base price)
      const price = product.basePriceSeller;
      if (price < selectedPriceRange.min || price > selectedPriceRange.max) {
        console.log(`Skipping ${product.id} - price out of range`);
        return false;
      }
      
      // Search filter
      if (searchQuery && !product.title.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !product.description.toLowerCase().includes(searchQuery.toLowerCase())) {
        console.log(`Skipping ${product.id} - search mismatch`);
        return false;
      }
      
      return true;
    });

    console.log(`Filtered to ${filtered.length} products`);

    // Sort products
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'price-low':
          return a.basePriceSeller - b.basePriceSeller;
        case 'price-high':
          return b.basePriceSeller - a.basePriceSeller;
        case 'impact':
          return calculateUplift(b.basePriceSeller, b.upliftPercent).charityAmount - 
                 calculateUplift(a.basePriceSeller, a.upliftPercent).charityAmount;
        case 'newest':
        default:
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
    });

    return filtered;
  }, [products, selectedCategory, selectedPriceRange, searchQuery, sortBy, sellerId]);

  useEffect(() => {
    setVisibleCount(20);
  }, [selectedCategory, selectedPriceRange, searchQuery, sortBy, sellerId]);

  const visibleProducts = useMemo(
    () => filteredAndSortedProducts.slice(0, visibleCount),
    [filteredAndSortedProducts, visibleCount]
  );

  const handleSeedProducts = async () => {
    setSeeding(true);
    try {
      // Reload from Firestore
      const fetched = await firestoreService.getProducts();
      setProducts(fetched);
    } catch (e) {
      console.error('Failed to seed products', e);
    } finally {
      setSeeding(false);
    }
  };

  // Update page title and handle seller filter
  useEffect(() => {
    if (sellerCode) {
      document.title = `Products by Seller ${sellerCode} - EWSells`;
      // When seller filter is active, reset other filters
      setSelectedCategory('All Categories');
      setSelectedPriceRange(priceRanges[0]);
      setSearchQuery('');
    } else {
      document.title = 'All Products - EWSells';
    }
  }, [sellerCode]);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4">
        {/* Header */}
        <header ref={headerRef} className="bg-white shadow-sm sticky top-0 z-10">
          {sellerCode && (
            <div className="bg-gradient-to-r from-yellow-50 to-amber-50 py-2 px-4 border-b border-amber-100">
              <div className="max-w-7xl mx-auto">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-amber-800">Viewing products from seller:</span>
                  <span className="font-medium text-amber-900">{sellerCode}</span>
                </div>
              </div>
            </div>
          )}
        </header>

        {/* Search and Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={headerInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mb-8"
        >
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between mb-6">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Controls */}
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                onClick={() => setIsFilterOpen(!isFilterOpen)}
                className="gap-2"
              >
                <Filter className="h-4 w-4" />
                Filters
              </Button>
              
              <div className="flex items-center gap-1 border rounded-md p-1">
                <Button
                  size="sm"
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  onClick={() => setViewMode('grid')}
                  className="p-2"
                >
                  <Grid3X3 className="h-4 w-4" />
                </Button>
                <Button
                  size="sm"
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  onClick={() => setViewMode('list')}
                  className="p-2"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Filter Panel */}
          <AnimatePresence>
            {isFilterOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden"
              >
                <Card className="p-6 mb-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Category Filter */}
                    <div>
                      <label className="text-sm font-medium mb-2 block">Category</label>
                      <div className="space-y-2">
                        {categories.map((category) => (
                          <button
                            key={category}
                            onClick={() => setSelectedCategory(category)}
                            className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${
                              selectedCategory === category
                                ? 'bg-gold text-black'
                                : 'hover:bg-muted'
                            }`}
                          >
                            {category}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Price Filter */}
                    <div>
                      <label className="text-sm font-medium mb-2 block">Price Range</label>
                      <div className="space-y-2">
                        {priceRanges.map((range) => (
                          <button
                            key={range.label}
                            onClick={() => setSelectedPriceRange(range)}
                            className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${
                              selectedPriceRange.label === range.label
                                ? 'bg-gold text-black'
                                : 'hover:bg-muted'
                            }`}
                          >
                            {range.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Sort */}
                    <div>
                      <label className="text-sm font-medium mb-2 block">Sort By</label>
                      <div className="space-y-2">
                        {sortOptions.map((option) => (
                          <button
                            key={option.value}
                            onClick={() => setSortBy(option.value)}
                            className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${
                              sortBy === option.value
                                ? 'bg-gold text-black'
                                : 'hover:bg-muted'
                            }`}
                          >
                            {option.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Active Filters */}
          <div className="flex flex-wrap gap-2 mb-4">
            {selectedCategory !== 'All Categories' && (
              <Badge variant="secondary" className="gap-1">
                {selectedCategory}
                <button onClick={() => setSelectedCategory('All Categories')}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            {selectedPriceRange.label !== 'All Prices' && (
              <Badge variant="secondary" className="gap-1">
                {selectedPriceRange.label}
                <button onClick={() => setSelectedPriceRange(priceRanges[0])}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
            {searchQuery && (
              <Badge variant="secondary" className="gap-1">
                "{searchQuery}"
                <button onClick={() => setSearchQuery('')}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            )}
          </div>

          {/* Results Count */}
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <span>
              {loading ? 'Loading...' : `${filteredAndSortedProducts.length} products found`}
            </span>
            <span>
              Sorted by {sortOptions.find(opt => opt.value === sortBy)?.label}
            </span>
          </div>
        </motion.div>

        {/* Products Grid */}
        <div ref={productsRef}>
          {loading ? (
            <div className={`grid gap-6 ${
              viewMode === 'grid' 
                ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
                : 'grid-cols-1'
            }`}>
              {Array.from({ length: 8 }).map((_, i) => (
                <ProductCardSkeleton key={i} />
              ))}
            </div>
          ) : filteredAndSortedProducts.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <div className="w-24 h-24 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="h-8 w-8 text-muted-foreground" />
              </div>
              <h3 className="text-xl font-semibold mb-2">No products found</h3>
              <p className="text-muted-foreground mb-4">
                Try adjusting your filters or search terms
              </p>
              <Button 
                onClick={() => {
                  setSelectedCategory('All Categories');
                  setSelectedPriceRange(priceRanges[0]);
                  setSearchQuery('');
                }}
              >
                Clear all filters
              </Button>
            </motion.div>
          ) : (
            <div className={`grid gap-6 ${
              viewMode === 'grid' 
                ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
                : 'grid-cols-1'
            }`}>
              <AnimatePresence mode="popLayout">
                {visibleProducts.map((product, index) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    index={index}
                    viewMode={viewMode}
                  />
                ))}
              </AnimatePresence>
            </div>
          )}
        </div>

        {/* Load More */}
        {filteredAndSortedProducts.length > visibleProducts.length && (
          <div className="flex justify-center mt-8">
            <Button
              size="lg"
              className="bg-gold text-black hover:bg-gold/90"
              onClick={() => setVisibleCount(filteredAndSortedProducts.length)}
            >
              Load More
            </Button>
          </div>
        )}
        
        {/* Dev-only seeding affordance when empty & signed-in */}
        {!loading && filteredAndSortedProducts.length === 0 && auth.currentUser && (
          <div className="text-center mt-6">
            <Button onClick={handleSeedProducts} disabled={seeding} variant="outline">
              {seeding ? 'Seeding products...' : 'Seed sample products'}
            </Button>
            <p className="text-xs text-muted-foreground mt-2">Visible only when signed in</p>
          </div>
        )}
      </div>
    </div>
  );
}