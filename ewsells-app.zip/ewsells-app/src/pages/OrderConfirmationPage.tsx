import { useSearchParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';

export default function OrderConfirmationPage() {
  const [params] = useSearchParams();
  const orderId = params.get('orderId');
  const method = params.get('method');

  return (
    <motion.div
      className="min-h-screen pt-20 pb-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <div className="container mx-auto px-4 max-w-2xl text-center">
        <h1 className="text-3xl font-bold mb-4">Order Confirmed</h1>
        <p className="text-muted-foreground mb-6">Thank you! Your payment method: <span className="font-medium uppercase">{method}</span>.</p>
        <div className="rounded-lg border border-border p-6 bg-card text-card-foreground">
          <p className="mb-2">Order ID</p>
          <p className="font-mono text-lg">{orderId}</p>
        </div>
        <div className="mt-8 flex justify-center gap-3">
          <Link to="/orders">
            <Button variant="outline">View My Orders</Button>
          </Link>
          <Link to="/products">
            <Button className="bg-gold hover:bg-gold/90 text-black">Continue Shopping</Button>
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
