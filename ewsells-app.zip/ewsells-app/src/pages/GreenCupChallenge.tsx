import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Search, SlidersHorizontal, Grid2X2, List, Heart, Filter, ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useStore } from '@/store/useStore';
import { formatCurrency } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';
import { useCart } from '@/contexts/CartContext';
import { useAuthGate } from '@/hooks/useAuthGate';
import ProductImageCarousel from '@/components/ProductImageCarousel';

interface ProductDoc {
  id: string;
  name: string;
  description?: string;
  price: number; // legacy price kept
  imageUrl?: string;
  imageUrls?: string[];
  category?: string;
  sellerPrice?: number; // seller-set
  finalPrice?: number; // admin-set
}

export function GreenCupChallengePage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<ProductDoc[]>([]);
  const { toggleWishlist, isWishlisted } = useStore();
  const navigate = useNavigate();
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [priceRange, setPriceRange] = useState<'all' | 'u25' | '25-50' | '50-100' | '100p'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'price-asc' | 'price-desc' | 'impact' | 'popular'>('newest');
  const { addToCart } = useCart();
  const { runOrLogin } = useAuthGate();

  useEffect(() => {
    const q = query(
      collection(db, 'products'),
      where('category', '==', 'green-cup-challenge'),
      where('published', '==', true)
    );
    const unsub = onSnapshot(q, (snap) => {
      const rows: ProductDoc[] = snap.docs.map((d) => {
        const data = d.data() as any;
        return {
          id: d.id,
          name: data.name,
          description: data.description,
          imageUrl: data.imageUrl,
          imageUrls: Array.isArray(data.imageUrls) ? data.imageUrls.filter((u: any) => typeof u === 'string' && u) : undefined,
          category: data.category,
          price: typeof data.price === 'number' ? data.price : Number(data.price || 0),
          sellerPrice: typeof data.sellerPrice === 'number' ? data.sellerPrice : (data.sellerPrice != null ? Number(data.sellerPrice) : undefined),
          finalPrice: typeof data.finalPrice === 'number' ? data.finalPrice : (data.finalPrice != null ? Number(data.finalPrice) : undefined),
        };
      });

      setProducts(rows);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return products;
    return products.filter((p) =>
      (p.name || '').toLowerCase().includes(q) || (p.description || '').toLowerCase().includes(q)
    );
  }, [products, searchQuery]);

  const effectivePrice = (p: ProductDoc) => Number(p.finalPrice ?? p.sellerPrice ?? p.price ?? 0);

  const finalProducts = useMemo(() => {
    let items = [...filteredProducts];
    // Apply price range
    items = items.filter((p) => {
      const price = effectivePrice(p);
      switch (priceRange) {
        case 'u25':
          return price < 25;
        case '25-50':
          return price >= 25 && price <= 50;
        case '50-100':
          return price > 50 && price <= 100;
        case '100p':
          return price > 100;
        default:
          return true;
      }
    });
    // Apply sort
    items.sort((a, b) => {
      const pa = effectivePrice(a);
      const pb = effectivePrice(b);
      switch (sortBy) {
        case 'price-asc':
          return pa - pb;
        case 'price-desc':
          return pb - pa;
        // 'newest', 'impact', 'popular' fall back to no-op without extra fields
        default:
          return 0;
      }
    });
    return items;
  }, [filteredProducts, priceRange, sortBy]);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-12"
    >
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Green Cup <span className="text-gold">Challenge</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover sustainable menstrual products that reduce waste and support women's health while making a positive environmental impact.
          </p>
        </div>

        <div className="mb-8">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between mb-6">
            {/* Left: Search Bar */}
            <div className="relative flex-1 max-w-md w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={handleSearch}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 pl-10"
              />
            </div>

            {/* Right: Filters + segmented toggle */}
            <div className="flex items-center gap-2">
              {/* Filters */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setIsFilterOpen((v) => !v)}
                  className="btn-hover inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-gold/60 bg-transparent text-gold hover:bg-gold hover:text-black h-10 px-4 py-2 gap-2"
                >
                  <Filter className="h-4 w-4" />
                  Filters
                </button>
                {isFilterOpen && (
                  <div className="absolute top-12 right-0 z-40 w-80 sm:w-[28rem] bg-background border border-border rounded-md shadow-lg p-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Price Range</label>
                      <div className="space-y-2">
                        <button onClick={() => setPriceRange('all')} className={`${priceRange === 'all' ? 'bg-gold text-black' : 'hover:bg-muted'} w-full text-left px-3 py-2 rounded-md text-sm transition-colors`}>All Prices</button>
                        <button onClick={() => setPriceRange('u25')} className={`${priceRange === 'u25' ? 'bg-gold text-black' : 'hover:bg-muted'} w-full text-left px-3 py-2 rounded-md text-sm transition-colors`}>Under ₹25</button>
                        <button onClick={() => setPriceRange('25-50')} className={`${priceRange === '25-50' ? 'bg-gold text-black' : 'hover:bg-muted'} w-full text-left px-3 py-2 rounded-md text-sm transition-colors`}>₹25 - ₹50</button>
                        <button onClick={() => setPriceRange('50-100')} className={`${priceRange === '50-100' ? 'bg-gold text-black' : 'hover:bg-muted'} w-full text-left px-3 py-2 rounded-md text-sm transition-colors`}>₹50 - ₹100</button>
                        <button onClick={() => setPriceRange('100p')} className={`${priceRange === '100p' ? 'bg-gold text-black' : 'hover:bg-muted'} w-full text-left px-3 py-2 rounded-md text-sm transition-colors`}>Over ₹100</button>
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">Sort By</label>
                      <div className="space-y-2">
                        <button onClick={() => setSortBy('newest')} className={`${sortBy === 'newest' ? 'bg-gold text-black' : 'hover:bg-muted'} w-full text-left px-3 py-2 rounded-md text-sm transition-colors`}>Newest First</button>
                        <button onClick={() => setSortBy('price-asc')} className={`${sortBy === 'price-asc' ? 'bg-gold text-black' : 'hover:bg-muted'} w-full text-left px-3 py-2 rounded-md text-sm transition-colors`}>Price: Low to High</button>
                        <button onClick={() => setSortBy('price-desc')} className={`${sortBy === 'price-desc' ? 'bg-gold text-black' : 'hover:bg-muted'} w-full text-left px-3 py-2 rounded-md text-sm transition-colors`}>Price: High to Low</button>
                        <button onClick={() => setSortBy('impact')} className={`${sortBy === 'impact' ? 'bg-gold text-black' : 'hover:bg-muted'} w-full text-left px-3 py-2 rounded-md text-sm transition-colors`}>Highest Impact</button>
                        <button onClick={() => setSortBy('popular')} className={`${sortBy === 'popular' ? 'bg-gold text-black' : 'hover:bg-muted'} w-full text-left px-3 py-2 rounded-md text-sm transition-colors`}>Most Popular</button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Segmented view toggle */}
              <div className="border border-gold/60 rounded-md flex overflow-hidden">
                <button
                  type="button"
                  aria-pressed={viewMode === 'grid'}
                  onClick={() => setViewMode('grid')}
                  className={`inline-flex items-center justify-center h-9 px-3 text-sm ${viewMode === 'grid' ? 'bg-gold text-black' : 'bg-transparent text-foreground hover:bg-muted'} rounded-none`}
                >
                  <Grid2X2 className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  aria-pressed={viewMode === 'list'}
                  onClick={() => setViewMode('list')}
                  className={`inline-flex items-center justify-center h-9 px-3 text-sm border-l border-gold/60 ${viewMode === 'list' ? 'bg-gold text-black' : 'bg-transparent text-foreground hover:bg-muted'} rounded-none`}
                >
                  <List className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Results Count */}
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">
              {finalProducts.length} products found
            </p>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading products…</p>
          </div>
        ) : (
          <>
            {/* Product Grid */}
            <div className={`grid ${viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4' : 'grid-cols-1'} gap-6`}>
              {finalProducts.map(product => (
                <Card
                  key={product.id}
                  className="overflow-hidden group cursor-pointer focus:outline-none focus:ring-2 focus:ring-gold h-full flex flex-col"
                  role="button"
                  tabIndex={0}
                  onClick={() => navigate(`/product/${product.id}`)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault();
                      navigate(`/product/${product.id}`);
                    }
                  }}
                >
                  <div className="relative h-48 w-full overflow-hidden bg-white">
                    <ProductImageCarousel
                      images={product.imageUrls && product.imageUrls.length > 0 ? product.imageUrls : (product.imageUrl ? [product.imageUrl] : [])}
                      alt={product.name}
                      className="w-full h-full object-cover"
                      aspect="free"
                    />
                    {product.category && (
                      <Badge className="absolute top-2 left-2 bg-gold text-black text-xs">
                        {product.category}
                      </Badge>
                    )}
                    <Button
                      size="icon"
                      variant="ghost"
                      className="absolute top-1 right-1 bg-black/50 hover:bg-black/70 text-white h-8 w-8"
                      onClick={(e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        toggleWishlist(product.id);
                      }}
                      aria-pressed={isWishlisted(product.id)}
                      aria-label={isWishlisted(product.id) ? 'Remove from wishlist' : 'Add to wishlist'}
                    >
                      <Heart className={`h-3.5 w-3.5 ${isWishlisted(product.id) ? 'fill-red-500 text-red-500' : ''}`} />
                    </Button>
                  </div>
                  
                  <CardContent className="p-3 flex-1 flex flex-col">
                    <h3 className="font-semibold text-base mb-1 group-hover:text-gold transition-colors line-clamp-1">
                      {product.name}
                    </h3>
                    <p className="text-muted-foreground text-xs mb-2 line-clamp-2 h-10">
                      {product.description}
                    </p>
                    <div className="mt-auto flex items-center justify-between">
                      <span className="font-bold text-base">
                        {formatCurrency(Number(product.finalPrice ?? product.sellerPrice ?? product.price ?? 0))}
                      </span>
                      <Button
                        className="bg-gold hover:bg-amber-500 text-black border border-amber-300 rounded-md px-3 py-1.5 h-8 text-sm font-medium transition-colors shadow-sm hover:shadow flex items-center gap-1.5 whitespace-nowrap"
                        onClick={async (e) => {
                          e.stopPropagation();
                          e.preventDefault();
                          const price = Number(product.finalPrice ?? product.sellerPrice ?? product.price ?? 0);
                          const cartProduct = {
                            id: product.id,
                            name: product.name,
                            price,
                            imageUrl: (product.imageUrls?.[0] || product.imageUrl || '/images/placeholder-item.jpg'),
                            category: product.category || 'green-cup-challenge',
                          };
                          runOrLogin(async () => {
                            await addToCart(cartProduct);
                            navigate('/cart');
                          });
                        }}
                      >
                        <ShoppingCart className="h-3.5 w-3.5" />
                        <span>Add to Cart</span>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {finalProducts.length === 0 && (
              <div className="text-center py-12">
                {products.length === 0 && !searchQuery ? (
                  <p className="text-muted-foreground">No products available at the moment.</p>
                ) : (
                  <p className="text-muted-foreground">No products found matching your search.</p>
                )}
              </div>
            )}

            {/* Green Cup Challenge Registration Button */}
            <div className="mt-16 mb-8 text-center">
              <h2 className="text-2xl font-bold mb-4">Join the Green Cup Challenge</h2>
              <p className="text-muted-foreground max-w-2xl mx-auto mb-6">
                Be part of the movement to reduce menstrual waste and promote sustainable period products. 
                Register for the Green Cup Challenge today!
              </p>
              
              <Button 
                size="lg" 
                className="bg-gold hover:bg-gold/90 text-black font-bold px-8 py-6 text-lg"
                onClick={() => {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                  alert('Thank you for your interest in the Green Cup Challenge! Registration form will be available soon.');
                }}
              >
                Register for Green Cup Challenge
              </Button>
            </div>
          </>
        )}
      </div>
    </motion.div>
  );
}