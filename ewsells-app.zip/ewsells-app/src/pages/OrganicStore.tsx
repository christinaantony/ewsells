import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { calculateUplift, formatCurrency } from '@/lib/utils';
import { collection, onSnapshot, query, where } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Heart, Search, Grid2X2, List, Filter, ShoppingCart } from 'lucide-react';
import { RatingPill } from '@/components/RatingPill';
import { useStore } from '@/store/useStore';
import { useNavigate } from 'react-router-dom';
import { useCart } from '@/contexts/CartContext';
import { useAuthGate } from '@/hooks/useAuthGate';
import ProductImageCarousel from '@/components/ProductImageCarousel';

type ProductDoc = {
  id: string;
  name: string;
  description: string;
  price: number;
  sellerPrice?: number;
  finalPrice?: number;
  category?: string;
  imageUrl?: string;
  imageUrls?: string[];
  badges?: string[];
  published?: boolean;
  customizable?: boolean;
};

export function OrganicStorePage() {
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<ProductDoc[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const { toggleWishlist, isWishlisted } = useStore();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { runOrLogin } = useAuthGate();
  const [showFilters, setShowFilters] = useState(false);
  const [priceFilter, setPriceFilter] = useState<'all' | 'under25' | '25-50' | '50-100' | 'over100'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'price-asc' | 'price-desc' | 'impact' | 'popular'>('newest');

  // Helper function to get display price with fallback
  const getDisplayPrice = (product: ProductDoc) => {
    return product.finalPrice ?? product.sellerPrice ?? product.price ?? 0;
  };

  useEffect(() => {
    const q = query(
      collection(db, 'products'),
      where('category', '==', 'organic-store'),
      where('published', '==', true)
    );
    const unsub = onSnapshot(q, (snap) => {
      const rows: ProductDoc[] = snap.docs.map((d) => {
        const data = d.data() as any;
        return {
          id: d.id,
          name: data.name,
          description: data.description,
          imageUrl: data.imageUrl,
          imageUrls: data.imageUrls,
          badges: data.badges,
          published: data.published,
          category: data.category,
          price: typeof data.price === 'number' ? data.price : Number(data.price || 0),
          sellerPrice: typeof data.sellerPrice === 'number' ? data.sellerPrice : (data.sellerPrice != null ? Number(data.sellerPrice) : undefined),
          finalPrice: typeof data.finalPrice === 'number' ? data.finalPrice : (data.finalPrice != null ? Number(data.finalPrice) : undefined),
          customizable: !!data.customizable,
        };
      });

      setProducts(rows);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    document.title = 'Organic Store | ewsells';
  }, []);

  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    let result = !q
      ? [...products]
      : products.filter((p) =>
          (p.name || '').toLowerCase().includes(q) || (p.description || '').toLowerCase().includes(q)
        );

    result = result.filter((p) => {
      const price = (p.finalPrice ?? p.sellerPrice ?? p.price ?? 0) as number;
      switch (priceFilter) {
        case 'under25':
          return price < 25;
        case '25-50':
          return price >= 25 && price <= 50;
        case '50-100':
          return price >= 50 && price <= 100;
        case 'over100':
          return price > 100;
        default:
          return true;
      }
    });

    result.sort((a, b) => {
      const priceA = (a.finalPrice ?? a.sellerPrice ?? a.price ?? 0) as number;
      const priceB = (b.finalPrice ?? b.sellerPrice ?? b.price ?? 0) as number;
      if (sortBy === 'price-asc') return priceA - priceB;
      if (sortBy === 'price-desc') return priceB - priceA;
      if (sortBy === 'impact') {
        const baseA = (a.sellerPrice ?? a.price ?? 0) as number;
        const baseB = (b.sellerPrice ?? b.price ?? 0) as number;
        const percA = baseA > 0 && a.finalPrice != null ? ((a.finalPrice - baseA) / baseA) * 100 : 0;
        const percB = baseB > 0 && b.finalPrice != null ? ((b.finalPrice - baseB) / baseB) * 100 : 0;
        const { charityAmount: charityA } = calculateUplift(baseA, percA);
        const { charityAmount: charityB } = calculateUplift(baseB, percB);
        return charityB - charityA;
      }
      if (sortBy === 'popular') {
        const popA = (Array.isArray(a.badges) ? a.badges.length : 0);
        const popB = (Array.isArray(b.badges) ? b.badges.length : 0);
        return popB - popA;
      }
      // 'newest' fallback – keep existing order
      return 0;
    });

    return result;
  }, [products, searchQuery, priceFilter, sortBy]);

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Organic <span className="text-gold">Store</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Fresh, sustainable, and organic products from local producers. Shop clean, eat clean, live clean.
          </p>
        </motion.div>

        {/* Controls: Search (left) and View toggles (right) */}
        <div className="mb-8">
          <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
            {/* Search */}
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 pl-10"
              />
            </div>
            {/* View toggles */}
            <div className="flex items-center gap-2">
              {/* Filters button */}
              <div className="relative">
                <Button
                  type="button"
                  onClick={() => setShowFilters((s) => !s)}
                  className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 btn-hover btn-hover border border-primary bg-transparent text-primary hover:bg-primary hover:text-primary-foreground h-10 px-4 py-2 gap-2"
                >
                  <Filter className="h-4 w-4" />
                  Filters
                </Button>
                {showFilters && (
                  <div className="absolute top-12 right-0 z-40 w-80 sm:w-[28rem] bg-background border border-border rounded-md shadow-lg p-4 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">Price Range</label>
                      <div className="space-y-2">
                        <button
                          className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === 'all' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                          onClick={() => setPriceFilter('all')}
                        >
                          All Prices
                        </button>
                        <button
                          className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === 'under25' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                          onClick={() => setPriceFilter('under25')}
                        >
                          Under ₹25
                        </button>
                        <button
                          className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === '25-50' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                          onClick={() => setPriceFilter('25-50')}
                        >
                          ₹25 - ₹50
                        </button>
                        <button
                          className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === '50-100' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                          onClick={() => setPriceFilter('50-100')}
                        >
                          ₹50 - ₹100
                        </button>
                        <button
                          className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${priceFilter === 'over100' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                          onClick={() => setPriceFilter('over100')}
                        >
                          Over ₹100
                        </button>
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">Sort By</label>
                      <div className="space-y-2">
                        <button
                          className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'newest' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                          onClick={() => setSortBy('newest')}
                        >
                          Newest First
                        </button>
                        <button
                          className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'price-asc' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                          onClick={() => setSortBy('price-asc')}
                        >
                          Price: Low to High
                        </button>
                        <button
                          className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'price-desc' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                          onClick={() => setSortBy('price-desc')}
                        >
                          Price: High to Low
                        </button>
                        <button
                          className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'impact' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                          onClick={() => setSortBy('impact')}
                        >
                          Highest Impact
                        </button>
                        <button
                          className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${sortBy === 'popular' ? 'bg-gold text-black' : 'hover:bg-muted'}`}
                          onClick={() => setSortBy('popular')}
                        >
                          Most Popular
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <div className="border rounded-md flex">
                <Button
                  variant={viewMode === 'grid' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className="rounded-r-none"
                >
                  <Grid2X2 className="h-4 w-4" />
                  <span className="sr-only">Grid view</span>
                </Button>
                <Button
                  variant={viewMode === 'list' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className="rounded-l-none"
                >
                  <List className="h-4 w-4" />
                  <span className="sr-only">List view</span>
                </Button>
              </div>
            </div>
          </div>
        </div>

        {loading ? (
          <motion.div
            className="text-center py-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <p className="text-muted-foreground">Loading organic products…</p>
          </motion.div>
        ) : filteredProducts.length > 0 ? (
          <motion.div
            className={viewMode === 'grid' ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6' : 'space-y-4'}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {filteredProducts.map((product) => {
              const displayPrice = getDisplayPrice(product);
              const charityAmount = 0;
              const wishlisted = isWishlisted(product.id);

              return (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                  className="group"
                >
                  <Card
                    className={`overflow-hidden h-full ${viewMode === 'list' ? 'flex flex-row' : 'flex flex-col'} cursor-pointer focus:outline-none focus:ring-2 focus:ring-gold`}
                    onClick={() => navigate(`/product/${product.id}`)}
                  >
                    <div className={viewMode === 'list' ? 'relative w-48 h-48 flex-shrink-0' : 'relative'}>
                      <div className="overflow-hidden h-48 w-full">
                        <ProductImageCarousel
                          images={product.imageUrls?.length ? product.imageUrls : (product.imageUrl ? [product.imageUrl] : [])}
                          alt={product.name}
                          className="w-full h-full object-cover"
                          aspect="free"
                        />
                      </div>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="absolute top-1 right-1 bg-black/50 hover:bg-black/70 text-white h-8 w-8"
                        onClick={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          toggleWishlist(product.id);
                        }}
                        aria-pressed={wishlisted}
                        aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
                      >
                        <Heart className={`h-3.5 w-3.5 ${wishlisted ? 'fill-red-500 text-red-500' : ''}`} />
                      </Button>
                      {product.badges?.[0] && (
                        <Badge className="absolute top-1 left-1 bg-gold text-black text-xs">
                          {product.badges[0]}
                        </Badge>
                      )}
                      {product.customizable && (
                        <Badge className="absolute top-1 left-1 translate-y-6 bg-emerald-500/90 text-white text-[10px]">
                          Customizable
                        </Badge>
                      )}
                    </div>

                    <div className={viewMode === 'list' ? 'p-4 flex-1 flex flex-col' : 'p-3 flex flex-col flex-1'}>
                      <h3 className="font-semibold text-base mb-1 group-hover:text-gold transition-colors line-clamp-2">
                        {product.name}
                      </h3>
                      {product.description && (
                        <p className="text-muted-foreground text-xs mb-2 line-clamp-2 h-10">
                          {product.description}
                        </p>
                      )}
                      <div className="mt-auto">
                        {/* Ratings pill above Add to Cart */}
                        <div className="mb-2">
                          <RatingPill productId={product.id} docData={product as any} />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-base">
                            {formatCurrency(displayPrice)}
                          </span>
                          <Button 
                            className="bg-gold hover:bg-amber-500 text-black border border-amber-300 rounded-md px-3 py-1.5 h-8 text-sm font-medium transition-colors shadow-sm hover:shadow flex items-center gap-1.5 whitespace-nowrap"
                            onClick={(e) => {
                              e.stopPropagation();
                              runOrLogin(async () => {
                                await addToCart({
                                  id: product.id,
                                  name: product.name,
                                  price: displayPrice,
                                  imageUrl: product.imageUrl || (product.imageUrls?.[0] || ''),
                                  category: product.category || 'organic-store'
                                });
                              });
                            }}
                          >
                            <ShoppingCart className="h-3.5 w-3.5" />
                            <span>Add to Cart</span>
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </motion.div>
        ) : (
          <motion.div
            className="text-center py-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {products.length === 0 ? (
              <>
                <p className="text-muted-foreground">No organic products available at the moment.</p>
                <p className="text-sm mt-2">Check back soon for fresh arrivals.</p>
              </>
            ) : (
              <p className="text-muted-foreground">No products found matching your search.</p>
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
}
