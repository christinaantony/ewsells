import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { XCircle, ArrowLeft, ShoppingCart } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';

export default function PaymentFailurePage() {
  const [errorDetails, setErrorDetails] = useState<string>('');
  const navigate = useNavigate();
  const location = useLocation();
  const { cartItems } = useCart();
  
  // Parse query parameters
  const queryParams = new URLSearchParams(location.search);
  const orderId = queryParams.get('orderId');
  const errorMessage = queryParams.get('error');

  useEffect(() => {
    // Set error details from URL parameters
    if (errorMessage) {
      setErrorDetails(decodeURIComponent(errorMessage));
    } else {
      setErrorDetails('Your payment could not be processed at this time.');
    }
  }, [errorMessage]);

  // Handle retry payment
  const handleRetryPayment = () => {
    if (cartItems.length > 0) {
      // If cart still has items, go back to cart page
      navigate('/cart');
    } else {
      // If cart is empty (e.g., user navigated directly to this page), go to home
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        <motion.div
          className="max-w-lg mx-auto text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex justify-center mb-6">
            <div className="rounded-full bg-red-100 p-4">
              <XCircle className="h-16 w-16 text-red-600" />
            </div>
          </div>
          <h1 className="text-4xl font-bold mb-4">Payment Failed</h1>
          <p className="text-lg text-muted-foreground mb-8">
            We're sorry, but your payment could not be completed.
          </p>

          <div className="bg-gray-50 rounded-lg p-6 mb-8 text-left">
            <h3 className="font-semibold text-lg mb-4">Error Details</h3>
            <div className="space-y-2">
              {orderId && (
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Order ID:</span>
                  <span className="font-medium">{orderId}</span>
                </div>
              )}
              <div className="border-t pt-2 mt-2">
                <p className="text-red-600">{errorDetails}</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={handleRetryPayment}
              className="bg-gold hover:bg-gold/90 text-black"
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              Try Again
            </Button>
            <Button
              onClick={() => navigate('/')}
              variant="outline"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Button>
          </div>
          
          <p className="text-sm text-muted-foreground mt-8">
            If you continue to experience issues, please contact our customer support.
          </p>
        </motion.div>
      </div>
    </div>
  );
}
