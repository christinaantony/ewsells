import { useEffect, useMemo, useState } from 'react';
import { collection, onSnapshot, query, where, doc, getDoc, orderBy, limit, getDocs } from 'firebase/firestore';
import { db, auth } from '@/lib/firebase';
import { useNavigate } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

interface ChatRow {
  id: string;
  orderId: string;
  productId: string;
  buyerId: string;
  sellerId: string;
  createdAt?: any;
  productName?: string;
  lastReadBuyerAt?: any;
  sellerCode?: string;
  unread?: boolean;
}

export default function UserCustomizations() {
  const uid = auth.currentUser?.uid || null;
  const [chats, setChats] = useState<ChatRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!uid) return;
    const q = query(
      collection(db, 'customizationChats'),
      where('buyerId', '==', uid)
    );
    const unsub = onSnapshot(q, async (snap) => {
      try {
        const rows: ChatRow[] = [];
        const sellerCodeCache: Record<string, string | undefined> = {};
        for (const d of snap.docs) {
          const data = d.data() as any;
          let productName: string | undefined;
          let sellerCode: string | undefined;
          try {
            const pSnap = await getDoc(doc(db, 'products', data.productId));
            if (pSnap.exists()) {
              const pData = pSnap.data() as any;
              productName = pData?.name;
              // Prefer sellerCode from product (public read), if available
              if (pData?.sellerCode) sellerCode = pData.sellerCode as string;
            }
          } catch {}
          try {
            // Try seller-profiles first (preferred source)
            const profSnap = await getDoc(doc(db, 'seller-profiles', data.sellerId));
            if (profSnap.exists()) {
              sellerCode = (profSnap.data() as any)?.sellerCode;
            }
            // Fallback to seller-registrations if code still missing
            if (!sellerCode) {
              const regSnap = await getDoc(doc(db, 'seller-registrations', data.sellerId));
              sellerCode = regSnap.exists() ? (regSnap.data() as any)?.sellerCode : undefined;
            }
          } catch {}
          // Final fallback: read any product of this seller with sellerCode (publicly readable)
          if (!sellerCode) {
            if (sellerCodeCache[data.sellerId] !== undefined) {
              sellerCode = sellerCodeCache[data.sellerId];
            } else {
              try {
                const prodQ = query(collection(db, 'products'), where('sellerId', '==', data.sellerId), limit(1));
                const prodSnap = await getDocs(prodQ);
                const p = prodSnap.docs[0]?.data() as any | undefined;
                sellerCode = p?.sellerCode;
                sellerCodeCache[data.sellerId] = sellerCode;
              } catch {}
            }
          }
          rows.push({ id: d.id, ...data, productName, sellerCode });
        }
        rows.sort((a, b) => {
          const toMs = (ts: any) => ts?.toMillis?.() ?? (ts instanceof Date ? ts.getTime() : (typeof ts === 'number' ? ts : 0));
          return toMs(b.createdAt) - toMs(a.createdAt);
        });
        // Compute unread per chat for buyer (latest message from seller after lastReadBuyerAt)
        const withUnread: ChatRow[] = [];
        for (const c of rows) {
          try {
            const latestQ = query(collection(db, 'customizationChats', c.id, 'messages'), orderBy('createdAt', 'desc'), limit(1));
            const s = await getDocs(latestQ);
            const latest = s.docs[0]?.data() as any | undefined;
            const lastRead = (c as any)?.lastReadBuyerAt;
            const unread = Boolean(latest && latest.senderId && latest.senderId !== uid && (!lastRead || (latest.createdAt?.toMillis && lastRead?.toMillis && latest.createdAt.toMillis() > lastRead.toMillis())));
            withUnread.push({ ...c, unread });
          } catch {
            withUnread.push({ ...c, unread: false });
          }
        }
        setChats(withUnread);
      } catch (e: any) {
        setError(e?.message || 'Failed to load chats');
      } finally {
        setLoading(false);
      }
    }, (err) => {
      setError(err?.message || 'Failed to load chats');
      setLoading(false);
    });
    return () => unsub();
  }, [uid]);

  const hasData = useMemo(() => chats.length > 0, [chats.length]);
  // const unreadTotal = useMemo(() => chats.filter(c => c.unread).length, [chats]);

  return (
    <div className="min-h-screen pt-20 pb-12 container mx-auto px-4">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold">Your Customization Chats</h1>
        </div>
        {loading && (
          <Card className="p-4">Loading...</Card>
        )}
        {error && (
          <Card className="p-4 border border-red-200 bg-red-50 text-red-700 text-sm">{error}</Card>
        )}
        {!loading && !hasData && !error && (
          <Card className="p-6 text-sm text-muted-foreground">No customization chats yet.</Card>
        )}
        <div className="space-y-3">
          {chats.map((c) => (
            <Card key={c.id} className="p-4 flex items-center justify-between">
              <div className="min-w-0">
                <div className="font-medium truncate flex items-center gap-2">
                  <span>{c.productName || c.productId}</span>
                  {c.unread && (
                    <span className="inline-flex items-center justify-center text-[10px] bg-amber-500 text-black rounded-full px-2 py-0.5">New</span>
                  )}
                </div>
                <div className="text-xs text-muted-foreground mt-1">Order: {c.orderId}</div>
                <div className="text-xs text-muted-foreground">Seller: {c.sellerCode || c.sellerId}</div>
              </div>
              <Button className="bg-gold text-black" onClick={() => navigate(`/customize/${c.productId}?orderId=${c.orderId}&from=buyer-chats`)}>
                Open chat
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
