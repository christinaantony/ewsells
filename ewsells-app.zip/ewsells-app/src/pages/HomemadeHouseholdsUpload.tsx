import React, { useRef, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Image as ImageIcon, X } from 'lucide-react';
import { db, storage, auth } from '@/lib/firebase';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { useStore } from '@/store/useStore';
import { generateProductCode } from '@/lib/utils';

export default function HomemadeHouseholdsUpload() {
  const navigate = useNavigate();
  const { user } = useStore();

  type FormState = { name: string; description: string; price: string; stock: string; customizable: boolean; imageFiles: File[]; submitting: boolean; message: string | null };
  const [form, setForm] = useState<FormState>({ name: '', description: '', price: '', stock: '', customizable: false, imageFiles: [], submitting: false, message: null });
  const imageInputRef = useRef<HTMLInputElement | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [previews, setPreviews] = useState<string[]>([]);
  const [isCustomizable, setIsCustomizable] = useState<boolean>(false);

  // Reset form to initial state
  const resetForm = () => {
    setForm({
      name: '',
      description: '',
      price: '',
      stock: '',
      customizable: false,
      imageFiles: [],
      submitting: false,
      message: null
    });
    setIsCustomizable(false);
    setPreviews([]);
    if (imageInputRef.current) {
      imageInputRef.current.value = '';
    }
  };

  useEffect(() => {
    setPreviews((old) => {
      old.forEach((u) => URL.revokeObjectURL(u));
      return [];
    });
    const urls = form.imageFiles.map((f) => URL.createObjectURL(f));
    setPreviews(urls);
    return () => {
      urls.forEach((u) => URL.revokeObjectURL(u));
    };
  }, [form.imageFiles]);

  const onFilesSelected = (files: FileList | File[]) => {
    const valid = Array.from(files).filter((f) => f.type.startsWith('image/'));
    if (valid.length === 0) return;
    setForm((p) => ({ ...p, imageFiles: [...p.imageFiles, ...valid] }));
  };

  const onDrop: React.DragEventHandler<HTMLDivElement> = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer?.files?.length) {
      onFilesSelected(e.dataTransfer.files);
    }
  };

  

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      navigate('/login');
      return;
    }
    // Must be authenticated with Firebase (rules require sellerId == request.auth.uid)
    const uid = auth.currentUser?.uid;
    if (!uid) {
      setForm((p) => ({ ...p, message: 'Please sign in to your seller account before uploading.' }));
      navigate('/seller-login');
      return;
    }
    if (!form.name.trim() || !form.description.trim() || !form.price || form.stock === '') {
      setForm((p) => ({ ...p, message: 'Please fill all required fields.' }));
      return;
    }
    const priceVal = Number(form.price);
    if (Number.isNaN(priceVal) || priceVal < 0) {
      setForm((p) => ({ ...p, message: 'Enter a valid price.' }));
      return;
    }
    const stockVal = Number(form.stock);
    if (!Number.isInteger(stockVal) || stockVal < 0) {
      setForm((p) => ({ ...p, message: 'Enter a valid stock (non-negative integer).' }));
      return;
    }
    if (!form.imageFiles || form.imageFiles.length < 3) {
      setForm((p) => ({ ...p, message: 'Please upload at least 3 images (minimum is 3).' }));
      return;
    }

    setForm((p) => ({ ...p, submitting: true, message: null }));
    try {
      let imageUrls: string[] = [];
      if (form.imageFiles && form.imageFiles.length > 0) {
        for (const file of form.imageFiles) {
          const path = `sellers/${uid}/homemade-households/${Date.now()}_${file.name}`;
          const storageRef = ref(storage, path);
          await uploadBytes(storageRef, file);
          const url = await getDownloadURL(storageRef);
          imageUrls.push(url);
        }
      }

      // Generate product code
      const sellerName = user?.displayName || 'Unknown';
      const productCode = await generateProductCode(sellerName, uid);

      await addDoc(collection(db, 'products'), {
        name: form.name.trim(),
        description: form.description.trim(),
        price: priceVal,
        stock: stockVal,
        category: 'homemade-households',
        imageUrl: imageUrls[0] || '',
        imageUrls: imageUrls,
        sellerId: uid,
        customizable: !!form.customizable,
        published: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        productCode: productCode,
      });

      setForm({ name: '', description: '', price: '', stock: '', customizable: false, imageFiles: [], submitting: false, message: 'Product created successfully.' });
      if (imageInputRef.current) imageInputRef.current.value = '';
      setPreviews((prev) => {
        prev.forEach((url) => URL.revokeObjectURL(url));
        return [];
      });
    } catch (err: any) {
      console.error('Save product error:', err);
      const msg = err?.code
        ? `Failed: ${err.code} – ${err.message || 'Permission denied.'}`
        : 'Failed to save product.';
      setForm((p) => ({ ...p, submitting: false, message: msg }));
      return;
    }
  };

  return (
    <section id="seller-upload" className="pt-24 pb-12 bg-surface/50 border-t border-border/40">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-bold">Upload to Homemade Households</h2>
            <p className="text-muted-foreground">Make it shine — add details and multiple images.</p>
          </div>
          <Button variant="outline" onClick={() => navigate('/seller')}>
            Back to Dashboard
          </Button>
        </div>

        {form.message && (
          <div className="mb-6 p-4 text-sm rounded-md bg-muted">
            {form.message}
          </div>
        )}

        <Card>
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="name-homemade-households">Title</Label>
                    <span className="text-xs text-muted-foreground">Required</span>
                  </div>
                  <Input 
                    id="name-homemade-households"
                    value={form.name}
                    onChange={(e) => setForm(p => ({ ...p, name: e.target.value }))}
                    placeholder="e.g. Handmade Soap Bars"
                    required
                  />
                  <p className="text-xs text-muted-foreground">Keep it short and catchy.</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="price-homemade-households">Price</Label>
                    <span className="text-xs text-muted-foreground">Required</span>
                  </div>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">₹</span>
                    <Input
                      id="price-homemade-households"
                      type="number"
                      value={form.price}
                      onChange={(e) => setForm(p => ({ ...p, price: e.target.value }))}
                      placeholder="0.00"
                      className="pl-8"
                      min="0"
                      step="0.01"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="stock-homemade-households">Stock</Label>
                    <span className="text-xs text-muted-foreground">Required</span>
                  </div>
                  <Input
                    id="stock-homemade-households"
                    type="number"
                    value={form.stock}
                    onChange={(e) => setForm(p => ({ ...p, stock: e.target.value }))}
                    placeholder="Available quantity"
                    min="0"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Description</Label>
                  <span className="text-xs text-muted-foreground">Required</span>
                </div>
                <textarea
                  value={form.description}
                  onChange={(e) => setForm(p => ({ ...p, description: e.target.value }))}
                  className="flex min-h-[100px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  placeholder="Describe your product in detail..."
                  required
                />
              </div>

              {/* Image Upload Section */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Product Images</Label>
                  <span className="text-xs text-muted-foreground">
                    {form.imageFiles.length} of 10 images
                  </span>
                </div>
                
                <input
                  ref={imageInputRef}
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={(e) => e.target.files && onFilesSelected(e.target.files)}
                />

                <div 
                  className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
                    isDragging ? 'bg-accent/50' : 'hover:bg-accent/50'
                  }`}
                  onClick={() => imageInputRef.current?.click()}
                  onDragOver={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setIsDragging(true);
                  }}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={onDrop}
                >
                  <div className="flex flex-col items-center justify-center space-y-2">
                    <ImageIcon className="h-8 w-8 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">
                      Drag & drop images here, or click to browse
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Minimum 3 images required (max 10)
                    </p>
                  </div>
                </div>

                {previews.length > 0 && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 mt-4">
                    {previews.map((preview, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={preview}
                          alt={`Preview ${index + 1}`}
                          className="h-24 w-full rounded-md object-cover border"
                        />
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setForm(p => ({
                              ...p,
                              imageFiles: p.imageFiles.filter((_, i) => i !== index)
                            }));
                          }}
                          className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Customizable toggle */}
              <div className="pt-2">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="customizable"
                    checked={form.customizable}
                    onChange={(e) => setForm(p => ({ ...p, customizable: e.target.checked }))}
                    className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                  />
                  <Label htmlFor="customizable">Allow customer customization requests</Label>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  If enabled, buyers can message you for post-purchase customization (no phone numbers or prices allowed).
                </p>
              </div>

              <div className="flex justify-end gap-4 pt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={resetForm}
                  disabled={form.submitting}
                  className="h-10 px-4 py-2"
                >
                  Reset
                </Button>
                <Button 
                  type="submit" 
                  disabled={form.submitting}
                  className="h-10 px-4 py-2 bg-gold text-black hover:bg-gold/90"
                >
                  {form.submitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    'Upload Product'
                  )}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
