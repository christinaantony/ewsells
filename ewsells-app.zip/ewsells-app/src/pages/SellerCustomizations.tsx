import { useEffect, useMemo, useState } from 'react';
import { collection, onSnapshot, query, where, doc, getDoc, orderBy, limit, getDocs } from 'firebase/firestore';
import { db, auth } from '@/lib/firebase';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface ChatRow {
  id: string;
  orderId: string;
  productId: string;
  buyerId: string;
  sellerId: string;
  createdAt?: any;
  productName?: string;
  lastReadSellerAt?: any;
  unread?: boolean;
}

export default function SellerCustomizations() {
  const uid = auth.currentUser?.uid || null;
  const [chats, setChats] = useState<ChatRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (!uid) return;
    // Note: Some legacy chats may not have createdAt. Firestore orderBy requires the field
    // to exist on all matched docs, so we avoid orderBy here and sort client-side instead.
    const q = query(
      collection(db, 'customizationChats'),
      where('sellerId', '==', uid)
    );
    const unsub = onSnapshot(q, async (snap) => {
      try {
        const rows: ChatRow[] = [];
        for (const d of snap.docs) {
          const data = d.data() as any;
          let productName: string | undefined;
          try {
            const pSnap = await getDoc(doc(db, 'products', data.productId));
            productName = pSnap.exists() ? (pSnap.data() as any)?.name : undefined;
          } catch {}
          rows.push({ id: d.id, ...data, productName });
        }
        // Client-side sort by createdAt desc, placing missing timestamps last
        rows.sort((a, b) => {
          const toMs = (ts: any) =>
            ts?.toMillis?.() ?? (ts instanceof Date ? ts.getTime() : (typeof ts === 'number' ? ts : 0));
          return toMs(b.createdAt) - toMs(a.createdAt);
        });
        // Compute unread per chat by checking latest message
        const withUnread: ChatRow[] = [];
        for (const c of rows) {
          try {
            const latestQ = query(collection(db, 'customizationChats', c.id, 'messages'), orderBy('createdAt', 'desc'), limit(1));
            const s = await getDocs(latestQ);
            const latest = s.docs[0]?.data() as any | undefined;
            const lastRead = (c as any)?.lastReadSellerAt;
            const unread = Boolean(latest && latest.senderId && latest.senderId !== uid && (!lastRead || (latest.createdAt?.toMillis && lastRead?.toMillis && latest.createdAt.toMillis() > lastRead.toMillis())));
            withUnread.push({ ...c, unread });
          } catch {
            withUnread.push({ ...c, unread: false });
          }
        }
        setChats(withUnread);
      } catch (e: any) {
        setError(e?.message || 'Failed to load chats');
      } finally {
        setLoading(false);
      }
    }, (err) => {
      setError(err?.message || 'Failed to load chats');
      setLoading(false);
    });
    return () => unsub();
  }, [uid]);

  const hasData = useMemo(() => chats.length > 0, [chats.length]);
  // Unread total badge moved into SellerHeader navbar

  return (
    <div className="min-h-screen pt-20 pb-12 container mx-auto px-4">
      <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold">Customization Requests</h1>
        </div>
        {loading && (
          <Card className="p-4">Loading...</Card>
        )}
        {error && (
          <Card className="p-4 border border-red-200 bg-red-50 text-red-700 text-sm">{error}</Card>
        )}
        {!loading && !hasData && !error && (
          <Card className="p-6 text-sm text-muted-foreground">No customization chats yet.</Card>
        )}
        <div className="space-y-3">
          {chats.map((c) => (
            <Card key={c.id} className="p-4 flex items-center justify-between">
              <div className="min-w-0">
                <div className="font-medium truncate flex items-center gap-2">
                  <span>{c.productName || c.productId}</span>
                  {c.unread && (
                    <span className="inline-flex items-center justify-center text-[10px] bg-amber-500 text-black rounded-full px-2 py-0.5">New</span>
                  )}
                </div>
                <div className="text-xs text-muted-foreground mt-1">Order: {c.orderId}</div>
                <div className="text-xs text-muted-foreground">Buyer: {c.buyerId}</div>
              </div>
              <Button className="bg-gold text-black" onClick={() => navigate(`/seller/customizations/${c.id}`)}>
                Open chat
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
