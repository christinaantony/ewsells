import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ShoppingBag, ArrowLeft, Trash2, ShoppingCart } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import type { CartItem } from '../contexts/CartContext';
import { useNavigate } from 'react-router-dom';
import { toast } from '@/components/ui/use-toast';

export default function SaveForLaterPage() {
  const { savedItems, moveSavedToCart, removeFromSaved } = useCart();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center mb-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Saved <span className="text-gold">for Later</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Items you saved to purchase another time
          </p>
          <div className="mt-3">
            <Button variant="link" onClick={() => navigate('/cart')} className="text-gold">
              <ArrowLeft className="h-4 w-4 mr-2" /> Back to Cart
            </Button>
          </div>
        </motion.div>

        {savedItems.length === 0 ? (
          <motion.div
            className="text-center py-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="flex justify-center mb-4">
              <ShoppingBag className="h-16 w-16 text-muted-foreground" />
            </div>
            <h2 className="text-2xl font-semibold mb-2">No items saved for later</h2>
            <p className="text-muted-foreground mb-6">
              You can save products from your cart and find them here.
            </p>
            <Button onClick={() => navigate('/products')} className="bg-gold hover:bg-gold/90 text-black">
              Browse Products
            </Button>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {savedItems.map((item: CartItem) => (
              <Card key={item.id} className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="flex flex-col sm:flex-row">
                    <div
                      className="relative sm:w-32 h-32 cursor-pointer"
                      onClick={() => navigate(`/product/${item.productId}`)}
                      role="button"
                      aria-label={`View ${item.name}`}
                    >
                      {item.imageUrl ? (
                        <img
                          src={item.imageUrl}
                          alt={item.name}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="h-full w-full bg-gray-200 flex items-center justify-center">
                          <ShoppingBag className="h-8 w-8 text-gray-400" />
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col flex-grow p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3
                            className="font-semibold text-lg cursor-pointer hover:text-gold"
                            onClick={() => navigate(`/product/${item.productId}`)}
                          >
                            {item.name}
                          </h3>
                          {item.category && (
                            <p className="text-sm text-muted-foreground">{item.category}</p>
                          )}
                          <p className="font-medium mt-2">₹{item.price.toFixed(2)}</p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-red-500 hover:text-red-700 hover:bg-red-50"
                          onClick={async () => {
                            await removeFromSaved(item.id);
                            toast({
                              title: 'Removed',
                              description: `${item.name} removed from Saved for Later`,
                            });
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">Remove</span>
                        </Button>
                      </div>
                      <div className="flex gap-2 mt-4">
                        <Button
                          className="bg-gold hover:bg-gold/90 text-black"
                          onClick={async () => {
                            await moveSavedToCart(item.id);
                            navigate('/cart');
                          }}
                        >
                          <ShoppingCart className="h-4 w-4 mr-2" /> Move to Cart
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
