// import { useEffect } from 'react';
// import { useNavigate, useParams } from 'react-router-dom';

// const CATEGORY_KEYS = [
//   'charity-craft',
//   'organic-store',
//   'scrap-store',
//   'scrap-books',
//   'moms-made-united',
//   'green-cup-challenge',
//   'charity-bakes',
// ] as const;

// type CategoryKey = typeof CATEGORY_KEYS[number];

// export default function SellerUploadRedirect() {
//   const { category } = useParams<{ category: string }>();
//   const navigate = useNavigate();

//   useEffect(() => {
//     const cat = (category || '').toLowerCase();
//     const valid = (CATEGORY_KEYS as readonly string[]).includes(cat);
//     const target = valid
//       ? `/seller?category=${encodeURIComponent(cat as CategoryKey)}#seller-upload`
//       : `/seller`;
//     // Use replace to keep history clean
//     navigate(target, { replace: true });
//   }, [category, navigate]);

//   return null;
// }
