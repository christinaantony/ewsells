import React, { useRef, useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ImageIcon, X } from 'lucide-react';
import { db, storage, auth } from '@/lib/firebase';
import { addDoc, collection, serverTimestamp, doc, updateDoc, getDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { useStore } from '@/store/useStore';
import { generateProductCode } from '@/lib/utils';
import { ProductUploadForm } from '@/components/forms/ProductUploadForm';

interface ProductData {
  id?: string;
  name: string;
  description: string;
  // pricing
  price: number;
  stock: number;
  plantType?: string;
  sunlightRequirements?: string[];
  wateringNeeds?: string;
  careLevel?: 'Easy' | 'Moderate' | 'Difficult';
  petFriendly?: boolean;
  plantHeight?: string;
  potIncluded?: boolean;
  potMaterial?: string;
  customizable?: boolean;
  status?: 'draft' | 'published' | 'pending_approval';
  images?: string[];
  imageUrls?: string[];
  category: string;
  sellerId: string;
  createdAt?: any;
  updatedAt?: any;
}

export default function HomePlantsUpload() {
  const navigate = useNavigate();
  const { id } = useParams();
  const { user } = useStore();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [isCustomizable, setIsCustomizable] = useState<boolean>(false);
  const [form, setForm] = useState({
    name: '',
    description: '',
    price: '',
    stock: '',
    plantType: '',
    sunlightRequirements: [] as string[],
    wateringNeeds: '',
    careLevel: 'Easy' as 'Easy' | 'Moderate' | 'Difficult' | undefined,
    petFriendly: false,
    plantHeight: '',
    potIncluded: false,
    potMaterial: '',
    category: 'home-plants',
    sellerId: user?.uid || '',
    images: [] as string[],
    customizable: false,
    status: 'draft' as 'draft' | 'published' | 'pending_approval'
  });
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [existingImages, setExistingImages] = useState<string[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const imageInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    const loadProduct = async () => {
      if (!id) return;
      
      try {
        const docRef = doc(db, 'products', id);
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          const data = docSnap.data() as ProductData;
          setForm(prev => ({
            ...prev,
            name: data.name,
            description: data.description,
            price: String(data.price),
            stock: String(data.stock),
            plantType: data.plantType || '',
            sunlightRequirements: data.sunlightRequirements || [],
            wateringNeeds: data.wateringNeeds || '',
            careLevel: data.careLevel || 'Easy',
            petFriendly: data.petFriendly || false,
            plantHeight: data.plantHeight || '',
            potIncluded: data.potIncluded || false,
            potMaterial: data.potMaterial || ''
          }));
          setIsCustomizable(!!data.customizable);
          if (data.images) {
            setExistingImages(data.images);
            setPreviews(data.images);
          }
          setIsEdit(true);
        } else {
          setMessage('Product not found');
          navigate('/home-plants');
        }
      } catch (error) {
        console.error('Error loading product:', error);
        setMessage('Failed to load product');
      }
    };
    
    loadProduct();
  }, [id, navigate]);

  useEffect(() => {
    const urls = imageFiles.map((file) => URL.createObjectURL(file));
    setPreviews([...existingImages, ...urls]);
    
    return () => {
      urls.forEach((url) => URL.revokeObjectURL(url));
    };
  }, [imageFiles, existingImages]);

  const onFilesSelected = (files: FileList | File[]) => {
    const valid = Array.from(files).filter((f) => f.type.startsWith('image/'));
    if (valid.length > 0) {
      setImageFiles(prev => [...prev, ...valid].slice(0, 10 - existingImages.length));
    }
  };

  const removeImage = (index: number) => {
    if (index < existingImages.length) {
      const updatedExisting = [...existingImages];
      updatedExisting.splice(index, 1);
      setExistingImages(updatedExisting);
    } else {
      const newIndex = index - existingImages.length;
      setImageFiles(prev => prev.filter((_, i) => i !== newIndex));
    }
  };

  const handleCheckboxChange = (field: string, value: string, isChecked: boolean) => {
    if (field === 'sunlightRequirements') {
      setForm(prev => ({
        ...prev,
        sunlightRequirements: isChecked
          ? [...prev.sunlightRequirements, value]
          : prev.sunlightRequirements.filter(item => item !== value)
      }));
    } else {
      setForm(prev => ({
        ...prev,
        [field]: isChecked
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      navigate('/login');
      return;
    }

    const uid = auth.currentUser?.uid;
    if (!uid) {
      setMessage('Please sign in to your seller account before uploading.');
      navigate('/seller-login');
      return;
    }

    if (!form.name.trim() || !form.description.trim() || !form.price || form.stock === '') {
      setMessage('Please fill all required fields.');
      return;
    }

    const priceVal = Number(form.price);
    if (Number.isNaN(priceVal) || priceVal < 0) {
      setMessage('Enter a valid price.');
      return;
    }

    const stockVal = Number(form.stock);
    if (!Number.isInteger(stockVal) || stockVal < 0) {
      setMessage('Enter a valid stock (non-negative integer).');
      return;
    }

    if (previews.length < 3) {
      setMessage('Please upload at least 3 images (minimum is 3).');
      return;
    }

    setIsSubmitting(true);
    setMessage(null);

    try {
      const newImageUrls = await Promise.all(
        imageFiles.map(async (file) => {
          const path = `sellers/${uid}/home-plants/${Date.now()}_${file.name}`;
          const storageRef = ref(storage, path);
          await uploadBytes(storageRef, file);
          return getDownloadURL(storageRef);
        })
      );

      const allImageUrls = [...existingImages, ...newImageUrls];

      const productData: Partial<ProductData> = {
        name: form.name.trim(),
        description: form.description.trim(),
        // store numeric values so dashboards render correctly
        price: priceVal as any,
        stock: stockVal as any,
        plantType: form.plantType,
        sunlightRequirements: form.sunlightRequirements,
        wateringNeeds: form.wateringNeeds,
        careLevel: form.careLevel,
        petFriendly: form.petFriendly,
        plantHeight: form.plantHeight,
        potIncluded: form.potIncluded,
        potMaterial: form.potIncluded ? form.potMaterial : '',
        images: allImageUrls,
        imageUrls: allImageUrls as any,
        customizable: isCustomizable,
        category: 'home-plants',
        updatedAt: serverTimestamp(),
        status: isEdit ? 'pending_approval' : 'published',
        sellerId: uid
      };

      if (isEdit && id) {
        await updateDoc(doc(db, 'products', id), productData);
        setMessage('Product updated successfully! It will be reviewed by an admin before being published again.');
      } else {
        // Generate product code for new product
        const sellerName = user?.displayName || 'Unknown';
        const productCode = await generateProductCode(sellerName, uid);

        await addDoc(collection(db, 'products'), {
          ...productData,
          published: false,
          status: 'pending_approval',
          createdAt: serverTimestamp(),
          productCode: productCode
        });
        setMessage('Product created successfully!');
        
        setForm({
          name: '',
          description: '',
          price: '',
          stock: '',
          plantType: '',
          sunlightRequirements: [] as string[],
          wateringNeeds: '',
          careLevel: 'Easy',
          petFriendly: false,
          plantHeight: '',
          potIncluded: false,
          potMaterial: '',
          category: 'home-plants',
          sellerId: user?.uid || '',
          images: [] as string[],
          customizable: false,
          status: 'draft' as 'draft' | 'published' | 'pending_approval'
        });
        setImageFiles([]);
        setExistingImages([]);
        setPreviews([]);
        if (imageInputRef.current) imageInputRef.current.value = '';
        setIsCustomizable(false);
      }
      
      // After submit, take the seller to their products management page
      setTimeout(() => navigate('/all-products'), 2000);
      
    } catch (error) {
      console.error('Error saving product:', error);
      setMessage('Failed to save plant. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const imageUpload = (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <Label>Plant Images</Label>
        <span className="text-xs text-muted-foreground">
          {previews.length} of 10 images
        </span>
      </div>
      
      <input
        ref={imageInputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => e.target.files && onFilesSelected(e.target.files)}
      />

      <div 
        className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-accent/50 transition-colors"
        onClick={() => imageInputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          e.stopPropagation();
        }}
        onDrop={(e) => {
          e.preventDefault();
          e.stopPropagation();
          if (e.dataTransfer?.files?.length) {
            onFilesSelected(e.dataTransfer.files);
          }
        }}
      >
        <div className="flex flex-col items-center justify-center space-y-2">
          <ImageIcon className="h-8 w-8 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">
            Drag & drop images here, or click to browse
          </p>
          <p className="text-xs text-muted-foreground">
            Minimum 3 images required (max 10)
          </p>
        </div>
      </div>

      {previews.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 mt-4">
          {previews.map((preview, index) => (
            <div key={index} className="relative group">
              <img
                src={preview}
                alt={`Preview ${index + 1}`}
                className="h-24 w-full rounded-md object-cover border"
              />
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  removeImage(index);
                }}
                className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                aria-label="Remove image"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const plantSpecificFields = (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <Label htmlFor="plantType">Plant Type</Label>
          <select
            id="plantType"
            value={form.plantType}
            onChange={(e) => setForm({...form, plantType: e.target.value})}
            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <option value="">Select plant type</option>
            <option value="Succulent">Succulent</option>
            <option value="Cactus">Cactus</option>
            <option value="Tropical">Tropical</option>
            <option value="Flowering">Flowering</option>
            <option value="Foliage">Foliage</option>
            <option value="Herb">Herb</option>
            <option value="Fern">Fern</option>
            <option value="Palm">Palm</option>
            <option value="Other">Other</option>
          </select>
        </div>

        <div>
          <Label>Sunlight Requirements</Label>
          <div className="space-y-2 mt-2">
            {['Full Sun', 'Partial Sun', 'Shade', 'Low Light'].map((option) => (
              <div key={option} className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id={`sunlight-${option.toLowerCase().replace(/\s+/g, '-')}`}
                  checked={form.sunlightRequirements.includes(option)}
                  onChange={(e) => handleCheckboxChange('sunlightRequirements', option, e.target.checked)}
                  className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                />
                <label htmlFor={`sunlight-${option.toLowerCase().replace(/\s+/g, '-')}`} className="text-sm">
                  {option}
                </label>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <Label htmlFor="wateringNeeds">Watering Needs</Label>
          <select
            id="wateringNeeds"
            value={form.wateringNeeds}
            onChange={(e) => setForm({...form, wateringNeeds: e.target.value})}
            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <option value="">Select watering needs</option>
            <option value="Low">Low (Let soil dry completely)</option>
            <option value="Moderate">Moderate (Water when top inch is dry)</option>
            <option value="High">High (Keep soil moist)</option>
          </select>
        </div>

        <div>
          <Label htmlFor="careLevel">Care Level</Label>
          <select
            id="careLevel"
            value={form.careLevel}
            onChange={(e) => setForm({...form, careLevel: e.target.value as 'Easy' | 'Moderate' | 'Difficult'})}
            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <option value="Easy">Easy (Great for beginners)</option>
            <option value="Moderate">Moderate (Some experience needed)</option>
            <option value="Difficult">Difficult (Expert level)</option>
          </select>
        </div>

        <div>
          <Label htmlFor="plantHeight">Mature Height</Label>
          <Input
            id="plantHeight"
            value={form.plantHeight}
            onChange={(e) => setForm({...form, plantHeight: e.target.value})}
            placeholder="e.g., 12-18 inches"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="petFriendly"
            checked={form.petFriendly}
            onChange={(e) => handleCheckboxChange('petFriendly', '', e.target.checked)}
            className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
          />
          <Label htmlFor="petFriendly">Pet Friendly</Label>
        </div>

        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            id="potIncluded"
            checked={form.potIncluded}
            onChange={(e) => {
              const isChecked = e.target.checked;
              setForm(prev => ({
                ...prev,
                potIncluded: isChecked,
                potMaterial: isChecked ? prev.potMaterial : ''
              }));
            }}
            className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
          />
          <Label htmlFor="potIncluded">Pot Included</Label>
        </div>

        {form.potIncluded && (
          <div>
            <Label htmlFor="potMaterial">Pot Material</Label>
            <select
              id="potMaterial"
              value={form.potMaterial}
              onChange={(e) => setForm({...form, potMaterial: e.target.value})}
              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <option value="">Select pot material</option>
              <option value="Plastic">Plastic</option>
              <option value="Ceramic">Ceramic</option>
              <option value="Terracotta">Terracotta</option>
              <option value="Concrete">Concrete</option>
              <option value="Metal">Metal</option>
              <option value="Fabric">Fabric</option>
            </select>
          </div>
        )}
      </div>
    </div>
  );

  const resetForm = () => {
    setForm({
      name: '',
      description: '',
      price: '',
      stock: '',
      plantType: '',
      sunlightRequirements: [] as string[],
      wateringNeeds: '',
      careLevel: 'Easy',
      petFriendly: false,
      plantHeight: '',
      potIncluded: false,
      potMaterial: '',
      category: 'home-plants',
      sellerId: user?.uid || '',
      images: [] as string[],
      customizable: false,
      status: 'draft' as 'draft' | 'published' | 'pending_approval'
    });
    setIsCustomizable(false);
    setImageFiles([]);
    setPreviews([]);
    if (imageInputRef.current) {
      imageInputRef.current.value = '';
    }
    setMessage(null);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold">
              {isEdit ? 'Edit Plant Listing' : 'Add New Plant'}
            </h1>
            <p className="text-muted-foreground">
              {isEdit ? 'Update your plant details' : 'List your unique plants to help others green their spaces.'}
            </p>
          </div>
          <Button
            variant="outline"
            onClick={() => navigate(-1)}
            className="border-primary bg-transparent text-primary hover:bg-primary hover:text-primary-foreground h-10 px-4 py-2 flex-1 sm:flex-initial"
          >
            Back to Dashboard
          </Button>
        </div>
        
        <div className="bg-card rounded-lg border shadow-sm p-6 mb-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4">Basic Information</h3>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Plant Name *</Label>
                    <Input
                      id="name"
                      value={form.name}
                      onChange={(e) => setForm({...form, name: e.target.value})}
                      placeholder="e.g., Monstera Deliciosa"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="description">Description *</Label>
                    <textarea
                      id="description"
                      value={form.description}
                      onChange={(e) => setForm({...form, description: e.target.value})}
                      placeholder="Tell us about your plant. Include any special care instructions, unique features, or interesting facts."
                      className="flex min-h-[100px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      required
                    />
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-4">Plant Details</h3>
                {plantSpecificFields}
              </div>

              

              <div>
                <h3 className="text-lg font-medium mb-4">Pricing & Stock</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="price">Price (₹) *</Label>
                    <Input
                      id="price"
                      type="number"
                      min="0"
                      step="0.01"
                      value={form.price}
                      onChange={(e) => setForm({...form, price: e.target.value})}
                      placeholder="0.00"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="stock">Available Stock *</Label>
                    <Input
                      id="stock"
                      type="number"
                      min="0"
                      step="1"
                      value={form.stock}
                      onChange={(e) => setForm({...form, stock: e.target.value})}
                      placeholder="Enter quantity"
                      required
                    />
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-4">Plant Images</h3>
                {imageUpload}
              </div>
            </div>

            <div className="pt-2">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="customizable"
                    checked={isCustomizable}
                    onChange={(e) => setIsCustomizable(e.target.checked)}
                    className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                  />
                  <Label htmlFor="customizable">Allow customer customization requests</Label>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  If enabled, buyers can message you for post-purchase customization (no phone numbers or prices allowed).
                </p>
              </div>

            {message && (
              <div className={`p-3 rounded-md ${
                message.toLowerCase().includes('success') 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-red-100 text-red-800'
              }`}>
                {message}
              </div>
            )}

            <div className="pt-6 border-t border-border">
              <div className="flex justify-end gap-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={resetForm}
                  disabled={isSubmitting}
                  className="h-10 px-4 py-2"
                >
                  Reset
                </Button>
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="h-10 px-4 py-2 bg-gold text-black hover:bg-gold/90 font-medium rounded-md transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-black" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Uploading...
                    </>
                  ) : (
                    'Upload Product'
                  )}
                </Button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
