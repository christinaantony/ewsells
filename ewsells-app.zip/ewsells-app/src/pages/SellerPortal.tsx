import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useStore } from '@/store/useStore';
import { Input } from '@/components/ui/input';
import { Eye, EyeOff, LogIn } from 'lucide-react';
import { authService } from '@/services/auth';
import { db } from '@/lib/firebase';
import { doc, getDoc } from 'firebase/firestore';

export default function SellerPortal() {
  const { user } = useStore();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleEnter = () => {
    sessionStorage.setItem('sellerPortalEntry', '1');
    navigate('/seller', { replace: true });
  };

  const handleInlineLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    try {
      const authUser = await authService.login(email, password);
      const snap = await getDoc(doc(db, 'users', authUser.uid));
      const data = snap.exists() ? (snap.data() as any) : {};
      const role = data.role || 'user';
      if (role !== 'seller') {
        setError('Your account is not a seller. Please complete seller registration.');
        return;
      }
      sessionStorage.setItem('sellerPortalEntry', '1');
      const intended = sessionStorage.getItem('sellerIntended') || '/seller';
      navigate(intended, { replace: true });
    } catch (err: any) {
      setError(err.message || 'Failed to sign in. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // Optional: if already entered via portal, show continue
  useEffect(() => {
    // no-op, keeping for future telemetry or auto-redirect if desired
  }, []);

  const isSeller = !!user && (user as any).role === 'seller';

  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-12"
    >
      <div className="container mx-auto px-4 max-w-3xl">
        <div className="rounded-2xl overflow-hidden border border-border bg-card">
          <div
            className="h-48 md:h-56 relative bg-gradient-to-r from-black/30 via-black/20 to-black/10"
          />
          <div className="p-6 md:p-8">
            <div className="inline-flex items-center px-3 py-1 rounded-full bg-white/10 border border-white/15 text-xs uppercase tracking-wide text-gray-200/90 mb-4">
              Seller Portal Access
            </div>
            <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight mb-2">Dedicated Seller Portal</h1>
            <p className="text-muted-foreground mb-6">
              Access your seller dashboard securely through this portal. Manage listings, upload products, and track your impact.
            </p>

            {!user ? (
              <>
                <div className="inline-flex items-center px-3 py-1 rounded-full bg-white/10 border border-white/15 text-xs uppercase tracking-wide text-gray-200/90 mb-3">
                  Seller Portal Login
                </div>
                {error && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-destructive/20 text-destructive p-3 rounded-lg mb-4 text-sm">
                    {error}
                  </motion.div>
                )}
                <form onSubmit={handleInlineLogin} className="space-y-4">
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-1">Email</label>
                    <Input id="email" type="email" placeholder="you@example.com" value={email} onChange={(e) => setEmail(e.target.value)} required />
                  </div>
                  <div>
                    <label htmlFor="password" className="block text-sm font-medium mb-1">Password</label>
                    <div className="relative">
                      <Input id="password" type={showPassword ? 'text' : 'password'} placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} required className="w-full pr-10" />
                      <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500">
                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                      </button>
                    </div>
                  </div>
                  <Button type="submit" disabled={isLoading} className="w-full bg-gold text-black hover:bg-gold/90">
                    {isLoading ? (
                      <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="mr-2 h-4 w-4 border-2 border-black border-t-transparent rounded-full" />
                    ) : (
                      <LogIn className="mr-2 h-4 w-4" />
                    )}
                    {isLoading ? 'Signing In...' : 'Sign In'}
                  </Button>
                </form>
                <div className="mt-6 text-center text-sm">
                  <p>
                    Back to{' '}
                    <Link to="/seller-portal" className="text-primary hover:underline">Seller Portal</Link>
                  </p>
                </div>
              </>
            ) : isSeller ? (
              <div className="flex flex-wrap gap-3">
                <Button onClick={handleEnter} className="bg-gold text-black hover:bg-gold/90">Enter Seller Dashboard</Button>
                <Button variant="outline" onClick={() => navigate('/')}>Back to Home</Button>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="text-sm text-red-400">Your account is not a seller. Please complete registration or contact support.</div>
                <div className="flex flex-wrap gap-3">
                  <Button onClick={() => navigate('/seller-registration')} className="bg-gold text-black hover:bg-gold/90">Become a Seller</Button>
                  <Button variant="outline" onClick={() => navigate('/')}>Back to Home</Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </motion.main>
  );
}
