import React, { useEffect, useMemo, useState } from 'react';
import { collection, query, where, onSnapshot, doc, updateDoc, deleteDoc, serverTimestamp, getDocs } from 'firebase/firestore';
import { db, storage } from '@/lib/firebase';
import { useStore } from '@/store/useStore';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Edit3, Trash2, Save, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { deleteObject, ref } from 'firebase/storage';
import type { Query, QuerySnapshot, DocumentData } from 'firebase/firestore';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { formatCurrency } from '@/lib/utils';

interface ProductDoc {
  id: string;
  name: string;
  description: string;
  // pricing
  finalPrice?: number; // admin-approved
  sellerPrice?: number; // seller-provided (seller edits this)
  price?: number; // legacy
  category?: string;
  imageUrl?: string;
  imageUrls?: string[];
  sellerId: string;
  stock?: number;
  createdAt?: any;
  updatedAt?: any;
  needsReview?: boolean;
  reviewReason?: string;
  reviewFields?: string[];
  reviewAt?: any;
  published?: boolean;
}

// Tiny inline carousel for table thumbnails
function MiniCarousel({ images, className }: { images: string[]; className?: string }) {
  const valid = Array.isArray(images) ? images.filter(Boolean) : [];
  const [idx, setIdx] = React.useState(0);
  const [lightboxOpen, setLightboxOpen] = React.useState(false);
  const [imageError, setImageError] = React.useState<Record<number, boolean>>({});
  
  const handleImageError = (index: number) => {
    setImageError(prev => ({ ...prev, [index]: true }));
  };

  if (valid.length === 0 || imageError[idx]) {
    return (
      <div className={`h-16 w-16 rounded border bg-muted flex items-center justify-center ${className || ''}`}>
        <div className="text-muted-foreground">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 mx-auto">
            <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
            <circle cx="9" cy="9" r="2" />
            <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
          </svg>
        </div>
      </div>
    );
  }
  const go = (delta: number) => setIdx((i) => (i + delta + valid.length) % valid.length);
  return (
    <div className={`relative h-16 w-16 ${className || ''}`}>
      <img
        src={valid[idx]}
        alt="item"
        className="h-16 w-16 object-cover rounded border cursor-zoom-in"
        onError={() => handleImageError(idx)}
        onLoad={() => setImageError(prev => ({ ...prev, [idx]: false }))}
        onClick={(e) => { e.stopPropagation(); setLightboxOpen(true); }}
      />
      {valid.length > 1 && (
        <>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); go(-1); }}
            className="absolute left-0 top-1/2 -translate-y-1/2 h-6 w-6 flex items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/70"
            aria-label="Previous image"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); go(1); }}
            className="absolute right-0 top-1/2 -translate-y-1/2 h-6 w-6 flex items-center justify-center rounded-full bg-black/50 text-white hover:bg-black/70"
            aria-label="Next image"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
          <div className="absolute bottom-0 left-1/2 -translate-x-1/2 mb-0.5 px-1.5 py-0.5 rounded bg-black/50 text-white text-[10px]">
            {idx + 1}/{valid.length}
          </div>
        </>
      )}

      {/* Lightbox Dialog */}
      <Dialog open={lightboxOpen} onOpenChange={setLightboxOpen}>
        <DialogContent className="max-w-3xl p-0 overflow-hidden">
          <div className="relative bg-black">
            <img
              src={valid[idx]}
              alt={`preview-${idx + 1}`}
              className="max-h-[80vh] w-full object-contain bg-black"
              onError={() => handleImageError(idx)}
              onLoad={() => setImageError(prev => ({ ...prev, [idx]: false }))}
              onClick={(e) => { e.stopPropagation(); setLightboxOpen(false); }}
            />
            {valid.length > 1 && (
              <>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); go(-1); }}
                  className="absolute left-2 top-1/2 -translate-y-1/2 h-9 w-9 flex items-center justify-center rounded-full bg-white/20 text-white hover:bg-white/30"
                  aria-label="Previous"
                >
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); go(1); }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 h-9 w-9 flex items-center justify-center rounded-full bg-white/20 text-white hover:bg-white/30"
                  aria-label="Next"
                >
                  <ChevronRight className="h-5 w-5" />
                </button>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function AllProducts() {
  const { user } = useStore();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<ProductDoc[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<{ name: string; description: string; sellerPrice: string; stock: string }>({ name: '', description: '', sellerPrice: '', stock: '' });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [indexUrl, setIndexUrl] = useState<string | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);

  const q = useMemo(() => {
    if (!user) return null;
    // Show all products for this seller, including unpublished ones
    return query(
      collection(db, 'products'),
      where('sellerId', '==', user.id)
      // Note: We're not filtering by 'published' here because sellers should see all their products
      // including unpublished ones in their dashboard
    );
  }, [user]);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }
    if (!q) return;

    let unsub: (() => void) | null = null;
    let triedFallback = false;

    const subscribe = (queryToUse: Query<DocumentData>) => {
      unsub = onSnapshot(
        queryToUse,
        (snap: QuerySnapshot<DocumentData>) => {
          const rows: ProductDoc[] = snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
          setProducts(rows);
          setError(null);
          setIndexUrl(null);
          setLoading(false);
        },
        (err) => {
          console.error('AllProducts onSnapshot error:', err);
          // Detect missing index and extract console URL if present
          const msg = String(err?.message || '');
          const match = msg.match(/https?:\/\/console\.firebase\.google\.com[^\s)]+/);
          if (match) setIndexUrl(match[0]);
          setError(err?.message || 'Failed to load products');

          // If the error is failed-precondition (likely missing composite index),
          // try again without orderBy as a graceful fallback.
          if (!triedFallback && (err?.code === 'failed-precondition' || match)) {
            triedFallback = true;
            try {
              // Fallback without orderBy
              const fallbackQ = query(collection(db, 'products'), where('sellerId', '==', user.id));
              if (unsub) try { unsub(); } catch {}
              subscribe(fallbackQ as Query<DocumentData>);
              return;
            } catch (fallbackErr) {
              console.error('Fallback query construction failed:', fallbackErr);
            } finally {
              setLoading(false);
            }
          } else {
            setLoading(false);
          }
        }
      );
    };

    // Prime the UI with a one-time fetch so the table shows quickly
    (async () => {
      try {
        const snap = await getDocs(q as Query<DocumentData>);
        const rows: ProductDoc[] = snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
        if (rows.length > 0) setProducts(rows);
      } catch (e) {
        console.warn('Initial getDocs failed (will rely on onSnapshot):', e);
      }
    })();

    subscribe(q as Query<DocumentData>);
    return () => { if (unsub) unsub(); };
  }, [q, user]);

  const startEdit = (p: ProductDoc) => {
    setEditingId(p.id);
    setEditForm({ name: p.name, description: p.description, sellerPrice: String(p.sellerPrice ?? p.price ?? ''), stock: String(p.stock ?? '') });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm({ name: '', description: '', sellerPrice: '', stock: '' });
  };

  const saveEdit = async (id: string) => {
    // Validate required fields
    if (!editForm.name.trim()) {
      setError('Product name is required');
      return;
    }
    if (!editForm.description.trim()) {
      setError('Product description is required');
      return;
    }
    if (editForm.sellerPrice.trim() === '') {
      setError('Price is required');
      return;
    }
    if (editForm.stock.trim() === '') {
      setError('Stock quantity is required');
      return;
    }

    const sellerPriceVal = Number(editForm.sellerPrice);
    const stockVal = Number(editForm.stock);
    
    if (Number.isNaN(sellerPriceVal) || sellerPriceVal < 0) {
      setError('Please enter a valid price (must be 0 or greater)');
      return;
    }
    if (!Number.isInteger(stockVal) || stockVal < 0) {
      setError('Stock must be a whole number (0 or greater)');
      return;
    }

    const product = products.find((p) => p.id === id);
    if (!user || !product) {
      setError('User not authenticated or product not found');
      return;
    }
    // Client-side ownership guard for clearer UX; rules still enforce on server
    if (product.sellerId !== (user as any).id && product.sellerId !== (user as any).uid) {
      setError('You can only update products you own.');
      return;
    }

    // Compute changed fields for admin context
    const changedFields: string[] = [];
    if (product.name !== editForm.name.trim()) changedFields.push('name');
    if (product.description !== editForm.description.trim()) changedFields.push('description');
    if (Number(product.sellerPrice ?? product.price ?? 0) !== sellerPriceVal) changedFields.push('sellerPrice');
    if (Number(product.stock ?? 0) !== stockVal) changedFields.push('stock');

    setSaving(true);
    try {
      await updateDoc(doc(db, 'products', id), {
        name: editForm.name.trim(),
        description: editForm.description.trim(),
        sellerPrice: sellerPriceVal,
        stock: stockVal,
        // Editing by seller should unpublish for admin re-approval
        published: false,
        outOfStock: stockVal === 0 ? true : false,
        needsReview: true,
        reviewReason: 'seller_edit',
        reviewFields: changedFields,
        reviewAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      
      // Update local state to reflect changes immediately
      setProducts(prevProducts => 
        prevProducts.map(p => 
          p.id === id 
            ? { 
                ...p, 
                name: editForm.name.trim(),
                description: editForm.description.trim(),
                sellerPrice: sellerPriceVal,
                stock: stockVal,
                outOfStock: stockVal === 0,
                needsReview: true,
                reviewReason: 'seller_edit',
                reviewFields: changedFields,
                updatedAt: new Date()
              } 
            : p
        )
      );
      
      cancelEdit();
    } catch (e) {
      console.error('Failed to update product', e);
      const msg = (e as any)?.message || 'Failed to update product';
      setError(msg);
    } finally {
      setSaving(false);
    }
  };

  const removeProduct = async (p: ProductDoc) => {
    if (!user) return;
    // Client-side ownership guard; admin will still be permitted by rules if logged in as admin
    if (p.sellerId !== (user as any).id && p.sellerId !== (user as any).uid) {
      setError('You can only delete products you own.');
      return;
    }
    setDeletingId(p.id);
    try {
      // Try to delete images from storage if URLs are present (best effort)
      const urls = p.imageUrls && Array.isArray(p.imageUrls) ? p.imageUrls : (p.imageUrl ? [p.imageUrl] : []);
      await Promise.all(
        urls.map(async (url) => {
          try {
            // ref(storage, urlOrPath) supports https:// and gs:// URLs as well as storage paths
            const fileRef = ref(storage, url);
            await deleteObject(fileRef);
          } catch (e) {
            // ignore failures; the doc will still be removed
            console.warn('Could not delete storage object for URL:', url);
          }
        })
      );
    } catch {}
    try {
      await deleteDoc(doc(db, 'products', p.id));
      // Optimistic UI update
      setProducts((prev) => prev.filter((x) => x.id !== p.id));
    } catch (e: any) {
      console.error('Failed to delete product', e);
      const msg = `Failed to delete. ${e?.code || ''} ${e?.message || ''}`.trim();
      setError(msg);
    } finally {
      setDeletingId(null);
    }
  };

  const confirmDelete = async () => {
    if (!confirmId) return;
    const p = products.find((x) => x.id === confirmId);
    if (!p) { setConfirmId(null); return; }
    await removeProduct(p);
    setConfirmId(null);
  };

  if (!user) {
    return (
      <main className="min-h-screen pt-24 pb-12">
        <div className="container mx-auto px-4 max-w-4xl">
          <Card>
            <CardContent className="p-6">
              <p className="mb-4">Please log in to view your products.</p>
              <Button onClick={() => navigate('/login')} className="bg-gold text-black hover:bg-gold/90">Go to Login</Button>
            </CardContent>
          </Card>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen">
      <section className="pt-24 pb-12 bg-surface/50 border-t border-border/40">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl font-bold">All Products</h1>
              <p className="text-muted-foreground">Manage products you have uploaded.</p>
            </div>
            <Button variant="outline" onClick={() => navigate('/seller')}>Back to Dashboard</Button>
          </div>

          {/* Global inline error banner for actions like save/delete */}
          {error && (
            <Card className="mb-4 border-destructive/50">
              <CardContent className="p-4 text-sm text-destructive">
                {error}
              </CardContent>
            </Card>
          )}

          {loading ? (
            <Card>
              <CardContent className="p-6 flex items-center gap-3 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" /> Loading your products...
              </CardContent>
            </Card>
          ) : error && products.length === 0 ? (
            <Card>
              <CardContent className="p-6 space-y-2">
                <div className="text-sm text-destructive">{error}</div>
                {indexUrl && (
                  <div className="text-xs text-muted-foreground">
                    A composite index may be required for this view. Create it here:{' '}
                    <a href={indexUrl} target="_blank" rel="noreferrer" className="underline text-gold">Open index setup</a>
                  </div>
                )}
              </CardContent>
            </Card>
          ) : products.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-center text-sm text-muted-foreground">
                No products yet. Upload from your category pages.
              </CardContent>
            </Card>
          ) : (
            <div>
              <table className="w-full border border-border text-sm">
                <thead className="bg-muted/40">
                  <tr className="text-left">
                    <th className="p-2 border-b border-border w-20">Image</th>
                    <th className="p-2 border-b border-border w-48">Title</th>
                    <th className="p-2 border-b border-border w-24">Price</th>
                    <th className="p-2 border-b border-border w-20">Stock</th>
                    <th className="p-2 border-b border-border w-20">Published</th>
                    <th className="p-2 border-b border-border w-32">Category</th>
                    <th className="p-2 border-b border-border">Description</th>
                    <th className="p-2 border-b border-border w-32">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((p) => (
                    <tr key={p.id} className="align-top">
                      <td className="p-2 border-b border-border">
                        {(() => {
                          const imgs =
                            (Array.isArray(p.imageUrls) && p.imageUrls.length > 0)
                              ? p.imageUrls as string[]
                              : (Array.isArray((p as any).images) && (p as any).images.length > 0)
                                ? ((p as any).images as string[])
                                : (p.imageUrl ? [p.imageUrl] : []);
                          return <MiniCarousel images={imgs} />;
                        })()}
                      </td>
                      {editingId === p.id ? (
                        <>
                          <td className="p-2 border-b border-border min-w-[220px]">
                            <Label htmlFor={`name-${p.id}`} className="sr-only">Title</Label>
                            <Input id={`name-${p.id}`} value={editForm.name} onChange={(e) => setEditForm((f) => ({ ...f, name: e.target.value }))} />
                          </td>
                          <td className="p-2 border-b border-border min-w-[140px]">
                            <Label htmlFor={`sellerPrice-${p.id}`} className="sr-only">Seller Price</Label>
                            <Input id={`sellerPrice-${p.id}`} type="number" min="0" step="0.01" value={editForm.sellerPrice} onChange={(e) => setEditForm((f) => ({ ...f, sellerPrice: e.target.value }))} />
                          </td>
                          <td className="p-2 border-b border-border min-w-[120px]">
                            <Label htmlFor={`stock-${p.id}`} className="sr-only">Stock</Label>
                            <Input id={`stock-${p.id}`} type="number" min="0" step="1" inputMode="numeric" pattern="[0-9]*" value={editForm.stock} onChange={(e) => setEditForm((f) => ({ ...f, stock: e.target.value }))} />
                          </td>
                          <td className="p-2 border-b border-border">
                            {p.published ? (
                              <span className="inline-flex items-center px-2 py-0.5 rounded bg-green-100 text-green-800 text-xs">Yes</span>
                            ) : (
                              <span className="inline-flex items-center px-2 py-0.5 rounded bg-red-100 text-red-800 text-xs">No</span>
                            )}
                          </td>
                          <td className="p-2 border-b border-border text-muted-foreground">
                            {p.category || '-'}
                          </td>
                          <td className="p-2 border-b border-border min-w-[320px]">
                            <Label htmlFor={`desc-${p.id}`} className="sr-only">Description</Label>
                            <textarea id={`desc-${p.id}`} className="min-h-[72px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm" value={editForm.description} onChange={(e) => setEditForm((f) => ({ ...f, description: e.target.value }))} />
                          </td>
                          <td className="p-2 border-b border-border">
                            <div className="flex items-center gap-2">
                              <Button size="sm" disabled={saving} onClick={() => saveEdit(p.id)} className="bg-gold text-black hover:bg-gold/90">
                                {saving ? <span className="inline-flex items-center"><Loader2 className="h-4 w-4 mr-2 animate-spin" />Saving</span> : <span className="inline-flex items-center"><Save className="w-4 h-4 mr-2" />Save</span>}
                              </Button>
                              <Button size="sm" variant="outline" onClick={cancelEdit}><X className="w-4 h-4 mr-2" />Cancel</Button>
                            </div>
                          </td>
                        </>
                      ) : (
                        <>
                          <td className="p-2 border-b border-border font-medium">{p.name}</td>
                          <td className="p-2 border-b border-border">{p.sellerPrice !== undefined ? formatCurrency(Number(p.sellerPrice)) : (p.price !== undefined ? formatCurrency(Number(p.price)) : '-')}</td>
                          <td className="p-2 border-b border-border">{
                            typeof p.stock === 'number'
                              ? p.stock
                              : (typeof (p as any).stock === 'string' && (p as any).stock.trim() !== '' && !Number.isNaN(Number((p as any).stock)))
                                ? Number((p as any).stock)
                                : '-'
                          }</td>
                          <td className="p-2 border-b border-border">
                            {p.published ? (
                              <span className="inline-flex items-center px-2 py-0.5 rounded bg-green-100 text-green-800 text-xs">Yes</span>
                            ) : (
                              <span className="inline-flex items-center px-2 py-0.5 rounded bg-red-100 text-red-800 text-xs">No</span>
                            )}
                          </td>
                          <td className="p-2 border-b border-border text-muted-foreground">{p.category || '-'}</td>
                          <td className="p-2 border-b border-border text-muted-foreground max-w-[420px]">
                            <div className="line-clamp-3 text-sm">{p.description}</div>
                          </td>
                          <td className="p-2 border-b border-border">
                            <div className="flex items-center gap-2">
                              <Button size="sm" variant="outline" onClick={() => startEdit(p)}><Edit3 className="w-4 h-4 mr-1" />Edit</Button>
                              <Button size="sm" variant="destructive" disabled={deletingId === p.id} onClick={() => setConfirmId(p.id)}>
                                {deletingId === p.id ? (<span className="inline-flex items-center"><Loader2 className="h-4 w-4 mr-1 animate-spin" />Deleting</span>) : (<span className="inline-flex items-center"><Trash2 className="w-4 h-4 mr-1" />Delete</span>)}
                              </Button>
                            </div>
                          </td>
                        </>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>
      {/* Delete confirmation dialog */}
      <Dialog open={!!confirmId} onOpenChange={(open) => { if (!open) setConfirmId(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete this product?</DialogTitle>
            <DialogDescription>
              This action cannot be undone. This will permanently remove the product and attempt to delete its images.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmId(null)}>Cancel</Button>
            <Button className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={confirmDelete} disabled={!!deletingId}>
              {deletingId ? (<span className="inline-flex items-center"><Loader2 className="h-4 w-4 mr-2 animate-spin" />Deleting</span>) : 'Delete'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </main>
  );
}
