import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, SlidersHorizontal, Grid2X2, List, Heart, Calendar, MapPin, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';

export function HelpingHandsPage() {
  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }}
      className="min-h-screen pt-20 pb-12"
    >
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="text-gold">Helping Hands</span> Request
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Submit your request for assistance and our community will do its best to help you.
          </p>
        </div>

        {/* Call to Action */}
        <div className="mt-16 mb-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Make a Difference Today</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-6">
            Whether you have time to volunteer or need support, our Helping Hands community is here for you.
            Join us in building a stronger, more compassionate community.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-gold hover:bg-gold/90 text-black font-bold px-8"
            >
              <Heart className="mr-2 h-5 w-5" /> Become a Volunteer
            </Button>
            <Link to="/helping-hands/register">
              <Button 
                size="lg" 
                variant="outline"
                className="font-bold px-8"
              >
                Request Support
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
