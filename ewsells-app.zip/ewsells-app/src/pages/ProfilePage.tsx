import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useStore } from '@/store/useStore';
import { doc, getDoc, updateDoc, arrayUnion, arrayRemove } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Address } from '@/types';
import { v4 as uuidv4 } from 'uuid';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from '@/components/ui/use-toast';
import { Pencil, Plus, Trash2, MapPin, Check, AlertCircle } from 'lucide-react';

// List of countries for dropdown
const countries = [
  "India",
  "Afghanistan",
  "Bangladesh",
  "Bhutan",
  "Maldives",
  "Nepal",
  "Pakistan",
  "Sri Lanka"
];

export default function ProfilePage() {
  const { user, setUser } = useStore();
  const [isLoading, setIsLoading] = useState(true);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [isAddingAddress, setIsAddingAddress] = useState(false);
  const [editingAddressId, setEditingAddressId] = useState<string | null>(null);
  
  // Profile form state
  const [profileForm, setProfileForm] = useState({
    displayName: user?.displayName || '',
    email: user?.email || '',
    phoneNumber: user?.phoneNumber || ''
  });
  
  // Validation state
  const [phoneError, setPhoneError] = useState('');
  
  // Address form state
  const [addressForm, setAddressForm] = useState<Address>({
    id: '',
    name: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    postalCode: '',
    country: 'India',
    phoneNumber: '',
    landmark: '',
    isDefault: false
  });
  
  // Address validation state
  const [addressPhoneError, setAddressPhoneError] = useState('');

  // Fetch user data including addresses from Firestore
  useEffect(() => {
    const fetchUserData = async () => {
      if (!user?.uid) return;
      
      setIsLoading(true);
      try {
        const userDoc = await getDoc(doc(db, 'users', user.uid));
        if (userDoc.exists()) {
          const userData = userDoc.data();
          
          // Update profile form with latest data
          setProfileForm({
            displayName: userData.displayName || '',
            email: userData.email || '',
            phoneNumber: userData.phoneNumber || ''
          });
          
          // Update user in store with complete data including addresses
          const updatedUser = {
            ...user,
            id: user.uid,
            uid: user.uid,
            displayName: userData.displayName,
            email: userData.email || user.email,
            phoneNumber: userData.phoneNumber,
            addresses: userData.addresses || [],
            defaultAddressId: userData.defaultAddressId,
            createdAt: userData.createdAt ? new Date(userData.createdAt.seconds * 1000) : new Date(),
            updatedAt: userData.updatedAt ? new Date(userData.updatedAt.seconds * 1000) : new Date(),
            role: userData.role || 'user'
          };
          
          setUser(updatedUser);
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        toast({
          title: 'Error',
          description: 'Failed to load your profile data',
          variant: 'destructive'
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchUserData();
  }, [user?.uid, setUser]);

  // Validate phone number format
  const validatePhoneNumber = (phone: string): boolean => {
    // Indian phone number validation (10 digits, optionally with country code)
    const phoneRegex = /^(\+91[\-\s]?)?[0]?(91)?[6789]\d{9}$/;
    return phoneRegex.test(phone);
  };

  // Handle profile update
  const handleProfileUpdate = async () => {
    if (!user?.uid) return;
    
    // Validate phone number
    if (profileForm.phoneNumber && !validatePhoneNumber(profileForm.phoneNumber)) {
      setPhoneError('Please enter a valid 10-digit Indian phone number');
      return;
    }
    
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        displayName: profileForm.displayName,
        phoneNumber: profileForm.phoneNumber,
        updatedAt: new Date()
      });
      
      // Update user in store
      setUser({
        ...user,
        displayName: profileForm.displayName,
        phoneNumber: profileForm.phoneNumber,
        updatedAt: new Date()
      });
      
      setIsEditingProfile(false);
      setPhoneError('');
      toast({
        title: 'Success',
        description: 'Your profile has been updated',
        variant: 'default'
      });
    } catch (error) {
      console.error('Error updating profile:', error);
      toast({
        title: 'Error',
        description: 'Failed to update your profile',
        variant: 'destructive'
      });
    }
  };

  // Handle address save (add or update)
  const handleAddressSave = async () => {
    if (!user?.uid) return;
    
    // Required fields validation
    if (!addressForm.name || !addressForm.addressLine1 || !addressForm.city || 
        !addressForm.state || !addressForm.postalCode || !addressForm.phoneNumber) {
      toast({
        title: 'Error',
        description: 'Please fill all required fields',
        variant: 'destructive'
      });
      return;
    }
    
    // Validate phone number
    if (!validatePhoneNumber(addressForm.phoneNumber)) {
      setAddressPhoneError('Please enter a valid 10-digit Indian phone number');
      return;
    }
    
    try {
      const userRef = doc(db, 'users', user.uid);
      const newAddress = {
        ...addressForm,
        id: addressForm.id || uuidv4()
      };
      
      if (editingAddressId) {
        // Update existing address
        const currentAddresses = user.addresses || [];
        const updatedAddresses = currentAddresses.map(addr => 
          addr.id === editingAddressId ? newAddress : addr
        );
        
        await updateDoc(userRef, {
          addresses: updatedAddresses,
          updatedAt: new Date()
        });
        
        // If this is the default address, update defaultAddressId
        if (newAddress.isDefault) {
          await updateDoc(userRef, { defaultAddressId: newAddress.id });
        }
        
        // Update user in store
        setUser({
          ...user,
          addresses: updatedAddresses,
          defaultAddressId: newAddress.isDefault ? newAddress.id : user.defaultAddressId,
          updatedAt: new Date()
        });
      } else {
        // Add new address
        const currentAddresses = user.addresses || [];
        
        // If this is the first address or marked as default
        if (currentAddresses.length === 0 || newAddress.isDefault) {
          await updateDoc(userRef, { defaultAddressId: newAddress.id });
          newAddress.isDefault = true;
        }
        
        await updateDoc(userRef, {
          addresses: arrayUnion(newAddress),
          updatedAt: new Date()
        });
        
        // Update user in store
        setUser({
          ...user,
          addresses: [...currentAddresses, newAddress],
          defaultAddressId: newAddress.isDefault ? newAddress.id : user.defaultAddressId,
          updatedAt: new Date()
        });
      }
      
      // Reset form and state
      setAddressForm({
        id: '',
        name: '',
        addressLine1: '',
        addressLine2: '',
        city: '',
        state: '',
        postalCode: '',
        country: 'India',
        phoneNumber: '',
        landmark: '',
        isDefault: false
      });
      setIsAddingAddress(false);
      setEditingAddressId(null);
      setAddressPhoneError('');
      
      toast({
        title: 'Success',
        description: editingAddressId ? 'Address updated successfully' : 'New address added successfully',
        variant: 'default'
      });
    } catch (error) {
      console.error('Error saving address:', error);
      toast({
        title: 'Error',
        description: 'Failed to save address',
        variant: 'destructive'
      });
    }
  };

  // Handle address deletion
  const handleDeleteAddress = async (addressId: string) => {
    if (!user?.uid || !user.addresses) return;
    
    try {
      const addressToDelete = user.addresses.find(addr => addr.id === addressId);
      if (!addressToDelete) return;
      
      const userRef = doc(db, 'users', user.uid);
      
      await updateDoc(userRef, {
        addresses: arrayRemove(addressToDelete),
        updatedAt: new Date()
      });
      
      // If deleted address was default, update defaultAddressId
      if (user.defaultAddressId === addressId) {
        const remainingAddresses = user.addresses.filter(addr => addr.id !== addressId);
        const newDefaultId = remainingAddresses.length > 0 ? remainingAddresses[0].id : null;
        
        if (newDefaultId) {
          await updateDoc(userRef, { 
            defaultAddressId: newDefaultId,
            addresses: remainingAddresses.map(addr => 
              addr.id === newDefaultId ? { ...addr, isDefault: true } : addr
            )
          });
        } else {
          await updateDoc(userRef, { defaultAddressId: null });
        }
        
        // Update user in store
        setUser({
          ...user,
          addresses: remainingAddresses.map(addr => 
            addr.id === newDefaultId ? { ...addr, isDefault: true } : addr
          ),
          defaultAddressId: newDefaultId || undefined,
          updatedAt: new Date()
        });
      } else {
        // Update user in store
        setUser({
          ...user,
          addresses: user.addresses.filter(addr => addr.id !== addressId),
          updatedAt: new Date()
        });
      }
      
      toast({
        title: 'Success',
        description: 'Address deleted successfully',
        variant: 'default'
      });
    } catch (error) {
      console.error('Error deleting address:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete address',
        variant: 'destructive'
      });
    }
  };

  // Handle setting an address as default
  const handleSetDefaultAddress = async (addressId: string) => {
    if (!user?.uid || !user.addresses) return;
    
    try {
      const userRef = doc(db, 'users', user.uid);
      
      // Update defaultAddressId in Firestore
      await updateDoc(userRef, { 
        defaultAddressId: addressId,
        updatedAt: new Date()
      });
      
      // Update addresses array to reflect new default
      const updatedAddresses = user.addresses.map(addr => ({
        ...addr,
        isDefault: addr.id === addressId
      }));
      
      await updateDoc(userRef, { addresses: updatedAddresses });
      
      // Update user in store
      setUser({
        ...user,
        addresses: updatedAddresses,
        defaultAddressId: addressId,
        updatedAt: new Date()
      });
      
      toast({
        title: 'Success',
        description: 'Default address updated',
        variant: 'default'
      });
    } catch (error) {
      console.error('Error setting default address:', error);
      toast({
        title: 'Error',
        description: 'Failed to update default address',
        variant: 'destructive'
      });
    }
  };

  // Handle edit address
  const handleEditAddress = (address: Address) => {
    setAddressForm(address);
    setEditingAddressId(address.id);
    setIsAddingAddress(true);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen pt-20 pb-12">
        <div className="container mx-auto px-4">
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gold"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen pt-20 pb-12">
        <div className="container mx-auto px-4">
          <div className="text-center py-12">
            <h2 className="text-2xl font-semibold mb-4">Please log in to view your profile</h2>
            <Button onClick={() => window.location.href = '/login'} className="bg-gold hover:bg-gold/90 text-black">
              Login
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center mb-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            My <span className="text-gold">Profile</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Manage your account details and delivery addresses
          </p>
        </motion.div>

        <Tabs defaultValue="profile" className="max-w-4xl mx-auto">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="profile">Profile Details</TabsTrigger>
            <TabsTrigger value="addresses">Delivery Addresses</TabsTrigger>
          </TabsList>
          
          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Personal Information</CardTitle>
                    <CardDescription>Update your personal details</CardDescription>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setIsEditingProfile(!isEditingProfile)}
                  >
                    {isEditingProfile ? 'Cancel' : (
                      <>
                        <Pencil className="h-4 w-4 mr-2" />
                        Edit
                      </>
                    )}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {isEditingProfile ? (
                  <div className="space-y-4">
                    <div className="grid gap-2">
                      <Label htmlFor="displayName">Name</Label>
                      <Input 
                        id="displayName" 
                        value={profileForm.displayName}
                        onChange={(e) => setProfileForm({...profileForm, displayName: e.target.value})}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="email">Email</Label>
                      <Input 
                        id="email" 
                        value={profileForm.email}
                        disabled
                      />
                      <p className="text-xs text-muted-foreground">Email cannot be changed</p>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="phoneNumber">Phone Number</Label>
                      <Input 
                        id="phoneNumber" 
                        value={profileForm.phoneNumber}
                        onChange={(e) => {
                          setProfileForm({...profileForm, phoneNumber: e.target.value});
                          setPhoneError('');
                        }}
                        className={phoneError ? 'border-red-500' : ''}
                      />
                      {phoneError && (
                        <div className="flex items-center text-red-500 text-xs mt-1">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          {phoneError}
                        </div>
                      )}
                      <p className="text-xs text-muted-foreground">Enter a valid 10-digit Indian phone number</p>
                    </div>
                    <Button 
                      className="w-full bg-gold hover:bg-gold/90 text-black mt-4"
                      onClick={handleProfileUpdate}
                    >
                      Save Changes
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                      <div className="font-medium">Name</div>
                      <div className="col-span-2">{user.displayName || 'Not set'}</div>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="font-medium">Email</div>
                      <div className="col-span-2">{user.email}</div>
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="font-medium">Phone Number</div>
                      <div className="col-span-2">{user?.phoneNumber ? user.phoneNumber : 'Not set'}</div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Addresses Tab */}
          <TabsContent value="addresses">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Delivery Addresses</CardTitle>
                    <CardDescription>Manage your delivery addresses</CardDescription>
                  </div>
                  {!isAddingAddress && (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => setIsAddingAddress(true)}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add New Address
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {isAddingAddress ? (
                  <div className="space-y-4 border rounded-md p-4">
                    <h3 className="text-lg font-medium mb-4">
                      {editingAddressId ? 'Edit Address' : 'Add New Address'}
                    </h3>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="grid gap-2">
                        <Label htmlFor="name">Address Name</Label>
                        <Input 
                          id="name" 
                          placeholder="Home, Work, etc."
                          value={addressForm.name}
                          onChange={(e) => setAddressForm({...addressForm, name: e.target.value})}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="phoneNumber">Phone Number</Label>
                        <Input 
                          id="phoneNumber" 
                          placeholder="Phone number for delivery"
                          value={addressForm.phoneNumber}
                          onChange={(e) => {
                            setAddressForm({...addressForm, phoneNumber: e.target.value});
                            setAddressPhoneError('');
                          }}
                          className={addressPhoneError ? 'border-red-500' : ''}
                        />
                        {addressPhoneError && (
                          <div className="flex items-center text-red-500 text-xs mt-1">
                            <AlertCircle className="h-3 w-3 mr-1" />
                            {addressPhoneError}
                          </div>
                        )}
                        <p className="text-xs text-muted-foreground">Enter a valid 10-digit Indian phone number</p>
                      </div>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="addressLine1">Address Line 1</Label>
                      <Input 
                        id="addressLine1" 
                        placeholder="House/Flat number, Building name, Street"
                        value={addressForm.addressLine1}
                        onChange={(e) => setAddressForm({...addressForm, addressLine1: e.target.value})}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="addressLine2">Address Line 2 (Optional)</Label>
                      <Input 
                        id="addressLine2" 
                        placeholder="Area, Colony, Street"
                        value={addressForm.addressLine2 || ''}
                        onChange={(e) => setAddressForm({...addressForm, addressLine2: e.target.value})}
                      />
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="landmark">Landmark (Optional)</Label>
                      <Input 
                        id="landmark" 
                        placeholder="Nearby landmark for easy navigation"
                        value={addressForm.landmark || ''}
                        onChange={(e) => setAddressForm({...addressForm, landmark: e.target.value})}
                      />
                    </div>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="grid gap-2">
                        <Label htmlFor="city">City</Label>
                        <Input 
                          id="city" 
                          placeholder="City"
                          value={addressForm.city}
                          onChange={(e) => setAddressForm({...addressForm, city: e.target.value})}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="state">State</Label>
                        <Input 
                          id="state" 
                          placeholder="State"
                          value={addressForm.state}
                          onChange={(e) => setAddressForm({...addressForm, state: e.target.value})}
                        />
                      </div>
                    </div>
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="grid gap-2">
                        <Label htmlFor="postalCode">Postal Code</Label>
                        <Input 
                          id="postalCode" 
                          placeholder="PIN code"
                          value={addressForm.postalCode}
                          onChange={(e) => setAddressForm({...addressForm, postalCode: e.target.value})}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="country">Country</Label>
                        <select 
                          id="country" 
                          value={addressForm.country}
                          onChange={(e) => setAddressForm({...addressForm, country: e.target.value})}
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          {countries.map(country => (
                            <option key={country} value={country}>{country}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 mt-2">
                      <input
                        type="checkbox"
                        id="isDefault"
                        checked={addressForm.isDefault}
                        onChange={(e) => setAddressForm({...addressForm, isDefault: e.target.checked})}
                        className="h-4 w-4 rounded border-gray-300 text-gold focus:ring-gold"
                      />
                      <Label htmlFor="isDefault" className="text-sm font-normal">Set as default address</Label>
                    </div>
                    <div className="flex justify-end space-x-2 mt-4">
                      <Button 
                        variant="outline" 
                        onClick={() => {
                          setIsAddingAddress(false);
                          setEditingAddressId(null);
                          setAddressForm({
                            id: '',
                            name: '',
                            addressLine1: '',
                            addressLine2: '',
                            city: '',
                            state: '',
                            postalCode: '',
                            country: 'India',
                            phoneNumber: '',
                            landmark: '',
                            isDefault: false
                          });
                        }}
                      >
                        Cancel
                      </Button>
                      <Button 
                        className="bg-gold hover:bg-gold/90 text-black"
                        onClick={handleAddressSave}
                      >
                        {editingAddressId ? 'Update Address' : 'Save Address'}
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div>
                    {user.addresses && user.addresses.length > 0 ? (
                      <div className="space-y-4">
                        {user.addresses.map((address) => (
                          <div 
                            key={address.id} 
                            className={`border rounded-md p-4 relative ${
                              address.id === user.defaultAddressId ? 'border-gold bg-gold/5' : ''
                            }`}
                          >
                            {address.id === user.defaultAddressId && (
                              <div className="absolute top-2 right-2 bg-gold text-black text-xs px-2 py-1 rounded-full flex items-center">
                                <Check className="h-3 w-3 mr-1" />
                                Default
                              </div>
                            )}
                            <div className="flex justify-between items-start">
                              <div>
                                <h3 className="font-semibold text-lg flex items-center">
                                  <MapPin className="h-4 w-4 mr-2 text-gold" />
                                  {address.name}
                                </h3>
                                <p className="text-sm text-muted-foreground mt-1">{address.phoneNumber}</p>
                              </div>
                              <div className="flex space-x-2">
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  onClick={() => handleEditAddress(address)}
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                  className="text-red-500 hover:text-red-700 hover:bg-red-50"
                                  onClick={() => handleDeleteAddress(address.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                            <div className="mt-2">
                              <p className="text-sm">
                                {address.addressLine1}
                                {address.addressLine2 && `, ${address.addressLine2}`}
                              </p>
                              {address.landmark && (
                                <p className="text-sm text-muted-foreground">Landmark: {address.landmark}</p>
                              )}
                              <p className="text-sm">
                                {address.city}, {address.state}, {address.postalCode}
                              </p>
                              <p className="text-sm">{address.country}</p>
                            </div>
                            {address.id !== user.defaultAddressId && (
                              <Button 
                                variant="link" 
                                size="sm" 
                                className="mt-2 text-gold p-0 h-auto"
                                onClick={() => handleSetDefaultAddress(address.id)}
                              >
                                Set as default
                              </Button>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <MapPin className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                        <h3 className="text-lg font-medium mb-2">No addresses saved yet</h3>
                        <p className="text-muted-foreground mb-4">
                          Add your delivery addresses to make checkout faster
                        </p>
                        <Button 
                          onClick={() => setIsAddingAddress(true)}
                          className="bg-gold hover:bg-gold/90 text-black"
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Add New Address
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
