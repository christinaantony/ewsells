import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AlertTriangle, CheckCircle, XCircle, Loader2, Package } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { db } from '@/lib/firebase';
import { collection, query, where, getDocs, updateDoc, doc } from 'firebase/firestore';

interface CategoryRequest {
  id: string;
  name: string;
  description: string;
  requestedBy: string;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: Date;
  updatedAt?: Date;
}

export function CategoryRequestsPage() {
  const [activeTab, setActiveTab] = useState<'pending' | 'all'>('pending');
  const [requests, setRequests] = useState<CategoryRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const navigate = useNavigate();

  const fetchRequests = async () => {
    try {
      setLoading(true);
      const q = activeTab === 'pending'
        ? query(collection(db, 'category-requests'), where('status', '==', 'pending'))
        : collection(db, 'category-requests');
      
      const querySnapshot = await getDocs(q);
      const requestsData = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        createdAt: doc.data().createdAt?.toDate(),
        updatedAt: doc.data()?.updatedAt?.toDate()
      })) as CategoryRequest[];
      
      setRequests(requestsData);
    } catch (error) {
      console.error('Error fetching category requests:', error);
      toast({
        title: 'Error',
        description: 'Failed to load category requests',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, [activeTab]);

  const handleStatusUpdate = async (id: string, status: 'approved' | 'rejected') => {
    try {
      await updateDoc(doc(db, 'category-requests', id), {
        status,
        updatedAt: new Date()
      });
      
      setRequests(prev => prev.filter(req => req.id !== id));
      
      toast({
        title: `Category ${status}`,
        description: `The category request has been ${status}.`,
      });
    } catch (error) {
      console.error(`Error ${status} category request:`, error);
      toast({
        title: 'Error',
        description: `Failed to ${status} request`,
        variant: 'destructive',
      });
    }
  };

  const pendingCount = requests.filter(r => r.status === 'pending').length;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col space-y-6">
        <div className="flex flex-col space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">Category Requests</h1>
          <p className="text-muted-foreground">
            Review and manage category requests from sellers
          </p>
        </div>

        <div className="flex space-x-4 border-b">
          <button
            onClick={() => setActiveTab('pending')}
            className={`flex items-center py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'pending'
                ? 'border-amber-500 text-amber-600'
                : 'border-transparent text-muted-foreground hover:border-muted-foreground/30 hover:text-foreground'
            }`}
          >
            <AlertTriangle className="h-4 w-4 mr-2" />
            Pending
            {pendingCount > 0 && (
              <span className="ml-2 inline-flex items-center justify-center rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-800">
                {pendingCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('all')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'all'
                ? 'border-primary text-foreground'
                : 'border-transparent text-muted-foreground hover:border-muted-foreground/30 hover:text-foreground'
            }`}
          >
            All Requests
          </button>
        </div>

        <div className="mt-6">
          {loading ? (
            <div className="flex items-center justify-center h-40">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : requests.length === 0 ? (
            <div className="text-center py-12 border rounded-lg">
              <Package className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-2 text-sm font-medium">No {activeTab} requests</h3>
              <p className="text-sm text-muted-foreground mt-1">
                {activeTab === 'pending' 
                  ? 'New category requests will appear here.'
                  : 'No category requests found.'}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {requests.map((request) => (
                <Card key={request.id} className="overflow-hidden hover:shadow-md transition-shadow">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{request.name}</CardTitle>
                      {request.status === 'pending' && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                          Pending
                        </span>
                      )}
                      {request.status === 'approved' && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Approved
                        </span>
                      )}
                      {request.status === 'rejected' && (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                          Rejected
                        </span>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-4">{request.description}</p>
                    <div className="flex items-center justify-between text-sm text-muted-foreground">
                      <div>
                        <span className="font-medium">Requested by:</span> {request.requestedBy}
                      </div>
                      <div className="text-xs">
                        {request.createdAt.toLocaleDateString()}
                      </div>
                    </div>
                    {request.status === 'pending' && (
                      <div className="flex justify-end space-x-2 mt-4">
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-green-700 border-green-200 bg-green-50 hover:bg-green-100"
                          onClick={() => handleStatusUpdate(request.id, 'approved')}
                        >
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Approve
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-700 border-red-200 bg-red-50 hover:bg-red-100"
                          onClick={() => handleStatusUpdate(request.id, 'rejected')}
                        >
                          <XCircle className="h-4 w-4 mr-2" />
                          Reject
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
