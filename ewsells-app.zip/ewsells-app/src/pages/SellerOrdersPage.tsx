import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { db } from '@/lib/firebase';
import { collection, query, updateDoc, doc, Timestamp, onSnapshot, where } from 'firebase/firestore';
import type { QuerySnapshot, DocumentData } from 'firebase/firestore';
import { useStore } from '@/store/useStore';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/components/ui/toast-context';
import { ShippingOptions } from '@/components/ShippingOptions';

interface OrderDoc {
  id: string;
  amount: number;
  contact: {
    email: string;
    name: string;
    phone: string;
  };
  createdAt: Timestamp;
  items: Array<{
    id: string;
    productId: string;
    name: string;
    price: number;
    quantity: number;
    sellerId: string | null;
    imageUrl: string;
    category?: string;
  }>;
  paymentMethod: string;
  paymentStatus: string;
  sellerIds: string[];
  shippingAddress: {
    city: string;
    email: string;
    fullName: string;
    line1: string;
    phone: string;
    pincode: string;
    state: string;
  };
  shippingMethod?: string;
  status: string;
  updatedAt: Timestamp;
  userId: string;
}

interface OrderCardProps {
  order: OrderDoc;
  items: OrderDoc['items'];
  onUpdateStatus: (orderId: string, newStatus: string) => void;
  onUpdateShipping: (orderId: string, method: string) => void;
}

function OrderCard({ order, items, onUpdateStatus, onUpdateShipping }: OrderCardProps) {
  const [showShippingDialog, setShowShippingDialog] = useState(false);
  const [actionBusyId, setActionBusyId] = useState<string | null>(null);

  const handleSaveShipping = async (orderId: string, shippingDetails: any) => {
    try {
      setActionBusyId(orderId);
      await updateDoc(doc(db, 'orders', orderId), {
        shippingDetails,
        updatedAt: Timestamp.now()
      });
      setShowShippingDialog(false);
      // showToast({ message: 'Shipping details updated', type: 'success' });
    } catch (error) {
      console.error('Error updating shipping details:', error);
      // showToast({ message: 'Failed to update shipping', type: 'error' });
    } finally {
      setActionBusyId(null);
    }
  };

  return (
    <li key={order.id} className="border rounded p-4 bg-black/20">
      <div className="flex items-center justify-between gap-3">
        <div className="flex flex-col">
          <span className="text-sm text-muted-foreground">Order ID</span>
          <span className="font-mono text-sm break-all">{order.id}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs capitalize px-2 py-0.5 rounded bg-muted/40 border border-border/50">{String(order.status || 'unknown')}</span>
        </div>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
        <div>
          <div className="text-muted-foreground">Created</div>
          <div>{(() => {
            const v: any = (order as any)?.createdAt || (order as any)?.created || (order as any)?.orderedAt;
            try { return typeof v?.toDate === 'function' ? v.toDate() : (v instanceof Date ? v : (typeof v === 'number' ? new Date(v) : (v ? new Date(v) : null))); } catch { return null; }
          })()?.toLocaleString() || '—'}</div>
        </div>
        <div>
          <div className="text-muted-foreground">Payment</div>
          <div className="uppercase">{order.paymentMethod || '—'}</div>
        </div>
      </div>

      {Array.isArray(items) && items.length > 0 && (
        <div className="mt-4 space-y-2">
          {items.map((it, idx) => (
            <Card key={`${order.id}-${idx}`} className="overflow-hidden">
              <CardContent className="p-3">
                <div className="flex items-center gap-3">
                  <img src={it.imageUrl || '/images/placeholder-item.jpg'} alt={it.name || 'Item'} className="h-14 w-14 rounded object-cover border"/>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{it.name}</div>
                    <div className="text-sm text-muted-foreground">₹{Number(it.price || 0).toFixed(2)} × {it.quantity || 1}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="mt-3 flex items-center gap-2">
        <Button size="sm" variant="outline" onClick={() => onUpdateStatus(order.id, 'pending')}>Pending</Button>
        <Button size="sm" variant="outline" onClick={() => onUpdateStatus(order.id, 'processing')}>Processing</Button>
        <Button size="sm" variant="destructive" onClick={() => onUpdateStatus(order.id, 'cancelled')}>Cancel</Button>
      </div>

      <div className="mt-3">
        <Button 
          size="sm" 
          variant="ghost"
          onClick={() => setShowShippingDialog(true)}
          disabled={actionBusyId === order.id}
        >
          {order.shippingMethod ? 'Update Shipping' : 'Add Shipping'}
        </Button>
        {order.shippingMethod ? (
          <div className="mt-2 text-sm">
            <span className="text-muted-foreground">Shipping: </span>
            <span className="capitalize">{order.shippingMethod || 'Not specified'}</span>
          </div>
        ) : null}
      </div>

      {showShippingDialog && (
        <div className="mt-4 p-4 border rounded bg-card">
          <ShippingOptions 
            orderId={order.id}
            onSave={(details) => handleSaveShipping(order.id, details)}
            initialMethod={order.shippingMethod}
          />
          <Button 
            variant="ghost" 
            size="sm" 
            className="mt-2"
            onClick={() => setShowShippingDialog(false)}
          >
            Cancel
          </Button>
        </div>
      )}
    </li>
  );
}

export default function SellerOrdersPage() {
  const { user } = useStore();
  const [orders, setOrders] = useState<OrderDoc[]>([]);
  const [loading, setLoading] = useState(true);
  const { showToast } = useToast();

  const sellerId = user?.uid || user?.id;

  useEffect(() => {
    if (!sellerId) { 
      setOrders([]); 
      setLoading(false); 
      return; 
    }
    
    setLoading(true);
    console.log('Subscribing to orders for seller:', sellerId);
    
    const q = query(
      collection(db, 'orders'),
      where('sellerIds', 'array-contains', sellerId)
    );
    
    const unsub = onSnapshot(q, 
      (snap: QuerySnapshot<DocumentData>) => {
        const sellerOrders = snap.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as OrderDoc[];
        setOrders(sellerOrders);
        setLoading(false);
      }, 
      (err: Error) => {
        console.error('Error fetching orders:', err);
        showToast({ message: 'Failed to load orders', type: 'error' });
        setLoading(false);
      }
    );
    
    return () => unsub();
  }, [sellerId, showToast]);

  const sellerOrders = useMemo(() => {
    if (!sellerId) return [] as Array<{ order: OrderDoc; items: OrderDoc['items'] }>;
    
    console.log('Processing orders for seller:', sellerId);
    console.log('Total orders:', orders.length);
    
    return orders.map(order => {
      // Filter items for this seller
      const items = (order.items || []).filter(
        item => String((item as any)?.sellerId || '') === String(sellerId)
      );
      console.log(`Order ${order.id} has ${items.length} items from this seller`);
      return { order, items };
    });
  }, [orders, sellerId]);

  // Handle order status updates
  const handleUpdateStatus = async (orderId: string, newStatus: string) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), {
        status: newStatus,
        updatedAt: Timestamp.now()
      });
      showToast({ message: 'Order status updated', type: 'success' });
    } catch (error) {
      console.error('Error updating order status:', error);
      showToast({ message: 'Failed to update order status', type: 'error' });
    }
  };

  // Handle shipping method updates
  const handleUpdateShipping = async (orderId: string, method: string) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), {
        shippingMethod: method,
        updatedAt: Timestamp.now()
      });
      showToast({ message: 'Shipping method updated', type: 'success' });
    } catch (error) {
      console.error('Error updating shipping method:', error);
      showToast({ message: 'Failed to update shipping', type: 'error' });
    }
  };

  return (
    <motion.div className="min-h-screen" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-4">My Orders</h1>
        <p className="text-muted-foreground mb-6">Update your orders to Pending, Processing, or Cancel. Mark Delivered is not permitted here.</p>
        {loading ? (
          <div className="text-muted-foreground">Loading…</div>
        ) : sellerOrders.length === 0 ? (
          <div className="text-muted-foreground">No orders found for your products.</div>
        ) : (
          <ul className="space-y-3">
            {sellerOrders.map(({ order, items }) => (
              <OrderCard 
                key={order.id}
                order={order}
                items={items}
                onUpdateStatus={handleUpdateStatus}
                onUpdateShipping={handleUpdateShipping}
              />
            ))}
          </ul>
        )}
      </div>
    </motion.div>
  );
}
