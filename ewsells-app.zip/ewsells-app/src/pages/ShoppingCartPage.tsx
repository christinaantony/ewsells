import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight, CreditCard, Truck, MapPin, Bookmark } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { useNavigate } from 'react-router-dom';
import { useStore } from '@/store/useStore';
import { v4 as uuidv4 } from 'uuid';
import { toast } from '@/components/ui/use-toast';
import { Address } from '@/types';

// Payment method type
type PaymentMethod = 'card' | 'cod' | 'upi';

export default function ShoppingCartPage() {
  const { cartItems, removeFromCart, updateQuantity, cartTotal, isLoading, moveToSaved } = useCart();
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('card');
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedAddress, setSelectedAddress] = useState<Address | null>(null);
  const navigate = useNavigate();
  const { user } = useStore();
  
  // Load default address when user data is available
  useEffect(() => {
    if (user?.addresses?.length) {
      // Find default address or use the first one
      const defaultAddress = user.defaultAddressId
        ? user.addresses.find(addr => addr.id === user.defaultAddressId)
        : user.addresses[0];
      
      if (defaultAddress) {
        setSelectedAddress(defaultAddress);
      }
    }
  }, [user?.addresses, user?.defaultAddressId]);

  // Navigate to profile page to add/edit addresses
  const navigateToAddressPage = () => {
    navigate('/profile');
    toast({
      title: 'Add Delivery Address',
      description: 'Please add a delivery address in your profile',
    });
  };

  // Handle checkout process
  const handleCheckout = async () => {
    if (!user) {
      // Redirect to login if user is not authenticated
      navigate('/login?redirect=cart');
      return;
    }

    // Check if user has selected an address
    if (!selectedAddress) {
      toast({
        title: 'Address Required',
        description: 'Please select a delivery address before checkout',
        variant: 'destructive'
      });
      return;
    }

    setIsProcessing(true);
    
    try {
      // Generate a unique order ID
      const orderId = `ORDER-${uuidv4().substring(0, 8)}`;
      
      // Add selected address to URL params
      const addressParam = encodeURIComponent(selectedAddress.id);
      
      if (paymentMethod === 'upi') {
        navigate(`/checkout/details?orderId=${orderId}&amount=${cartTotal}&method=upi&addressId=${addressParam}`);
        return;
      } else if (paymentMethod === 'card') {
        navigate(`/checkout/details?orderId=${orderId}&amount=${cartTotal}&method=card&addressId=${addressParam}`);
        return;
      } else if (paymentMethod === 'cod') {
        navigate(`/checkout/details?orderId=${orderId}&amount=${cartTotal}&method=cod&addressId=${addressParam}`);
        return;
      }
    } catch (error) {
      console.error('Checkout error:', error);
      toast({
        title: 'Payment Error',
        description: error instanceof Error ? error.message : 'An error occurred during checkout',
        variant: 'destructive'
      });
    } finally {
      setIsProcessing(false);
    }
  };

  // Calculate shipping cost (free over ₹500)
  const shippingCost = cartTotal > 500 ? 0 : 50;
  
  // Calculate tax (5% GST)
  const taxAmount = cartTotal * 0.05;
  
  // Calculate order total
  const orderTotal = cartTotal + shippingCost + taxAmount;

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="container mx-auto px-4">
        <motion.div
          className="text-center mb-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Shopping <span className="text-gold">Cart</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Review your items and proceed to checkout
          </p>
          <div className="mt-3">
            <Button variant="outline" onClick={() => navigate('/saved')}>
              View Save For Later
            </Button>
          </div>
          {/* View Saved for Later link removed as requested */}
        </motion.div>

        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gold"></div>
          </div>
        ) : cartItems.length === 0 ? (
          <motion.div
            className="text-center py-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="flex justify-center mb-4">
              <ShoppingBag className="h-16 w-16 text-muted-foreground" />
            </div>
            <h2 className="text-2xl font-semibold mb-2">Your cart is empty</h2>
            <p className="text-muted-foreground mb-6">
              Looks like you haven't added any products to your cart yet.
            </p>
            <Button onClick={() => navigate('/products')} className="bg-gold hover:bg-gold/90 text-black">
              Continue Shopping
            </Button>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <motion.div
              className="lg:col-span-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-2xl font-semibold mb-4">Cart Items ({cartItems.length})</h2>
              <div className="space-y-4">
                {cartItems.map((item) => (
                  <Card key={item.id} className="overflow-hidden">
                    <CardContent className="p-0">
                      <div className="flex flex-col sm:flex-row">
                        <div className="relative sm:w-32 h-32">
                          {item.imageUrl ? (
                            <img
                              src={item.imageUrl}
                              alt={item.name}
                              className="h-full w-full object-cover"
                            />
                          ) : (
                            <div className="h-full w-full bg-gray-200 flex items-center justify-center">
                              <ShoppingBag className="h-8 w-8 text-gray-400" />
                            </div>
                          )}
                        </div>

                        <div className="flex flex-col flex-grow p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-semibold text-lg">{item.name}</h3>
                              {item.category && (
                                <p className="text-sm text-muted-foreground">{item.category}</p>
                              )}
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-red-500 hover:text-red-700 hover:bg-red-50"
                              onClick={() => removeFromCart(item.productId)}
                            >
                              <Trash2 className="h-4 w-4" />
                              <span className="sr-only">Remove item</span>
                            </Button>
                          </div>

                          <div className="flex justify-between items-center mt-4">
                            <p className="font-medium text-lg">₹{item.price.toFixed(2)}</p>
                            <div className="flex items-center space-x-2">
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => updateQuantity(item.productId, item.quantity - 1)}
                                disabled={item.quantity <= 1}
                              >
                                <Minus className="h-3 w-3" />
                                <span className="sr-only">Decrease quantity</span>
                              </Button>
                              <span className="w-8 text-center">{item.quantity}</span>
                              <Button
                                variant="outline"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => updateQuantity(item.productId, item.quantity + 1)}
                              >
                                <Plus className="h-3 w-3" />
                                <span className="sr-only">Increase quantity</span>
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="ml-2"
                                onClick={() => {
                                  // Navigate first to avoid being blocked by async state updates/unmount
                                  navigate('/saved');
                                  // Perform move in the background
                                  Promise.resolve().then(() => moveToSaved(item.productId));
                                }}
                              >
                                <Bookmark className="h-4 w-4 mr-2" /> Save for Later
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </motion.div>

            {/* Order Summary */}
            <motion.div
              className="lg:col-span-1"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Card className="sticky top-24">
                <CardContent className="p-6">
                  <h2 className="text-2xl font-semibold mb-4">Order Summary</h2>
                  
                  <div className="space-y-3 mb-6">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Subtotal</span>
                      <span>₹{cartTotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Shipping</span>
                      <span>{shippingCost === 0 ? 'Free' : `₹${shippingCost.toFixed(2)}`}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Tax (5% GST)</span>
                      <span>₹{taxAmount.toFixed(2)}</span>
                    </div>
                    <div className="border-t pt-3 mt-3">
                      <div className="flex justify-between font-semibold">
                        <span>Total</span>
                        <span>₹{orderTotal.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="mb-6">
                    <h3 className="font-medium mb-3">Delivery Address</h3>
                    {!user ? (
                      <div className="text-center p-4 bg-black/20 rounded-md mb-4">
                        <p className="text-sm text-muted-foreground mb-2">Please sign in to select a delivery address</p>
                        <Button 
                          onClick={() => navigate('/login?redirect=cart')} 
                          className="bg-gold hover:bg-gold/90 text-black"
                        >
                          Sign In
                        </Button>
                      </div>
                    ) : !user.addresses || user.addresses.length === 0 ? (
                      <div className="text-center p-4 bg-black/20 rounded-md mb-4">
                        <p className="text-sm text-muted-foreground mb-2">You don't have any saved addresses</p>
                        <Button 
                          onClick={navigateToAddressPage} 
                          className="bg-gold hover:bg-gold/90 text-black"
                        >
                          <MapPin className="h-4 w-4 mr-2" />
                          Add Address
                        </Button>
                      </div>
                    ) : (
                      <div className="mb-4">
                        {selectedAddress ? (
                          <div className="p-3 border border-white/10 rounded-md mb-3">
                            <div className="flex justify-between items-start mb-2">
                              <div className="font-medium">{selectedAddress.name}</div>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => setSelectedAddress(null)}
                                className="h-6 px-2"
                              >
                                Change
                              </Button>
                            </div>
                            <div className="text-sm text-muted-foreground">
                              <p>{selectedAddress.addressLine1}</p>
                              {selectedAddress.addressLine2 && <p>{selectedAddress.addressLine2}</p>}
                              <p>{selectedAddress.city}, {selectedAddress.state} {selectedAddress.postalCode}</p>
                              <p>Phone: {selectedAddress.phoneNumber}</p>
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <p className="text-sm mb-2">Select a delivery address:</p>
                            {user.addresses.map(address => (
                              <div 
                                key={address.id} 
                                className="p-3 border border-white/10 rounded-md cursor-pointer hover:bg-black/20"
                                onClick={() => setSelectedAddress(address)}
                              >
                                <div className="flex justify-between">
                                  <div className="font-medium">{address.name}</div>
                                  {address.isDefault && (
                                    <span className="text-xs bg-gold/20 text-gold px-2 py-0.5 rounded">Default</span>
                                  )}
                                </div>
                                <div className="text-sm text-muted-foreground">
                                  <p>{address.addressLine1}</p>
                                  {address.addressLine2 && <p>{address.addressLine2}</p>}
                                  <p>{address.city}, {address.state} {address.postalCode}</p>
                                </div>
                              </div>
                            ))}
                            <Button 
                              onClick={navigateToAddressPage} 
                              variant="outline" 
                              className="w-full mt-2"
                            >
                              <MapPin className="h-4 w-4 mr-2" />
                              Add New Address
                            </Button>
                          </div>
                        )}
                      </div>
                    )}
                    
                    <h3 className="font-medium mb-3">Payment Method</h3>
                    <div className="grid grid-cols-3 gap-2">
                      <Button
                        variant={paymentMethod === 'card' ? 'default' : 'outline'}
                        className={paymentMethod === 'card' ? 'bg-gold hover:bg-gold/90 text-black' : ''}
                        onClick={() => setPaymentMethod('card')}
                      >
                        <CreditCard className="h-4 w-4 mr-2" />
                        Card
                      </Button>
                      <Button
                        variant={paymentMethod === 'upi' ? 'default' : 'outline'}
                        className={paymentMethod === 'upi' ? 'bg-gold hover:bg-gold/90 text-black' : ''}
                        onClick={() => setPaymentMethod('upi')}
                      >
                        <svg className="h-4 w-4 mr-2" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M6 12L18 4L14 12L18 20L6 12Z" fill="currentColor" />
                        </svg>
                        UPI
                      </Button>
                      <Button
                        variant={paymentMethod === 'cod' ? 'default' : 'outline'}
                        className={paymentMethod === 'cod' ? 'bg-gold hover:bg-gold/90 text-black' : ''}
                        onClick={() => setPaymentMethod('cod')}
                      >
                        <Truck className="h-4 w-4 mr-2" />
                        COD
                      </Button>
                    </div>
                  </div>

                  <Button
                    className="w-full bg-gold hover:bg-gold/90 text-black"
                    size="lg"
                    onClick={handleCheckout}
                    disabled={isProcessing}
                  >
                    {isProcessing ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-black mr-2"></div>
                        Processing...
                      </>
                    ) : (
                      <>
                        Checkout <ArrowRight className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>

                  <p className="text-xs text-muted-foreground text-center mt-4">
                    By proceeding to checkout, you agree to our terms and conditions.
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
}
