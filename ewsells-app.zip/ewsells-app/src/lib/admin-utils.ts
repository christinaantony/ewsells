import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { auth, db } from './firebase';

/**
 * Creates an admin account with the specified email and password
 * This should only be used in a secure environment by authorized personnel
 * 
 * @param email - Admin email address
 * @param password - Admin password (must meet Firebase requirements)
 * @param displayName - Admin display name
 * @returns Promise resolving to the created admin user ID
 */
export async function createAdminAccount(
  email: string, 
  password: string, 
  displayName: string = 'System Administrator'
): Promise<string> {
  try {
    // Create the user account in Firebase Authentication
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    
    // Create the admin user document in Firestore
    await setDoc(doc(db, 'users', user.uid), {
      email,
      displayName,
      role: 'admin',
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString()
    });
    
    console.log(`Admin account created successfully: ${user.uid}`);
    return user.uid;
  } catch (error: any) {
    console.error('Error creating admin account:', error);
    throw new Error(`Failed to create admin account: ${error.message}`);
  }
}

/**
 * Instructions for creating an admin account:
 * 
 * 1. This function should only be used in a secure environment
 * 2. Ideally, run this once from a secure terminal or admin panel
 * 3. Example usage:
 *    ```
 *    import { createAdminAccount } from '@/lib/admin-utils';
 *    
 *    // Run this in a secure environment
 *    createAdminAccount('admin@example.com', 'securePassword123', 'System Admin')
 *      .then(adminId => console.log('Admin created with ID:', adminId))
 *      .catch(error => console.error('Failed to create admin:', error));
 *    ```
 * 4. After creating the admin account, securely store the credentials
 * 5. Use the admin-login route to access the admin dashboard
 */
