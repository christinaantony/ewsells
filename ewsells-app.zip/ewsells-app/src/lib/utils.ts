import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { runTransaction, doc, collection, query, where, getDocs, limit, orderBy, getDoc } from 'firebase/firestore';

import { db } from './firebase';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
  }).format(amount);
}

export function formatNumber(num: number): string {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  }
  return num.toString();
}

export function calculateUplift(basePrice: number, upliftPercent: number) {
  const uplift = basePrice * (upliftPercent / 100);
  const totalPrice = basePrice + uplift;
  const charityAmount = uplift * 0.8;
  const opsAmount = uplift * 0.2;
  
  return {
    basePrice,
    uplift,
    totalPrice,
    charityAmount,
    opsAmount,
  };
}

export function debounce<T extends (this: any, ...args: any[]) => any>(
  func: T,
  wait: number
): (this: ThisParameterType<T>, ...args: Parameters<T>) => void {
  let timeout: ReturnType<typeof setTimeout>;
  return function (this: ThisParameterType<T>, ...args: Parameters<T>) {
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(this, args), wait);
  };
}

export function throttle<T extends (this: any, ...args: any[]) => any>(
  func: T,
  limit: number
): (this: ThisParameterType<T>, ...args: Parameters<T>) => void {
  let inThrottle = false;
  return function (this: ThisParameterType<T>, ...args: Parameters<T>) {
    if (!inThrottle) {
      func.apply(this, args);
      inThrottle = true;
      setTimeout(() => {
        inThrottle = false;
      }, limit);
    }
  };
}

export function getImagePlaceholder(width: number, height: number): string {
  return `https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=${width}&h=${height}`;
}

export function shareContent(title: string, text: string, url: string) {
  if (navigator.share) {
    return navigator.share({
      title,
      text,
      url,
    });
  } else {
    // Fallback for browsers that don't support Web Share API
    if (navigator.clipboard) {
      return navigator.clipboard.writeText(url);
    }
    return Promise.reject(new Error('Sharing not supported'));
  }
}

/**
 * Generates a product code with the pattern PREFIX + sequential number.
 * Preferred PREFIX is derived from sellerCode: first 5 chars (e.g., sellerCode EWSAATVC -> prefix EWSAA).
 * If sellerCode is not available, falls back to 'EWS' + first two letters of seller name.
 * Ensures uniqueness per seller by using a per-seller counter and verifying no duplicates.
 *
 * @param sellerName - The name of the seller (used only as a fallback if sellerCode not found)
 * @param sellerId - The seller's UID, used for counter and to look up sellerCode
 */
export async function generateProductCode(sellerName: string, sellerId: string): Promise<string> {
  // Try to derive prefix from sellerCode in seller-profiles (preferred) or seller-registrations
  let prefix = '';
  try {
    const profileRef = doc(db, 'seller-profiles', sellerId);
    const profileSnap = await getDoc(profileRef);
    const sellerCodeFromProfile: string | undefined = profileSnap.exists() ? (profileSnap.data() as any)?.sellerCode : undefined;

    let sellerCode = sellerCodeFromProfile;
    if (!sellerCode) {
      const regRef = doc(db, 'seller-registrations', sellerId);
      const regSnap = await getDoc(regRef);
      sellerCode = regSnap.exists() ? (regSnap.data() as any)?.sellerCode : undefined;
    }

    if (sellerCode && typeof sellerCode === 'string' && sellerCode.length >= 5) {
      prefix = sellerCode.substring(0, 5).toUpperCase();
    }
  } catch (e) {
    // Non-fatal; will fallback to name-based prefix
    console.warn('Could not fetch sellerCode, falling back to name-based prefix:', e);
  }

  if (!prefix) {
    // Fallback: Extract first two letters of seller name (uppercase) and prefix with EWS
    const sellerPrefix = (sellerName || 'UN')
      .replace(/\s+/g, '')
      .substring(0, 2)
      .toUpperCase();
    prefix = 'EWS' + sellerPrefix; // Length 5
  }

  // Use a per-seller counter document to ensure sequential unique numbers across all categories
  const counterRef = doc(db, 'product_counters', sellerId);

  try {
    // If there are no existing products globally for this prefix, force-start at 001.
    // This handles cases where the counter doc drifted (e.g., prior failed attempts) but no products exist yet.
    try {
      const productsRef = collection(db, 'products');
      const existsQ = query(
        productsRef,
        where('productCode', '>=', `${prefix}001`),
        where('productCode', '<', `${prefix}999`),
        limit(1)
      );
      const existsSnap = await getDocs(existsQ);
      if (existsSnap.empty) {
        // Atomically bump counter to at least 2 and return 001
        await runTransaction(db, async (tx) => {
          const snap = await tx.get(counterRef);
          const currentNext = snap.exists() ? Number((snap.data() as any)?.nextNumber || 1) : 1;
          const desiredNext = Math.max(2, currentNext);
          if (snap.exists()) {
            tx.update(counterRef, { nextNumber: desiredNext, updatedAt: new Date().toISOString() });
          } else {
            tx.set(counterRef, { nextNumber: desiredNext, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
          }
        });
        return `${prefix}001`;
      }
    } catch (prefCheckErr) {
      // Non-fatal; continue with normal counter flow
      console.warn('Prefix existence check failed, continuing:', prefCheckErr);
    }

    // Try a few times to avoid rare collisions (e.g., concurrent writes or legacy duplicates)
    for (let attempt = 0; attempt < 5; attempt++) {
      const nextNumber = await runTransaction(db, async (tx) => {
        const snap = await tx.get(counterRef);
        const current = snap.exists() ? Number((snap.data() as any)?.nextNumber || 1) : 1;
        const toStore = current + 1;
        if (snap.exists()) {
          tx.update(counterRef, { nextNumber: toStore, updatedAt: new Date().toISOString() });
        } else {
          tx.set(counterRef, { nextNumber: toStore, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
        }
        return current;
      });

      const code = `${prefix}${String(nextNumber).padStart(3, '0')}`;

      // Check for existing product with the same code globally
      const productsRef = collection(db, 'products');
      const q = query(
        productsRef,
        where('productCode', '==', code),
        limit(1)
      );
      const snap = await getDocs(q);
      if (snap.empty) {
        return code;
      }
      // Else, loop and try to get the next number
    }
    // If all attempts failed, derive next code by scanning existing products globally for this prefix
    try {
      const productsRef = collection(db, 'products');
      const q = query(
        productsRef,
        where('productCode', '>=', `${prefix}001`),
        where('productCode', '<', `${prefix}999`),
        orderBy('productCode', 'desc'),
        limit(1)
      );
      const snap = await getDocs(q);
      if (snap.empty) {
        return `${prefix}001`;
      }
      const highest = (snap.docs[0].data() as any)?.productCode as string;
      const numeric = Number(highest.substring(5)) || 0;
      const next = numeric + 1;
      return `${prefix}${String(next).padStart(3, '0')}`;
    } catch (fallbackErr) {
      console.error('Fallback query failed, using time suffix:', fallbackErr);
      return `${prefix}${String(Date.now() % 1000).padStart(3, '0')}`;
    }
  } catch (error) {
    console.error('Error generating product code (counter):', error);
    // Fallback: derive next code by scanning existing products globally for this prefix
    try {
      const productsRef = collection(db, 'products');
      const q = query(
        productsRef,
        where('productCode', '>=', `${prefix}001`),
        where('productCode', '<', `${prefix}999`),
        orderBy('productCode', 'desc'),
        limit(1)
      );
      const snap = await getDocs(q);
      if (snap.empty) {
        return `${prefix}001`;
      }
      const highest = (snap.docs[0].data() as any)?.productCode as string;
      const numeric = Number(highest.substring(5)) || 0;
      const next = numeric + 1;
      return `${prefix}${String(next).padStart(3, '0')}`;
    } catch (fallbackErr) {
      console.error('Fallback query failed, using time suffix:', fallbackErr);
      return `${prefix}${String(Date.now() % 1000).padStart(3, '0')}`;
    }
  }
}