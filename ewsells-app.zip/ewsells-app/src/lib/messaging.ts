import { isSupported, getToken, onMessage } from 'firebase/messaging';
import { messaging } from '@/lib/firebase';

// Initialize Firebase Cloud Messaging in the browser
// - Registers the service worker at /firebase-messaging-sw.js
// - Requests notification permission
// - Retrieves the FCM token using the VAPID key
// - Subscribes to foreground messages and shows a Notification
export async function initMessaging(): Promise<string | null> {
  try {
    const supported = await isSupported();
    if (!supported) return null;
    if (!('serviceWorker' in navigator)) return null;
    if (!messaging) return null;

    // Ensure service worker is registered
    // On localhost, Firebase Hosting helper scripts (__/firebase/*) are unavailable,
    // so the production SW would fail to evaluate. Use a lightweight dev SW locally.
    const swPath = location.hostname === 'localhost'
      ? '/dev-firebase-messaging-sw.js'
      : '/firebase-messaging-sw.js';
    const swReg = await navigator.serviceWorker.register(swPath);

    // Ask for permission
    let permission = Notification.permission;
    if (permission === 'default') {
      permission = await Notification.requestPermission();
    }
    if (permission !== 'granted') return null;

    const vapidKey = import.meta.env.VITE_FIREBASE_VAPID_KEY as string | undefined;

    const token = await getToken(messaging, {
      vapidKey,
      serviceWorkerRegistration: swReg,
    });

    // Foreground messages
    onMessage(messaging, (payload) => {
      // Try to show a notification using the SW registration
      const title = payload.notification?.title || 'New message';
      const body = payload.notification?.body || 'You have a new chat message';
      const icon = payload.notification?.icon || '/favicon.png';
      // Only show if permission granted
      if (Notification.permission === 'granted') {
        swReg.showNotification(title, { body, icon });
      }
    });

    return token || null;
  } catch (e) {
    console.error('initMessaging failed', e);
    return null;
  }
}
