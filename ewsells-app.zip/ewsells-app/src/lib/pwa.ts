// Service Worker Registration
// TypeScript doesn't include Background Sync in DOM typings by default.
// Add a minimal type augmentation so `registration.sync` is recognized.
declare global {
  interface SyncManager {
    register(tag: string): Promise<void>;
    getTags(): Promise<string[]>;
  }
  interface ServiceWorkerRegistration {
    sync?: SyncManager;
  }
}

export async function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js');
      console.log('SW registered: ', registration);
      return registration;
    } catch (error) {
      console.log('SW registration failed: ', error);
    }
  }
}

// Install Prompt
let deferredPrompt: any = null;

export function setupInstallPrompt() {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    // Show install button
    const installButton = document.getElementById('install-button');
    if (installButton) {
      installButton.style.display = 'block';
    }
  });

  window.addEventListener('appinstalled', () => {
    deferredPrompt = null;
    const installButton = document.getElementById('install-button');
    if (installButton) {
      installButton.style.display = 'none';
    }
  });
}

export async function showInstallPrompt() {
  if (!deferredPrompt) return false;

  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  
  if (outcome === 'accepted') {
    deferredPrompt = null;
    return true;
  }
  
  return false;
}

// Push Notifications
export async function requestNotificationPermission() {
  if (!('Notification' in window)) {
    return false;
  }

  if (Notification.permission === 'granted') {
    return true;
  }

  const permission = await Notification.requestPermission();
  return permission === 'granted';
}

// Background Sync
export function registerBackgroundSync(tag: string, data: any) {
  if ('serviceWorker' in navigator && 'sync' in window.ServiceWorkerRegistration.prototype) {
    navigator.serviceWorker.ready.then((registration) => {
      // Store data in IndexedDB for the service worker to use
      const request = indexedDB.open('ew-sells-sync', 1);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('sync-data')) {
          db.createObjectStore('sync-data');
        }
      };
      request.onsuccess = () => {
        const db = request.result;
        const tx = db.transaction('sync-data', 'readwrite');
        tx.objectStore('sync-data').put(data, tag);
        tx.oncomplete = () => {
          // Optional chaining keeps this safe if Background Sync isn't supported
          registration.sync?.register(tag);
        };
      };
    });
  }
}