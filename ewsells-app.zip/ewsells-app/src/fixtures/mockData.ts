import type { Product, Project, Seller, Order } from '@/types';

// Mock Products
export const mockProducts: Product[] = [
  {
    id: '1',
    title: 'Handwoven Organic Cotton Scarf',
    description: 'Beautiful handwoven scarf made from 100% organic cotton by local artisans.',
    images: [
      'https://images.pexels.com/photos/7679720/pexels-photo-7679720.jpeg?auto=compress&cs=tinysrgb&w=600',
      'https://images.pexels.com/photos/5709661/pexels-photo-5709661.jpeg?auto=compress&cs=tinysrgb&w=600'
    ],
    category: 'Charity Craft',
    tags: ['handmade', 'organic', 'sustainable', 'fashion'],
    sellerId: '1',
    basePriceSeller: 45,
    upliftPercent: 20,
    projectAllocations: [{ projectId: '1', percent: 100 }],
    location: {
      address: '123 Craft Street',
      city: 'Portland',
      state: 'OR',
      country: 'USA',
      lat: 45.5152,
      lng: -122.6784
    },
    badges: ['eco-friendly', 'handmade'],
    isRental: false,
    status: 'active',
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-01-15')
  },
  {
    id: '2',
    title: 'Artisan Sourdough Bread',
    description: 'Fresh baked sourdough bread made with traditional techniques and organic flour.',
    images: [
      'https://images.pexels.com/photos/1586947/pexels-photo-1586947.jpeg?auto=compress&cs=tinysrgb&w=600',
      'https://images.pexels.com/photos/4686818/pexels-photo-4686818.jpeg?auto=compress&cs=tinysrgb&w=600'
    ],
    category: 'Charity Bakes',
    tags: ['fresh', 'organic', 'artisan', 'sourdough'],
    sellerId: '2',
    basePriceSeller: 12,
    upliftPercent: 25,
    projectAllocations: [{ projectId: '2', percent: 100 }],
    location: {
      address: '456 Bakery Lane',
      city: 'Seattle',
      state: 'WA',
      country: 'USA',
      lat: 47.6062,
      lng: -122.3321
    },
    badges: ['fresh-daily', 'organic'],
    isRental: false,
    status: 'active',
    createdAt: new Date('2024-01-16'),
    updatedAt: new Date('2024-01-16')
  },
  {
    id: '3',
    title: 'Upcycled Wooden Bookshelf',
    description: 'Beautifully crafted bookshelf made from reclaimed wood, perfect for any home.',
    images: [
      'https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=600',
      'https://images.pexels.com/photos/2343468/pexels-photo-2343468.jpeg?auto=compress&cs=tinysrgb&w=600'
    ],
    category: 'Scrap Store',
    tags: ['upcycled', 'furniture', 'sustainable', 'handmade'],
    sellerId: '3',
    basePriceSeller: 85,
    upliftPercent: 15,
    projectAllocations: [{ projectId: '3', percent: 100 }],
    location: {
      address: '789 Recycle Road',
      city: 'Austin',
      state: 'TX',
      country: 'USA',
      lat: 30.2672,
      lng: -97.7431
    },
    badges: ['upcycled', 'sustainable'],
    isRental: true,
    rentalTerms: {
      monthlyFee: 25,
      deposit: 50,
      duration: '1-12 months',
      terms: ['Return in good condition', 'No modifications allowed', 'Monthly inspection']
    },
    status: 'active',
    createdAt: new Date('2024-01-17'),
    updatedAt: new Date('2024-01-17')
  },
  {
    id: '4',
    title: 'Organic Tomato Sauce',
    description: 'Homemade tomato sauce from organic tomatoes, perfect for pasta and pizza.',
    images: [
      'https://images.pexels.com/photos/4518843/pexels-photo-4518843.jpeg?auto=compress&cs=tinysrgb&w=600',
      'https://images.pexels.com/photos/6544394/pexels-photo-6544394.jpeg?auto=compress&cs=tinysrgb&w=600'
    ],
    category: 'Organic Store',
    tags: ['organic', 'homemade', 'healthy', 'preservative-free'],
    sellerId: '4',
    basePriceSeller: 8,
    upliftPercent: 30,
    projectAllocations: [{ projectId: '1', percent: 60 }, { projectId: '4', percent: 40 }],
    location: {
      address: '321 Farm Road',
      city: 'Denver',
      state: 'CO',
      country: 'USA',
      lat: 39.7392,
      lng: -104.9903
    },
    badges: ['organic', 'local'],
    isRental: false,
    status: 'active',
    createdAt: new Date('2024-01-18'),
    updatedAt: new Date('2024-01-18')
  },
  {
    id: '5',
    title: 'Handknitted Baby Blanket',
    description: 'Soft and warm baby blanket handknitted by loving mothers in our community.',
    images: [
      'https://images.pexels.com/photos/6849159/pexels-photo-6849159.jpeg?auto=compress&cs=tinysrgb&w=600',
      'https://images.pexels.com/photos/7155957/pexels-photo-7155957.jpeg?auto=compress&cs=tinysrgb&w=600'
    ],
    category: 'Moms Made United',
    tags: ['handknitted', 'baby', 'soft', 'caring'],
    sellerId: '5',
    basePriceSeller: 35,
    upliftPercent: 22,
    projectAllocations: [{ projectId: '5', percent: 100 }],
    location: {
      address: '654 Mother Street',
      city: 'Nashville',
      state: 'TN',
      country: 'USA',
      lat: 36.1627,
      lng: -86.7816
    },
    badges: ['handmade', 'with-love'],
    isRental: false,
    status: 'active',
    createdAt: new Date('2024-01-19'),
    updatedAt: new Date('2024-01-19')
  },
  {
    id: '6',
    title: 'Organic Whole Wheat Pasta',
    description: 'Nutritious whole wheat pasta made from organically grown grains.',
    images: [
      'https://images.pexels.com/photos/1437267/pexels-photo-1437267.jpeg?auto=compress&cs=tinysrgb&w=600',
      'https://images.pexels.com/photos/6287521/pexels-photo-6287521.jpeg?auto=compress&cs=tinysrgb&w=600'
    ],
    category: 'Organic Store',
    tags: ['organic', 'whole-wheat', 'pasta', 'healthy'],
    sellerId: '4',
    basePriceSeller: 6,
    upliftPercent: 30,
    projectAllocations: [{ projectId: '1', percent: 100 }],
    location: {
      address: '321 Farm Road',
      city: 'Denver',
      state: 'CO',
      country: 'USA',
      lat: 39.7392,
      lng: -104.9903
    },
    badges: ['organic'],
    isRental: false,
    status: 'active',
    createdAt: new Date('2024-01-20'),
    updatedAt: new Date('2024-01-20')
  },
  {
    id: '7',
    title: 'Raw Organic Honey',
    description: 'Unfiltered, raw organic honey harvested from local apiaries.',
    images: [
      'https://images.pexels.com/photos/678414/pexels-photo-678414.jpeg?auto=compress&cs=tinysrgb&w=600',
      'https://images.pexels.com/photos/1111315/pexels-photo-1111315.jpeg?auto=compress&cs=tinysrgb&w=600'
    ],
    category: 'Organic Store',
    tags: ['organic', 'honey', 'natural', 'local'],
    sellerId: '4',
    basePriceSeller: 10,
    upliftPercent: 28,
    projectAllocations: [{ projectId: '4', percent: 100 }],
    location: {
      address: '321 Farm Road',
      city: 'Denver',
      state: 'CO',
      country: 'USA',
      lat: 39.7392,
      lng: -104.9903
    },
    badges: ['organic', 'local'],
    isRental: false,
    status: 'active',
    createdAt: new Date('2024-01-20'),
    updatedAt: new Date('2024-01-20')
  },
  {
    id: '8',
    title: 'Cold-Pressed Organic Olive Oil',
    description: 'Premium extra virgin olive oil, cold-pressed from organic olives.',
    images: [
      'https://images.pexels.com/photos/1453734/pexels-photo-1453734.jpeg?auto=compress&cs=tinysrgb&w=600',
      'https://images.pexels.com/photos/2664116/pexels-photo-2664116.jpeg?auto=compress&cs=tinysrgb&w=600'
    ],
    category: 'Organic Store',
    tags: ['organic', 'olive-oil', 'cold-pressed', 'kitchen'],
    sellerId: '4',
    basePriceSeller: 15,
    upliftPercent: 30,
    projectAllocations: [{ projectId: '1', percent: 50 }, { projectId: '4', percent: 50 }],
    location: {
      address: '321 Farm Road',
      city: 'Denver',
      state: 'CO',
      country: 'USA',
      lat: 39.7392,
      lng: -104.9903
    },
    badges: ['organic', 'premium'],
    isRental: false,
    status: 'active',
    createdAt: new Date('2024-01-20'),
    updatedAt: new Date('2024-01-20')
  }
];

// Mock Projects
export const mockProjects: Project[] = [
  {
    id: '1',
    name: 'Clean Water Initiative',
    description: 'Building wells and water purification systems in rural communities.',
    goalAmount: 50000,
    currentRaised: 32500,
    coverImage: 'https://images.pexels.com/photos/618612/pexels-photo-618612.jpeg?auto=compress&cs=tinysrgb&w=600',
    region: 'Global',
    status: 'active',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-20')
  },
  {
    id: '2',
    name: 'Education for All',
    description: 'Providing educational resources and scholarships to underprivileged children.',
    goalAmount: 75000,
    currentRaised: 45300,
    coverImage: 'https://images.pexels.com/photos/1181534/pexels-photo-1181534.jpeg?auto=compress&cs=tinysrgb&w=600',
    region: 'Asia-Pacific',
    status: 'active',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-20')
  },
  {
    id: '3',
    name: 'Sustainable Farming',
    description: 'Supporting local farmers with sustainable farming practices and tools.',
    goalAmount: 40000,
    currentRaised: 28700,
    coverImage: 'https://images.pexels.com/photos/974314/pexels-photo-974314.jpeg?auto=compress&cs=tinysrgb&w=600',
    region: 'Americas',
    status: 'active',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-20')
  },
  {
    id: '4',
    name: 'Medical Aid Program',
    description: 'Providing essential medical supplies and healthcare services.',
    goalAmount: 100000,
    currentRaised: 67800,
    coverImage: 'https://images.pexels.com/photos/5452293/pexels-photo-5452293.jpeg?auto=compress&cs=tinysrgb&w=600',
    region: 'Africa',
    status: 'active',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-20')
  },
  {
    id: '5',
    name: 'Community Gardens',
    description: 'Creating community gardens to promote healthy eating and community bonding.',
    goalAmount: 25000,
    currentRaised: 18900,
    coverImage: 'https://images.pexels.com/photos/4503821/pexels-photo-4503821.jpeg?auto=compress&cs=tinysrgb&w=600',
    region: 'Local',
    status: 'active',
    createdAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-20')
  }
];

// Mock Sellers
export const mockSellers: Seller[] = [
  {
    id: '1',
    name: 'Sarah\'s Crafts',
    avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=150',
    region: 'Pacific Northwest',
    categories: ['Charity Craft', 'Handmade'],
    rating: 4.8,
    leadTime: '3-5 days',
    deliveryRadiusKm: 50,
    createdAt: new Date('2023-12-01'),
    updatedAt: new Date('2024-01-15')
  },
  {
    id: '2',
    name: 'Tom\'s Bakery',
    avatar: 'https://images.pexels.com/photos/1484794/pexels-photo-1484794.jpeg?auto=compress&cs=tinysrgb&w=150',
    region: 'Washington State',
    categories: ['Charity Bakes', 'Fresh Food'],
    rating: 4.9,
    leadTime: '1-2 days',
    deliveryRadiusKm: 25,
    createdAt: new Date('2023-12-01'),
    updatedAt: new Date('2024-01-16')
  },
  {
    id: '3',
    name: 'Green Furniture Co.',
    avatar: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=150',
    region: 'Texas',
    categories: ['Scrap Store', 'Furniture'],
    rating: 4.7,
    leadTime: '1-2 weeks',
    deliveryRadiusKm: 100,
    createdAt: new Date('2023-12-01'),
    updatedAt: new Date('2024-01-17')
  },
  {
    id: '4',
    name: 'Organic Harvest',
    avatar: 'https://images.pexels.com/photos/1674752/pexels-photo-1674752.jpeg?auto=compress&cs=tinysrgb&w=150',
    region: 'Colorado',
    categories: ['Organic Store', 'Fresh Produce'],
    rating: 4.6,
    leadTime: '2-3 days',
    deliveryRadiusKm: 75,
    createdAt: new Date('2023-12-01'),
    updatedAt: new Date('2024-01-18')
  },
  {
    id: '5',
    name: 'Mothers United',
    avatar: 'https://images.pexels.com/photos/1181605/pexels-photo-1181605.jpeg?auto=compress&cs=tinysrgb&w=150',
    region: 'Tennessee',
    categories: ['Moms Made United', 'Baby Items'],
    rating: 5.0,
    leadTime: '1-3 weeks',
    deliveryRadiusKm: 60,
    createdAt: new Date('2023-12-01'),
    updatedAt: new Date('2024-01-19')
  }
];

// Mock Orders
export const mockOrders: Order[] = Array.from({ length: 25 }, (_, i) => {
  const items = mockProducts.slice(0, Math.floor(Math.random() * 3) + 1).map(product => ({
    productId: product.id,
    title: product.title,
    image: product.images[0],
    quantity: Math.floor(Math.random() * 3) + 1,
    basePrice: product.basePriceSeller,
    uplift: product.basePriceSeller * (product.upliftPercent / 100),
  }));

  const subtotal = items.reduce((sum, item) => sum + (item.basePrice * item.quantity), 0);
  const uplift = items.reduce((sum, item) => sum + (item.uplift * item.quantity), 0);
  const total = subtotal + uplift;
  const charity = uplift * 0.8;
  const ops = uplift * 0.2;

  return {
    id: `order-${i + 1}`,
    items,
    totals: { subtotal, uplift, total, charity, ops },
    donationFromUplift: charity,
    status: ['delivered', 'pending', 'confirmed'][Math.floor(Math.random() * 3)] as any,
    createdAt: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
  };
});

// Calculate total raised from orders
export const totalRaised = mockOrders
  .filter(order => order.status === 'delivered')
  .reduce((sum, order) => sum + order.donationFromUplift, 0);