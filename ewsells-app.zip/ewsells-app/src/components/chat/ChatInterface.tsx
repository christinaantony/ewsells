import React, { useRef, useEffect, useState } from 'react';
import useChat from '../../hooks/useChat';
import { Send, Loader2, Smile, User, Search, ChevronRight } from 'lucide-react';
import { collection, query, getDocs } from 'firebase/firestore';
import { db, auth } from '@/lib/firebase';
import { saveChatMessages } from '../../services/chatStorage';
import ProductCard, { ProductCardProps } from './ProductCard';
import { Link } from 'react-router-dom';

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface ChatInterfaceProps {
  initialMessages?: ChatMessage[];
  onNewMessage?: (content: string) => void;
  className?: string;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({
  initialMessages = [
    {
      role: 'assistant',
      content: 'Hello! How can I help you today?',
    },
  ],
  onNewMessage,
  className = '',
}) => {
  const [input, setInput] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [isUserAction, setIsUserAction] = useState(false); // Track if action is user-initiated
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { messages, sendMessage, isLoading, error, setMessages } = useChat(initialMessages);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    
    const userInput = input.trim();
    setInput('');
    setIsUserAction(true); // Mark this as a user action
    onNewMessage?.(userInput);
    
    // Check if this is a search query - either with search phrases or direct product terms
    const searchPhrases = ['search for', 'find', 'show me', 'looking for', 'search', 'get', 'i want', 'i need'];
    
    // First check if it contains search phrases
    const containsSearchPhrase = searchPhrases.some(phrase => userInput.toLowerCase().includes(phrase));
    
    // If it contains search phrases or is a single/few words (likely a product name)
    const wordCount = userInput.trim().split(/\s+/).length;
    const isLikelyProductSearch = wordCount <= 3;
    const isSearchQuery = containsSearchPhrase || isLikelyProductSearch;
    
    if (isSearchQuery) {
      // Extract search term - try different patterns
      let searchTerm = '';
      
      // Try to extract using common search phrases
      const searchRegex = new RegExp(`(search for|find|show me|looking for|search|get|i want|i need)\\s+(.+)`, 'i');
      const match = userInput.match(searchRegex);
      
      if (match && match[2]) {
        searchTerm = match[2].trim();
      } else {
        // Fallback: just use the input as the search term
        searchTerm = userInput.trim();
      }
      if (searchTerm) {
        // Add user message to chat immediately
        const newMessages = [...messages, { role: 'user' as const, content: userInput }];
        setMessages(newMessages);
        
        // Show loading state
        setIsSearching(true);
        
        // Perform search and add results directly to chat
        await performProductSearch(searchTerm, newMessages);
        return;
      }
    }
    
    // Regular message handling
    sendMessage(userInput);
  };

  // New approach: Perform product search and update messages directly
  const performProductSearch = async (searchTerm: string, currentMessages: ChatMessage[]) => {
    try {
      // Search for products in Firebase
      const productsRef = collection(db, 'products');
      const searchTermLower = searchTerm.toLowerCase();
      
      // Get all products without limit to ensure we fetch everything
      const productsQuery = query(productsRef);
      const snapshot = await getDocs(productsQuery);
      
      // Log the number of products fetched for debugging
      console.log(`Fetched ${snapshot.size} products from Firebase`);
      
      interface Product {
        id: string;
        name?: string;
        description?: string;
        category?: string;
        price?: number;
        tags?: string[];
        brand?: string;
        imageUrl?: string;
        images?: string[];
        imageUrls?: string[];
      }
      
      const matchingProducts: Product[] = [];
      
      snapshot.forEach(doc => {
        const product = { id: doc.id, ...doc.data() } as Product;
        // Extract all searchable fields with fallbacks to empty strings
        const name = (product.name || '').toLowerCase();
        const description = (product.description || '').toLowerCase();
        const category = (product.category || '').toLowerCase();
        // Add any other fields that might contain relevant search data
        const tags = Array.isArray(product.tags) ? product.tags.join(' ').toLowerCase() : '';
        const brand = (product.brand || '').toLowerCase();
        
        // Split search term into words for more flexible matching
        const searchWords = searchTermLower.split(/\s+/).filter(word => word.length > 0);
        
        // Check if any search word is found in any product field
        const matchesAnyWord = searchWords.some(word => 
          name.includes(word) || 
          description.includes(word) || 
          category.includes(word) ||
          tags.includes(word) ||
          brand.includes(word)
        );
        
        // Also keep the original full search term matching for exact phrases
        const matchesFullTerm = 
          name.includes(searchTermLower) || 
          description.includes(searchTermLower) || 
          category.includes(searchTermLower) ||
          tags.includes(searchTermLower) ||
          brand.includes(searchTermLower);
        
        if (matchesAnyWord || matchesFullTerm) {
          matchingProducts.push(product);
        }
      });
      
      // Log matching products for debugging
      console.log(`Found ${matchingProducts.length} matching products for search term: "${searchTerm}"`);
      
      // Create response message based on search results
      let responseMessage: ChatMessage;
      
      if (matchingProducts.length > 0) {
        // Sort products by relevance (exact name match first, then category match)
        matchingProducts.sort((a, b) => {
          const aName = (a.name || '').toLowerCase();
          const bName = (b.name || '').toLowerCase();
          const aCategory = (a.category || '').toLowerCase();
          const bCategory = (b.category || '').toLowerCase();
          
          // Exact name matches first
          if (aName === searchTermLower && bName !== searchTermLower) return -1;
          if (bName === searchTermLower && aName !== searchTermLower) return 1;
          
          // Then name contains search term
          if (aName.includes(searchTermLower) && !bName.includes(searchTermLower)) return -1;
          if (bName.includes(searchTermLower) && !aName.includes(searchTermLower)) return 1;
          
          // Then category matches
          if (aCategory === searchTermLower && bCategory !== searchTermLower) return -1;
          if (bCategory === searchTermLower && aCategory !== searchTermLower) return 1;
          
          return 0;
        });
        
        // Only show 3 products initially with a View More option
        const initialProducts = matchingProducts.slice(0, 3);
        const hasMoreProducts = matchingProducts.length > 3;
        
        // Create product cards as React components rendered to HTML string
        const productsHtml = initialProducts.map((product) => {
          // Handle different image URL formats
          let imageUrl = product.imageUrl;
          if (!imageUrl && product.images && Array.isArray(product.images) && product.images.length > 0) {
            imageUrl = product.images[0];
          } else if (!imageUrl && product.imageUrls && Array.isArray(product.imageUrls) && product.imageUrls.length > 0) {
            imageUrl = product.imageUrls[0];
          }
          
          // Create a card with proper styling
          return `
            <div class="product-card" data-product-id="${product.id}">
              <div class="product-card-inner">
                <div class="product-image">
                  ${imageUrl ? 
                    `<img src="${imageUrl}" alt="${product.name || 'Product'}" class="product-image-src">` : 
                    '<div class="no-image">No image available</div>'
                  }
                </div>
                <div class="product-details">
                  <h3 class="product-title">${product.name || 'Unnamed Product'}</h3>
                  <div class="product-category">${product.category || 'General'}</div>
                  <div class="product-price">₹${product.price || 0}</div>
                  <p class="product-description">${product.description ? (product.description.length > 80 ? product.description.substring(0, 80) + '...' : product.description) : ''}</p>
                </div>
              </div>
            </div>
          `;
        }).join('\n');
        
        // Add view more link if needed
        const viewMoreLink = hasMoreProducts ? 
          `<div class="view-more-link"><a href="/products?search=${encodeURIComponent(searchTerm)}">View all ${matchingProducts.length} products</a></div>` : 
          '';
        
        // Create a special content type that will be recognized as product cards
        responseMessage = {
          role: 'assistant',
          content: `I found ${matchingProducts.length} product${matchingProducts.length !== 1 ? 's' : ''} matching "${searchTerm}". Here are the top results:\n\n<div class="product-results">${productsHtml}${viewMoreLink}</div>\n\nClick on any product to view more details.`
        };
      } else {
        // No results found
        responseMessage = {
          role: 'assistant',
          content: `I couldn't find any products matching "${searchTerm}". Would you like to try a different search term?`
        };
      }
      
      // Add the response message to the current messages
      const updatedMessages = [...currentMessages, responseMessage];
      
      // Save to Firestore and update UI
      if (auth.currentUser?.uid) {
        await saveChatMessages(auth.currentUser.uid, updatedMessages);
      }
      
      // Update UI with search results
      setMessages(updatedMessages);
      
    } catch (error) {
      console.error('Error searching products:', error);
      
      // Add error message to chat
      const errorMessage: ChatMessage = {
        role: 'assistant',
        content: 'Sorry, I encountered an error while searching for products. Please try again.'
      };
      
      const updatedMessages = [...currentMessages, errorMessage];
      setMessages(updatedMessages);
      
      // Save error message to Firestore
      if (auth.currentUser?.uid) {
        saveChatMessages(auth.currentUser.uid, updatedMessages).catch(console.error);
      }
    } finally {
      setIsSearching(false);
    }
  };

  // Auto-scroll behavior with improved refresh handling
  useEffect(() => {
    // Only scroll to bottom for user-initiated message updates
    if (isUserAction && messages.length > 0) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      setIsUserAction(false); // Reset after scrolling
    }
  }, [messages, isUserAction]);
  
  // Force scroll to top on initial render and refresh
  useEffect(() => {
    // Immediate scroll to top
    window.scrollTo(0, 0);
    
    // Also use setTimeout to ensure it happens after any other rendering
    const timeoutId = setTimeout(() => {
      window.scrollTo(0, 0);
    }, 100);
    
    return () => clearTimeout(timeoutId);
  }, []);

  // Add event listeners for product selection, quick actions, and product card clicks
  useEffect(() => {
    const handleProductSelected = (event: any) => {
      const { product, message } = event.detail;
      
      // Create a user message about the product
      const userMessage = `Show me details for ${product.name}`;
      
      // Create an AI response with the product details
      const productMessage = {
        role: 'assistant' as const,
        content: message
      };
      
      // Send the messages
      sendMessage(userMessage, [productMessage]);
    };
    
    const handleQuickAction = (event: any) => {
      const { message } = event.detail;
      
      if (message) {
        // Set the input value to the message
        setInput(message);
        
        // Submit the form programmatically
        setTimeout(() => {
          const form = document.querySelector('.chat-form') as HTMLFormElement;
          if (form) {
            form.dispatchEvent(new Event('submit', { cancelable: true }));
          }
        }, 100);
      }
    };
    
    // Handle message clicks for product cards
    const handleMessageClick = (event: Event) => {
      const target = event.target as HTMLElement;
      
      // Find the closest product card element
      const productCard = target.closest('.product-card');
      if (!productCard) return;
      
      // Get the product ID from the data attribute
      const productId = (productCard as HTMLElement).dataset.productId;
      if (!productId) return;
      
      // Prevent default behavior if it's a link
      event.preventDefault();
      
      // Navigate to the product page
      window.location.href = `/product/${productId}`;
      
      // Log the click for analytics
      console.log(`Product clicked: ${productId}`);
    };

    // Add event listeners to this component
    const element = document.querySelector('.chat-interface');
    if (element) {
      element.addEventListener('product-selected', handleProductSelected);
      element.addEventListener('quick-action', handleQuickAction);
      element.addEventListener('click', handleMessageClick as EventListener);
    }

    return () => {
      // Clean up event listeners
      if (element) {
        element.removeEventListener('product-selected', handleProductSelected);
        element.removeEventListener('quick-action', handleQuickAction);
        element.removeEventListener('click', handleMessageClick as EventListener);
      }
    };
  }, [sendMessage, setInput]);

  // Use a ref to track if this is the first render
  const isFirstRender = useRef(true);
  
  // Update scroll position when messages change
  useEffect(() => {
    if (isFirstRender.current) {
      // On first render, scroll to top
      window.scrollTo(0, 0);
      isFirstRender.current = false;
    } else if (isUserAction) {
      // On user action, scroll to bottom of messages
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isUserAction]);
  
  return (
    <div className={`flex flex-col h-full chat-interface ${className}`}>
      <style>{`
        .messages-container {
          scrollbar-width: thin;
          scrollbar-color: rgba(255, 215, 0, 0.3) transparent;
        }
        .messages-container::-webkit-scrollbar {
          width: 6px;
        }
        .messages-container::-webkit-scrollbar-track {
          background: transparent;
        }
        .messages-container::-webkit-scrollbar-thumb {
          background-color: rgba(255, 215, 0, 0.3);
          border-radius: 3px;
        }
        .messages-container::-webkit-scrollbar-thumb:hover {
          background-color: rgba(255, 215, 0, 0.5);
        }
        
        /* Product card styles */
        .product-results {
          display: grid;
          grid-template-columns: repeat(1, 1fr);
          gap: 12px;
          margin: 12px 0;
        }
        
        @media (min-width: 640px) {
          .product-results {
            grid-template-columns: repeat(3, 1fr);
          }
        }
        
        .product-card {
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 12px;
          overflow: hidden;
          background-color: rgba(30, 30, 30, 0.5);
          backdrop-filter: blur(8px);
          transition: all 0.2s ease;
          cursor: pointer;
        }
        
        .product-card:hover {
          transform: translateY(-2px);
          border-color: rgba(255, 215, 0, 0.3);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .product-card-inner {
          display: flex;
          flex-direction: column;
          height: 100%;
        }
        
        .product-image {
          height: 120px;
          background: linear-gradient(to bottom right, #f1f1f1, #e0e0e0);
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
        }
        
        .product-image img.product-image-src {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        
        .product-image .no-image {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 100%;
          height: 100%;
          color: rgba(255, 255, 255, 0.5);
          font-size: 12px;
        }
        
        .product-title {
          font-weight: 500;
          margin: 0 0 4px 0;
          font-size: 14px;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          color: white;
        }
        
        .product-details {
          padding: 12px;
          flex: 1;
          display: flex;
          flex-direction: column;
        }
        
        .product-details h3 {
          font-weight: 500;
          margin: 0 0 4px 0;
          font-size: 14px;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        
        .product-category {
          font-size: 12px;
          color: rgba(255, 255, 255, 0.6);
          margin-bottom: 4px;
        }
        
        .product-price {
          font-weight: 600;
          font-size: 14px;
          color: #ffd700;
          margin-bottom: 8px;
        }
        
        .product-description {
          font-size: 12px;
          color: rgba(255, 255, 255, 0.6);
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
          margin: 0;
        }
        
        .view-more-link {
          text-align: center;
          margin-top: 12px;
        }
        
        .view-more-link a {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          padding: 8px 16px;
          background-color: rgba(30, 30, 30, 0.5);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          font-size: 14px;
          color: rgba(255, 255, 255, 0.8);
          text-decoration: none;
          transition: all 0.2s ease;
        }
        
        .view-more-link a:hover {
          background-color: rgba(30, 30, 30, 0.7);
          border-color: rgba(255, 215, 0, 0.3);
        }
      `}</style>
      
      {/* Messages container */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6 messages-container">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`flex items-start gap-4 ${
              message.role === 'user' ? 'flex-row-reverse' : ''
            }`}
          >
            <div className="flex-shrink-0">
              {message.role === 'user' ? (
                <div className="relative">
                  <div className="h-12 w-12 rounded-2xl bg-gradient-to-r from-gold to-amber-400 flex items-center justify-center text-black shadow-lg">
                    <User className="h-6 w-6" />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-r from-gold to-amber-400 rounded-2xl blur-md opacity-50 -z-10" />
                </div>
              ) : (
                <div className="relative">
                  <div className="h-12 w-12 rounded-2xl bg-card/80 backdrop-blur-sm border border-border/50 flex items-center justify-center shadow-lg">
                    <Smile className="h-6 w-6 text-gold" />
                  </div>
                  <div className="absolute inset-0 bg-gold/20 rounded-2xl blur-md opacity-30 -z-10" />
                </div>
              )}
            </div>
            <div
              className={`max-w-[75%] rounded-3xl p-5 shadow-lg backdrop-blur-sm ${message.role === 'user' ? 'bg-gold/10 text-foreground rounded-br-lg border border-gold/30' : 'bg-card/60 text-foreground rounded-bl-lg border border-border/30'}`}
            >
              <div 
                className="prose prose-sm max-w-none message-content"
                dangerouslySetInnerHTML={{ __html: message.content }}
              />
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="flex items-center gap-3 p-4 bg-card/40 backdrop-blur-sm border border-border/30 rounded-2xl">
              <Loader2 className="h-5 w-5 animate-spin text-gold" />
              <span className="text-sm text-muted-foreground">AI is thinking...</span>
            </div>
          </div>
        )}
        {error && (
          <div className="bg-red-500/10 text-red-400 border border-red-500/30 p-4 rounded-2xl text-sm backdrop-blur-sm">
            {error instanceof Error ? error.message : String(error)}
          </div>
        )}
        <div ref={messagesEndRef} className="h-4" />
      </div>

      {/* Input area */}
      <form onSubmit={handleSubmit} className="p-6 flex-shrink-0 chat-form">
        <div className="relative">
          <div className="absolute left-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
            <Search className="h-5 w-5 text-muted-foreground" />
          </div>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Search for products or ask me anything..."
            className="w-full rounded-2xl border border-border/50 bg-card/50 backdrop-blur-sm text-foreground placeholder-muted-foreground pl-12 pr-14 py-4 focus:outline-none focus:ring-2 focus:ring-gold/50 focus:border-gold/30 transition-all shadow-sm"
            disabled={isLoading || isSearching}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit(e);
              }
            }}
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading || isSearching}
            className="absolute right-3 top-1/2 -translate-y-1/2 bg-gradient-to-r from-gold to-amber-400 text-black rounded-xl p-2.5 hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg hover:shadow-xl hover:scale-105"
            aria-label="Send message"
          >
            {isLoading || isSearching ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <Send className="h-5 w-5" />
            )}
          </button>
        </div>
        {input.trim() && (
          <div className="mt-2 text-xs text-muted-foreground">
            <span className="italic">Tip: Try "search for plants" or "find shoes" to search products</span>
          </div>
        )}
      </form>
    </div>
  );
};

export default ChatInterface;
