import React, { useState, useEffect } from 'react';
import { Search, X, Loader2 } from 'lucide-react';
import { collection, query, getDocs, orderBy, limit } from 'firebase/firestore';
import { db } from '@/lib/firebase';

interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  description: string;
  imageUrl?: string;
}

interface ProductSearchProps {
  onSelectProduct: (product: Product) => void;
  onClose: () => void;
}

export const ProductSearch: React.FC<ProductSearchProps> = ({ onSelectProduct, onClose }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch all products on component mount
  useEffect(() => {
    const fetchProducts = async () => {
      setIsLoading(true);
      setError(null);
      
      try {
        const productsRef = collection(db, 'products');
        const productsQuery = query(productsRef, orderBy('name'), limit(100));
        const snapshot = await getDocs(productsQuery);
        
        const fetchedProducts: Product[] = [];
        const categorySet = new Set<string>();
        
        snapshot.docs.forEach(doc => {
          const data = doc.data() as Omit<Product, 'id'>;
          fetchedProducts.push({
            id: doc.id,
            name: data.name || 'Unknown Product',
            category: data.category || 'General',
            price: data.price || 0,
            description: data.description || '',
            imageUrl: data.imageUrl
          });
          
          if (data.category) {
            categorySet.add(data.category);
          }
        });
        
        setProducts(fetchedProducts);
        setFilteredProducts(fetchedProducts);
        setCategories(Array.from(categorySet));
      } catch (err) {
        console.error('Error fetching products:', err);
        setError('Failed to load products. Please try again.');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchProducts();
  }, []);

  // Filter products based on search term and category
  useEffect(() => {
    if (!searchTerm && !selectedCategory) {
      setFilteredProducts(products);
      return;
    }
    
    let filtered = products;
    
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(product => 
        product.name.toLowerCase().includes(term) || 
        product.description.toLowerCase().includes(term)
      );
    }
    
    if (selectedCategory) {
      filtered = filtered.filter(product => product.category === selectedCategory);
    }
    
    setFilteredProducts(filtered);
  }, [searchTerm, selectedCategory, products]);

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };

  // Handle category selection
  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category === selectedCategory ? '' : category);
  };

  // Handle product selection
  const handleProductSelect = (product: Product) => {
    onSelectProduct(product);
  };

  return (
    <div className="bg-black/80 backdrop-blur-sm fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="bg-background rounded-2xl w-full max-w-3xl max-h-[80vh] flex flex-col overflow-hidden shadow-xl border border-border">
        <div className="p-4 border-b border-border flex justify-between items-center">
          <h2 className="text-lg font-semibold">Search Products</h2>
          <button 
            onClick={onClose}
            className="p-1 rounded-full hover:bg-muted transition-colors"
            aria-label="Close search"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        <div className="p-4 border-b border-border">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              value={searchTerm}
              onChange={handleSearchChange}
              placeholder="Search products by name or description..."
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-border bg-card focus:outline-none focus:ring-2 focus:ring-gold/50"
              autoFocus
            />
          </div>
          
          {categories.length > 0 && (
            <div className="mt-3">
              <p className="text-sm text-muted-foreground mb-2">Filter by category:</p>
              <div className="flex flex-wrap gap-2">
                {categories.map(category => (
                  <button
                    key={category}
                    onClick={() => handleCategoryChange(category)}
                    className={`px-3 py-1 rounded-full text-xs transition-colors ${
                      selectedCategory === category 
                        ? 'bg-gold text-black' 
                        : 'bg-muted text-foreground hover:bg-muted/80'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
        
        <div className="flex-1 overflow-y-auto p-4">
          {isLoading ? (
            <div className="flex justify-center items-center h-full">
              <Loader2 className="h-8 w-8 animate-spin text-gold" />
            </div>
          ) : error ? (
            <div className="text-center text-red-500 p-4">
              {error}
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="text-center text-muted-foreground p-4">
              No products found matching your search.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredProducts.map(product => (
                <button
                  key={product.id}
                  className="bg-card hover:bg-card/80 rounded-xl p-4 text-left border border-border/50 transition-all hover:shadow-md flex flex-col h-full"
                  onClick={() => handleProductSelect(product)}
                >
                  <div className="flex items-start gap-3">
                    {product.imageUrl ? (
                      <div className="w-16 h-16 rounded-md overflow-hidden flex-shrink-0 bg-muted">
                        <img 
                          src={product.imageUrl} 
                          alt={product.name}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.style.display = 'none';
                          }}
                        />
                      </div>
                    ) : (
                      <div className="w-16 h-16 rounded-md bg-muted flex items-center justify-center flex-shrink-0">
                        <Search className="h-6 w-6 text-muted-foreground" />
                      </div>
                    )}
                    
                    <div className="flex-1">
                      <h3 className="font-medium text-foreground">{product.name}</h3>
                      <p className="text-sm text-muted-foreground line-clamp-2">{product.description}</p>
                      <div className="mt-2 flex items-center justify-between">
                        <span className="text-sm font-semibold text-gold">₹{product.price}</span>
                        <span className="text-xs bg-muted px-2 py-0.5 rounded-full">{product.category}</span>
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductSearch;
