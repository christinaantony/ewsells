import React, { ReactNode } from 'react';
import { Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';

type FormField = {
  id: string;
  label: string;
  type?: string;
  placeholder: string;
  required?: boolean;
  value: string;
  onChange: (value: string) => void;
  helpText?: string;
  min?: number;
  step?: string | number;
  inputMode?: string;
  pattern?: string;
  prefix?: string;
  rows?: number;
  options?: Array<{ value: string; label: string }>;
};

type ProductUploadFormProps = {
  title: string;
  description: string;
  onSubmit: (e: React.FormEvent) => void;
  onReset: () => void;
  formFields: {
    basic: FormField[];
    description: FormField & { rows?: number };
  };
  imageUpload: ReactNode;
  message?: string | null;
  isSubmitting: boolean;
  isEdit?: boolean;
  onBack: () => void;
  // Optional toggle to indicate if the product is customizable
  customizable?: {
    checked: boolean;
    onChange: (checked: boolean) => void;
  };
};

export function ProductUploadForm({
  title,
  description,
  onSubmit,
  onReset,
  formFields,
  imageUpload,
  message,
  isSubmitting,
  isEdit = false,
  onBack,
  customizable
}: ProductUploadFormProps) {
  return (
    <main className="min-h-screen">
      <section className="pt-24 pb-12 bg-surface/50 border-t border-border/40">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h2 className="text-2xl font-bold">
                {isEdit ? 'Edit' : 'Add New'} {title}
              </h2>
              <p className="text-muted-foreground">
                {isEdit 
                  ? 'Editing this product will require admin approval before it\'s published again.'
                  : description}
              </p>
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button variant="outline" onClick={onBack} className="flex-1 sm:flex-initial">
                {isEdit ? 'Cancel' : 'Back to Dashboard'}
              </Button>
            </div>
          </div>

          {message && (
            <div className="mb-6 p-4 text-sm rounded-md bg-muted">
              {message}
            </div>
          )}

          <Card>
            <CardContent className="p-6">
              <form onSubmit={onSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {formFields.basic.map((field) => (
                    <div key={field.id} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor={field.id}>{field.label}</Label>
                        {field.required && (
                          <span className="text-xs text-muted-foreground">Required</span>
                        )}
                      </div>
                      <div className="relative">
                        {field.prefix && (
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                            {field.prefix}
                          </span>
                        )}
                        <Input
                          id={field.id}
                          type={field.type || 'text'}
                          value={field.value}
                          onChange={(e) => field.onChange(e.target.value)}
                          placeholder={field.placeholder}
                          required={field.required}
                          min={field.min}
                          step={field.step}
                          inputMode={field.inputMode as any}
                          pattern={field.pattern}
                          className={field.prefix ? 'pl-8' : ''}
                        />
                      </div>
                      {field.helpText && (
                        <p className="text-xs text-muted-foreground">
                          {field.helpText}
                        </p>
                      )}
                    </div>
                  ))}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor={formFields.description.id}>
                      {formFields.description.label}
                    </Label>
                    {formFields.description.required && (
                      <span className="text-xs text-muted-foreground">Required</span>
                    )}
                  </div>
                  <textarea
                    id={formFields.description.id}
                    className="min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    value={formFields.description.value}
                    onChange={(e) => formFields.description.onChange(e.target.value)}
                    placeholder={formFields.description.placeholder}
                    required={formFields.description.required}
                    rows={formFields.description.rows || 4}
                  />
                  {formFields.description.helpText && (
                    <p className="text-xs text-muted-foreground">
                      {formFields.description.helpText}
                    </p>
                  )}
                </div>

                {imageUpload}

                {customizable && (
                  <div className="pt-2">
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="customizable"
                        checked={customizable.checked}
                        onChange={(e) => customizable.onChange(e.target.checked)}
                        className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      />
                      <Label htmlFor="customizable">Allow customer customization requests</Label>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      If enabled, buyers can message you for post-purchase customization (no phone numbers or prices allowed).
                    </p>
                  </div>
                )}

                <div className="flex justify-end gap-4 pt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={onReset}
                    disabled={isSubmitting}
                    className="h-10 px-4 py-2"
                  >
                    Reset
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="h-10 px-4 py-2 bg-gold text-black hover:bg-gold/90"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      'Upload Product'
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>
    </main>
  );
}
