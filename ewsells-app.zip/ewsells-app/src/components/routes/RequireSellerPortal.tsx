import { Navigate, useLocation } from 'react-router-dom';
import { ReactNode } from 'react';
import { useStore } from '@/store/useStore';

export default function RequireSellerPortal({ children }: { children: ReactNode }) {
  const { user } = useStore();
  const location = useLocation();

  // Only allow access if entered via seller portal within this session
  const enteredViaPortal = typeof window !== 'undefined' && sessionStorage.getItem('sellerPortalEntry') === '1';

  // Must be logged in and have seller role
  const isSeller = !!user && (user as any).role === 'seller';

  if (!isSeller || !enteredViaPortal) {
    // Persist intended path to return after portal entry
    const to = location.pathname + location.search + location.hash;
    sessionStorage.setItem('sellerIntended', to);
    return <Navigate to="/seller-portal" replace />;
  }

  return <>{children}</>;
}
