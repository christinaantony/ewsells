import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Heart, ShoppingCart } from 'lucide-react';
import ProductImageCarousel from '@/components/ProductImageCarousel';

// Define the book type
export interface Book {
  id: number;
  title: string;
  author: string;
  coverImage: string;
  price: number;
  category: string;
  cause: string;
  impact: string;
}

interface BookCardProps {
  book: Book;
  viewMode: 'grid' | 'list';
  onAddToCart?: (book: Book) => void;
  onWishlistClick?: () => void;
}

// Map categories to colors
const categoryColors: Record<string, string> = {
  'fiction': 'bg-amber-500',
  'non-fiction': 'bg-blue-500',
  'classics': 'bg-purple-500',
  'self-help': 'bg-green-500'
};

export function BookCard({ book, viewMode, onAddToCart, onWishlistClick }: BookCardProps) {
  const { title, author, coverImage, price, category, cause, impact } = book;
  
  // Get the appropriate color for the category or use a default
  const categoryColor = categoryColors[category] || 'bg-gray-500';
  
  if (viewMode === 'grid') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <Card className="overflow-hidden h-full flex flex-col">
          <div className="relative">
            <div className="aspect-[3/4] overflow-hidden bg-gray-100">
              <ProductImageCarousel
                images={coverImage ? [coverImage] : []}
                alt={title}
                aspect="free"
              />
            </div>
            <Badge className={`absolute top-2 left-2 ${categoryColor}`}>
              {category}
            </Badge>
            <Button 
              variant="ghost" 
              size="icon" 
              className="absolute top-2 right-2 bg-white/80 hover:bg-white rounded-full"
              onClick={(e) => { e.stopPropagation(); e.preventDefault(); onWishlistClick?.(); }}
            >
              <Heart className="h-4 w-4" />
              <span className="sr-only">Add to wishlist</span>
            </Button>
          </div>
          
          <CardContent className="flex-grow pt-4">
            <h3 className="font-semibold text-lg line-clamp-1">{title}</h3>
            <p className="text-sm text-muted-foreground mb-2">{author}</p>
            <p className="font-medium text-lg">${price.toFixed(2)}</p>
            <div className="mt-2">
              <p className="text-xs text-muted-foreground">Supports: {cause}</p>
              <p className="text-xs text-emerald-600 font-medium">{impact}</p>
            </div>
          </CardContent>
          
          <CardFooter className="pt-0">
            <Button 
              className="w-full"
              onClick={(e) => { e.stopPropagation(); e.preventDefault(); onAddToCart?.(book); }}
            >
              <ShoppingCart className="h-4 w-4 mr-2" />
              Add to Cart
            </Button>
          </CardFooter>
        </Card>
      </motion.div>
    );
  }
  
  // List view
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="overflow-hidden">
        <div className="flex flex-col sm:flex-row">
          <div className="relative sm:w-48 h-48">
            <ProductImageCarousel
              images={coverImage ? [coverImage] : []}
              alt={title}
              aspect="free"
              className="w-full h-full"
            />
            <Badge className={`absolute top-2 left-2 ${categoryColor}`}>
              {category}
            </Badge>
          </div>
          
          <div className="flex flex-col flex-grow p-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold text-lg">{title}</h3>
                <p className="text-sm text-muted-foreground">{author}</p>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="rounded-full"
                onClick={(e) => { e.stopPropagation(); e.preventDefault(); onWishlistClick?.(); }}
              >
                <Heart className="h-4 w-4" />
                <span className="sr-only">Add to wishlist</span>
              </Button>
            </div>
            
            <div className="mt-2 flex-grow">
              <p className="text-xs text-muted-foreground">Supports: {cause}</p>
              <p className="text-xs text-emerald-600 font-medium">{impact}</p>
            </div>
            
            <div className="flex justify-between items-center mt-4">
              <p className="font-medium text-lg">${price.toFixed(2)}</p>
              <Button
                onClick={(e) => { e.stopPropagation(); e.preventDefault(); onAddToCart?.(book); }}
              >
                <ShoppingCart className="h-4 w-4 mr-2" />
                Add to Cart
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
