import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Package } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';
import type { SearchResult } from '@/services/searchService';

interface SearchDropdownProps {
  query: string;
  results: SearchResult[];
  isLoading: boolean;
  onResultClick: () => void;
  onKeyDown: (e: React.KeyboardEvent) => void;
  selectedIndex: number;
}

export function SearchDropdown({
  query,
  results,
  isLoading,
  onResultClick,
  onKeyDown,
  selectedIndex
}: SearchDropdownProps) {
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Scroll selected item into view
  useEffect(() => {
    if (selectedIndex >= 0 && dropdownRef.current) {
      const selectedItem = dropdownRef.current.querySelector(`[data-index="${selectedIndex}"]`);
      if (selectedItem) {
        selectedItem.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      }
    }
  }, [selectedIndex]);

  if (query.length < 2) return null;

  return (
    <div 
      className="absolute top-full left-0 right-0 mt-1 bg-card/95 backdrop-blur-xl border border-gold/20 rounded-lg shadow-lg z-50 max-h-80 overflow-y-auto"
      ref={dropdownRef}
      onKeyDown={onKeyDown}
    >
      {isLoading ? (
        <div className="p-4 text-center text-sm text-muted-foreground">
          <div className="animate-pulse flex justify-center items-center space-x-2">
            <div className="h-2 w-2 bg-gold rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
            <div className="h-2 w-2 bg-gold rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
            <div className="h-2 w-2 bg-gold rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
          </div>
          <p className="mt-2">Searching products...</p>
        </div>
      ) : results.length === 0 ? (
        <div className="p-4 text-center text-sm text-muted-foreground">
          No products found for "{query}"
        </div>
      ) : (
        <div>
          <div className="p-2 border-b border-border">
            <p className="text-xs text-muted-foreground px-2">
              {results.length} result{results.length !== 1 ? 's' : ''} found
            </p>
          </div>
          <div className="py-1">
            {results.map((result, index) => (
              <Link
                key={result.id}
                to={result.url}
                className={`flex items-center px-3 py-2 hover:bg-gold/10 transition-colors ${selectedIndex === index ? 'bg-gold/10' : ''}`}
                onClick={onResultClick}
                data-index={index}
              >
                <div className="w-10 h-10 bg-muted rounded-md flex-shrink-0 overflow-hidden">
                  {result.image ? (
                    <img
                      src={result.image}
                      alt={result.title}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://via.placeholder.com/40?text=Product';
                      }}
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Package className="h-5 w-5 text-muted-foreground" />
                    </div>
                  )}
                </div>
                <div className="ml-3 flex-grow">
                  <div className="text-sm font-medium line-clamp-1">{result.title}</div>
                  {result.category && (
                    <div className="text-xs text-muted-foreground">{result.category}</div>
                  )}
                </div>
                {result.price !== undefined && (
                  <div className="text-gold font-medium text-sm ml-2">
                    {formatCurrency(result.price)}
                  </div>
                )}
              </Link>
            ))}
          </div>
          <div className="p-2 border-t border-border">
            <Link
              to={`/search?q=${encodeURIComponent(query)}`}
              className="block w-full text-center text-sm text-gold hover:underline py-1"
              onClick={onResultClick}
            >
              View all results
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
