import { Link } from 'react-router-dom';
import { SearchResult } from '@/services/searchService';
import { formatCurrency } from '@/lib/utils';

interface RelatedProductsProps {
  items: SearchResult[];
  title?: string;
  showTitle?: boolean;
}

export function RelatedProducts({ items, title = 'Related Products', showTitle = true }: RelatedProductsProps) {
  if (!items || items.length === 0) return null;

  return (
    <div className="mt-2 mb-1">
      {showTitle && <h4 className="text-xs font-medium text-muted-foreground mb-2">{title}</h4>}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {items.map((item) => (
          <Link
            key={item.id}
            to={item.url}
            className="group flex flex-col rounded-md overflow-hidden border border-border hover:border-gold/50 transition-colors"
          >
            <div className="h-24 bg-muted relative">
              {item.image ? (
                <img
                  src={item.image}
                  alt={item.title}
                  className="h-full w-full object-cover group-hover:scale-105 transition-transform"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://via.placeholder.com/100?text=EW';
                  }}
                />
              ) : (
                <div className="h-full w-full flex items-center justify-center bg-muted">
                  <span className="text-xs text-muted-foreground">No image</span>
                </div>
              )}
            </div>
            <div className="p-2">
              <h3 className="text-xs font-medium truncate">{item.title}</h3>
              {item.price !== undefined && (
                <p className="text-xs text-gold font-medium mt-1">
                  {formatCurrency(item.price)}
                </p>
              )}
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
