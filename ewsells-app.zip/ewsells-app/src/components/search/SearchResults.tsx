import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, ShoppingBag, Loader2, X, Grid, Package } from 'lucide-react';
import { SearchResult } from '@/services/searchService';
import { Button } from '@/components/ui/button';
import { RelatedProducts } from './RelatedProducts';
import { formatCurrency } from '@/lib/utils';

interface SearchResultsProps {
  results: SearchResult[];
  isLoading: boolean;
  onResultClick: (result: SearchResult) => void;
  onClose: () => void;
  searchQuery: string;
}

export function SearchResults({ 
  results, 
  isLoading, 
  onResultClick, 
  onClose,
  searchQuery 
}: SearchResultsProps) {
  const navigate = useNavigate();
  const [selectedIndex, setSelectedIndex] = useState<number>(-1);

  // Reset selected index when results change
  useEffect(() => {
    setSelectedIndex(-1);
  }, [results]);

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!results.length) return;
      
      switch (e.key) {
        case 'ArrowDown':
          e.preventDefault();
          setSelectedIndex(prev => (prev + 1) % results.length);
          break;
        case 'ArrowUp':
          e.preventDefault();
          setSelectedIndex(prev => (prev - 1 + results.length) % results.length);
          break;
        case 'Enter':
          e.preventDefault();
          if (selectedIndex >= 0 && selectedIndex < results.length) {
            onResultClick(results[selectedIndex]);
          } else if (searchQuery.trim()) {
            // If no result is selected but there's a search query, navigate to search page
            navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
            onClose();
          }
          break;
        case 'Escape':
          e.preventDefault();
          onClose();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [results, selectedIndex, onResultClick, onClose, navigate, searchQuery]);

  if (!searchQuery.trim()) {
    return null;
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="absolute top-full left-0 right-0 mt-2 bg-card rounded-lg shadow-xl border border-border z-50 max-h-[70vh] overflow-hidden"
    >
      <div className="flex items-center justify-between p-3 border-b border-border">
        <div className="flex items-center">
          <Search className="h-4 w-4 mr-2 text-muted-foreground" />
          <span className="text-sm font-medium">
            {isLoading ? 'Searching...' : results.length ? `Results for "${searchQuery}"` : `No results for "${searchQuery}"`}
          </span>
        </div>
        <Button
          size="icon"
          variant="ghost"
          className="h-6 w-6 rounded-full hover:bg-muted"
          onClick={onClose}
        >
          <X className="h-3 w-3" />
        </Button>
      </div>

      <div className="overflow-y-auto max-h-[calc(70vh-48px)]">
        {isLoading ? (
          <div className="flex items-center justify-center p-6">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : results.length > 0 ? (
          <ul className="py-2">
            {results.map((result, index) => (
              <motion.li
                key={`${result.type}-${result.id}`}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: index * 0.05 }}
                className={`px-3 py-2 cursor-pointer hover:bg-gold/10 ${
                  selectedIndex === index ? 'bg-gold/10' : ''
                }`}
                onClick={() => onResultClick(result)}
                onMouseEnter={() => setSelectedIndex(index)}
              >
                <div className="flex items-center">
                  {result.image ? (
                    <div className="h-12 w-12 rounded-md overflow-hidden mr-3 bg-muted flex-shrink-0">
                      <img 
                        src={result.image} 
                        alt={result.title} 
                        className="h-full w-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://via.placeholder.com/40?text=EW';
                        }}
                      />
                    </div>
                  ) : (
                    <div className="h-12 w-12 rounded-md overflow-hidden mr-3 bg-muted flex items-center justify-center flex-shrink-0">
                      {result.type === 'product' ? (
                        <ShoppingBag className="h-5 w-5 text-muted-foreground" />
                      ) : (
                        <Grid className="h-5 w-5 text-muted-foreground" />
                      )}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <div className="text-sm font-medium truncate">{result.title}</div>
                      {result.price !== undefined && (
                        <div className="text-sm font-medium text-gold ml-2">
                          {formatCurrency(result.price)}
                        </div>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground flex items-center">
                      {result.type === 'product' ? (
                        <>
                          <Package className="h-3 w-3 mr-1" />
                          <span className="capitalize">Product</span>
                          {result.category && (
                            <span className="ml-1">• {result.category}</span>
                          )}
                        </>
                      ) : (
                        <>
                          <Grid className="h-3 w-3 mr-1" />
                          <span className="capitalize">Category</span>
                        </>
                      )}
                      {result.description && (
                        <span className="truncate ml-1 hidden sm:inline">
                          • {result.description.substring(0, 40)}
                          {result.description.length > 40 ? '...' : ''}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                
                {/* Show related items if available */}
                {result.relatedItems && result.relatedItems.length > 0 && (
                  <div className="mt-2 pl-14">
                    <RelatedProducts 
                      items={result.relatedItems} 
                      title={result.type === 'category' ? 'Products in this category' : 'Similar products'} 
                    />
                  </div>
                )}
              </motion.li>
            ))}
          </ul>
        ) : (
          <div className="p-6 text-center">
            <p className="text-sm text-muted-foreground">No results found for "{searchQuery}"</p>
            <Button 
              variant="link" 
              className="mt-2 text-gold"
              onClick={() => navigate(`/search?q=${encodeURIComponent(searchQuery)}`)}
            >
              View all products
            </Button>
          </div>
        )}
      </div>

      {results.length > 0 && (
        <div className="p-3 border-t border-border">
          <Button
            variant="outline"
            size="sm"
            className="w-full hover:bg-gold/10 hover:text-gold hover:border-gold"
            onClick={() => {
              navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
              onClose();
            }}
          >
            <Search className="h-4 w-4 mr-2" />
            See all results
          </Button>
        </div>
      )}
    </motion.div>
  );
}
