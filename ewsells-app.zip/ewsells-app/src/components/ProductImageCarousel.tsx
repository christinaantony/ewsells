import { useMemo, useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Image as ImageIcon } from 'lucide-react';
import clsx from 'clsx';

interface ProductImageCarouselProps {
  images?: string[] | null;
  alt: string;
  className?: string;
  aspect?: 'square' | 'video' | 'banner' | 'free';
  thumbnails?: boolean;
}

export default function ProductImageCarousel({ images, alt, className, aspect = 'square', thumbnails = false }: ProductImageCarouselProps) {
  const placeholder = '/favicon.png';
  const [imageError, setImageError] = useState<Record<number, boolean>>({});
  const [isLoading, setIsLoading] = useState(true);
  
  const list = useMemo(() => {
    const arr = Array.isArray(images) ? images.filter(Boolean) : [];
    const dedup = Array.from(new Set(arr));
    return dedup.length > 0 ? dedup : [];
  }, [images]);

  const [idx, setIdx] = useState(0);
  const next = () => setIdx((i) => (i + 1) % list.length);
  const prev = () => setIdx((i) => (i - 1 + list.length) % list.length);

  // Reset states when images change
  useEffect(() => {
    setImageError({});
    setIdx(0);
    setIsLoading(true);
  }, [images]);

  // Ensure active index is in range when list changes
  useEffect(() => {
    if (list.length > 0 && idx >= list.length) {
      setIdx(0);
    }
  }, [list.length, idx]);

  const handleImageError = (index: number) => {
    setImageError(prev => ({ ...prev, [index]: true }));
    setIsLoading(false);
  };

  const handleImageLoad = () => {
    setIsLoading(false);
  };

  const getImageSource = (index: number) => {
    if (list.length === 0) return placeholder;
    if (imageError[index]) return placeholder;
    return list[index];
  };

  const currentImageSrc = getImageSource(idx);
  const showPlaceholder = list.length === 0 || imageError[idx];
  
  const aspectClass =
    aspect === 'square' ? 'aspect-square' :
    aspect === 'video' ? 'aspect-video' :
    aspect === 'banner' ? 'aspect-[16/7]' :
    '';

  return (
    <div className={clsx('relative', className)}>
      <div className={clsx('relative overflow-hidden bg-gray-100 dark:bg-gray-800 rounded-xl', aspectClass)}>
        {currentImageSrc && !showPlaceholder && (
          <img
            key={`${currentImageSrc}-${idx}`}
            src={currentImageSrc}
            alt={alt}
            className={clsx(
              'object-cover w-full h-full',
              !isLoading && 'opacity-100'
            )}
            loading="lazy"
            onError={() => handleImageError(idx)}
            onLoad={handleImageLoad}
          />
        )}

        {/* Navigation arrows */}
        {list.length > 1 && !showPlaceholder && (
          <>
            <button
              type="button"
              aria-label="Previous image"
              className="absolute left-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/40 text-white hover:bg-black/60 z-20 transition-opacity"
              onClick={(e) => { e.preventDefault(); e.stopPropagation(); prev(); }}
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              type="button"
              aria-label="Next image"
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/40 text-white hover:bg-black/60 z-20 transition-opacity"
              onClick={(e) => { e.preventDefault(); e.stopPropagation(); next(); }}
            >
              <ChevronRight className="h-5 w-5" />
            </button>

            <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
              {list.map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); setIdx(i); }}
                  className={clsx(
                    'h-1.5 w-1.5 rounded-full transition-all',
                    i === idx ? 'bg-white w-4' : 'bg-white/50 hover:bg-white/75'
                  )}
                  aria-label={`Go to image ${i + 1}`}
                />
              ))}
            </div>
          </>
        )}

        {/* Placeholder overlay when no valid images or error */}
        {showPlaceholder && (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center">
            <ImageIcon className="h-12 w-12 text-gray-400 dark:text-gray-600 mb-2" />
            <p className="text-sm text-gray-500 dark:text-gray-400">No image available</p>
          </div>
        )}
      </div>

      {thumbnails && list.length > 1 && !showPlaceholder && (
        <div className="mt-2 flex gap-2 overflow-x-auto pb-1">
          {list.map((src, i) => {
            const hasError = imageError[i];
            return (
              <button
                key={`thumb-${i}`}
                type="button"
                aria-label={`Show image ${i + 1}`}
                onClick={(e) => { 
                  e.preventDefault(); 
                  e.stopPropagation(); 
                  setIdx(i);
                  setIsLoading(true);
                }}
                className={clsx(
                  'relative shrink-0 h-10 w-10 rounded-md overflow-hidden border transition-all duration-200 ring-offset-2 focus:outline-none focus:ring-2 focus:ring-ring',
                  i === idx 
                    ? 'border-gold ring-2 ring-gold/60 scale-105' 
                    : 'border-border hover:border-foreground/30 hover:scale-105',
                  hasError ? 'opacity-50' : ''
                )}
              >
                {hasError ? (
                  <div className="h-full w-full flex items-center justify-center bg-gray-100 dark:bg-gray-800">
                    <ImageIcon className="h-4 w-4 text-gray-400" />
                  </div>
                ) : (
                  <img 
                    src={src} 
                    alt={`""`} 
                    className="h-full w-full object-cover" 
                    loading="lazy" 
                    onError={() => handleImageError(i)}
                  />
                )}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
