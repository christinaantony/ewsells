import React from 'react';
import { Star } from 'lucide-react';
import { useProductRating } from '@/hooks/useProductRating';

interface RatingPillProps {
  productId: string;
  docData?: any;
  className?: string;
  onClick?: () => void;
}

/**
 * Gold ratings pill used across listings.
 * - Rated: shows star + numeric avg (e.g., 4.6)
 * - Unrated: shows only star; tooltip says "Not yet rated"
 */
export const RatingPill: React.FC<RatingPillProps> = ({ productId, docData, className = '' }) => {
  const { rating, count } = useProductRating(productId, docData);

  const title = typeof rating === 'number'
    ? `Rating ${rating.toFixed(1)} out of 5${typeof count === 'number' ? ` • ${count} ratings` : ''}`
    : 'Not yet rated';

  return (
    <div
      className={`inline-flex items-center text-sm ${className}`}
      title={title}
      aria-label={typeof rating === 'number' ? `Rating ${rating.toFixed(1)} out of 5` : 'Not yet rated'}
    >
      <Star className="h-4 w-4 text-amber-400 fill-amber-400" />
      {typeof rating === 'number' ? (
        <span className="ml-1 text-xs text-muted-foreground">{rating.toFixed(1)}</span>
      ) : null}
    </div>
  );
};
