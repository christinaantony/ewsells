import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, X } from 'lucide-react';
import { Button } from './button';
import { useStore } from '@/store/useStore';
import { showInstallPrompt, setupInstallPrompt } from '@/lib/pwa';

export function InstallPrompt() {
  const { isInstallPromptVisible, setInstallPromptVisible } = useStore();
  const [isInstallable, setIsInstallable] = useState(false);

  useEffect(() => {
    setupInstallPrompt();
    
    const handleInstallPrompt = () => {
      setIsInstallable(true);
      setInstallPromptVisible(true);
    };

    const handleAppInstalled = () => {
      setIsInstallable(false);
      setInstallPromptVisible(false);
    };

    window.addEventListener('beforeinstallprompt', handleInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, [setInstallPromptVisible]);

  const handleInstall = async () => {
    const success = await showInstallPrompt();
    if (success) {
      setInstallPromptVisible(false);
    }
  };

  if (!isInstallable) return null;

  return (
    <AnimatePresence>
      {isInstallPromptVisible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:max-w-sm bg-card border border-gold/20 rounded-xl p-4 z-50 shadow-2xl backdrop-blur-lg"
        >
          <div className="flex items-start gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-gold to-yellow-400 rounded-lg flex items-center justify-center flex-shrink-0">
              <Download className="h-6 w-6 text-black" />
            </div>
            
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-sm mb-1">Install EWSELLS |CHARITY STORE BEYOND|</h4>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Get faster access, offline browsing, and push notifications
              </p>
              
              <div className="flex gap-2 mt-3">
                <Button 
                  size="sm" 
                  onClick={handleInstall}
                  className="text-xs px-3 py-1.5 h-auto"
                >
                  Install
                </Button>
                <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={() => setInstallPromptVisible(false)}
                  className="text-xs px-3 py-1.5 h-auto"
                >
                  Later
                </Button>
              </div>
            </div>
            
            <Button
              size="icon"
              variant="ghost"
              onClick={() => setInstallPromptVisible(false)}
              className="h-6 w-6 flex-shrink-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}