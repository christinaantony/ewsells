import { useState, useRef, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { SearchResult } from '@/services/searchService';
import { formatCurrency } from '@/lib/utils';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';

interface ProductCarouselProps {
  items: SearchResult[];
  title?: string;
  showTitle?: boolean;
}

export function ProductCarousel({ items, title = 'Related Products', showTitle = true }: ProductCarouselProps) {
  const [scrollPosition, setScrollPosition] = useState(0);
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);

  const scrollAmount = 300; // Amount to scroll on each arrow click

  useEffect(() => {
    const checkScrollButtons = () => {
      if (!containerRef.current) return;
      
      setShowLeftArrow(scrollPosition > 0);
      setShowRightArrow(
        containerRef.current.scrollWidth > 
        containerRef.current.clientWidth + scrollPosition
      );
    };

    checkScrollButtons();
    window.addEventListener('resize', checkScrollButtons);
    
    return () => {
      window.removeEventListener('resize', checkScrollButtons);
    };
  }, [scrollPosition, items]);

  const scrollLeft = () => {
    if (!containerRef.current) return;
    
    const newPosition = Math.max(0, scrollPosition - scrollAmount);
    containerRef.current.scrollTo({
      left: newPosition,
      behavior: 'smooth'
    });
    setScrollPosition(newPosition);
  };

  const scrollRight = () => {
    if (!containerRef.current) return;
    
    const newPosition = Math.min(
      containerRef.current.scrollWidth - containerRef.current.clientWidth,
      scrollPosition + scrollAmount
    );
    containerRef.current.scrollTo({
      left: newPosition,
      behavior: 'smooth'
    });
    setScrollPosition(newPosition);
  };

  const handleScroll = () => {
    if (!containerRef.current) return;
    setScrollPosition(containerRef.current.scrollLeft);
  };

  if (!items || items.length === 0) return null;

  return (
    <div className="relative">
      {showTitle && title && (
        <h4 className="text-xs font-medium text-muted-foreground mb-3">{title}</h4>
      )}
      
      {/* Navigation arrows */}
      {showLeftArrow && (
        <button 
          onClick={scrollLeft}
          className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-background/80 backdrop-blur-sm rounded-full p-2 shadow-md border border-border hover:bg-background hover:border-gold/50 transition-all"
          aria-label="Scroll left"
        >
          <ChevronLeft className="h-5 w-5 text-foreground" />
        </button>
      )}
      
      {showRightArrow && (
        <button 
          onClick={scrollRight}
          className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-background/80 backdrop-blur-sm rounded-full p-2 shadow-md border border-border hover:bg-background hover:border-gold/50 transition-all"
          aria-label="Scroll right"
        >
          <ChevronRight className="h-5 w-5 text-foreground" />
        </button>
      )}
      
      {/* Carousel container */}
      <div 
        ref={containerRef}
        className="flex overflow-x-auto scrollbar-hide snap-x snap-mandatory gap-4 pb-2 pt-1 px-1 -mx-1"
        onScroll={handleScroll}
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {items.map((item) => (
          <Link
            key={item.id}
            to={item.url}
            className={cn(
              "group flex-shrink-0 snap-start",
              "w-[180px] sm:w-[200px] md:w-[220px]",
              "flex flex-col rounded-md overflow-hidden border border-border",
              "hover:border-gold/50 transition-colors"
            )}
          >
            <div className="h-32 bg-muted relative">
              {item.image ? (
                <img
                  src={item.image}
                  alt={item.title}
                  className="h-full w-full object-cover group-hover:scale-105 transition-transform"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://via.placeholder.com/200x150?text=Product';
                  }}
                />
              ) : (
                <div className="h-full w-full flex items-center justify-center bg-muted">
                  <span className="text-xs text-muted-foreground">No image</span>
                </div>
              )}
            </div>
            <div className="p-3">
              <h3 className="text-sm font-medium truncate">{item.title}</h3>
              {item.price !== undefined && (
                <p className="text-sm text-gold font-medium mt-1">
                  {formatCurrency(item.price)}
                </p>
              )}
            </div>
          </Link>
        ))}
      </div>
      
      {/* Custom scrollbar indicator */}
      {items.length > 4 && (
        <div className="mt-3 h-1 bg-border/30 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gold rounded-full"
            style={{ 
              width: containerRef.current ? 
                `${(containerRef.current.clientWidth / containerRef.current.scrollWidth) * 100}%` : '25%',
              marginLeft: containerRef.current && containerRef.current.scrollWidth > 0 ? 
                `${(scrollPosition / containerRef.current.scrollWidth) * 100}%` : '0%',
              transition: 'margin-left 0.1s ease-out'
            }}
          />
        </div>
      )}
    </div>
  );
}
