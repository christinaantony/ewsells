import React, { useRef, useState, useEffect, forwardRef, useImperativeHandle } from 'react';
import { motion } from 'framer-motion';
import { Camera, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { faceAuthService } from '@/services/faceAuth';

interface FaceAuthProps {
  onCapture: (imageData: string) => void;
  onError: (error: string) => void;
  isRegistration?: boolean;
}

export interface FaceAuthHandle {
  stopCamera: () => void;
}

export const FaceAuth = forwardRef<FaceAuthHandle, FaceAuthProps>(({ onCapture, onError, isRegistration = false }, ref) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isCameraReady, setIsCameraReady] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [faceDetected, setFaceDetected] = useState(false);
  const [modelsLoaded, setModelsLoaded] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Stop camera function
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCameraReady(false);
  };

  // Expose stopCamera to parent via ref
  useImperativeHandle(ref, () => ({
    stopCamera
  }));

  // Load face-api models on component mount
  useEffect(() => {
    const loadModels = async () => {
      try {
        setIsLoading(true);
        await faceAuthService.loadModels();
        setModelsLoaded(true);
      } catch (error) {
        console.error('Error loading models:', error);
        onError(`Failed to load face detection models. Please visit /setup-face-models.html to set up the required models.`);
      } finally {
        setIsLoading(false);
      }
    };

    loadModels();

    // Clean up on unmount
    return () => {
      stopCamera();
    };
  }, [onError]);

  // Start camera when models are loaded
  useEffect(() => {
    if (modelsLoaded) {
      startCamera();
    }
  }, [modelsLoaded]);

  // Start face detection when camera is ready
  useEffect(() => {
    let detectionInterval: NodeJS.Timeout | null = null;

    if (isCameraReady && !capturedImage) {
      detectionInterval = setInterval(detectFace, 500);
    }

    return () => {
      if (detectionInterval) {
        clearInterval(detectionInterval);
      }
    };
  }, [isCameraReady, capturedImage]);

  const startCamera = async () => {
    try {
      setCameraError(null);
      
      // First stop any existing streams
      stopCamera();
      
      console.log('Requesting camera access...');
      
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            width: { ideal: 640 },
            height: { ideal: 480 },
            facingMode: 'user',
            frameRate: { ideal: 30 }
          },
          audio: false
        });
        
        streamRef.current = stream;
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.onloadedmetadata = () => {
            console.log('Camera stream loaded successfully');
            setIsCameraReady(true);
          };
        }
      } catch (specificError) {
        console.warn('Failed with specific constraints, trying with basic constraints:', specificError);
        
        // Fall back to basic constraints
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: false
        });
        
        streamRef.current = stream;
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.onloadedmetadata = () => {
            console.log('Camera stream loaded with basic constraints');
            setIsCameraReady(true);
          };
        }
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
      setCameraError('Unable to access camera. Please ensure you have granted camera permissions.');
      onError('Camera access denied. Please enable camera access and try again.');
    }
  };

  const detectFace = async () => {
    if (!videoRef.current || !canvasRef.current || !isCameraReady) return;

    try {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      // Set canvas dimensions to match video
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      
      const context = canvas.getContext('2d');
      
      if (!context) return;

      // Draw video frame to canvas
      context.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      // Get current frame as image data
      const imageData = canvas.toDataURL('image/jpeg');
      
      // Check if face is detected
      const img = await faceAuthService.createImageFromBase64(imageData);
      const descriptor = await faceAuthService.getFaceDescriptor(img);
      
      setFaceDetected(!!descriptor);
      console.log('Face detection result:', !!descriptor);
    } catch (error) {
      console.error('Error detecting face:', error);
    }
  };

  const captureImage = () => {
    if (!videoRef.current || !canvasRef.current || !isCameraReady) return;

    try {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');
      
      if (!context) return;

      // Set canvas dimensions to match video
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      // Draw current video frame to canvas
      context.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      // Get image data as base64 string
      const imageData = canvas.toDataURL('image/jpeg');
      setCapturedImage(imageData);
      
      // Pass image data to parent component
      onCapture(imageData);
    } catch (error) {
      console.error('Error capturing image:', error);
      onError('Failed to capture image. Please try again.');
    }
  };

  const retakeImage = () => {
    setCapturedImage(null);
  };

  return (
    <div className="flex flex-col items-center">
      <h3 className="text-lg font-semibold mb-4">Face Authentication Setup</h3>
      
      <div className="relative w-full max-w-md aspect-video bg-black rounded-lg overflow-hidden mb-4">
        {isLoading ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gold"></div>
          </div>
        ) : cameraError ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center">
            <AlertCircle className="h-12 w-12 text-red-500 mb-2" />
            <p className="text-red-500">{cameraError}</p>
            <Button 
              variant="outline" 
              className="mt-4 bg-primary text-white hover:bg-primary/80"
              onClick={() => {
                setCameraError(null);
                startCamera();
              }}
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry Camera
            </Button>
          </div>
        ) : capturedImage ? (
          <>
            <img 
              src={capturedImage} 
              alt="Captured face" 
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-2 right-2">
              <Button
                onClick={retakeImage}
                className="bg-gold hover:bg-gold/90 text-black"
                size="sm"
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                Retake
              </Button>
            </div>
          </>
        ) : (
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            muted 
            className="w-full h-full object-cover"
          />
        )}
        {/* Hidden canvas used for face detection processing */}
        <canvas 
          ref={canvasRef} 
          className="hidden" 
          width="640" 
          height="480"
        />
        {!capturedImage && (
          <>
            {faceDetected ? (
              <motion.div 
                className="absolute top-2 right-2 bg-green-500 text-white px-2 py-1 rounded-full flex items-center"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ repeat: Infinity, duration: 1.5 }}
              >
                <CheckCircle className="h-4 w-4 mr-1" />
                Face Detected
              </motion.div>
            ) : (
              <div className="absolute top-2 right-2 bg-yellow-500 text-black px-2 py-1 rounded-full flex items-center">
                <AlertCircle className="h-4 w-4 mr-1" />
                No Face Detected
              </div>
            )}
            
            {isCameraReady && (
              <div className="absolute bottom-2 right-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  className="bg-primary/20 backdrop-blur-sm text-white hover:bg-primary/40"
                  onClick={() => {
                    if (videoRef.current && videoRef.current.srcObject) {
                      const stream = videoRef.current.srcObject as MediaStream;
                      stream.getTracks().forEach(track => track.stop());
                    }
                    startCamera();
                  }}
                >
                  <RefreshCw className="h-3 w-3 mr-1" />
                  Reset Camera
                </Button>
              </div>
            )}
          </>
        )}
      </div>

      <div className="flex justify-center space-x-4 w-full">
        {!capturedImage && (
          <Button
            onClick={captureImage}
            disabled={isLoading || !isCameraReady || !faceDetected}
            className="bg-gold hover:bg-gold/90 text-black"
          >
            <Camera className="mr-2 h-4 w-4" />
            {isRegistration ? 'Capture Face for Registration' : 'Authenticate with Face'}
          </Button>
        )}
      </div>

      {isRegistration && (
        <p className="text-xs text-muted-foreground mt-4 text-center max-w-md">
          Please position your face clearly in the frame. This image will be used for future login authentication.
          Make sure you're in a well-lit environment with your face clearly visible.
        </p>
      )}
    </div>
  );
});

FaceAuth.displayName = 'FaceAuth';

export default FaceAuth;
