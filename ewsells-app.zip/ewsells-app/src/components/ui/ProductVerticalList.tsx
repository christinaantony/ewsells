import { Link } from 'react-router-dom';
import { Package, Grid } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatCurrency } from '@/lib/utils';
import type { SearchResult } from '@/services/searchService';

interface ProductVerticalListProps {
  items: SearchResult[];
  title?: string;
  showTitle?: boolean;
}

export function ProductVerticalList({ items, title = 'Products', showTitle = true }: ProductVerticalListProps) {
  if (!items || items.length === 0) return null;

  return (
    <div className="w-full">
      {showTitle && (
        <h3 className="text-xl font-semibold mb-4">{title}</h3>
      )}
      
      <div className="flex flex-col space-y-4">
        {items.map(item => (
          <div 
            key={item.id}
            className="border border-border rounded-lg overflow-hidden hover:border-gold/50 transition-colors flex flex-col md:flex-row shadow-sm hover:shadow-md"
          >
            <Link to={item.url} className="md:w-48 lg:w-56 h-48 md:h-auto bg-muted relative flex-shrink-0">
              {item.image ? (
                <img
                  src={item.image}
                  alt={item.title}
                  className="h-full w-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://via.placeholder.com/300x200?text=Product';
                  }}
                />
              ) : (
                <div className="h-full w-full flex items-center justify-center bg-muted">
                  <Package className="h-12 w-12 text-muted-foreground" />
                </div>
              )}
            </Link>
            
            <div className="p-4 flex-grow flex flex-col justify-between">
              <div>
                <Link to={item.url} className="hover:text-gold transition-colors">
                  <h3 className="font-medium text-lg">{item.title}</h3>
                </Link>
                
                {item.category && (
                  <div className="text-xs text-muted-foreground mt-1 flex items-center">
                    <Grid className="h-3 w-3 mr-1" />
                    {item.category}
                  </div>
                )}
                
                {item.description && (
                  <p className="text-sm text-muted-foreground mt-3 line-clamp-2">
                    {item.description}
                  </p>
                )}
              </div>
              
              <div className="mt-4 flex items-center justify-between">
                {item.price !== undefined && (
                  <div className="text-gold font-medium text-lg">
                    {formatCurrency(item.price)}
                  </div>
                )}
                
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="border-gold/30 hover:border-gold hover:bg-gold/10"
                  asChild
                >
                  <Link to={item.url}>View Details</Link>
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
