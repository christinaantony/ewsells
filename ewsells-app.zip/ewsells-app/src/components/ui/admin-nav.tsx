import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Shield, Users, ShoppingBag, Settings, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { auth, db } from '@/lib/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { useStore } from '@/store/useStore';

export function AdminNav() {
  const location = useLocation();
  const [isAdmin, setIsAdmin] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const { user } = useStore();

  useEffect(() => {
    const checkAdminStatus = async () => {
      if (!user) return;

      try {
        const userRef = doc(db, 'users', user.id);     //const userRef = doc(db, 'users', user.uid);
        const userDoc = await getDoc(userRef);
        
        if (userDoc.exists() && userDoc.data().role === 'admin') {
          setIsAdmin(true);
        }
      } catch (error) {
        console.error('Error checking admin status:', error);
      }
    };

    checkAdminStatus();
  }, [user]);

  if (!isAdmin) return null;

  const adminLinks = [
    {
      name: 'Seller Approvals',
      href: '/admin/seller-approvals',
      icon: <Users className="h-4 w-4 mr-2" />
    },
    {
      name: 'Orders',
      href: '/admin/orders',
      icon: <ShoppingBag className="h-4 w-4 mr-2" />
    },
    {
      name: 'Settings',
      href: '/admin/settings',
      icon: <Settings className="h-4 w-4 mr-2" />
    }
  ];

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <div className="flex flex-col items-end">
        {isOpen && (
          <div className="bg-card border border-border rounded-lg shadow-lg mb-2 overflow-hidden">
            <div className="p-2">
              {adminLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.href}
                  className={`flex items-center px-4 py-2 text-sm rounded-md transition-colors ${
                    location.pathname === link.href
                      ? 'bg-gold/10 text-gold'
                      : 'hover:bg-muted'
                  }`}
                >
                  {link.icon}
                  {link.name}
                </Link>
              ))}
            </div>
          </div>
        )}
        
        <Button
          onClick={() => setIsOpen(!isOpen)}
          className="bg-gold hover:bg-gold/90 text-black flex items-center gap-2"
        >
          <Shield className="h-4 w-4" />
          Admin
          {isOpen ? (
            <ChevronDown className="h-4 w-4" />
          ) : (
            <ChevronUp className="h-4 w-4" />
          )}
        </Button>
      </div>
    </div>
  );
}
