import React from 'react';
import { motion } from 'framer-motion';
import { useCounter } from '@/hooks/useScrollAnimation';

interface AnimatedCounterProps {
  value: number;
  duration?: number;
  prefix?: string;
  suffix?: string;
  className?: string;
}

export function AnimatedCounter({ 
  value, 
  duration = 2000, 
  prefix = '', 
  suffix = '', 
  className 
}: AnimatedCounterProps) {
  const counterRef = useCounter(value, duration);

  return (
    <motion.span
      ref={counterRef}
      className={className}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      {prefix}0{suffix}
    </motion.span>
  );
}