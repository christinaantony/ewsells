import React from 'react';
import { motion } from 'framer-motion';
import { formatCurrency } from '@/lib/utils';

interface ImpactBarProps {
  basePrice: number;
  upliftPercent: number;
  quantity?: number;
}

export function ImpactBar({ basePrice, upliftPercent, quantity = 1 }: ImpactBarProps) {
  const subtotal = basePrice * quantity;
  const uplift = subtotal * (upliftPercent / 100);
  const charity = uplift * 0.8;
  const ops = uplift * 0.2;
  const total = subtotal + uplift;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card/90 backdrop-blur-lg border border-gold/20 rounded-xl p-4 sticky top-20 z-30"
    >
      <h3 className="text-gold font-semibold mb-3">Impact Breakdown</h3>
      
      <div className="space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-muted-foreground">Base Price</span>
          <span>{formatCurrency(subtotal)}</span>
        </div>
        
        <div className="flex justify-between">
          <span className="text-muted-foreground">Uplift ({upliftPercent}%)</span>
          <span className="text-gold">+{formatCurrency(uplift)}</span>
        </div>
        
        <div className="border-t border-border pt-2">
          <div className="flex justify-between font-medium">
            <span>Total</span>
            <span>{formatCurrency(total)}</span>
          </div>
        </div>
        
        <div className="bg-muted/50 rounded-lg p-3 mt-3">
          <div className="text-xs text-muted-foreground mb-2">Your contribution goes to:</div>
          <div className="flex justify-between text-sm">
            <span className="text-green-400">80% Charity</span>
            <span className="text-green-400">{formatCurrency(charity)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-blue-400">20% Operations</span>
            <span className="text-blue-400">{formatCurrency(ops)}</span>
          </div>
        </div>
      </div>

      <motion.div
        className="impact-bar h-1 rounded-full mt-3"
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ duration: 1.5, delay: 0.5 }}
      />
    </motion.div>
  );
}