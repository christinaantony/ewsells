import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { X, UserPlus, FileText, Check } from 'lucide-react';
import { Button } from './button';
import { auth, db } from '@/lib/firebase';
import { doc, getDoc } from 'firebase/firestore';

interface SellerModalProps {
  isOpen: boolean;
  onClose: () => void;
  isApproved?: boolean;
}

export function SellerModal({ isOpen, onClose, isApproved = false }: SellerModalProps) {
  const navigate = useNavigate();
  const [status, setStatus] = React.useState<'pending' | 'approved' | 'rejected' | 'none'>('none');
  const [rejectionReason, setRejectionReason] = React.useState<string>('');

  React.useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const user = auth.currentUser;
        if (!user) { setStatus('none'); return; }
        const ref = doc(db, 'seller-registrations', user.uid);
        const snap = await getDoc(ref);
        if (cancelled) return;
        if (!snap.exists()) { setStatus('none'); return; }
        const data = snap.data() as any;
        const st = data?.status as 'pending' | 'approved' | 'rejected';
        setStatus(st || 'none');
        if (st === 'rejected') setRejectionReason(data?.rejectionReason || 'Your application was rejected. You may resubmit.');
      } catch {
        setStatus('none');
      }
    })();
    return () => { cancelled = true; };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-card rounded-xl shadow-xl max-w-md w-full p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Become a Seller</h2>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        <p className="text-muted-foreground mb-6">
          Complete these two steps to start selling your products on our platform.
        </p>

        <div className="space-y-4">
          <Button
            onClick={() => {
              if (status === 'approved' || status === 'pending') return;
              onClose();
              navigate('/seller-registration');
            }}
            className="w-full flex items-center justify-between"
            disabled={status === 'approved' || status === 'pending'}
            variant={status === 'approved' || status === 'pending' ? 'outline' : undefined as any}
          >
            <div className="flex items-center">
              <UserPlus className="mr-2 h-5 w-5" />
              <span>Seller Registration</span>
            </div>
            <div className="flex items-center gap-2">
              {status === 'approved' && (
                <span className="text-xs px-2 py-1 rounded bg-green-100 text-green-800 flex items-center gap-1">
                  <Check size={14} />
                  Approved
                </span>
              )}
              {status === 'pending' && (
                <span className="text-xs px-2 py-1 rounded bg-yellow-100 text-yellow-800">Pending</span>
              )}
              <span className="text-xs bg-black/10 px-2 py-1 rounded">Step 1</span>
            </div>
          </Button>

          <Button
            onClick={() => {
              if (isApproved || status === 'approved') {
                onClose();
                navigate('/seller-agreement');
              }
            }}
            className="w-full flex items-center justify-between"
            disabled={!(isApproved || status === 'approved')}
          >
            <div className="flex items-center">
              <FileText className="mr-2 h-5 w-5" />
              <span>Seller Agreement</span>
            </div>
            <span className="text-xs bg-black/10 px-2 py-1 rounded">Step 2</span>
          </Button>
        </div>

        {(status === 'pending') && (
          <p className="text-sm text-amber-500 mt-4">
            Your registration is pending admin review. The Seller Agreement unlocks after approval.
          </p>
        )}

        {(status === 'approved') && (
          <div className="mt-4 text-sm text-green-700 flex items-center gap-2">
            <Check size={16} />
            <span>Seller registration approved. Proceed to the agreement to activate your seller profile.</span>
          </div>
        )}

        {(status === 'rejected') && (
          <div className="mt-4 text-sm">
            <div className="text-red-600 font-medium">Registration Rejected</div>
            <p className="text-muted-foreground mt-1">Reason: {rejectionReason}</p>
            <p className="mt-2">You can update your details and resubmit from the registration page.</p>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}
