import { useEffect, useState } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase';

type DeliveryStatusProps = {
  deliveryId: string;
};

type DeliveryData = {
  status: 'pending' | 'processing' | 'shipped' | 'in_transit' | 'delivered' | 'failed';
  trackingNumber?: string;
  courier?: 'shiprocket' | 'nimbuzpost' | 'other';
  estimatedDelivery?: string;
  lastUpdated?: string;
};

export function DeliveryStatus({ deliveryId }: DeliveryStatusProps) {
  const [delivery, setDelivery] = useState<DeliveryData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsubscribe = onSnapshot(doc(db, 'deliveries', deliveryId),
      (doc) => {
        if (doc.exists()) {
          setDelivery(doc.data() as DeliveryData);
          setLoading(false);
        } else {
          setError('Delivery not found');
          setLoading(false);
        }
      },
      (err) => {
        setError(err.message);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [deliveryId]);

  if (loading) return <div>Loading delivery status...</div>;
  if (error) return <div className="text-red-500">{error}</div>;
  if (!delivery) return <div>No delivery data available</div>;

  return (
    <div className="border rounded-lg p-4">
      <h3 className="font-bold mb-2">Delivery Status</h3>
      <div className="space-y-2">
        <div>
          <span className="font-medium">Status:</span>
          <span className="ml-2 capitalize">{delivery.status.replace('_', ' ')}</span>
        </div>
        {delivery.trackingNumber && (
          <div>
            <span className="font-medium">Tracking:</span>
            <span className="ml-2">{delivery.trackingNumber}</span>
          </div>
        )}
        {delivery.estimatedDelivery && (
          <div>
            <span className="font-medium">Estimated Delivery:</span>
            <span className="ml-2">{delivery.estimatedDelivery}</span>
          </div>
        )}
      </div>
    </div>
  );
}
