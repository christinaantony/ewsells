import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Heart, ShoppingCart, Star } from 'lucide-react';
import ProductImageCarousel from './ProductImageCarousel';
import { formatCurrency } from '@/lib/utils';
import { useProductRating } from '@/hooks/useProductRating';

interface ProductCardProps {
  id: string;
  name: string;
  description?: React.ReactNode;
  price: number;
  finalPrice?: number;
  sellerPrice?: number;
  category?: string;
  imageUrl?: string;
  imageUrls?: string[];
  badges?: string[];
  customizable?: boolean;
  isWishlisted?: boolean;
  onWishlistClick?: () => void;
  onAddToCart?: () => void;
  onClick?: () => void;
  viewMode?: 'grid' | 'list';
  className?: string;
  // Optional ratings (numeric average and count) to display a ratings chip
  ratingValue?: number;
  ratingCount?: number;
  onRatingClick?: () => void;
  // Optional: pass through the product Firestore doc data so we can read aggregate fields if present
  docData?: any;
}

export function ProductCard({
  id,
  name,
  description = '',
  price,
  finalPrice,
  sellerPrice,
  category = '',
  imageUrl = '',
  imageUrls = [],
  badges = [],
  customizable = false,
  isWishlisted = false,
  onWishlistClick,
  onAddToCart,
  onClick,
  viewMode = 'grid',
  className = '',
  ratingValue,
  ratingCount,
  onRatingClick,
  docData,
}: ProductCardProps) {
  const displayPrice = finalPrice ?? sellerPrice ?? price ?? 0;
  const images = imageUrls.length ? imageUrls : imageUrl ? [imageUrl] : [];
  const categoryColors: Record<string, string> = {
    'handmade': 'bg-purple-500',
    'jewelry': 'bg-pink-500',
    'homeDecor': 'bg-amber-700',
    'accessories': 'bg-blue-400',
    'clothing': 'bg-green-500',
    'art': 'bg-yellow-500',
    'stationery': 'bg-slate-500',
    'charity-craft': 'bg-emerald-600',
    'scrap-store': 'bg-amber-600',
    'green-cup': 'bg-green-600',
    'organic-store': 'bg-lime-600',
    'moms-made': 'bg-pink-400',
    'beauty': 'bg-fuchsia-500',
    'household': 'bg-blue-500',
    'birthday': 'bg-rose-500',
    'food': 'bg-orange-500',
    'books': 'bg-indigo-500',
  };

  const categoryColor = categoryColors[category.toLowerCase()] || 'bg-gray-500';

  // Pull actual rating from Firebase if not provided via props
  const { rating: fetchedRating, count: fetchedCount } = useProductRating(id, docData);
  const effectiveRating = typeof ratingValue === 'number' ? ratingValue : fetchedRating;
  const effectiveCount = typeof ratingCount === 'number' ? ratingCount : fetchedCount;

  if (viewMode === 'list') {
    return (
      <div 
        className={`flex flex-col sm:flex-row bg-card rounded-lg overflow-hidden border border-border hover:shadow-lg transition-shadow duration-200 ${className}`}
        onClick={onClick}
      >
        <div className="relative w-full sm:w-48 h-48 flex-shrink-0">
          <div className="overflow-hidden h-full w-full">
            <ProductImageCarousel
              images={images}
              alt={name}
              className="w-full h-full object-cover"
              aspect="free"
            />
          </div>
          {category && (
            <Badge className="absolute top-2 left-2 inline-flex items-center h-8 px-3 text-sm rounded-md bg-gold text-black border border-amber-300 shadow-sm hover:shadow-md hover:brightness-95 transition-transform duration-150">
              {category}
            </Badge>
          )}
          {customizable && (
            <Badge className="absolute top-2 left-2 translate-y-10 inline-flex items-center h-8 px-3 text-sm rounded-md bg-emerald-500/90 text-white border border-emerald-400/50 shadow-sm hover:shadow-md hover:brightness-110 transition-transform duration-150">
              Customizable
            </Badge>
          )}
        </div>
        <div className="flex-1 p-4 flex flex-col">
          <div className="flex justify-between items-start gap-4">
            <h3 className="text-lg font-semibold line-clamp-2 group-hover:text-gold transition-colors">
              {name}
            </h3>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 rounded-full"
              onClick={(e) => {
                e.stopPropagation();
                onWishlistClick?.();
              }}
            >
              <Heart className={`h-4 w-4 ${isWishlisted ? 'fill-red-500 text-red-500' : ''}`} />
            </Button>
          </div>
          {description && (
            <div className="text-sm text-muted-foreground mt-2 line-clamp-3">
              {description}
            </div>
          )}
          {/* Ratings: star-only, not a button (list view) */}
          <div className="mt-3">
            <div
              className="inline-flex items-center text-sm"
              title={typeof effectiveRating === 'number' ? `Rating ${effectiveRating.toFixed(1)} out of 5${typeof effectiveCount === 'number' ? ` • ${effectiveCount} ratings` : ''}` : 'Not yet rated'}
              aria-label={typeof effectiveRating === 'number' ? `Rating ${effectiveRating.toFixed(1)} out of 5` : 'Not yet rated'}
            >
              <Star className="h-4 w-4 text-amber-400 fill-amber-400" />
              {typeof effectiveRating === 'number' ? (
                <span className="ml-1 text-xs text-muted-foreground">{effectiveRating.toFixed(1)}</span>
              ) : null}
            </div>
          </div>
          <div className="mt-auto pt-4">
            <div className="flex items-center justify-between">
              <span className="font-bold text-base">
                {formatCurrency(displayPrice)}
              </span>
              <Button 
                className="bg-gold hover:bg-amber-500 text-black border border-amber-300 rounded-md px-3 py-1.5 h-8 text-sm font-medium transition-colors shadow-sm hover:shadow flex items-center gap-1.5 whitespace-nowrap"
                onClick={(e) => {
                  e.stopPropagation();
                  onAddToCart?.();
                }}
              >
                <ShoppingCart className="h-3.5 w-3.5" />
                <span>Add to Cart</span>
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Grid view (default)
  return (
    <div 
      className={`flex flex-col h-full bg-card rounded-lg border shadow-sm hover:shadow-md transition-shadow duration-200 group cursor-pointer ${className}`}
      onClick={onClick}
    >
      <div className="relative h-48 w-full overflow-hidden">
        <ProductImageCarousel
          images={images}
          alt={name}
          className="w-full h-full object-cover"
          aspect="free"
        />
        {category && (
          <Badge className="absolute top-2 left-2 inline-flex items-center h-8 px-3 text-sm rounded-md bg-gold text-black border border-amber-300 shadow-sm hover:shadow-md hover:brightness-95 transition-transform duration-150">
            {category}
          </Badge>
        )}
        {customizable && (
          <Badge className="absolute top-2 left-2 translate-y-10 inline-flex items-center h-8 px-3 text-sm rounded-md bg-emerald-500/90 text-white border border-emerald-400/50 shadow-sm hover:shadow-md hover:brightness-110 transition-transform duration-150">
            Customizable
          </Badge>
        )}
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-2 right-2 bg-black/50 hover:bg-black/70 text-white h-8 w-8 rounded-full"
          onClick={(e) => {
            e.stopPropagation();
            onWishlistClick?.();
          }}
        >
          <Heart className={`h-3.5 w-3.5 ${isWishlisted ? 'fill-red-500 text-red-500' : ''}`} />
        </Button>
      </div>
      <div className="p-4 flex flex-col flex-1">
        <h3 className="font-semibold text-base mb-1 line-clamp-1">
          {name}
        </h3>
        {description && (
          <div className="text-sm text-muted-foreground line-clamp-2 mb-3">
            {description}
          </div>
        )}
        {/* Ratings: star-only, not a button (grid view) */}
        <div className="mb-3">
          <div
            className="inline-flex items-center text-sm"
            title={typeof effectiveRating === 'number' ? `Rating ${effectiveRating.toFixed(1)} out of 5${typeof effectiveCount === 'number' ? ` • ${effectiveCount} ratings` : ''}` : 'Not yet rated'}
            aria-label={typeof effectiveRating === 'number' ? `Rating ${effectiveRating.toFixed(1)} out of 5` : 'Not yet rated'}
          >
            <Star className="h-4 w-4 text-amber-400 fill-amber-400" />
            {typeof effectiveRating === 'number' ? (
              <span className="ml-1 text-xs text-muted-foreground">{effectiveRating.toFixed(1)}</span>
            ) : null}
          </div>
        </div>
        <div className="mt-auto">
          <div className="flex items-center justify-between">
            <span className="font-bold text-base">
              {formatCurrency(displayPrice)}
            </span>
            <Button 
              className="bg-gold hover:bg-amber-500 text-black border border-amber-300 rounded-md px-3 py-1.5 h-8 text-sm font-medium transition-colors shadow-sm hover:shadow flex items-center gap-1.5 whitespace-nowrap"
              onClick={(e) => {
                e.stopPropagation();
                onAddToCart?.();
              }}
            >
              <ShoppingCart className="h-3.5 w-3.5" />
              <span>Add to Cart</span>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
