import React from 'react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';

interface RadioGroupProps {
  value: string;
  onValueChange: (value: string) => void;
  children: React.ReactNode;
  className?: string;
}

const RadioGroup = ({ value, onValueChange, className, children }: RadioGroupProps) => {
  return (
    <div 
      className={className} 
      onChange={(e: React.ChangeEvent<HTMLDivElement>) => {
        const target = e.target as HTMLInputElement;
        if (target.type === 'radio' && target.checked) {
          onValueChange(target.value);
        }
      }}
    >
      {React.Children.map(children, child => {
        if (React.isValidElement(child) && child.type === RadioGroupItem) {
          return React.cloneElement(child, { 
            checked: value === child.props.value
          } as any);
        }
        return child;
      })}
    </div>
  );
};

const RadioGroupItem = ({ value, id, checked }: { value: string; id: string; checked?: boolean }) => (
  <input 
    type="radio" 
    id={id}
    value={value}
    checked={checked}
    className="mr-2"
  />
);

type ShippingOption = {
  id: 'shiprocket' | 'nimbuzpost' | 'custom';
  label: string;
  description: string;
};

type ShippingOptionsProps = {
  orderId: string;
  onSave: (option: 'shiprocket' | 'nimbuzpost' | 'custom', details?: string) => void;
  initialMethod?: string;
};

const shippingOptions: ShippingOption[] = [
  {
    id: 'shiprocket',
    label: 'Shiprocket',
    description: 'Fast and reliable shipping with tracking'
  },
  {
    id: 'nimbuzpost',
    label: 'NimbuzPost',
    description: 'Economical shipping solution'
  },
  {
    id: 'custom',
    label: 'Custom Shipping',
    description: 'Use your own shipping provider'
  }
];

export function ShippingOptions({ orderId, onSave, initialMethod }: ShippingOptionsProps) {
  const [selectedOption, setSelectedOption] = useState<string>(initialMethod || 'shiprocket');
  const [customDetails, setCustomDetails] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await onSave(
        selectedOption as 'shiprocket' | 'nimbuzpost' | 'custom',
        selectedOption === 'custom' ? customDetails : undefined
      );
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="font-bold">Shipping Options for Order {orderId}</h3>
      <RadioGroup 
        value={selectedOption} 
        onValueChange={setSelectedOption}
        className="space-y-2"
      >
        {shippingOptions.map((option) => (
          <div key={option.id} className="flex items-center space-x-2">
            <RadioGroupItem value={option.id} id={option.id} />
            <Label htmlFor={option.id}>
              <div className="font-medium">{option.label}</div>
              <div className="text-sm text-muted-foreground">{option.description}</div>
            </Label>
          </div>
        ))}
      </RadioGroup>

      {selectedOption === 'custom' && (
        <div className="space-y-2">
          <Label htmlFor="customDetails">Shipping Details</Label>
          <Input 
            id="customDetails"
            value={customDetails}
            onChange={(e) => setCustomDetails(e.target.value)}
            placeholder="Enter tracking number or shipping details"
          />
        </div>
      )}

      <Button 
        onClick={handleSave}
        disabled={isSaving}
        className="w-full"
      >
        {isSaving ? 'Saving...' : 'Save Shipping Option'}
      </Button>
    </div>
  );
}
