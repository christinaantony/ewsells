import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Heart, ShoppingCart } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';
import ProductImageCarousel from '@/components/ProductImageCarousel';

// Define the scrap item type
export interface ScrapItem {
  id: string;
  title: string;
  creator: string;
  imageUrl: string;
  imageUrls?: string[];
  price: number;
  category: string;
  cause: string;
  impact: string;
  productId?: string;
  finalPrice?: number;
  sellerPrice?: number;
  badges?: string[];
}

interface ScrapItemCardProps {
  item: ScrapItem;
  viewMode: 'grid' | 'list';
  onWishlistClick?: () => void;
  onAddToCart?: (product: any) => void;
  isWishlisted?: boolean;
  onClick?: () => void;
  className?: string;
}

// Map categories to colors
const categoryColors: Record<string, string> = {
  'metal': 'bg-slate-500',
  'fabric': 'bg-pink-500',
  'wood': 'bg-amber-700',
  'glass': 'bg-blue-400',
  'plastic': 'bg-green-500',
  'paper': 'bg-yellow-500',
  'electronics': 'bg-purple-500'
};

export function ScrapItemCard({ 
  item, 
  viewMode = 'grid', 
  onWishlistClick, 
  onAddToCart, 
  isWishlisted = false,
  onClick,
  className = ''
}: ScrapItemCardProps) {
  const { title, creator, imageUrl, imageUrls = [], price, category, cause, impact, finalPrice, sellerPrice, badges = [] } = item;
  const displayPrice = finalPrice ?? sellerPrice ?? price;
  const images = imageUrls.length ? imageUrls : imageUrl ? [imageUrl] : [];
  const categoryColor = categoryColors[category.toLowerCase()] || 'bg-gray-500';

  if (viewMode === 'grid') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className={className}
        onClick={onClick}
      >
        <Card className="h-full flex flex-col rounded-lg bg-card shadow-sm hover:shadow-md transition-shadow duration-200 card-hover cursor-pointer">
          {/* Image Container */}
          <div className="relative aspect-square w-full overflow-hidden bg-gray-50 rounded-t-lg">
            <ProductImageCarousel 
              images={images}
              alt={title}
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              aspect="square"
            />
            
            {/* Badges */}
            <div className="absolute top-2 left-2 flex gap-1">
              {badges.map((badge, i) => (
                <Badge key={i} variant="secondary" className="text-xs">
                  {badge}
                </Badge>
              ))}
              <Badge className={`text-xs ${categoryColor} text-white`}>
                {category}
              </Badge>
            </div>

            {/* Wishlist Button */}
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-2 right-2 bg-black/50 hover:bg-black/70 text-white h-8 w-8 rounded-full hover:bg-black/70 transition-colors"
              onClick={(e) => {
                e.stopPropagation();
                onWishlistClick?.();
              }}
            >
              <Heart 
                className={`h-4 w-4 ${isWishlisted ? 'fill-current' : ''}`} 
                fill={isWishlisted ? 'currentColor' : 'none'}
              />
            </Button>
          </div>

          {/* Content */}
          <CardContent className="p-4 flex-1 flex flex-col">
            <div className="flex-1">
              <h3 className="font-medium text-sm md:text-base line-clamp-2 mb-1 group-hover:text-primary">
                {title}
              </h3>
              <p className="text-xs text-muted-foreground mb-2">By {creator}</p>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-sm font-semibold">{formatCurrency(displayPrice)}</span>
                {finalPrice && finalPrice !== price && (
                  <span className="text-xs text-muted-foreground line-through">
                    {formatCurrency(price)}
                  </span>
                )}
              </div>
            </div>
            
            <Button
              variant="default"
              className="w-full flex items-center justify-center gap-2 mt-2"
              onClick={(e) => {
                e.stopPropagation();
                onAddToCart?.(item);
              }}
            >
              <ShoppingCart className="h-4 w-4" />
              Add to Cart
            </Button>
          </CardContent>
        </Card>
      </motion.div>
    );
  }

  // List view
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={className}
      onClick={onClick}
    >
      <Card className="overflow-hidden">
        <div className="flex">
          {/* Image Container */}
          <div className="w-32 h-32 flex-shrink-0 relative">
            <ProductImageCarousel 
              images={images}
              alt={title}
              className="h-full w-full object-contain p-2"
              aspect="free"
            />
          </div>

          {/* Content */}
          <div className="flex-1 p-3 flex flex-col">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold text-base mb-1">{title}</h3>
                <p className="text-muted-foreground text-xs">By {creator}</p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={(e) => {
                  e.stopPropagation();
                  onWishlistClick?.();
                }}
              >
                <Heart
                  className={`h-4 w-4 ${isWishlisted ? 'fill-red-500 text-red-500' : 'text-gray-600'}`}
                />
              </Button>
            </div>

            <div className="mt-2 flex gap-1 flex-wrap">
              {badges.map((badge, i) => (
                <Badge key={i} variant="secondary" className="text-xs">
                  {badge}
                </Badge>
              ))}
              <Badge className={`text-xs ${categoryColor} text-white`}>
                {category}
              </Badge>
            </div>

            <div className="mt-2">
              <p className="text-xs text-gray-600">{cause}</p>
              <p className="text-xs text-emerald-600 font-medium">{impact}</p>
            </div>
            
            <div className="flex justify-between items-center mt-4">
              <div>
                <p className="font-medium text-lg">
                  {formatCurrency(displayPrice)}
                  {finalPrice && finalPrice > displayPrice && (
                    <span className="ml-1 text-xs text-gray-500 line-through">
                      {formatCurrency(finalPrice)}
                    </span>
                  )}
                </p>
              </div>
              <Button
                variant="default"
                className="h-9 flex items-center justify-center gap-2"
                onClick={(e) => { 
                  e.stopPropagation();
                  onAddToCart?.(item);
                }}
              >
                <ShoppingCart className="h-4 w-4" />
                Add to Cart
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}
