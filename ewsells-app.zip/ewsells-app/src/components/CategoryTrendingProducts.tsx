import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, ShoppingBag, Heart, Users, Zap, Star, Eye, Plus, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { formatCurrency } from '@/lib/utils';
import type { Product } from '@/types';
import { useNavigate } from 'react-router-dom';
import { useStore } from '@/store/useStore';
import { useCart } from '@/contexts/CartContext';
import { useAuthGate } from '@/hooks/useAuthGate';

const categories = [
  {
    name: 'Charity Craft',
    description: 'Handmade items supporting artisan communities',
    icon: Heart,
    color: 'from-rose-500 to-pink-600'
  },
  {
    name: 'Organic Store',
    description: 'Fresh, sustainable produce from local farms',
    icon: ShoppingBag,
    color: 'from-green-500 to-emerald-600'
  },
  {
    name: 'Scrap Store',
    description: 'Upcycled treasures giving new life to materials',
    icon: Zap,
    color: 'from-amber-500 to-orange-600'
  },
  {
    name: 'Home Plants',
    description: 'Indoor greens to brighten and purify your home',
    icon: Users,
    color: 'from-emerald-500 to-green-600'
  },
  {
    name: 'Beauty Homemade',
    description: 'Natural, handcrafted skincare and self-care',
    icon: Heart,
    color: 'from-purple-500 to-pink-600'
  },
  {
    name: 'Home Decor',
    description: 'Artisanal decor to style your space beautifully',
    icon: ShoppingBag,
    color: 'from-indigo-500 to-purple-600'
  }
];

interface CategoryTrendingProductsProps {
  products: Product[];
  isInView: boolean;
}

export function CategoryTrendingProducts({ products, isInView }: CategoryTrendingProductsProps) {
  const navigate = useNavigate();
  const { toggleWishlist, isWishlisted } = useStore();
  const { addToCart, cartItems } = useCart();
  const { runOrLogin } = useAuthGate();

  // Determine if any category has matching products
  const anyCategoryMatch = categories.some((category) =>
    products.some((product) => {
      const prodCat = (product.category || '').toLowerCase();
      const catKey = category.name.toLowerCase().split(' ')[0];
      return prodCat.includes(catKey) || category.name.toLowerCase().includes(prodCat);
    })
  );

  // Calculate total price including uplift
  const calculateTotalPrice = (product: Product) => {
    const uplift = product.basePriceSeller * (product.upliftPercent / 100);
    return product.basePriceSeller + uplift;
  };

  // Calculate charity impact amount (uplift goes to charity)
  const calculateCharityImpact = (product: Product) => {
    return product.basePriceSeller * (product.upliftPercent / 100);
  };

  // Check if a product is in the cart
  const isInCart = (productId: string) => {
    return cartItems.some(item => item.productId === productId);
  };

  // Handle add to cart with auth gate (require sign-in before adding)
  const handleAddToCart = async (e: React.MouseEvent, product: Product) => {
    e.stopPropagation();
    runOrLogin(async () => {
      await addToCart({
        id: product.id,
        productId: product.id,
        name: product.title,
        price: calculateTotalPrice(product),
        quantity: 1,
        imageUrl: product.images?.[0],
        category: product.category,
        sellerId: product.sellerId
      });
    });
  };

  return (
    <section className="py-32 relative overflow-hidden bg-gradient-to-br from-background via-background/95 to-surface/30">
      {/* Ultra-Modern Background Elements */}
      <div className="absolute inset-0">
        {/* Primary gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-gold/8 via-transparent to-primary/8" />
        
        {/* Animated floating orbs */}
        <motion.div 
          className="absolute top-20 right-20 w-96 h-96 bg-gradient-to-r from-gold/10 to-amber/5 rounded-full blur-3xl"
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.6, 0.3]
          }}
          transition={{ 
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div 
          className="absolute bottom-32 left-16 w-80 h-80 bg-gradient-to-l from-primary/10 to-blue/5 rounded-full blur-3xl"
          animate={{ 
            scale: [1.2, 1, 1.2],
            opacity: [0.4, 0.7, 0.4]
          }}
          transition={{ 
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 2
          }}
        />
        <motion.div 
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-r from-emerald/8 to-teal/4 rounded-full blur-2xl"
          animate={{ 
            rotate: [0, 360],
            scale: [1, 1.1, 1]
          }}
          transition={{ 
            duration: 15,
            repeat: Infinity,
            ease: "linear"
          }}
        />

        {/* Subtle grid pattern */}
        <div className="absolute inset-0 opacity-[0.02]" style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,255,255,0.3) 1px, transparent 0)`,
          backgroundSize: '50px 50px'
        }} />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <motion.div
          initial={{ opacity: 1, y: 0 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-center mb-20"
        >
          {/* Modern badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-gold/20 to-amber/10 backdrop-blur-xl border border-gold/30 rounded-full mb-8"
          >
            <div className="w-2 h-2 bg-gold rounded-full animate-pulse" />
            <span className="text-gold font-semibold text-sm tracking-wide uppercase">Curated Collections</span>
          </motion.div>

          {/* Enhanced title with gradient text */}
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-3xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight"
          >
            <span className="bg-gradient-to-r from-foreground via-foreground/90 to-foreground/70 bg-clip-text text-transparent">
              Trending by
            </span>
            <br />
            <span className="bg-gradient-to-r from-gold via-amber-400 to-gold bg-clip-text text-transparent">
              Category
            </span>
          </motion.h2>

          {/* Enhanced description */}
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-muted-foreground/70 text-lg max-w-2xl mx-auto leading-relaxed"
          >
            Discover handpicked items from our community of makers, thoughtfully organized by category to help you find exactly what you're looking for
          </motion.p>

          {/* Decorative line */}
          <motion.div
            initial={{ scaleX: 0 }}
            animate={isInView ? { scaleX: 1 } : {}}
            transition={{ duration: 1, delay: 0.6 }}
            className="w-24 h-1 bg-gradient-to-r from-transparent via-gold to-transparent mx-auto mt-8"
          />
        </motion.div>

        {/* Category Sections */}
        <div className="space-y-32">
          {categories.map((category, categoryIndex) => {
            const categoryProducts = products.filter(product => 
              product.category.toLowerCase().includes(category.name.toLowerCase().split(' ')[0]) ||
              category.name.toLowerCase().includes(product.category.toLowerCase())
            ).slice(0, 4);

            if (categoryProducts.length === 0) return null;

            return (
              <div key={category.name} className="relative">
                {/* Modern Section Divider */}
                {categoryIndex > 0 && (
                  <motion.div
                    initial={{ opacity: 0, scaleX: 0 }}
                    animate={isInView ? { opacity: 1, scaleX: 1 } : {}}
                    transition={{ duration: 1.2, delay: categoryIndex * 0.1 }}
                    className="relative mb-20"
                  >
                    <div className="flex items-center justify-center">
                      <div className="flex-1 h-px bg-gradient-to-r from-transparent via-white/20 to-white/40" />
                      <div className="px-8">
                        <div className="w-3 h-3 bg-gradient-to-r from-gold to-amber-400 rounded-full shadow-lg shadow-gold/30" />
                      </div>
                      <div className="flex-1 h-px bg-gradient-to-r from-white/40 via-white/20 to-transparent" />
                    </div>
                    
                    {/* Floating accent elements */}
                    <div className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-gradient-to-r from-gold/5 to-amber/5 rounded-full blur-2xl opacity-60" />
                  </motion.div>
                )}

                <motion.div
                  initial={{ opacity: 0, y: 80 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.8, delay: categoryIndex * 0.15, ease: "easeOut" }}
                  className="space-y-12"
                >
                  {/* Ultra-Modern Category Header - Next-Gen UI/UX */}
                  <motion.div 
                    className="relative group cursor-pointer"
                    whileHover={{ y: -6, rotateX: 2 }}
                    transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
                  >
                    {/* Floating Background Orbs */}
                    <div className="absolute -inset-4 opacity-0 group-hover:opacity-100 transition-opacity duration-1000">
                      <motion.div 
                        className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${category.color} rounded-full blur-3xl opacity-20`}
                        animate={{ 
                          scale: [1, 1.2, 1],
                          rotate: [0, 180, 360]
                        }}
                        transition={{ 
                          duration: 8,
                          repeat: Infinity,
                          ease: "linear"
                        }}
                      />
                      <motion.div 
                        className="absolute bottom-0 left-0 w-24 h-24 bg-gradient-to-tr from-gold/30 to-amber/20 rounded-full blur-2xl"
                        animate={{ 
                          scale: [1.2, 1, 1.2],
                          opacity: [0.3, 0.6, 0.3]
                        }}
                        transition={{ 
                          duration: 6,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      />
                    </div>

                    {/* Main Header Container with Advanced Glass Morphism */}
                    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-black/50 via-black/40 to-black/30 backdrop-blur-3xl border border-white/30 group-hover:border-gold/50 transition-all duration-700 shadow-2xl group-hover:shadow-gold/25 group-hover:shadow-2xl">
                      {/* Animated Mesh Gradient Background */}
                      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-1000">
                        <div className="absolute inset-0 bg-gradient-to-r from-gold/10 via-emerald/5 to-purple/10" />
                        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,215,0,0.1),transparent_50%)]" />
                        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(16,185,129,0.08),transparent_50%)]" />
                      </div>
                      
                      {/* Floating Particles Effect */}
                      <div className="absolute inset-0 overflow-hidden opacity-0 group-hover:opacity-100 transition-opacity duration-1000">
                        {[...Array(6)].map((_, i) => (
                          <motion.div
                            key={i}
                            className="absolute w-1 h-1 bg-gold/60 rounded-full"
                            style={{
                              left: `${20 + i * 15}%`,
                              top: `${30 + (i % 3) * 20}%`
                            }}
                            animate={{
                              y: [-10, -30, -10],
                              opacity: [0, 1, 0],
                              scale: [0, 1, 0]
                            }}
                            transition={{
                              duration: 3,
                              repeat: Infinity,
                              delay: i * 0.5,
                              ease: "easeInOut"
                            }}
                          />
                        ))}
                      </div>
                      
                      {/* Content Container */}
                      <div className="relative z-10 flex items-center justify-between p-8 md:p-10">
                        {/* Left Section - Enhanced Icon & Info */}
                        <div className="flex items-center gap-8">
                          {/* Revolutionary Icon Design */}
                          <motion.div 
                            whileHover={{ 
                              scale: 1.15, 
                              rotate: [0, -5, 5, 0]
                            }}
                            whileTap={{ scale: 0.9 }}
                            className="relative"
                          >
                            {/* Icon Container with Advanced Effects */}
                            <div className="relative">
                              <div className={`relative p-5 rounded-3xl bg-gradient-to-br ${category.color} shadow-2xl group-hover:shadow-3xl transition-all duration-700 border border-white/20`}>
                                <category.icon className="w-10 h-10 text-white relative z-10" />
                                
                                {/* Rotating Border */}
                                <motion.div 
                                  className={`absolute inset-0 rounded-3xl border-2 border-transparent bg-gradient-to-r ${category.color} opacity-0 group-hover:opacity-100`}
                                  style={{ 
                                    background: `conic-gradient(from 0deg, transparent, rgba(255,215,0,0.5), transparent)`,
                                    padding: '2px'
                                  }}
                                  animate={{ rotate: 360 }}
                                  transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                                />
                                
                                {/* Pulsing Glow */}
                                <motion.div 
                                  className={`absolute inset-0 rounded-3xl bg-gradient-to-br ${category.color} blur-xl`}
                                  animate={{ 
                                    opacity: [0, 0.4, 0],
                                    scale: [1, 1.2, 1]
                                  }}
                                  transition={{ 
                                    duration: 2,
                                    repeat: Infinity,
                                    ease: "easeInOut"
                                  }}
                                />
                              </div>
                            </div>
                          </motion.div>
                          
                          {/* Enhanced Category Information */}
                          <div className="space-y-3">
                            <motion.div
                              whileHover={{ x: 4 }}
                              transition={{ duration: 0.3 }}
                            >
                              <h3 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-white via-white/90 to-gold/80 bg-clip-text text-transparent group-hover:from-gold group-hover:to-amber-300 transition-all duration-500">
                                {category.name}
                              </h3>
                            </motion.div>
                            
                            <motion.p 
                              className="text-white/80 text-base md:text-lg leading-relaxed max-w-md font-medium"
                              whileHover={{ x: 2 }}
                              transition={{ duration: 0.3 }}
                            >
                              {category.description}
                            </motion.p>
                            
                            {/* Advanced Stats with Modern Pills */}
                            <div className="flex items-center gap-4 mt-4">
                              <motion.div 
                                className="group/stat relative overflow-hidden"
                                whileHover={{ scale: 1.05, y: -2 }}
                                transition={{ duration: 0.3 }}
                              >
                                <div className="px-4 py-2 bg-white/15 backdrop-blur-xl rounded-2xl border border-white/30 group-hover/stat:border-gold/50 transition-all duration-300">
                                  <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
                                    <span className="text-sm font-semibold text-white/90">
                                      {categoryProducts.length} Items
                                    </span>
                                  </div>
                                  {/* Hover shine effect */}
                                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover/stat:translate-x-full transition-transform duration-700" />
                                </div>
                              </motion.div>
                              
                              <motion.div 
                                className="group/trending relative"
                                whileHover={{ scale: 1.05, y: -2 }}
                                transition={{ duration: 0.3 }}
                              >
                                <div className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-gold/20 to-amber/15 backdrop-blur-xl rounded-2xl border border-gold/40">
                                  <motion.div 
                                    className="w-2 h-2 bg-gold rounded-full"
                                    animate={{ 
                                      scale: [1, 1.3, 1],
                                      opacity: [0.7, 1, 0.7]
                                    }}
                                    transition={{ 
                                      duration: 1.5,
                                      repeat: Infinity,
                                      ease: "easeInOut"
                                    }}
                                  />
                                  <span className="text-sm font-bold text-gold uppercase tracking-wider">
                                    Trending
                                  </span>
                                </div>
                              </motion.div>
                            </div>
                          </div>
                        </div>

                        {/* Revolutionary CTA Button */}
                        <motion.div
                          whileHover={{ scale: 1.08, x: 6, rotateY: 5 }}
                          whileTap={{ scale: 0.95 }}
                          className="relative"
                        >
                          <div className="relative group/btn">
                            <Button 
                              variant="outline"
                              className="relative border-2 border-white/40 hover:border-gold/70 text-white hover:text-black px-8 md:px-10 py-4 md:py-5 rounded-2xl backdrop-blur-xl bg-gradient-to-r from-white/10 to-white/5 hover:from-gold/90 hover:to-amber/80 hover:shadow-2xl hover:shadow-gold/40 transition-all duration-700 font-bold text-base md:text-lg group overflow-hidden"
                              onClick={() => {
                                const categorySlug = category.name.toLowerCase().replace(/\s+/g, '-');
                                navigate(`/category/${categorySlug}`);
                              }}
                            >
                              <span className="relative z-10 flex items-center gap-3">
                                Explore All
                                <motion.div
                                  animate={{ x: [0, 4, 0] }}
                                  transition={{ 
                                    duration: 1.5,
                                    repeat: Infinity,
                                    ease: "easeInOut"
                                  }}
                                >
                                  <ArrowRight className="w-5 h-5" />
                                </motion.div>
                              </span>
                              
                              {/* Advanced Button Effects */}
                              <motion.div 
                                className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full"
                                animate={{ x: ['-100%', '100%'] }}
                                transition={{ 
                                  duration: 2,
                                  repeat: Infinity,
                                  ease: "easeInOut",
                                  repeatDelay: 3
                                }}
                              />
                              
                              {/* Ripple Effect */}
                              <motion.div 
                                className="absolute inset-0 rounded-2xl border-2 border-gold/50 opacity-0 group-hover/btn:opacity-100"
                                animate={{ 
                                  scale: [1, 1.05, 1],
                                  opacity: [0, 0.5, 0]
                                }}
                                transition={{ 
                                  duration: 1.5,
                                  repeat: Infinity,
                                  ease: "easeOut"
                                }}
                              />
                            </Button>
                          </div>
                        </motion.div>
                      </div>
                      
                      {/* Advanced Border Effects */}
                      <div className="absolute inset-0 rounded-3xl border border-gold/40 opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />
                      
                      {/* Dynamic Inner Highlights */}
                      <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-white/15 via-transparent to-gold/10 opacity-0 group-hover:opacity-100 transition-opacity duration-1000 pointer-events-none" />
                      
                      {/* Corner Accents */}
                      <div className="absolute top-4 right-4 w-8 h-8 border-t-2 border-r-2 border-gold/50 rounded-tr-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                      <div className="absolute bottom-4 left-4 w-8 h-8 border-b-2 border-l-2 border-gold/50 rounded-bl-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                    </div>
                  </motion.div>

                {/* Ultra-Modern Products Display Container */}
                <motion.div
                  initial={{ opacity: 1, scale: 1 }}
                  animate={isInView ? { opacity: 1, scale: 1 } : {}}
                  transition={{ duration: 0.8, delay: categoryIndex * 0.1 + 0.3 }}
                  className="relative"
                >
                  {/* Modern container with glass morphism */}
                  <div className="relative p-8 bg-gradient-to-br from-white/8 via-white/4 to-transparent backdrop-blur-xl border border-white/20 rounded-3xl shadow-2xl hover:shadow-gold/10 transition-all duration-700">
                    {/* Floating gradient orbs inside container */}
                    <div className="absolute top-4 right-8 w-32 h-32 bg-gradient-to-r from-gold/10 to-amber/5 rounded-full blur-2xl opacity-50" />
                    <div className="absolute bottom-6 left-6 w-24 h-24 bg-gradient-to-l from-primary/8 to-blue/4 rounded-full blur-xl opacity-40" />
                    
                    {/* Modern Asymmetric Grid Layout */}
                    <div className="relative z-10">
                      {/* Featured product (first item) - larger display */}
                      {categoryProducts.length > 0 && (
                        <div className="mb-8">
                          <motion.div
                            key={categoryProducts[0].id}
                            initial={{ opacity: 0, y: 30 }}
                            animate={isInView ? { opacity: 1, y: 0 } : {}}
                            transition={{ duration: 0.6, delay: (categoryIndex * 0.1) + 0.05 }}
                            className="group"
                          >
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                              {/* Featured product card - enhanced size */}
                              <div className="order-2 lg:order-1">
                                <Card className="group relative overflow-hidden bg-gradient-to-br from-white/10 via-white/5 to-transparent backdrop-blur-xl border border-white/20 hover:border-gold/40 transition-all duration-500 hover:shadow-2xl hover:shadow-gold/20 h-auto rounded-2xl">
                                  {/* Keep existing product card content */}
                                  <div className="relative overflow-hidden aspect-square rounded-t-2xl">
                                    <img
                                      src={categoryProducts[0].images?.[0] || '/images/charity-background.svg'}
                                      alt={categoryProducts[0].title}
                                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                                      onError={(e) => {
                                        const t = e.currentTarget;
                                        if (t.src !== '/images/charity-background.svg') {
                                          t.src = '/images/charity-background.svg';
                                        }
                                      }}
                                    />
                                    
                                    {/* Modern Gradient Overlay */}
                                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500" />
                                    
                                    {/* Enhanced Quick Actions */}
                                    <div className="absolute inset-0 flex items-center justify-center gap-3 opacity-0 group-hover:opacity-100 transition-all duration-500 transform translate-y-4 group-hover:translate-y-0">
                                      <motion.div whileHover={{ scale: 1.15, y: -2 }} whileTap={{ scale: 0.95 }}>
                                        <Button 
                                          size="sm" 
                                          className="bg-white/10 backdrop-blur-md hover:bg-white/20 border border-white/30 hover:border-white/50 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            navigate(`/product/${categoryProducts[0].id}`);
                                          }}
                                          aria-label="View product details"
                                        >
                                          <Eye className="w-4 h-4" />
                                        </Button>
                                      </motion.div>
                                      <motion.div whileHover={{ scale: 1.15, y: -2 }} whileTap={{ scale: 0.95 }}>
                                        <Button 
                                          size="sm" 
                                          className="bg-white/10 backdrop-blur-md hover:bg-red-500/80 border border-white/30 hover:border-red-400 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            runOrLogin(() => toggleWishlist(categoryProducts[0].id));
                                          }}
                                          aria-label={isWishlisted(categoryProducts[0].id) ? "Remove from wishlist" : "Add to wishlist"}
                                        >
                                          <Heart className={`w-4 h-4 ${isWishlisted(categoryProducts[0].id) ? 'fill-red-500 text-red-500' : ''}`} />
                                        </Button>
                                      </motion.div>
                                      <motion.div whileHover={{ scale: 1.15, y: -2 }} whileTap={{ scale: 0.95 }}>
                                        <Button size="sm" className={`bg-gradient-to-r from-gold to-amber-400 hover:from-gold/90 hover:to-amber-300 text-black font-medium shadow-lg hover:shadow-xl hover:shadow-gold/30 transition-all duration-300 border border-gold/50 ${isInCart(categoryProducts[0].id) ? 'bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600' : ''}`} onClick={(e) => handleAddToCart(e, categoryProducts[0])}>
                                          {isInCart(categoryProducts[0].id) ? (
                                            <Check className="w-4 h-4" />
                                          ) : (
                                            <Plus className="w-4 h-4" />
                                          )}
                                        </Button>
                                      </motion.div>
                                    </div>
                                    
                                    {/* Subtle border glow effect */}
                                    <div className="absolute inset-0 rounded-t-2xl border-2 border-gold/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

                                    <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                                      {categoryProducts[0].badges?.map((badge) => (
                                        <span key={badge} className="px-3 py-1.5 text-xs bg-gradient-to-r from-gold to-amber-400 text-black rounded-full font-semibold shadow-lg backdrop-blur-sm border border-gold/30">
                                          {badge}
                                        </span>
                                      ))}
                                    </div>

                                    {categoryProducts[0].isRental && (
                                      <div className="absolute top-4 right-4">
                                        <span className="px-3 py-1.5 text-xs bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-full font-semibold shadow-lg backdrop-blur-sm border border-purple-400/50">
                                          Rental
                                        </span>
                                      </div>
                                    )}
                                  </div>

                                  <CardContent className="p-6 flex-1 bg-gradient-to-b from-transparent to-black/5">
                                    <div>
                                      <div className="flex items-start justify-between mb-3">
                                        <h3 className="font-bold text-xl group-hover:text-gold transition-colors duration-300 line-clamp-2 leading-tight">
                                          {categoryProducts[0].title}
                                        </h3>
                                        <div className="flex items-center gap-1.5 bg-gold/10 px-2 py-1 rounded-full border border-gold/20">
                                          <Star className="w-4 h-4 fill-gold text-gold" />
                                          <span className="text-sm font-semibold text-gold">4.8</span>
                                        </div>
                                      </div>
                                      
                                      <p className="text-sm text-muted-foreground/80 mb-4 line-clamp-2 leading-relaxed">
                                        {categoryProducts[0].description}
                                      </p>

                                      <div className="flex items-center gap-3 mb-4">
                                        <span className="px-3 py-1.5 text-xs bg-white/10 backdrop-blur-sm rounded-full border border-white/20 font-medium">
                                          {categoryProducts[0].category}
                                        </span>
                                        <span className="text-xs text-muted-foreground/70 flex items-center gap-1">
                                          <div className="w-1 h-1 bg-gold rounded-full"></div>
                                          {[
                                            categoryProducts[0].location?.city,
                                            categoryProducts[0].location?.state
                                          ].filter(Boolean).join(', ') || 'Location unavailable'}
                                        </span>
                                      </div>
                                    </div>

                                    <div className="space-y-4">
                                      <div className="flex items-center justify-between p-4 bg-gradient-to-r from-white/5 to-white/10 rounded-xl border border-white/10 backdrop-blur-sm">
                                        <div>
                                          <div className="text-2xl font-bold bg-gradient-to-r from-gold to-amber-400 bg-clip-text text-transparent">
                                            {formatCurrency(calculateTotalPrice(categoryProducts[0]))}
                                          </div>
                                          <div className="text-xs text-muted-foreground/70 mt-1">
                                            Seller gets {formatCurrency(categoryProducts[0].basePriceSeller)}
                                          </div>
                                        </div>
                                        <div className="text-right">
                                          <div className="text-lg font-bold text-emerald-400 flex items-center gap-1">
                                            <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                                            +{formatCurrency(calculateCharityImpact(categoryProducts[0]))}
                                          </div>
                                          <div className="text-xs text-muted-foreground/70 mt-1">
                                            to charity
                                          </div>
                                        </div>
                                      </div>

                                      <div className="space-y-2">
                                        <div className="flex justify-between text-xs font-medium">
                                          <span className="text-muted-foreground">Charity Impact</span>
                                          <span className="text-gold">{categoryProducts[0].upliftPercent}% uplift</span>
                                        </div>
                                        <Progress value={categoryProducts[0].upliftPercent} className="h-2 bg-white/10" />
                                      </div>

                                      <Button 
                                        className="w-full bg-gold hover:bg-gold/90 text-black font-medium" 
                                        onClick={() => {
                                          navigate(`/product/${categoryProducts[0].id}`);
                                        }}
                                        aria-label="View product details"
                                      >
                                        View Details
                                      </Button>
                                    </div>
                                  </CardContent>
                                </Card>
                              </div>
                              
                              {/* Featured product info panel */}
                              <div className="order-1 lg:order-2 space-y-6">
                                <div className="space-y-4">
                                  <div className="inline-flex items-center gap-2 px-4 py-2 bg-gold/10 backdrop-blur-sm border border-gold/30 rounded-full">
                                    <div className="w-2 h-2 bg-gold rounded-full animate-pulse" />
                                    <span className="text-gold font-semibold text-sm">Featured in {category.name}</span>
                                  </div>
                                  
                                  <h4 className="text-2xl font-bold text-foreground leading-tight">
                                    Discover Premium {category.name.split(' ')[0]} Products
                                  </h4>
                                  
                                  <p className="text-muted-foreground/80 leading-relaxed">
                                    Handpicked selections from our most trusted makers, featuring the highest quality items with maximum charity impact.
                                  </p>
                                  
                                  <div className="flex items-center gap-4 text-sm">
                                    <div className="flex items-center gap-2">
                                      <div className="w-2 h-2 bg-emerald-400 rounded-full" />
                                      <span className="text-muted-foreground">Verified Quality</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <div className="w-2 h-2 bg-gold rounded-full" />
                                      <span className="text-muted-foreground">High Impact</span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </motion.div>
                        </div>
                      )}

                      {/* Remaining products in modern grid */}
                      {categoryProducts.length > 1 && (
                        <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                          {categoryProducts.slice(1).map((product, index) => (
                            <motion.div
                              key={product.id}
                              initial={{ opacity: 0, y: 30 }}
                              animate={isInView ? { opacity: 1, y: 0 } : {}}
                              transition={{ duration: 0.6, delay: (categoryIndex * 0.1) + (index * 0.1) + 0.3 }}
                              className="group"
                            >
                              <Card className="group relative overflow-hidden bg-gradient-to-br from-white/10 via-white/5 to-transparent backdrop-blur-xl border border-white/20 hover:border-gold/40 transition-all duration-500 hover:shadow-2xl hover:shadow-gold/20 h-auto rounded-2xl">
                                {/* Product Image */}
                                <div className="relative overflow-hidden aspect-square rounded-t-2xl">
                                  <img
                                    src={product.images?.[0] || '/images/charity-background.svg'}
                                    alt={product.title}
                                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                                    onError={(e) => {
                                      const t = e.currentTarget;
                                      if (t.src !== '/images/charity-background.svg') {
                                        t.src = '/images/charity-background.svg';
                                      }
                                    }}
                                  />
                                  
                                  {/* Modern Gradient Overlay */}
                                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500" />
                                  
                                  {/* Enhanced Quick Actions */}
                                  <div className="absolute inset-0 flex items-center justify-center gap-3 opacity-0 group-hover:opacity-100 transition-all duration-500 transform translate-y-4 group-hover:translate-y-0">
                                    <motion.div
                                      whileHover={{ scale: 1.15, y: -2 }}
                                      whileTap={{ scale: 0.95 }}
                                    >
                                      <Button 
                                        size="sm" 
                                        className="bg-white/10 backdrop-blur-md hover:bg-white/20 border border-white/30 hover:border-white/50 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          navigate(`/product/${product.id}`);
                                        }}
                                        aria-label="View product details"
                                      >
                                        <Eye className="w-4 h-4" />
                                      </Button>
                                    </motion.div>
                                    <motion.div
                                      whileHover={{ scale: 1.15, y: -2 }}
                                      whileTap={{ scale: 0.95 }}
                                    >
                                      <Button 
                                        size="sm" 
                                        className="bg-white/10 backdrop-blur-md hover:bg-red-500/80 border border-white/30 hover:border-red-400 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          runOrLogin(() => toggleWishlist(product.id));
                                        }}
                                        aria-label={isWishlisted(product.id) ? "Remove from wishlist" : "Add to wishlist"}
                                      >
                                        <Heart className={`w-4 h-4 ${isWishlisted(product.id) ? 'fill-red-500 text-red-500' : ''}`} />
                                      </Button>
                                    </motion.div>
                                    <motion.div
                                      whileHover={{ scale: 1.15, y: -2 }}
                                      whileTap={{ scale: 0.95 }}
                                    >
                                      <Button size="sm" className={`bg-gradient-to-r from-gold to-amber-400 hover:from-gold/90 hover:to-amber-300 text-black font-medium shadow-lg hover:shadow-xl hover:shadow-gold/30 transition-all duration-300 border border-gold/50 ${isInCart(product.id) ? 'bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600' : ''}`} onClick={(e) => handleAddToCart(e, product)}>
                                        {isInCart(product.id) ? (
                                          <Check className="w-4 h-4" />
                                        ) : (
                                          <Plus className="w-4 h-4" />
                                        )}
                                      </Button>
                                    </motion.div>
                                  </div>
                                  
                                  {/* Subtle border glow effect */}
                                  <div className="absolute inset-0 rounded-t-2xl border-2 border-gold/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

                                  {/* Enhanced Badges */}
                                  <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                                    {categoryProducts[0].badges?.map((badge) => (
                                      <span
                                        key={badge}
                                        className="px-3 py-1.5 text-xs bg-gradient-to-r from-gold to-amber-400 text-black rounded-full font-semibold shadow-lg backdrop-blur-sm border border-gold/30"
                                      >
                                        {badge}
                                      </span>
                                    ))}
                                  </div>

                                  {/* Enhanced Rental Badge */}
                                  {categoryProducts[0].isRental && (
                                    <div className="absolute top-4 right-4">
                                      <span className="px-3 py-1.5 text-xs bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-full font-semibold shadow-lg backdrop-blur-sm border border-purple-400/50">
                                        Rental
                                      </span>
                                    </div>
                                  )}
                                </div>

                                {/* Enhanced Product Info */}
                                <CardContent className="p-6 flex-1 bg-gradient-to-b from-transparent to-black/5">
                                  <div>
                                    <div className="flex items-start justify-between mb-3">
                                      <h3 className="font-bold text-xl group-hover:text-gold transition-colors duration-300 line-clamp-2 leading-tight">
                                        {product.title}
                                      </h3>
                                      <div className="flex items-center gap-1.5 bg-gold/10 px-2 py-1 rounded-full border border-gold/20">
                                        <Star className="w-4 h-4 fill-gold text-gold" />
                                        <span className="text-sm font-semibold text-gold">4.8</span>
                                      </div>
                                    </div>
                                    
                                    <p className="text-sm text-muted-foreground/80 mb-4 line-clamp-2 leading-relaxed">
                                      {product.description}
                                    </p>

                                    <div className="flex items-center gap-3 mb-4">
                                      <span className="px-3 py-1.5 text-xs bg-white/10 backdrop-blur-sm rounded-full border border-white/20 font-medium">
                                        {product.category}
                                      </span>
                                      <span className="text-xs text-muted-foreground/70 flex items-center gap-1">
                                        <div className="w-1 h-1 bg-gold rounded-full"></div>
                                        {[
                                          product.location?.city,
                                          product.location?.state
                                        ].filter(Boolean).join(', ') || 'Location unavailable'}
                                      </span>
                                    </div>
                                  </div>

                                  {/* Enhanced Pricing and Impact */}
                                  <div className="space-y-4">
                                    <div className="flex items-center justify-between p-4 bg-gradient-to-r from-white/5 to-white/10 rounded-xl border border-white/10 backdrop-blur-sm">
                                      <div>
                                        <div className="text-2xl font-bold bg-gradient-to-r from-gold to-amber-400 bg-clip-text text-transparent">
                                          {formatCurrency(calculateTotalPrice(product))}
                                        </div>
                                        <div className="text-xs text-muted-foreground/70 mt-1">
                                          Seller gets {formatCurrency(product.basePriceSeller)}
                                        </div>
                                      </div>
                                      <div className="text-right">
                                        <div className="text-lg font-bold text-emerald-400 flex items-center gap-1">
                                          <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                                          +{formatCurrency(calculateCharityImpact(product))}
                                        </div>
                                        <div className="text-xs text-muted-foreground/70 mt-1">
                                          to charity
                                        </div>
                                      </div>
                                    </div>

                                    {/* Enhanced Progress Bar for Charity Impact */}
                                    <div className="space-y-2">
                                      <div className="flex justify-between text-xs font-medium">
                                        <span className="text-muted-foreground">Charity Impact</span>
                                        <span className="text-gold">{product.upliftPercent}% uplift</span>
                                      </div>
                                      <Progress 
                                        value={product.upliftPercent} 
                                        className="h-2 bg-white/10"
                                      />
                                    </div>

                                    <Button 
                                      className="w-full bg-gold hover:bg-gold/90 text-black font-medium"
                                      onClick={() => {
                                        navigate(`/product/${product.id}`);
                                      }}
                                      aria-label="View product details"
                                    >
                                      View Details
                                    </Button>
                                  </div>
                                </CardContent>
                              </Card>
                            </motion.div>
                          ))}
                        </div>
                      )}
                    </div>
                    
                    {/* Modern "View More" section */}
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={isInView ? { opacity: 1, y: 0 } : {}}
                      transition={{ duration: 0.6, delay: categoryIndex * 0.1 + 0.8 }}
                      className="relative z-10 mt-8 text-center"
                    >
                      <Button 
                        variant="ghost"
                        className="inline-flex items-center gap-3 px-6 py-6 bg-white/5 backdrop-blur-sm border border-white/20 rounded-2xl hover:border-gold/30 hover:bg-white/10 transition-all duration-300 group"
                        onClick={() => {
                          const categorySlug = category.name.toLowerCase().replace(/\s+/g, '-');
                          navigate(`/category/${categorySlug}`);
                        }}
                      >
                        <span className="text-sm font-medium text-muted-foreground group-hover:text-gold transition-colors">
                          View All in {category.name}
                        </span>
                        <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-gold group-hover:translate-x-1 transition-all duration-300" />
                      </Button>
                    </motion.div>
                  </div>
                  
                  {/* Container border glow effect */}
                  <div className="absolute inset-0 rounded-3xl border border-gold/20 opacity-0 hover:opacity-100 transition-opacity duration-700 pointer-events-none" />
                </motion.div>
                </motion.div>
              </div>
            );
          })}
        </div>

        {/* Fallback generic grid when no category matches */}
        {!anyCategoryMatch && (
            <div className="mt-16">
              <h3 className="text-3xl font-bold text-center mb-8">Trending Products</h3>
              <div className="grid gap-6 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
                {products.slice(0, 6).map((p) => (
                  <div key={p.id} className="p-4 rounded-2xl border border-white/15 bg-white/5 backdrop-blur-md">
                    <div className="aspect-square rounded-xl overflow-hidden">
                      <img
                        src={p.images?.[0] || '/images/charity-background.svg'}
                        alt={p.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          const t = e.currentTarget as HTMLImageElement;
                          if (t.src !== '/images/charity-background.svg') t.src = '/images/charity-background.svg';
                        }}
                      />
                    </div>
                    <div className="mt-3 font-semibold">{p.title}</div>
                    <div className="text-xs text-muted-foreground">
                      {[p.location?.city, p.location?.state].filter(Boolean).join(', ') || 'Location unavailable'}
                    </div>
                    <div className="mt-3">
                      <Button variant="outline" onClick={() => navigate(`/product/${p.id}`)}>View</Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
      </div>
    </section>
  );
}
