import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Menu, X, Home, LogOut, Package, MessageSquare, Megaphone } from 'lucide-react';
import { useStore } from '@/store/useStore';
import logoImage from '@/assets/logo.png';
import { auth } from '@/lib/firebase';
import { signOut } from 'firebase/auth';
import { cn } from '@/lib/utils';
import { db } from '@/lib/firebase';
import { doc, getDoc, collection, onSnapshot, query, where, orderBy, limit, getDocs } from 'firebase/firestore';

export function SellerHeader() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, setUser } = useStore();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [isCategoriesOpen, setIsCategoriesOpen] = useState(false);
  const [allowedDepts, setAllowedDepts] = useState<string[]>([]);
  const [loadingDepts, setLoadingDepts] = useState(false);
  const [unreadTotal, setUnreadTotal] = useState<number>(0);
  const CATEGORIES: { key: string; label: string }[] = [
    { key: 'charity-craft', label: 'Charity Craft' },
    { key: 'organic-store', label: 'Organic Store' },
    { key: 'scrap-store', label: 'Scrap Store' },
    { key: 'moms-made-united', label: 'Moms Made United' },
    { key: 'charity-bakes', label: 'Charity Bakes' },
    { key: 'green-cup-challenge', label: 'Green Cup Challenge' },
    { key: 'scrap-books', label: 'Scrap Books' },
    { key: 'home-decor', label: 'Home Decor' },
    { key: 'packed-food', label: 'Packed Food' },
    { key: 'home-plants', label: 'Home Plants' },
    { key: 'beauty-homemade', label: 'Beauty Homemade' },
    { key: 'homemade-households', label: 'Homemade Households' },
    { key: 'birthday-gifts', label: 'Birthday Gifts' }
  ];

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = docHeight > 0 ? scrollTop / docHeight : 0;
      setScrollProgress(progress);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Fetch allowed departments for the seller from Firestore (seller-profiles)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (!user?.id) { setAllowedDepts([]); return; }
        setLoadingDepts(true);
        const profRef = doc(db, 'seller-profiles', user.id);
        const snap = await getDoc(profRef);
        if (cancelled) return;
        const depts = (snap.exists() ? (snap.data() as any)?.departments : []) || [];
        setAllowedDepts(Array.isArray(depts) ? depts : []);
      } catch {
        if (!cancelled) setAllowedDepts([]);
      } finally {
        if (!cancelled) setLoadingDepts(false);
      }
    })();
    return () => { cancelled = true; };
  }, [user?.id]);

  // Compute unread total for seller customization chats and show in navbar
  useEffect(() => {
    if (!user?.id) { setUnreadTotal(0); return; }
    const q = query(collection(db, 'customizationChats'), where('sellerId', '==', user.id));
    const unsub = onSnapshot(q, async (snap) => {
      try {
        let count = 0;
        const checks = snap.docs.map(async (d) => {
          const c = d.data() as any;
          try {
            const latestQ = query(collection(db, 'customizationChats', d.id, 'messages'), orderBy('createdAt', 'desc'), limit(1));
            const s = await getDocs(latestQ);
            const latest = s.docs[0]?.data() as any | undefined;
            const lastRead = c?.lastReadSellerAt;
            const isUnread = Boolean(latest && latest.senderId && latest.senderId !== user.id && (!lastRead || (latest.createdAt?.toMillis && lastRead?.toMillis && latest.createdAt.toMillis() > lastRead.toMillis())));
            if (isUnread) count++;
          } catch { /* ignore */ }
        });
        await Promise.all(checks);
        setUnreadTotal(count);
      } catch {
        setUnreadTotal(0);
      }
    }, () => setUnreadTotal(0));
    return () => unsub();
  }, [user?.id]);

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      localStorage.removeItem('currentUser');
      localStorage.removeItem('faceAuthSession');
      localStorage.removeItem('faceAuthEmail');
      setUser(null);
      navigate('/');
    } catch (e) {
      console.error('Seller sign out failed', e);
      setUser(null);
      navigate('/');
    }
  };

  return (
    <>
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-gold via-amber-400 to-yellow-400 z-50 origin-left shadow-sm"
        style={{ scaleX: scrollProgress }}
        initial={{ scaleX: 0 }}
      />

      <header className="sticky top-0 z-50 w-full border-b-2 border-gradient-to-r from-gold/30 via-amber-400/40 to-gold/30 bg-gradient-to-r from-background/85 via-background/90 to-background/85 backdrop-blur-2xl supports-[backdrop-filter]:bg-background/60 shadow-2xl shadow-gold/10 before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-gold/5 before:to-transparent before:pointer-events-none">
        <div className="container mx-auto px-6 relative">
          <div className="flex h-20 items-center justify-between relative">
            {/* Brand */}
            <div className="flex items-center min-w-0">
              <Link to="/seller" className="flex items-center space-x-3 group relative">
                <div className="relative">
                  <img src={logoImage} alt="EWSELLS Seller" className="w-28 h-auto transition-all duration-300 group-hover:scale-105 drop-shadow-lg" />
                  <div className="absolute -inset-2 bg-gradient-to-r from-gold/20 to-amber-400/20 rounded-xl opacity-0 group-hover:opacity-100 transition-all duration-300 blur-xl -z-10"></div>
                </div>
                <div className="relative hidden sm:block">
                  <span className="text-sm font-bold text-transparent bg-gradient-to-r from-gold via-amber-400 to-gold bg-clip-text tracking-wide uppercase transition-all duration-300 group-hover:scale-105 whitespace-nowrap">
                    Seller Portal
                  </span>
                  <div className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-gold to-amber-400 group-hover:w-full transition-all duration-500 ease-out"></div>
                </div>
              </Link>
            </div>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center space-x-1 mx-auto bg-white/5 backdrop-blur-md rounded-2xl px-4 py-2 border border-white/10 shadow-xl">
              <Link
                to="/seller"
                className={cn(
                  'inline-flex items-center transition-all duration-300 hover:text-white hover:scale-110 px-4 py-2 text-sm font-semibold relative rounded-xl hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:shadow-lg hover:shadow-gold/30 group',
                  location.pathname === '/seller' ? 'text-white bg-gradient-to-r from-gold to-amber-400 shadow-lg shadow-gold/30' : 'text-foreground hover:text-white'
                )}
              >
                <Home className="mr-2 h-4 w-4 transition-transform duration-300 group-hover:scale-125" />
                Dashboard
              </Link>
              <Link
                to="/seller/orders"
                className={cn(
                  'inline-flex items-center transition-all duration-300 hover:text-white hover:scale-110 px-4 py-2 text-sm font-semibold relative rounded-xl hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:shadow-lg hover:shadow-gold/30 group',
                  location.pathname.startsWith('/seller/orders') ? 'text-white bg-gradient-to-r from-gold to-amber-400 shadow-lg shadow-gold/30' : 'text-foreground hover:text-white'
                )}
              >
                <Package className="mr-2 h-4 w-4 transition-transform duration-300 group-hover:scale-125" />
                Seller Orders
              </Link>
              <Link
                to="/seller/promotions"
                className={cn(
                  'inline-flex items-center transition-all duration-300 hover:text-white hover:scale-110 px-4 py-2 text-sm font-semibold relative rounded-xl hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:shadow-lg hover:shadow-gold/30 group',
                  location.pathname.startsWith('/seller/promotions') ? 'text-white bg-gradient-to-r from-gold to-amber-400 shadow-lg shadow-gold/30' : 'text-foreground hover:text-white'
                )}
              >
                <Megaphone className="mr-2 h-4 w-4 transition-transform duration-300 group-hover:scale-125" />
                Promote Products
              </Link>
              <Link
                to="/seller/customizations"
                className={cn(
                  'inline-flex items-center transition-all duration-300 hover:text-white hover:scale-110 px-4 py-2 text-sm font-semibold relative rounded-xl hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:shadow-lg hover:shadow-gold/30 group',
                  location.pathname.startsWith('/seller/customizations') ? 'text-white bg-gradient-to-r from-gold to-amber-400 shadow-lg shadow-gold/30' : 'text-foreground hover:text-white'
                )}
              >
                <MessageSquare className="mr-2 h-4 w-4 transition-transform duration-300 group-hover:scale-125" />
                Customizations
                {unreadTotal > 0 && (
                  <span className="absolute -top-2 -right-2 inline-flex items-center justify-center rounded-full bg-red-500 text-white text-[10px] h-5 min-w-5 px-1 font-bold shadow-lg">
                    {unreadTotal}
                  </span>
                )}
              </Link>
              <Link
                to="/seller/allproducts"
                className={cn(
                  'inline-flex items-center transition-all duration-300 hover:text-white hover:scale-110 px-4 py-2 text-sm font-semibold relative rounded-xl hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:shadow-lg hover:shadow-gold/30 group',
                  location.pathname.startsWith('/seller/allproducts') ? 'text-white bg-gradient-to-r from-gold to-amber-400 shadow-lg shadow-gold/30' : 'text-foreground hover:text-white'
                )}
              >
                All Products
              </Link>
            </nav>

            {/* Actions */}
            <div className="flex items-center space-x-2 bg-white/5 backdrop-blur-md rounded-2xl px-3 py-2 border border-white/10 shadow-xl">
              {user && (
                <span className="text-xs font-semibold text-transparent bg-gradient-to-r from-gold via-amber-400 to-gold bg-clip-text hidden sm:block">{user.displayName}</span>
              )}
              <Button
                size="icon"
                variant="ghost"
                className="h-12 w-12 hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:text-white hover:scale-110 transition-all duration-300 hover:shadow-lg hover:shadow-gold/30 rounded-xl md:hidden"
                onClick={() => setIsMenuOpen(v => !v)}
                aria-label="Toggle menu"
              >
                {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
              <Button
                size="icon"
                variant="ghost"
                className="h-12 w-12 hover:bg-gradient-to-r hover:from-red-500 hover:to-pink-500 hover:text-white hover:scale-110 transition-all duration-300 hover:shadow-lg hover:shadow-red-300 rounded-xl"
                onClick={handleSignOut}
                aria-label="Sign out"
              >
                <LogOut className="h-5 w-5" />
              </Button>
              {/* Desktop Categories dropdown trigger at far right (filtered by allowed departments) */}
              <div className="relative hidden md:block">
                <button
                  className="inline-flex items-center justify-center h-12 w-12 rounded-xl transition-all duration-300 hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:text-white hover:scale-110 hover:shadow-lg hover:shadow-gold/30"
                  onClick={() => setIsCategoriesOpen(v => !v)}
                  onBlur={() => setTimeout(() => setIsCategoriesOpen(false), 150)}
                  aria-haspopup="menu"
                  aria-expanded={isCategoriesOpen}
                  aria-label="Open categories"
                >
                  <Menu className="h-5 w-5" />
                </button>
                {isCategoriesOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-card/95 backdrop-blur-xl border border-gold/20 rounded-2xl shadow-2xl shadow-gold/10 z-50" role="menu" aria-label="Categories">
                    <ul className="py-2">
                      {(loadingDepts ? [] : CATEGORIES.filter(c => allowedDepts.includes(c.key))).map(c => (
                        <li key={c.key}>
                          <Link
                            to={`/seller/upload/${c.key}`}
                            className="block px-3 py-2 text-sm hover:bg-gradient-to-r hover:from-gold/10 hover:to-amber-400/10 hover:text-gold transition-all duration-200 rounded-lg mx-2"
                            onClick={() => setIsCategoriesOpen(false)}
                            role="menuitem"
                          >
                            {c.label}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Mobile menu (filtered by allowed departments) */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-border bg-card">
            <div className="container mx-auto px-6 py-3 space-y-2">
              <Link to="/seller" className="block px-2 py-2 text-sm hover:text-gold" onClick={() => setIsMenuOpen(false)}>
                Dashboard
              </Link>
              <Link to="/seller/orders" className="block px-2 py-2 text-sm hover:text-gold" onClick={() => setIsMenuOpen(false)}>
                Seller Orders
              </Link>
              <Link to="/seller/promotions" className="block px-2 py-2 text-sm hover:text-gold" onClick={() => setIsMenuOpen(false)}>
                Promote Products
              </Link>
              <Link to="/seller/customizations" className="block px-2 py-2 text-sm hover:text-gold" onClick={() => setIsMenuOpen(false)}>
                Customizations
              </Link>
              <Link to="/seller/allproducts" className="block px-2 py-2 text-sm hover:text-gold" onClick={() => setIsMenuOpen(false)}>
                Allproducts
              </Link>
              <div className="border-t border-border pt-2">
                <div className="px-2 py-2 text-xs uppercase tracking-wide text-muted-foreground">Categories</div>
                {(loadingDepts ? [] : CATEGORIES.filter(c => allowedDepts.includes(c.key))).map(c => (
                  <Link
                    key={c.key}
                    to={`/seller?category=${encodeURIComponent(c.key)}#seller-upload`}
                    className="block px-2 py-2 text-sm hover:text-gold"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {c.label}
                  </Link>
                ))}
              </div>
              <a href="#seller-upload" className="block px-2 py-2 text-sm hover:text-gold" onClick={() => setIsMenuOpen(false)}>
                Upload Product
              </a>
            </div>
          </div>
        )}
      </header>
    </>
  );
}
