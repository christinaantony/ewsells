import { useState, useEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, ShoppingCart, Menu, X, User, LogIn, UserPlus, Store, HandHelping, Home, MessageSquare, ArrowLeft, Heart } from 'lucide-react';
import { authService } from '../../services/auth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useStore } from '@/store/useStore';
import { auth, db } from '@/lib/firebase';
import { doc, getDoc, setDoc, collection, query, where, orderBy, limit, onSnapshot, getDocs } from 'firebase/firestore';
import { signOut } from 'firebase/auth';
import { cn } from '@/lib/utils';
import logoImage from '@/assets/logo.png';
import { useCart } from '@/contexts/CartContext';
import { SearchDropdown } from '@/components/search/SearchDropdown';
import { searchItems } from '@/services/searchService';
import type { SearchResult } from '@/services/searchService';
import { initMessaging } from '@/lib/messaging';

interface HeaderProps {
  onOpenSellerModal?: () => void;
}

const navigationItems = [
  { name: 'Home', href: '/' },
  { name: 'Chat with Smile Sales AI', href: '/chat' },
  { name: 'Green Cup Challenge', href: '/green-cup' },
  { name: 'Charity Craft', href: '/category/charity-craft' },
  { name: 'Organic Store', href: '/category/organic-store' },
  { name: 'Scrap Store', href: '/category/scrap-store' },
  { name: 'Scrap Books', href: '/category/scrap-books' },
  { name: 'Moms Made United', href: '/category/moms-made-united' },
  { name: 'Helping Hands', href: '/category/helping-hands' },
  { name: 'Home Plants', href: '/category/home-plants' },
  { name: 'Beauty Homemade', href: '/category/beauty-homemade' },
  { name: 'Homemade Households', href: '/category/homemade-households' },
  { name: 'Birthday Gifts', href: '/category/birthday-gifts' },
  { name: 'Home Decor', href: '/category/home-decor' },
  { name: 'Packed Food', href: '/category/packed-food' },
  { name: 'Charity Bakes', href: '/category/charity-bakes' },
  { name: 'FAQ', href: '/faq' },
  { name: 'Meet our Team', href: '/team' },
  { name: 'Official Portal', href: '/portal' },
  { name: 'Registered Sellers', href: '/sellers' },
  { name: 'Group List', href: '/groups' },
  { name: 'Smile Community Kitchen', href: '/community-kitchen' },
  { name: 'SCK Smile Loyalty', href: '/loyalty' },
  { name: 'Refer Friends', href: '/refer' },
  { name: 'SKC Reservations', href: '/reservations' },
  { name: 'Plans and Pricing', href: '/pricing' },
  { name: 'SCK Irinjalakuda Mothers', href: '/irinjalakuda' },
];

export function Header({}: HeaderProps) {
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const navigate = useNavigate();
  const canGoBack = typeof window !== 'undefined' && window.history.length > 1;
  const showBack = location.pathname !== '/' && canGoBack;
  
  // Search dropdown state
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedResultIndex, setSelectedResultIndex] = useState(-1);
  const searchDropdownRef = useRef<HTMLDivElement>(null);
  
  const {
    searchQuery,
    setSearchQuery,
    user,
    logout,
    wishlist,
  } = useStore();
  
  // Use the cart context instead of the store
  const { cartCount } = useCart();

  const cartItemCount = cartCount;
  // Do not show wishlist count when logged out, but keep data persisted
  const wishlistCount = user && Array.isArray(wishlist) ? wishlist.length : 0;
  const isWishlistActive = location.pathname.startsWith('/wishlist');
  const isCartActive = location.pathname.startsWith('/cart');

  // Global unread count for seller customization chats
  const [sellerUnreadCount, setSellerUnreadCount] = useState(0);
  const [buyerUnreadCount, setBuyerUnreadCount] = useState(0);
  useEffect(() => {
    let unsub: undefined | (() => void);
    if (!user?.id) { setSellerUnreadCount(0); return; }
    try {
      const q = query(collection(db, 'customizationChats'), where('sellerId', '==', user.id));
      unsub = onSnapshot(q, async (snap) => {
        try {
          let total = 0;
          // For each chat, consider latest message; if from buyer and newer than lastReadSellerAt, count as 1
          for (const d of snap.docs) {
            const c = d.data() as any;
            const latestQ = query(collection(db, 'customizationChats', d.id, 'messages'), orderBy('createdAt', 'desc'), limit(1));
            const s = await getDocs(latestQ);
            const latest = s.docs[0]?.data() as any | undefined;
            const lastRead = c?.lastReadSellerAt;
            const unread = Boolean(latest && latest.senderId && latest.senderId !== user.id && (!lastRead || (latest.createdAt?.toMillis && lastRead?.toMillis && latest.createdAt.toMillis() > lastRead.toMillis())));
            if (unread) total += 1;
          }
          setSellerUnreadCount(total);
        } catch {
          setSellerUnreadCount(0);
        }
      });
    } catch {
      setSellerUnreadCount(0);
    }
    return () => { try { unsub && unsub(); } catch {} };
  }, [user?.id]);

  // Initialize browser notifications (FCM) once user is available
  useEffect(() => {
    (async () => {
      if (!user?.id) return;
      try {
        const token = await initMessaging();
        if (token) {
          try {
            await setDoc(doc(db, 'users', user.id), { fcmToken: token }, { merge: true });
          } catch {}
        }
      } catch (e) {
        // silent
      }
    })();
  }, [user?.id]);

  // Global unread for buyers: number of customization chats with a new seller message after lastReadBuyerAt
  useEffect(() => {
    let unsub: undefined | (() => void);
    if (!user?.id) { setBuyerUnreadCount(0); return; }
    try {
      const q = query(collection(db, 'customizationChats'), where('buyerId', '==', user.id));
      unsub = onSnapshot(q, async (snap) => {
        try {
          let total = 0;
          for (const d of snap.docs) {
            const c = d.data() as any;
            const latestQ = query(collection(db, 'customizationChats', d.id, 'messages'), orderBy('createdAt', 'desc'), limit(1));
            const s = await getDocs(latestQ);
            const latest = s.docs[0]?.data() as any | undefined;
            const lastRead = c?.lastReadBuyerAt;
            const unread = Boolean(latest && latest.senderId && latest.senderId !== user.id && (!lastRead || (latest.createdAt?.toMillis && lastRead?.toMillis && latest.createdAt.toMillis() > lastRead.toMillis())));
            if (unread) total += 1;
          }
          setBuyerUnreadCount(total);
        } catch {
          setBuyerUnreadCount(0);
        }
      });
    } catch {
      setBuyerUnreadCount(0);
    }
    return () => { try { unsub && unsub(); } catch {} };
  }, [user?.id]);
  
  // Handle search query changes
  const handleSearchQueryChange = (query: string) => {
    setSearchQuery(query);
    setSelectedResultIndex(-1);
    
    if (query.trim().length >= 2) {
      fetchSearchResults(query);
    } else {
      setSearchResults([]);
    }
  };
  
  // Fetch search results as user types
  const fetchSearchResults = async (query: string) => {
    if (query.trim().length < 2) return;
    
    setIsSearching(true);
    try {
      const results = await searchItems(query, 5, false);
      setSearchResults(results);
    } catch (error) {
      console.error('Error fetching search results:', error);
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };
  
  // Handle search form submission
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim().length >= 2) {
      setIsSearchOpen(false);
      setSearchResults([]);
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };
  
  // Handle search result click
  const handleSearchResultClick = () => {
    setIsSearchOpen(false);
    setSearchResults([]);
  };
  
  // Handle keyboard navigation in search results
  const handleSearchKeyDown = (e: React.KeyboardEvent) => {
    if (searchResults.length === 0) return;
    
    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedResultIndex(prev => 
          prev < searchResults.length - 1 ? prev + 1 : prev
        );
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedResultIndex(prev => (prev > 0 ? prev - 1 : prev));
        break;
      case 'Enter':
        if (selectedResultIndex >= 0 && selectedResultIndex < searchResults.length) {
          e.preventDefault();
          const selectedResult = searchResults[selectedResultIndex];
          navigate(selectedResult.url);
          setIsSearchOpen(false);
          setSearchResults([]);
        }
        break;
      case 'Escape':
        setIsSearchOpen(false);
        setSearchResults([]);
        break;
    }
  };
  
  // Close search dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        searchDropdownRef.current && 
        !searchDropdownRef.current.contains(event.target as Node) &&
        searchInputRef.current &&
        !searchInputRef.current.contains(event.target as Node)
      ) {
        setSearchResults([]);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Seller registration status for navbar badge
  const [sellerStatus, setSellerStatus] = useState<'pending' | 'approved' | 'rejected' | 'none'>('none');

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (!user?.id) { setSellerStatus('none'); return; }
        const regRef = doc(db, 'seller-registrations', user.id);
        const regSnap = await getDoc(regRef);
        if (cancelled) return;
        if (!regSnap.exists()) { setSellerStatus('none'); return; }
        const st = (regSnap.data()?.status as any) || 'none';
        if (st === 'pending' || st === 'approved' || st === 'rejected') setSellerStatus(st);
        else setSellerStatus('none');
      } catch {
        setSellerStatus('none');
      }
    })();
    return () => { cancelled = true; };
  }, [user?.id]);
 
   const renderSellerBadge = () => {
     return null; // Remove status badge completely
   };
 

  // Proper sign-out handler
  const handleSignOut = async () => {
    try {
      await signOut(auth);
      // Clear any cached user info
      localStorage.removeItem('currentUser');
      localStorage.removeItem('faceAuthSession');
      localStorage.removeItem('faceAuthEmail');
      logout();
      setIsUserMenuOpen(false);
      setIsMenuOpen(false);
      navigate('/');
    } catch (err) {
      console.error('Error signing out:', err);
      // Fallback to service logout cleanup
      try { await authService.logout(); } catch {}
      logout();
      navigate('/');
    }
  };

  // Scroll progress bar
  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = scrollTop / docHeight;
      setScrollProgress(progress);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Effect to prevent body scroll when menu is open
  useEffect(() => {
    if (isMenuOpen) {
      // Lock body scroll when sidebar is open
      document.body.style.overflow = 'hidden';
    } else {
      // Restore body scroll when sidebar is closed
      document.body.style.overflow = 'auto';
    }
    
    // Cleanup function to ensure scroll is restored when component unmounts
    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isMenuOpen]);

  return (
    <>
      {/* Progress bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-gold via-amber-400 to-yellow-400 z-50 origin-left shadow-sm"
        style={{ scaleX: scrollProgress }}
        initial={{ scaleX: 0 }}
      />

      {/* Top install prompt removed intentionally. Bottom prompt remains via InstallPrompt component. */}

      {/* Add body class to prevent scrolling when sidebar is open */}
      {isMenuOpen && (
        <style>
          {`
            body {
              overflow: hidden;
              pointer-events: none;
            }
            .sidebar-container {
              pointer-events: auto;
            }
          `}
        </style>
      )}
      
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b-2 border-gradient-to-r from-gold/30 via-amber-400/40 to-gold/30 bg-gradient-to-r from-background/85 via-background/90 to-background/85 backdrop-blur-2xl supports-[backdrop-filter]:bg-background/60 shadow-2xl shadow-gold/10 before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-gold/5 before:to-transparent before:pointer-events-none">
        <div className="container mx-auto px-12 relative">
          <div className="flex h-28 items-center justify-between relative gap-3">
            {/* Back + Logo + Tagline */}
            <div className="flex items-center">
              {showBack && (
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => navigate(-1)}
                  className="h-10 w-10 mr-3 hover:bg-gold/10 hover:text-gold hover:scale-105 transition-all duration-200"
                  aria-label="Go back"
                >
                  <ArrowLeft className="h-4 w-4" />
                </Button>
              )}
              <Link to="/" className="flex items-center space-x-4 group relative bg-gradient-to-r from-white/5 to-white/10 backdrop-blur-md rounded-2xl px-6 py-4 border border-white/10 shadow-xl hover:shadow-2xl hover:shadow-gold/20 transition-all duration-500 hover:scale-105">
                <div className="relative">
                  <img src={logoImage} alt="EWSELLS |CHARITY STORE BEYOND| logo" className="w-24 h-auto transition-all duration-500 group-hover:scale-110 drop-shadow-2xl" />
                  <div className="absolute -inset-3 bg-gradient-to-r from-gold/30 via-amber-400/40 to-gold/30 rounded-2xl opacity-0 group-hover:opacity-100 transition-all duration-500 blur-2xl -z-10 animate-pulse"></div>
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full animate-pulse shadow-lg shadow-green-400/50"></div>
                </div>
                <div className="relative hidden sm:flex flex-col">
                  <span className="text-xs font-semibold text-transparent bg-gradient-to-r from-gold/90 via-amber-400/90 to-gold/90 bg-clip-text tracking-wide uppercase transition-all duration-500 group-hover:scale-105 whitespace-nowrap">
                    India's First Online Charity Store
                  </span>
                  <div className="absolute -bottom-2 left-0 w-0 h-1 bg-gradient-to-r from-gold via-amber-400 to-yellow-300 group-hover:w-full transition-all duration-700 ease-out rounded-full shadow-lg shadow-gold/50"></div>
                </div>
                <div className="absolute top-0 right-0 w-2 h-2 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-300 animate-ping"></div>
              </Link>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center space-x-4 mx-auto bg-white/5 backdrop-blur-md rounded-2xl px-4 py-2 border border-white/10 shadow-xl">
              <div className="relative group">
                <Link
                  to="/"
                  className={cn(
                    'inline-flex items-center justify-center transition-all duration-300 hover:text-white hover:scale-110 w-12 h-12 text-sm font-semibold relative rounded-xl hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:shadow-lg hover:shadow-gold/30',
                    location.pathname === '/' ? 'text-white bg-gradient-to-r from-gold to-amber-400 shadow-lg shadow-gold/30' : 'text-foreground hover:text-white'
                  )}
                >
                  <Home className="h-6 w-6 transition-transform duration-300 group-hover:scale-125" />
                </Link>
                <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 px-4 py-2.5 bg-gradient-to-r from-black/90 to-gray-800/90 backdrop-blur-sm text-white text-sm rounded-lg shadow-xl border border-white/10 opacity-0 scale-75 -translate-y-2 group-hover:opacity-100 group-hover:scale-100 group-hover:translate-y-0 transition-all duration-300 ease-out whitespace-nowrap pointer-events-none z-50">
                  <span className="font-semibold">Home</span>
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-b-4 border-transparent border-b-black/90"></div>
                </div>
              </div>
              
              <div className="relative group">
                <Link
                  to="/chat"
                  className={cn(
                    'inline-flex items-center justify-center transition-all duration-300 hover:text-white hover:scale-110 w-12 h-12 text-sm font-semibold relative rounded-xl hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:shadow-lg hover:shadow-gold/30',
                    location.pathname === '/chat' ? 'text-white bg-gradient-to-r from-gold to-amber-400 shadow-lg shadow-gold/30' : 'text-foreground hover:text-white'
                  )}
                >
                  <MessageSquare className="h-6 w-6 transition-transform duration-300 group-hover:scale-125" />
                </Link>
                <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 px-4 py-2.5 bg-gradient-to-r from-black/90 to-gray-800/90 backdrop-blur-sm text-white text-sm rounded-lg shadow-xl border border-white/10 opacity-0 scale-75 -translate-y-2 group-hover:opacity-100 group-hover:scale-100 group-hover:translate-y-0 transition-all duration-300 ease-out whitespace-nowrap pointer-events-none z-50">
                  <span className="font-semibold">Chat with AI</span>
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-b-4 border-transparent border-b-black/90"></div>
                </div>
              </div>
              
              {/* Become a Seller button */}
              <div className="relative group">
                <Link
                  to="/become-seller"
                  className={cn(
                    'inline-flex items-center justify-center transition-all duration-300 hover:text-white hover:scale-110 w-12 h-12 text-sm font-semibold relative rounded-xl hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:shadow-lg hover:shadow-gold/30',
                    location.pathname === '/become-seller' ? 'text-white bg-gradient-to-r from-gold to-amber-400 shadow-lg shadow-gold/30' : 'text-foreground hover:text-white'
                  )}
                >
                  <Store className="h-6 w-6 transition-transform duration-300 group-hover:scale-125" />
                  {renderSellerBadge()}
                </Link>
                <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 px-4 py-2.5 bg-gradient-to-r from-black/90 to-gray-800/90 backdrop-blur-sm text-white text-sm rounded-lg shadow-xl border border-white/10 opacity-0 scale-75 -translate-y-2 group-hover:opacity-100 group-hover:scale-100 group-hover:translate-y-0 transition-all duration-300 ease-out whitespace-nowrap pointer-events-none z-50">
                  <span className="font-semibold">Become Seller</span>
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-b-4 border-transparent border-b-black/90"></div>
                </div>
              </div>
              
              {/* Add Helping Hands button with similar styling */}
              <div className="relative group">
                <Link
                  to="/helping-hands"
                  className={cn(
                    'inline-flex items-center justify-center transition-all duration-300 hover:text-white hover:scale-110 w-12 h-12 text-sm font-semibold relative rounded-xl hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:shadow-lg hover:shadow-gold/30',
                    location.pathname === '/helping-hands' ? 'text-white bg-gradient-to-r from-gold to-amber-400 shadow-lg shadow-gold/30' : 'text-foreground hover:text-white'
                  )}
                >
                  <HandHelping className="h-6 w-6 transition-transform duration-300 group-hover:scale-125" />
                </Link>
                <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 px-4 py-2.5 bg-gradient-to-r from-black/90 to-gray-800/90 backdrop-blur-sm text-white text-sm rounded-lg shadow-xl border border-white/10 opacity-0 scale-75 -translate-y-2 group-hover:opacity-100 group-hover:scale-100 group-hover:translate-y-0 transition-all duration-300 ease-out whitespace-nowrap pointer-events-none z-50">
                  <span className="font-semibold">Help Others</span>
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-b-4 border-transparent border-b-black/90"></div>
                </div>
              </div>
            </nav>

            {/* Search and Actions */}
            <div className="flex items-center space-x-2 bg-white/5 backdrop-blur-md rounded-2xl px-3 py-2 border border-white/10 shadow-xl">
              {/* Search */}
              <div className="relative">
                <AnimatePresence>
                  {isSearchOpen ? (
                    <motion.div
                      initial={{ width: 0, opacity: 0, scale: 0.95 }}
                      animate={{ width: '240px', opacity: 1, scale: 1 }}
                      exit={{ width: 0, opacity: 0, scale: 0.95 }}
                      transition={{ duration: 0.2, ease: "easeOut" }}
                      className="relative"
                    >
                      <form onSubmit={handleSearchSubmit}>
                        <div className="relative" ref={searchDropdownRef}>
                          <Input
                            type="text"
                            placeholder="Search products..."
                            value={searchQuery}
                            onChange={(e) => handleSearchQueryChange(e.target.value)}
                            className="pr-10 border-gold/20 focus:border-gold/40 focus:ring-gold/20 bg-background/80 backdrop-blur-sm shadow-lg"
                            ref={searchInputRef}
                            autoFocus
                            onKeyDown={(e) => {
                              handleSearchKeyDown(e);
                              if (e.key === 'Enter' && selectedResultIndex === -1) {
                                handleSearchSubmit(e);
                              }
                            }}
                          />
                          
                          <SearchDropdown
                            query={searchQuery}
                            results={searchResults}
                            isLoading={isSearching}
                            onResultClick={handleSearchResultClick}
                            onKeyDown={handleSearchKeyDown}
                            selectedIndex={selectedResultIndex}
                          />
                        </div>
                      </form>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="absolute right-0 top-0 h-10 w-10 hover:bg-gold/10 hover:text-gold transition-all duration-200 hover:scale-105"
                        onClick={() => {
                          setIsSearchOpen(false);
                        }}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </motion.div>
                  ) : (
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => setIsSearchOpen(true)}
                      className="h-12 w-12 hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:text-white hover:scale-110 transition-all duration-300 hover:shadow-lg hover:shadow-gold/30 rounded-xl"
                    >
                      <Search className="h-5 w-5" />
                    </Button>
                  )}
                </AnimatePresence>
              </div>

              {/* Notifications removed per request */}

              {/* Cart */}
              <Link to="/cart">
                <Button 
                  size="icon" 
                  variant="ghost" 
                  className={cn(
                    'h-12 w-12 relative hover:scale-110 transition-all duration-300 hover:shadow-lg rounded-xl',
                    isCartActive 
                      ? 'text-white bg-gradient-to-r from-gold to-amber-400 hover:shadow-gold/30' 
                      : 'hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:text-white hover:shadow-gold/30'
                  )}
                  aria-current={isCartActive ? 'page' : undefined}
                >
                  <ShoppingCart className="h-5 w-5" />
                  {cartItemCount > 0 && (
                    <Badge className="absolute -top-2 -right-2 bg-gradient-to-r from-red-500 to-pink-500 text-white font-bold text-xs px-2 py-1 rounded-full animate-bounce shadow-lg">{cartItemCount}</Badge>
                  )}
                </Button>
              </Link>

              {/* Buyer customization chats quick link with global unread badge */}
              <Link to="/buyer/customizations">
                <Button size="icon" variant="ghost" className="h-12 w-12 relative hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:text-white hover:scale-110 transition-all duration-300 hover:shadow-lg hover:shadow-gold/30 rounded-xl">
                  <MessageSquare className="h-5 w-5" />
                  {buyerUnreadCount > 0 && (
                    <span className="absolute -top-2 -right-2 inline-flex items-center justify-center rounded-full bg-red-500 text-white text-xs h-6 min-w-6 px-1 font-bold animate-bounce shadow-lg">
                      {buyerUnreadCount}
                    </span>
                  )}
                </Button>
              </Link>

              

              {/* Wishlist */}
              <Link to="/wishlist">
                <Button
                  size="icon"
                  variant="ghost"
                  className={cn('h-12 w-12 relative hover:scale-110 transition-all duration-300 hover:shadow-lg rounded-xl', isWishlistActive ? 'text-white bg-gradient-to-r from-gold to-amber-400 hover:shadow-gold/30' : 'hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:text-white hover:shadow-gold/30')}
                  aria-label="Wishlist"
                  aria-current={isWishlistActive ? 'page' : undefined}
                >
                  <Heart className={cn('h-5 w-5 transition-all duration-300', isWishlistActive && 'fill-white text-white animate-pulse')} />
                  {wishlistCount > 0 && (
                    <Badge className="absolute -top-2 -right-2 bg-gradient-to-r from-red-500 to-pink-500 text-white font-bold text-xs px-2 py-1 rounded-full animate-bounce shadow-lg">
                      {wishlistCount}
                    </Badge>
                  )}
                </Button>
              </Link>

              {/* User Menu */}
              <div className="relative">
                {user && user.displayName ? (
                  <Button 
                    variant="ghost" 
                    className="flex items-center space-x-2 hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:text-white hover:scale-110 transition-all duration-300 h-12 px-4 rounded-xl hover:shadow-lg hover:shadow-gold/30"
                    onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  >
                    <User className="h-5 w-5 mr-2" />
                    <span className="text-sm font-semibold">{user.displayName}</span>
                  </Button>
                ) : (
                  <Link to="/login?mode=face">
                    <Button 
                      variant="ghost" 
                      className="h-12 px-4 inline-flex items-center hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:text-white hover:scale-110 transition-all duration-300 rounded-xl hover:shadow-lg hover:shadow-gold/30 font-semibold"
                      aria-label="Sign in or Sign up"
                    >
                      <LogIn className="h-5 w-5 mr-2" />
                      <span className="text-sm font-semibold">Sign In</span>
                    </Button>
                  </Link>
                )}
                
                {/* User Dropdown Menu */}
                <AnimatePresence>
                  {isUserMenuOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      className="absolute right-0 mt-2 w-48 bg-card rounded-md shadow-lg border border-border overflow-hidden z-50"
                    >
                      <div className="py-1">
                        {!user ? (
                          <>
                            <Link 
                              to="/login?mode=face" 
                              className="flex items-center px-4 py-2 text-sm hover:bg-gold/10 hover:text-gold"
                              onClick={() => setIsUserMenuOpen(false)}
                            >
                              <LogIn className="mr-2 h-4 w-4" />
                              Sign In
                            </Link>
                            <Link 
                              to="/register" 
                              className="flex items-center px-4 py-2 text-sm hover:bg-gold/10 hover:text-gold"
                              onClick={() => setIsUserMenuOpen(false)}
                            >
                              <UserPlus className="mr-2 h-4 w-4" />
                              Create Account
                            </Link>
                          </>
                        ) : (
                          <>
                            <div className="px-4 py-3 text-sm font-medium border-b border-border">
                              <div className="font-semibold">{user.displayName || 'User'}</div>
                              <div className="text-xs text-muted-foreground mt-1">{user.email}</div>
                            </div>
                            
                            <Link 
                              to="/profile" 
                              className="flex items-center px-4 py-2 text-sm hover:bg-gold/10 hover:text-gold"
                              onClick={() => setIsUserMenuOpen(false)}
                            >
                              <User className="mr-2 h-4 w-4" />
                              Profile
                            </Link>
                            <Link 
                              to="/orders" 
                              className="flex items-center px-4 py-2 text-sm hover:bg-gold/10 hover:text-gold"
                              onClick={() => setIsUserMenuOpen(false)}
                            >
                              <ShoppingCart className="mr-2 h-4 w-4" />
                              Orders
                            </Link>
                            <button 
                              className="w-full text-left flex items-center px-4 py-2 text-sm hover:bg-gold/10 hover:text-gold"
                              onClick={handleSignOut}
                            >
                              <LogIn className="mr-2 h-4 w-4 rotate-180" />
                              Sign Out
                            </button>
                          </>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Mobile Menu Toggle */}
              <Button
                size="icon"
                variant="ghost"
                className="h-12 w-12 hover:bg-gradient-to-r hover:from-gold hover:to-amber-400 hover:text-white hover:scale-110 transition-all duration-300 hover:shadow-lg hover:shadow-gold/30 rounded-xl lg:hidden"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Overlay */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              className="fixed inset-0 z-[40]" 
              style={{ touchAction: 'none' }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
            >
              {/* Backdrop overlay */}
              <motion.div 
                className="absolute inset-0 w-full h-full bg-black/60 backdrop-blur-sm"
                onClick={() => setIsMenuOpen(false)}
                style={{ pointerEvents: 'all' }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              />
              
              {/* Side Navigation */}
              <motion.div 
                className="absolute top-0 right-0 bottom-0 w-4/5 md:w-1/2 lg:w-1/3 border-l border-gold/20 bg-card/95 backdrop-blur-xl z-[60] overflow-hidden sidebar-container shadow-2xl shadow-black/20"
                style={{ height: '100vh', pointerEvents: 'all' }}
                onClick={(e) => e.stopPropagation()}
                initial={{ x: '100%' }}
                animate={{ x: 0 }}
                exit={{ x: '100%' }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              >
              {/* Header with close button */}
              <div className="sticky top-0 z-10 flex justify-between items-center p-5 border-b border-gold/20 bg-gradient-to-r from-card/95 to-card/90 backdrop-blur-xl">
                <div className="flex flex-col items-start space-y-1">
                  <img src={logoImage} alt="EWSELLS |CHARITY STORE BEYOND| logo" className="w-24 h-auto" />
                  <span className="text-[10px] font-medium text-gold/80 tracking-wide uppercase">
                    India's First Online Charity Store
                  </span>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => setIsMenuOpen(false)}
                  className="h-8 w-8 text-foreground hover:bg-gold/10 hover:text-gold hover:scale-105 transition-all duration-200"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              
              {/* Scrollable content */}
              <div 
                className="overflow-y-auto overscroll-contain" 
                style={{ height: 'calc(100vh - 73px)' }}
                onWheel={(e) => e.stopPropagation()}
              >
                <div className="p-5 space-y-5">
                  {/* Authentication Links */}
                  {!user && (
                    <div className="border-b border-gold/20 pb-4 mb-4">
                      <h3 className="font-semibold text-sm text-gold mb-3 px-3 uppercase tracking-wider flex items-center">
                        <User className="mr-2 h-4 w-4" />
                        Account
                      </h3>
                      <Link
                        to="/login?mode=face"
                        onClick={() => setIsMenuOpen(false)}
                        className="flex items-center px-3 py-3 text-sm font-medium transition-all duration-200 hover:text-gold hover:bg-gold/5 text-foreground rounded-lg mx-2 hover:scale-105"
                      >
                        <LogIn className="mr-3 h-4 w-4" />
                        Sign In
                      </Link>
                      <Link
                        to="/register"
                        onClick={() => setIsMenuOpen(false)}
                        className="flex items-center px-3 py-3 text-sm font-medium transition-all duration-200 hover:text-gold hover:bg-gold/5 text-foreground rounded-lg mx-2 hover:scale-105"
                      >
                        <UserPlus className="mr-3 h-4 w-4" />
                        Create Account
                      </Link>
                    </div>
                  )}
                  
                {/* Quick Actions */}
                <div className="border-b border-gold/20 pb-4 mb-4">
                    <h3 className="font-semibold text-sm text-gold mb-3 px-3 uppercase tracking-wider flex items-center">
                      <Store className="mr-2 h-4 w-4" />
                      Quick Actions
                    </h3>
                    <Link
                      to="/become-seller"
                      onClick={() => setIsMenuOpen(false)}
                      className="flex items-center w-full px-3 py-3 text-sm font-medium rounded-lg transition-all duration-200 hover:text-gold hover:bg-gold/5 text-foreground mx-2 hover:scale-105"
                    >
                      <Store className="mr-3 h-4 w-4" />
                      Become a Seller
                      <span className="ml-auto">{renderSellerBadge()}</span>
                    </Link>
                    
                    <Link
                      to="/helping-hands"
                      onClick={() => setIsMenuOpen(false)}
                      className="flex items-center w-full px-3 py-3 text-sm font-medium transition-all duration-200 hover:text-gold hover:bg-gold/5 text-foreground rounded-lg mx-2 hover:scale-105"
                    >
                      <HandHelping className="mr-3 h-4 w-4" />
                      Helping Hands
                    </Link>
                    
                    <Link
                      to="/chat"
                      onClick={() => setIsMenuOpen(false)}
                      className="flex items-center w-full px-3 py-3 text-sm font-medium transition-all duration-200 hover:text-gold hover:bg-gold/5 text-foreground rounded-lg mx-2 hover:scale-105"
                    >
                      <MessageSquare className="mr-3 h-4 w-4" />
                      Chat with Smile Sales AI
                    </Link>
                  </div>
                  
                  {/* Navigation Items */}
                  <div className="pb-24">
                    <h3 className="font-semibold text-sm text-gold mb-3 px-3 uppercase tracking-wider flex items-center">
                      <Home className="mr-2 h-4 w-4" />
                      Explore
                    </h3>
                    {navigationItems.filter(item => item.name !== 'Helping Hands' && item.name !== 'Chat with Smile Sales AI' && item.name !== 'Official Portal' && item.name !== 'Group List').map((item, index) => (
                      <motion.div
                        key={item.name}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                      >
                        <Link
                          to={item.href}
                          onClick={() => setIsMenuOpen(false)}
                          className={cn(
                            'block px-3 py-3 text-sm font-medium transition-all duration-200 hover:text-gold hover:bg-gold/5 rounded-lg mx-2 hover:scale-105',
                            location.pathname === item.href
                              ? 'text-gold font-semibold bg-gold/10'
                              : 'text-foreground'
                          )}
                        >
                          {item.name}
                        </Link>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>
    </>
  );
}