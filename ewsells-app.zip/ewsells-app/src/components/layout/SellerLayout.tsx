import { Outlet } from 'react-router-dom';
import { SellerHeader } from './SellerHeader';
import { Footer } from '@/components/layout/Footer';

export function SellerLayout() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <SellerHeader />
      <main className="pt-20 pb-12">
        <div className="container mx-auto px-4">
          <Outlet />
        </div>
      </main>
      <Footer />
    </div>
  );
}
