import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heart, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';
import logoImage from '@/assets/logo.png';

const footerLinks = [
  {
    title: 'Shop',
    links: [
      { name: 'Charity Craft', href: '/category/charity-craft' },
      { name: 'Organic Store', href: '/category/organic-store' },
      { name: 'Scrap Store', href: '/category/scrap-store' },
      { name: 'Moms Made United', href: '/category/moms-made-united' },
      { name: 'Charity Bakes', href: '/charity-bakes' },
      { name: 'Home Decor', href: '/category/home-decor' },
    ],
  },
  {
    title: 'Community',
    links: [
      { name: 'Green Cup Challenge', href: '/green-cup' },
      { name: 'Smile Community Kitchen', href: '/community-kitchen' },
      { name: 'Registered Sellers', href: '/sellers' },
      { name: 'Meet our Team', href: '/team' },
    ],
  },
  {
    title: 'Support',
    links: [
      { name: 'FAQ', href: '/faq' },
      { name: 'Chat with Smile Sales AI', href: '/chat' },
      { name: 'Become a Seller', href: '/become-seller' },
      { name: 'Plans and Pricing', href: '/pricing' },
    ],
  },
  {
    title: 'Connect',
    links: [
      { name: 'Refer Friends', href: '/refer' },
      { name: 'SCK Loyalty', href: '/loyalty' },
      { name: 'Reservations', href: '/reservations' },
      { name: 'About Us', href: '/about' },
      { name: 'Contact', href: '/contact' },
      { name: 'Admin', href: '/admin-login' },
    ],
  },
];

const socialLinks = [
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Youtube, href: '#', label: 'YouTube' },
];

// Create a motion version of Link
const MotionLink = motion.create(Link);

export function Footer() {
  return (
    <footer className="bg-surface mt-20 relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-gradient-to-br from-gold/20 via-transparent to-transparent" />
        <div className="grain" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* Main footer content */}
        <div className="pt-16 pb-8 border-b border-border/20">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            {/* Brand section */}
            <div className="lg:col-span-1 space-y-4">
              <MotionLink to="/" className="flex items-center space-x-2">
                <img src={logoImage} alt="EWSELLS |CHARITY STORE BEYOND| logo" className="w-38 h-24" />
              </MotionLink>
              
              <p className="text-muted-foreground text-sm leading-relaxed">
                A charity storefront where every purchase makes a difference. 
                Transparent impact, authentic products, real change.
              </p>

              <div className="flex space-x-4">
                {socialLinks.map((social) => (
                  <motion.a
                    key={social.label}
                    href={social.href}
                    className="w-10 h-10 bg-card hover:bg-gold/20 rounded-lg flex items-center justify-center text-muted-foreground hover:text-gold transition-colors"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    aria-label={social.label}
                  >
                    <social.icon className="h-5 w-5" />
                  </motion.a>
                ))}
              </div>
            </div>

            {/* Links sections */}
            {footerLinks.map((section, index) => (
              <div key={section.title} className="space-y-4">
                <h3 className="text-sm font-semibold text-gold uppercase tracking-wide">
                  {section.title}
                </h3>
                <ul className="space-y-2">
                  {section.links.map((link) => (
                    <motion.li key={link.name}>
                      {link.name === 'Admin' ? (
                        <MotionLink
                          to={link.href}
                          className="text-muted-foreground/50 hover:text-foreground text-xs transition-colors"
                          whileHover={{ x: 4 }}
                        >
                          {link.name}
                        </MotionLink>
                      ) : (
                        <MotionLink
                          to={link.href}
                          className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                          whileHover={{ x: 4 }}
                        >
                          {link.name}
                        </MotionLink>
                      )}
                    </motion.li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* Contact info */}
          <div className="mt-12 pt-8 border-t border-border/20">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gold/10 rounded-lg flex items-center justify-center">
                  <Mail className="h-5 w-5 text-gold" />
                </div>
                <div>
                  <p className="text-sm font-medium">Email</p>
                  <p className="text-sm text-muted-foreground">hello@ewsells.org</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gold/10 rounded-lg flex items-center justify-center">
                  <Phone className="h-5 w-5 text-gold" />
                </div>
                <div>
                  <p className="text-sm font-medium">Phone</p>
                  <p className="text-sm text-muted-foreground">+1 (555) 123-4567</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gold/10 rounded-lg flex items-center justify-center">
                  <MapPin className="h-5 w-5 text-gold" />
                </div>
                <div>
                  <p className="text-sm font-medium">Address</p>
                  <p className="text-sm text-muted-foreground">123 Impact Street, Change City</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="py-6 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="flex items-center space-x-1 text-sm text-muted-foreground">
            <span>Made with</span>
            <Heart className="h-4 w-4 text-red-500 fill-current" />
            <span>for a better world</span>
          </div>
          
          <div className="flex flex-col md:flex-row items-center space-y-2 md:space-y-0 md:space-x-6 text-sm text-muted-foreground">
            <Link to="/privacy" className="hover:text-foreground transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms" className="hover:text-foreground transition-colors">
              Terms of Service
            </Link>
            <span> 2025 EWSELLS |CHARITY STORE BEYOND|. All rights reserved.</span>
          </div>
        </div>
      </div>
    </footer>
  );
}