import { collection, query, getDocs, limit } from 'firebase/firestore';
import { db } from '@/lib/firebase';

export interface SearchResult {
  id: string;
  title: string;
  type: 'product' | 'category';
  image?: string;
  description?: string;
  url: string;
  relatedItems?: SearchResult[];
  category?: string;
  categoryId?: string;
  price?: number;
}

/**
 * Search for products and categories in Firestore
 * @param searchQuery The search query string
 * @param maxResults Maximum number of results to return (default: 10)
 * @param includeRelated Whether to include related products (default: true)
 * @param maxRelatedItems Maximum number of related items per result (default: 4)
 * @returns Promise with search results
 */
export const searchItems = async (searchQuery: string, maxResults = 10, includeRelated = true, maxRelatedItems = 4): Promise<SearchResult[]> => {
  console.log('Search query:', searchQuery);
  if (!searchQuery || searchQuery.trim().length < 2) {
    console.log('Search query too short');
    return [];
  }

  const results: SearchResult[] = [];
  const searchQueryLower = searchQuery.toLowerCase().trim();
  
  console.log('Search query lower:', searchQueryLower);
  
  try {
    console.log('%c Starting Firestore queries', 'background: #222; color: #bada55');
    
    // Get all products and filter client-side
    // This approach is more reliable for small to medium-sized collections
    const productsRef = collection(db, 'products');
    console.log('Products collection reference:', productsRef.path);
    
    // Get all products without status filter
    const productQuery = query(
      productsRef,
      limit(100) // Limit to 100 products for performance
    );
    
    console.log('%c Executing product query', 'background: #222; color: #bada55');
    const productSnapshots = await getDocs(productQuery);
    console.log('%c Product snapshots count:', 'background: #222; color: #bada55', productSnapshots.size);
    
    // Log the first few products to see what we're working with
    if (productSnapshots.size > 0) {
      console.log('%c First product example:', 'background: #222; color: #bada55');
      const firstProduct = productSnapshots.docs[0].data();
      console.log('Product ID:', productSnapshots.docs[0].id);
      console.log('Product data:', firstProduct);
      
      // Log all fields to understand the data structure
      Object.keys(firstProduct).forEach(key => {
        console.log(`Product ${key}:`, firstProduct[key]);
      });
    } else {
      console.log('%c NO PRODUCTS FOUND IN FIRESTORE', 'background: red; color: white; font-size: 16px');
    }
    
    // Process product results - filter client-side
    const processedProductIds = new Set<string>();
    
    productSnapshots.forEach(snapshot => {
      const productData = snapshot.data();
      
      // Try different possible field names for title
      const possibleTitleFields = ['title', 'name', 'productName', 'product_name'];
      let title = '';
      for (const field of possibleTitleFields) {
        if (productData[field]) {
          title = String(productData[field]).toLowerCase();
          break;
        }
      }
      
      // Try different possible field names for description
      const possibleDescFields = ['description', 'desc', 'productDescription', 'product_description', 'details'];
      let description = '';
      for (const field of possibleDescFields) {
        if (productData[field]) {
          description = String(productData[field]);
          break;
        }
      }
      
      // Try different possible field names for tags
      const possibleTagFields = ['tags', 'categories', 'keywords', 'tag'];
      let tags: string[] = [];
      for (const field of possibleTagFields) {
        if (productData[field]) {
          if (Array.isArray(productData[field])) {
            tags = productData[field];
          } else if (typeof productData[field] === 'string') {
            // Handle comma-separated string tags
            tags = productData[field].split(',').map((tag: string) => tag.trim());
          }
          break;
        }
      }
      
      // Try different possible field names for image
      const possibleImageFields = ['images', 'image', 'imageUrl', 'image_url', 'imageURL', 'photos', 'photo'];
      let imageUrl: string | undefined = undefined;
      for (const field of possibleImageFields) {
        if (productData[field]) {
          if (Array.isArray(productData[field]) && productData[field].length > 0) {
            imageUrl = productData[field][0];
          } else if (typeof productData[field] === 'string') {
            imageUrl = productData[field];
          }
          break;
        }
      }
      
      // Debug individual product
      console.log(`Checking product ${snapshot.id}:`, {
        title,
        description: description?.substring(0, 30) + '...',
        tags,
        imageUrl,
        matchesQuery: title.includes(searchQueryLower) || description.toLowerCase().includes(searchQueryLower),
        tagMatch: tags.some(tag => typeof tag === 'string' && tag.toLowerCase().includes(searchQueryLower))
      });
      
      // Check if product title, description or tags match the search query
      if (title.includes(searchQueryLower) || 
          description.toLowerCase().includes(searchQueryLower) ||
          tags.some(tag => typeof tag === 'string' && tag.toLowerCase().includes(searchQueryLower))) {
        
        console.log('%c Found matching product:', 'background: green; color: white', snapshot.id, title);
        
        if (!processedProductIds.has(snapshot.id)) {
          processedProductIds.add(snapshot.id);
          results.push({
            id: snapshot.id,
            title: title || 'Unnamed Product',
            type: 'product',
            image: imageUrl,
            description: description?.substring(0, 100) || undefined,
            url: `/product/${snapshot.id}`
          });
        }
      }
    });
    
    // Search categories - get all and filter client-side
    try {
      const categoriesRef = collection(db, 'categories');
      console.log('Categories collection reference:', categoriesRef.path);
      
      // Get all categories (usually a small collection)
      const categoryQuery = query(
        categoriesRef,
        limit(50) // Reasonable limit for categories
      );
      
      console.log('%c Executing category query', 'background: #222; color: #bada55');
      const categorySnapshots = await getDocs(categoryQuery);
      console.log('%c Category snapshots count:', 'background: #222; color: #bada55', categorySnapshots.size);
      
      // Log the first category to see what we're working with
      if (categorySnapshots.size > 0) {
        console.log('%c First category example:', 'background: #222; color: #bada55');
        const firstCategory = categorySnapshots.docs[0].data();
        console.log('Category ID:', categorySnapshots.docs[0].id);
        console.log('Category data:', firstCategory);
        
        // Log all fields to understand the data structure
        Object.keys(firstCategory).forEach(key => {
          console.log(`Category ${key}:`, firstCategory[key]);
        });
      } else {
        console.log('%c NO CATEGORIES FOUND IN FIRESTORE', 'background: red; color: white; font-size: 16px');
      }
      
      // Process category results - filter client-side with flexible field matching
      const processedCategoryIds = new Set<string>();
      
      categorySnapshots.forEach(snapshot => {
        const categoryData = snapshot.data();
        
        // Try different possible field names for name
        const possibleNameFields = ['name', 'title', 'categoryName', 'category_name'];
        let name = '';
        for (const field of possibleNameFields) {
          if (categoryData[field]) {
            name = String(categoryData[field]).toLowerCase();
            break;
          }
        }
        
        // Try different possible field names for description
        const possibleDescFields = ['description', 'desc', 'categoryDescription', 'category_description', 'details'];
        let description = '';
        for (const field of possibleDescFields) {
          if (categoryData[field]) {
            description = String(categoryData[field]);
            break;
          }
        }
        
        // Try different possible field names for image
        const possibleImageFields = ['image', 'imageUrl', 'image_url', 'imageURL', 'photo'];
        let imageUrl: string | undefined = undefined;
        for (const field of possibleImageFields) {
          if (categoryData[field]) {
            imageUrl = String(categoryData[field]);
            break;
          }
        }
        
        // Debug individual category
        console.log(`Checking category ${snapshot.id}:`, {
          name,
          description: description?.substring(0, 30) + '...',
          imageUrl,
          matchesQuery: name.includes(searchQueryLower) || description.toLowerCase().includes(searchQueryLower)
        });
        
        // Check if category name or description matches the search query
        if (name.includes(searchQueryLower) || description.toLowerCase().includes(searchQueryLower)) {
          console.log('%c Found matching category:', 'background: green; color: white', snapshot.id, name);
          
          if (!processedCategoryIds.has(snapshot.id)) {
            processedCategoryIds.add(snapshot.id);
            results.push({
              id: snapshot.id,
              title: name || 'Unnamed Category',
              type: 'category',
              image: imageUrl,
              description: description?.substring(0, 100) || undefined,
              url: `/category/${snapshot.id}`
            });
          }
        }
      });
    } catch (categoryError) {
      console.error('%c Error fetching categories:', 'background: red; color: white', categoryError);
      // Continue with the results we have from products
      console.log('Continuing with product results only due to category permission error');
    }
    
    // Sort results by relevance (exact matches first)
    results.sort((a, b) => {
      // Categories first
      if (a.type === 'category' && b.type !== 'category') return -1;
      if (a.type !== 'category' && b.type === 'category') return 1;
      
      const aTitle = a.title?.toLowerCase() || '';
      const bTitle = b.title?.toLowerCase() || '';
      
      // Exact matches first
      const aExact = aTitle === searchQueryLower;
      const bExact = bTitle === searchQueryLower;
      
      if (aExact && !bExact) return -1;
      if (!aExact && bExact) return 1;
      
      // Then starts with
      const aStartsWith = aTitle.startsWith(searchQueryLower);
      const bStartsWith = bTitle.startsWith(searchQueryLower);
      
      if (aStartsWith && !bStartsWith) return -1;
      if (!aStartsWith && bStartsWith) return 1;
      
      // Then contains (closer to beginning is better)
      const aIndex = aTitle.indexOf(searchQueryLower);
      const bIndex = bTitle.indexOf(searchQueryLower);
      
      if (aIndex !== -1 && bIndex !== -1) {
        return aIndex - bIndex;
      }
      
      // Then alphabetical
      return aTitle.localeCompare(bTitle);
    });
    
    // Get related products for each product result if requested
    if (includeRelated) {
      // First, check if we have category data available
      let categorySnapshots: any[] = [];
      try {
        const categoriesRef = collection(db, 'categories');
        const categoryQuery = query(
          categoriesRef,
          limit(50) // Reasonable limit for categories
        );
        
        const categorySnapshotsResult = await getDocs(categoryQuery);
        categorySnapshots = categorySnapshotsResult.docs;
      } catch (categoryError) {
        console.error('Error fetching categories for related products:', categoryError);
        // Continue without categories
      }
      
      await Promise.all(
        results
          .filter(result => result.type === 'product')
          .map(async (result) => {
            try {
              // Get the product data to find category or other related attributes
              const productDoc = productSnapshots.docs.find(doc => doc.id === result.id);
              if (productDoc) {
                const productData = productDoc.data();
                
                // Try to get category ID from product
                let categoryId = '';
                const possibleCategoryFields = ['category', 'categoryId', 'category_id', 'categories'];
                for (const field of possibleCategoryFields) {
                  if (productData[field]) {
                    if (typeof productData[field] === 'string') {
                      categoryId = productData[field];
                      break;
                    } else if (Array.isArray(productData[field]) && productData[field].length > 0) {
                      categoryId = productData[field][0];
                      break;
                    }
                  }
                }
                
                // Store category info in the result
                if (categoryId) {
                  result.categoryId = categoryId;
                  
                  // Find category name if available
                  const categoryDoc = categorySnapshots.find((doc: any) => doc.id === categoryId);
                  if (categoryDoc) {
                    const categoryData = categoryDoc.data();
                    const possibleNameFields = ['name', 'title', 'categoryName', 'category_name'];
                    for (const field of possibleNameFields) {
                      if (categoryData[field]) {
                        result.category = String(categoryData[field]);
                        break;
                      }
                    }
                  }
                }
                
                // Get price if available
                const possiblePriceFields = ['price', 'cost', 'amount'];
                for (const field of possiblePriceFields) {
                  if (productData[field] && typeof productData[field] === 'number') {
                    result.price = productData[field];
                    break;
                  }
                }
                
                // Find related products based on category
                if (categoryId) {
                  const relatedProducts = productSnapshots.docs
                    .filter(doc => {
                      if (doc.id === result.id) return false; // Skip the current product
                      
                      const data = doc.data();
                      let docCategoryId = '';
                      
                      // Check if product has the same category
                      for (const field of possibleCategoryFields) {
                        if (data[field]) {
                          if (typeof data[field] === 'string') {
                            docCategoryId = data[field];
                            break;
                          } else if (Array.isArray(data[field]) && data[field].length > 0) {
                            docCategoryId = data[field][0];
                            break;
                          }
                        }
                      }
                      
                      return docCategoryId === categoryId;
                    })
                    .slice(0, maxRelatedItems)
                    .map(doc => {
                      const data = doc.data();
                      
                      // Get title
                      let title = '';
                      const possibleTitleFields = ['title', 'name', 'productName', 'product_name'];
                      for (const field of possibleTitleFields) {
                        if (data[field]) {
                          title = String(data[field]);
                          break;
                        }
                      }
                      
                      // Get image
                      let imageUrl: string | undefined = undefined;
                      const possibleImageFields = ['images', 'image', 'imageUrl', 'image_url', 'imageURL', 'photos', 'photo'];
                      for (const field of possibleImageFields) {
                        if (data[field]) {
                          if (Array.isArray(data[field]) && data[field].length > 0) {
                            imageUrl = data[field][0];
                          } else if (typeof data[field] === 'string') {
                            imageUrl = data[field];
                          }
                          break;
                        }
                      }
                      
                      // Get price
                      let price: number | undefined = undefined;
                      for (const field of possiblePriceFields) {
                        if (data[field] && typeof data[field] === 'number') {
                          price = data[field];
                          break;
                        }
                      }
                      
                      return {
                        id: doc.id,
                        title: title || 'Related Product',
                        type: 'product' as const,
                        image: imageUrl,
                        url: `/product/${doc.id}`,
                        price
                      };
                    });
                  
                  if (relatedProducts.length > 0) {
                    result.relatedItems = relatedProducts;
                  }
                }
              }
            } catch (error) {
              console.error('Error getting related products:', error);
            }
          })
      );
      
      // For category results, include some products from that category
      await Promise.all(
        results
          .filter(result => result.type === 'category')
          .map(async (result) => {
            try {
              const categoryProducts = productSnapshots.docs
                .filter((doc: any) => {
                  const data = doc.data();
                  let docCategoryId = '';
                  
                  // Check if product belongs to this category
                  const possibleCategoryFields = ['category', 'categoryId', 'category_id', 'categories'];
                  for (const field of possibleCategoryFields) {
                    if (data[field]) {
                      if (typeof data[field] === 'string') {
                        docCategoryId = data[field];
                        break;
                      } else if (Array.isArray(data[field]) && data[field].length > 0) {
                        docCategoryId = data[field][0];
                        break;
                      }
                    }
                  }
                  
                  return docCategoryId === result.id;
                })
                .slice(0, maxRelatedItems)
                .map(doc => {
                  const data = doc.data();
                  
                  // Get title
                  let title = '';
                  const possibleTitleFields = ['title', 'name', 'productName', 'product_name'];
                  for (const field of possibleTitleFields) {
                    if (data[field]) {
                      title = String(data[field]);
                      break;
                    }
                  }
                  
                  // Get image
                  let imageUrl: string | undefined = undefined;
                  const possibleImageFields = ['images', 'image', 'imageUrl', 'image_url', 'imageURL', 'photos', 'photo'];
                  for (const field of possibleImageFields) {
                    if (data[field]) {
                      if (Array.isArray(data[field]) && data[field].length > 0) {
                        imageUrl = data[field][0];
                      } else if (typeof data[field] === 'string') {
                        imageUrl = data[field];
                      }
                      break;
                    }
                  }
                  
                  // Get price
                  let price: number | undefined = undefined;
                  const possiblePriceFields = ['price', 'cost', 'amount'];
                  for (const field of possiblePriceFields) {
                    if (data[field] && typeof data[field] === 'number') {
                      price = data[field];
                      break;
                    }
                  }
                  
                  return {
                    id: doc.id,
                    title: title || 'Category Product',
                    type: 'product' as const,
                    image: imageUrl,
                    url: `/product/${doc.id}`,
                    price
                  };
                });
              
              if (categoryProducts.length > 0) {
                result.relatedItems = categoryProducts;
              }
            } catch (error) {
              console.error('Error getting category products:', error);
            }
          })
      );
    }
    
    console.log('Final search results count:', results.length);
    return results.slice(0, maxResults);
  } catch (error) {
    console.error('Error searching items:', error);
    console.error('Error details:', JSON.stringify(error));
    return [];
  }
};

/**
 * Get suggested search terms based on popular products and categories
 * @param maxResults Maximum number of suggestions to return
 * @returns Promise with suggested search terms
 */
export const getSearchSuggestions = async (maxResults = 5): Promise<string[]> => {
  try {
    // Get products - use a simpler query to avoid index issues
    const productsRef = collection(db, 'products');
    const productsQuery = query(
      productsRef,
      limit(20) // Get more than needed to have a selection
    );
    
    const productsSnapshot = await getDocs(productsQuery);
    
    // Sort client-side by viewCount if available, otherwise just use the first few
    const sortedProducts = productsSnapshot.docs
      .map(doc => ({
        id: doc.id,
        data: doc.data(),
        viewCount: doc.data().viewCount || 0
      }))
      .sort((a, b) => b.viewCount - a.viewCount)
      .slice(0, maxResults);
    
    const suggestions = sortedProducts.map(product => product.data.title || '');
    
    // Get categories - use a simpler query
    const categoriesRef = collection(db, 'categories');
    const categoriesQuery = query(
      categoriesRef,
      limit(20) // Get more than needed
    );
    
    const categoriesSnapshot = await getDocs(categoriesQuery);
    
    // Sort client-side by priority if available
    const sortedCategories = categoriesSnapshot.docs
      .map(doc => ({
        id: doc.id,
        data: doc.data(),
        priority: doc.data().priority || 0
      }))
      .sort((a, b) => b.priority - a.priority)
      .slice(0, maxResults);
    
    const categorySuggestions = sortedCategories.map(category => category.data.name || '');
    
    // Combine, filter out empty strings, remove duplicates and limit
    return [...suggestions, ...categorySuggestions]
      .filter(value => value && value.trim() !== '') // Remove empty strings
      .filter((value, index, self) => self.indexOf(value) === index) // Remove duplicates
      .slice(0, maxResults);
  } catch (error) {
    console.error('Error getting search suggestions:', error);
    return [];
  }
};
