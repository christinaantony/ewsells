import { httpsCallable } from 'firebase/functions';
import { functions } from '../lib/firebase';
import { getChatContextWithUser, formatContextForAI, formatUserContextForAI } from './contextService';
import { auth } from '../lib/firebase';

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export const sendChatMessage = async (messages: ChatMessage[]): Promise<ChatMessage> => {
  try {
    const chatFunction = httpsCallable<{ messages: ChatMessage[] }, ChatMessage>(
      functions,
      'chat'
    );
    
    const result = await chatFunction({ messages });
    return result.data;
  } catch (error) {
    console.error('Error sending chat message:', error);
    throw new Error('Failed to get response from the chat service');
  }
};

// Direct HTTP call to the deployed Cloud Function
export const sendChatMessageDirect = async (messages: ChatMessage[]): Promise<ChatMessage> => {
  try {
    // Get current user ID if authenticated
    const currentUser = auth.currentUser;
    const userId = currentUser?.uid;
    
    // Get context data from Firestore with user-specific context if available
    const contextWithUser = await getChatContextWithUser(userId);
    const generalContextInfo = formatContextForAI(contextWithUser);
    
    // Create enhanced system message with context
    let systemMessage = `You are Smile Sales AI, a helpful shopping assistant for Expectation Walkers Public Charitable Trust. Be friendly, concise, and helpful.

PERSONALIZATION INSTRUCTIONS:
- Always address the user by their name when available
- Reference their order history, preferences, and past interactions when relevant
- Provide personalized recommendations based on their purchase history
- Acknowledge their membership status and loyalty
- Use context from their previous orders and requests to make conversations more natural

PRIVACY RULES:
- You can access and discuss the authenticated user's own data (orders, profile, requests)
- NEVER share or mention any other customers' or sellers' personal information
- Only discuss the current user's personal information when they ask about it
- Maintain privacy for all other users' data

Current Platform Context:
${generalContextInfo}`;

    // Add user-specific context if available
    if (userId && contextWithUser.userContext) {
      const userContextInfo = formatUserContextForAI(contextWithUser.userContext);
      
      // Get user name from profile or Firebase Auth as fallback
      let userName = contextWithUser.userContext.userProfile?.name;
      if (!userName || userName === 'User') {
        userName = currentUser?.displayName || currentUser?.email?.split('@')[0] || 'valued customer';
      }
      
      systemMessage += `

AUTHENTICATED USER CONTEXT:
${userContextInfo}

PERSONALIZATION GUIDELINES FOR THIS USER:
- Address them as "${userName}"
- Reference their order history when making recommendations
- Acknowledge their role as a ${contextWithUser.userContext.userProfile?.role || 'customer'}
- Use their past purchase patterns to suggest relevant products
- Be aware of their helping hands requests and show empathy
- Make the conversation feel personal and tailored to their needs`;
    } else if (userId && currentUser) {
      // Fallback when context service fails but user is authenticated
      const userName = currentUser.displayName || currentUser.email?.split('@')[0] || 'valued customer';
      systemMessage += `

AUTHENTICATED USER FALLBACK:
- Address them as "${userName}"
- User is authenticated but detailed context unavailable
- Provide general assistance while being personable`;
    }

    systemMessage += `

Use this context to provide helpful, accurate, and highly personalized information about products, charity projects, and the user's personal data when requested. Make every interaction feel tailored to the individual user.`;

    // Add system message if not present, or replace existing one with enhanced version
    const chatMessages = messages.some(m => m.role === 'system') 
      ? [
          { role: 'system', content: systemMessage } as ChatMessage,
          ...messages.filter(m => m.role !== 'system')
        ]
      : [
          { role: 'system', content: systemMessage } as ChatMessage,
          ...messages
        ];

    const response = await fetch('https://chat-qvnxnz2rfa-uc.a.run.app', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ messages: chatMessages }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error || `Error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    return {
      role: 'assistant',
      content: data.message?.content || 'Sorry, I had trouble understanding that.'
    };
  } catch (error) {
    console.error('Error sending chat message:', error);
    throw error instanceof Error ? error : new Error('Failed to get response from the chat service');
  }
};
