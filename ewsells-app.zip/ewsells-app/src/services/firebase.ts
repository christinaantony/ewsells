import {
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  updateDoc,
  Timestamp,
} from 'firebase/firestore';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged
} from 'firebase/auth';
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { db, auth, storage } from '@/lib/firebase';
import { mockProducts, mockProjects, mockSellers, mockOrders } from '@/fixtures/mockData';
import type { Product, Project, Seller, Order } from '@/types';

// Auth Service
export const authService = {
  async signIn(email: string, password: string) {
    return signInWithEmailAndPassword(auth, email, password);
  },
  
  async signUp(email: string, password: string) {
    return createUserWithEmailAndPassword(auth, email, password);
  },
  
  async signOut() {
    return firebaseSignOut(auth);
  },
  
  onAuthStateChange(callback: (user: any) => void) {
    return onAuthStateChanged(auth, callback);
  },
};

// Firestore Service
export const firestoreService = {
  // Products
  async getProducts(includeUnpublished: boolean = false): Promise<Product[]> {
    try {
      let q;
      if (includeUnpublished) {
        q = collection(db, 'products');
      } else {
        // Only fetch published products
        q = query(collection(db, 'products'), where('published', '==', true));
      }
      
      const querySnapshot = await getDocs(q);
      if (querySnapshot.empty) {
        return [];
      }
      
      return querySnapshot.docs.map(d => {
        const raw = d.data() as any;
        // Accept multiple possible image field names
        const imageCandidates: string[] = [];
        if (Array.isArray(raw.images)) imageCandidates.push(...raw.images);
        if (Array.isArray(raw.imageUrls)) imageCandidates.push(...raw.imageUrls);
        if (typeof raw.imageUrl === 'string') imageCandidates.push(raw.imageUrl);
        if (typeof raw.image === 'string') imageCandidates.push(raw.image);
        if (typeof raw.photo === 'string') imageCandidates.push(raw.photo);
        if (typeof raw.thumbnail === 'string') imageCandidates.push(raw.thumbnail);
        if (typeof raw.coverUrl === 'string') imageCandidates.push(raw.coverUrl);
        const images: string[] = imageCandidates.filter(Boolean);

        const createdAt = raw.createdAt?.toDate ? raw.createdAt.toDate() : (raw.createdAt ? new Date(raw.createdAt) : new Date());
        const updatedAt = raw.updatedAt?.toDate ? raw.updatedAt.toDate() : (raw.updatedAt ? new Date(raw.updatedAt) : createdAt);

        const product: Product = {
          id: d.id,
          title: raw.title ?? raw.name ?? 'Untitled',
          description: raw.description ?? '',
          images,
          category: raw.category ?? 'Uncategorized',
          tags: raw.tags ?? [],
          sellerId: raw.sellerId ?? '',
          basePriceSeller: raw.basePriceSeller ?? raw.finalPrice ?? raw.sellerPrice ?? raw.price ?? 0,
          upliftPercent: raw.upliftPercent ?? 20,
          projectAllocations: raw.projectAllocations ?? [],
          location: raw.location ?? {
            address: raw.address ?? '',
            city: raw.city ?? 'Unknown',
            state: raw.state ?? '',
            country: raw.country ?? '',
            lat: raw.lat ?? 0,
            lng: raw.lng ?? 0,
          },
          badges: raw.badges ?? [],
          isRental: raw.isRental ?? false,
          customizable: !!raw.customizable,
          status: raw.status ?? 'active',
          createdAt,
          updatedAt,
          stock: typeof raw.stock === 'number' ? raw.stock : (raw.stock != null ? Number(raw.stock) : undefined),
          outOfStock: typeof raw.outOfStock === 'boolean' ? raw.outOfStock : (typeof raw.stock === 'number' ? raw.stock <= 0 : undefined),
        };
        return product;
      });
    } catch (error) {
      console.error('Error fetching products:', error);
      // On error, surface empty list (no mock fallback)
      return [];
    }
  },

  async getProduct(id: string, includeUnpublished: boolean = false): Promise<Product | null> {
    try {
      const docSnap = await getDoc(doc(db, 'products', id));
      if (!docSnap.exists()) return null;
      
      const raw = docSnap.data() as any;
      
      // Skip unpublished products unless explicitly requested
      if (!includeUnpublished && raw.published === false) {
        return null;
      }

      // Accept multiple possible image field names
      const imageCandidates: string[] = [];
      if (Array.isArray(raw.images)) imageCandidates.push(...raw.images);
      if (Array.isArray(raw.imageUrls)) imageCandidates.push(...raw.imageUrls);
      if (typeof raw.imageUrl === 'string') imageCandidates.push(raw.imageUrl);
      if (typeof raw.image === 'string') imageCandidates.push(raw.image);
      if (typeof raw.photo === 'string') imageCandidates.push(raw.photo);
      if (typeof raw.thumbnail === 'string') imageCandidates.push(raw.thumbnail);
      if (typeof raw.coverUrl === 'string') imageCandidates.push(raw.coverUrl);
      const images: string[] = imageCandidates.filter(Boolean);

      const createdAt = raw.createdAt?.toDate ? raw.createdAt.toDate() : (raw.createdAt ? new Date(raw.createdAt) : new Date());
      const updatedAt = raw.updatedAt?.toDate ? raw.updatedAt.toDate() : (raw.updatedAt ? new Date(raw.updatedAt) : createdAt);

      const product: Product = {
        id: docSnap.id,
        title: raw.title ?? raw.name ?? 'Untitled',
        description: raw.description ?? '',
        images,
        category: raw.category ?? 'Uncategorized',
        tags: raw.tags ?? [],
        sellerId: raw.sellerId ?? '',
        basePriceSeller: raw.basePriceSeller ?? raw.finalPrice ?? raw.sellerPrice ?? raw.price ?? 0,
        upliftPercent: raw.upliftPercent ?? 20,
        projectAllocations: raw.projectAllocations ?? [],
        location: raw.location ?? {
          address: raw.address ?? '',
          city: raw.city ?? 'Unknown',
          state: raw.state ?? '',
          country: raw.country ?? '',
          lat: raw.lat ?? 0,
          lng: raw.lng ?? 0,
        },
        badges: raw.badges ?? [],
        isRental: raw.isRental ?? false,
        customizable: !!raw.customizable,
        status: raw.status ?? 'active',
        createdAt,
        updatedAt,
        stock: typeof raw.stock === 'number' ? raw.stock : (raw.stock != null ? Number(raw.stock) : undefined),
        outOfStock: typeof raw.outOfStock === 'boolean' ? raw.outOfStock : (typeof raw.stock === 'number' ? raw.stock <= 0 : undefined),
      };
      return product;
    } catch (error) {
      console.error('Error fetching product:', error);
      // Fallback to mock data
      return mockProducts.find(p => p.id === id) || null;
    }
  },

  async getProductsByCategory(category: string): Promise<Product[]> {
    try {
      const q = query(collection(db, 'products'), where('category', '==', category));
      const querySnapshot = await getDocs(q);
      if (querySnapshot.empty) {
        return mockProducts.filter(p => p.category === category);
      }
      return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product));
    } catch (error) {
      console.error('Error fetching products by category:', error);
      return mockProducts.filter(p => p.category === category);
    }
  },

  // Dev-only: seed some products into Firestore. Requires signed-in admin/seller per rules.
  async seedProductsFromMocks(count: number = 6): Promise<number> {
    if (!auth.currentUser) {
      throw new Error('Please sign in to seed products');
    }
    const toSeed = mockProducts.slice(0, Math.max(0, count));
    let created = 0;
    for (const p of toSeed) {
      try {
        await addDoc(collection(db, 'products'), {
          title: p.title,
          description: p.description,
          images: p.images,
          category: p.category,
          tags: p.tags ?? [],
          sellerId: auth.currentUser.uid, // attribute to current user for simplicity
          basePriceSeller: p.basePriceSeller,
          upliftPercent: p.upliftPercent ?? 20,
          projectAllocations: p.projectAllocations ?? [],
          location: p.location ?? null,
          badges: p.badges ?? [],
          isRental: p.isRental ?? false,
          status: p.status ?? 'active',
          createdAt: new Date(),
          updatedAt: new Date(),
        });
        created++;
      } catch (e) {
        console.error('Seed error for product', p.title, e);
      }
    }
    return created;
  },

  // Projects
  async getProjects(): Promise<Project[]> {
    try {
      const querySnapshot = await getDocs(collection(db, 'projects'));
      if (querySnapshot.empty) {
        return mockProjects;
      }
      return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Project));
    } catch (error) {
      console.error('Error fetching projects:', error);
      return mockProjects;
    }
  },

  async getProject(id: string): Promise<Project | null> {
    try {
      const docSnap = await getDoc(doc(db, 'projects', id));
      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() } as Project;
      }
      return mockProjects.find(p => p.id === id) || null;
    } catch (error) {
      console.error('Error fetching project:', error);
      return mockProjects.find(p => p.id === id) || null;
    }
  },

  // Sellers
  async getSellers(): Promise<Seller[]> {
    try {
      const querySnapshot = await getDocs(collection(db, 'sellers'));
      if (querySnapshot.empty) {
        return mockSellers;
      }
      return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Seller));
    } catch (error) {
      console.error('Error fetching sellers:', error);
      return mockSellers;
    }
  },

  async getSeller(id: string): Promise<Seller | null> {
    try {
      const docSnap = await getDoc(doc(db, 'sellers', id));
      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() } as Seller;
      }
      return mockSellers.find(s => s.id === id) || null;
    } catch (error) {
      console.error('Error fetching seller:', error);
      return mockSellers.find(s => s.id === id) || null;
    }
  },

  // Orders
  async createOrder(order: Omit<Order, 'id'>): Promise<string> {
    try {
      const docRef = await addDoc(collection(db, 'orders'), order);
      return docRef.id;
    } catch (error) {
      console.error('Error creating order:', error);
      throw error;
    }
  },

  async getOrders(userId?: string): Promise<Order[]> {
    try {
      let q;
      if (userId) {
        q = query(collection(db, 'orders'), where('userId', '==', userId));
      } else {
        q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
      }
      
      const querySnapshot = await getDocs(q);
      if (querySnapshot.empty && !userId) {
        return mockOrders;
      }
      return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
    } catch (error) {
      console.error('Error fetching orders:', error);
      return userId ? [] : mockOrders;
    }
  },

  // Real-time subscriptions
  subscribeToProducts(callback: (products: Product[]) => void, includeUnpublished: boolean = false) {
    try {
      let q;
      if (includeUnpublished) {
        q = collection(db, 'products');
      } else {
        // Only subscribe to published products
        q = query(collection(db, 'products'), where('published', '==', true));
      }
      
      return onSnapshot(q, 
        (snapshot) => {
          // If Firestore has no products, emit empty list (no mock fallback)
          if (snapshot.empty) {
            callback([]);
            return;
          }
          const products = snapshot.docs.map((d) => {
            const raw = d.data() as any;
            // Accept multiple possible image field names
            const imageCandidates: string[] = [];
            if (Array.isArray(raw.images)) imageCandidates.push(...raw.images);
            if (Array.isArray(raw.imageUrls)) imageCandidates.push(...raw.imageUrls);
            if (typeof raw.imageUrl === 'string') imageCandidates.push(raw.imageUrl);
            if (typeof raw.image === 'string') imageCandidates.push(raw.image);
            if (typeof raw.photo === 'string') imageCandidates.push(raw.photo);
            if (typeof raw.thumbnail === 'string') imageCandidates.push(raw.thumbnail);
            if (typeof raw.coverUrl === 'string') imageCandidates.push(raw.coverUrl);
            const images: string[] = imageCandidates.filter(Boolean);

            const createdAt = raw.createdAt?.toDate ? raw.createdAt.toDate() : (raw.createdAt ? new Date(raw.createdAt) : new Date());
            const updatedAt = raw.updatedAt?.toDate ? raw.updatedAt.toDate() : (raw.updatedAt ? new Date(raw.updatedAt) : createdAt);

            return {
              id: d.id,
              title: raw.title ?? raw.name ?? 'Untitled',
              description: raw.description ?? '',
              images,
              category: raw.category ?? 'Uncategorized',
              tags: raw.tags ?? [],
              sellerId: raw.sellerId ?? '',
              basePriceSeller: raw.basePriceSeller ?? raw.finalPrice ?? raw.sellerPrice ?? raw.price ?? 0,
              upliftPercent: raw.upliftPercent ?? 20,
              projectAllocations: raw.projectAllocations ?? [],
              location: raw.location ?? null,
              badges: raw.badges ?? [],
              isRental: raw.isRental ?? false,
              customizable: !!raw.customizable,
              status: raw.status ?? 'active',
              published: raw.published ?? false,
              createdAt,
              updatedAt,
              stock: typeof raw.stock === 'number' ? raw.stock : (raw.stock != null ? Number(raw.stock) : undefined),
              outOfStock: typeof raw.outOfStock === 'boolean' ? raw.outOfStock : (typeof raw.stock === 'number' ? raw.stock <= 0 : undefined),
            } as Product;
          });
          callback(products);
        },
        (error) => {
          console.error('Error in products subscription:', error);
          // On error, emit empty list (no mock fallback)
          callback([]);
        }
      );
    } catch (error) {
      console.error('Error setting up products subscription:', error);
      // Return a no-op unsubscribe function in case of error
      return () => {};
    }
  },

  subscribeToProjects(callback: (projects: Project[]) => void) {
    return onSnapshot(collection(db, 'projects'), 
      (querySnapshot) => {
        const projects = querySnapshot.docs.map(doc => ({ 
          id: doc.id, 
          ...doc.data() 
        } as Project));
        callback(projects);
      }, 
      (error) => {
        console.error('Error in projects subscription:', error);
        callback(mockProjects);
      }
    );
  },

  // Promotions / Trending helpers
  async getSellerProducts(sellerId: string): Promise<Product[]> {
    try {
      const qRef = query(collection(db, 'products'), where('sellerId', '==', sellerId));
      const snap = await getDocs(qRef);
      return snap.docs.map((d) => {
        const raw = d.data() as any;
        const imageCandidates: string[] = [];
        if (Array.isArray(raw.images)) imageCandidates.push(...raw.images);
        if (Array.isArray(raw.imageUrls)) imageCandidates.push(...raw.imageUrls);
        if (typeof raw.imageUrl === 'string') imageCandidates.push(raw.imageUrl);
        if (typeof raw.image === 'string') imageCandidates.push(raw.image);
        if (typeof raw.photo === 'string') imageCandidates.push(raw.photo);
        if (typeof raw.thumbnail === 'string') imageCandidates.push(raw.thumbnail);
        if (typeof raw.coverUrl === 'string') imageCandidates.push(raw.coverUrl);
        const images: string[] = imageCandidates.filter(Boolean);

        return {
          id: d.id,
          title: raw.title ?? raw.name ?? 'Untitled',
          description: raw.description ?? '',
          images,
          category: raw.category ?? 'Uncategorized',
          tags: raw.tags ?? [],
          sellerId: raw.sellerId ?? '',
          basePriceSeller: raw.basePriceSeller ?? raw.finalPrice ?? raw.sellerPrice ?? raw.price ?? 0,
          upliftPercent: raw.upliftPercent ?? 20,
          projectAllocations: raw.projectAllocations ?? [],
          location: raw.location ?? null,
          badges: raw.badges ?? [],
          isRental: raw.isRental ?? false,
          customizable: !!raw.customizable,
          status: raw.status ?? 'active',
          published: raw.published ?? false,
          createdAt: raw.createdAt?.toDate ? raw.createdAt.toDate() : new Date(),
          updatedAt: raw.updatedAt?.toDate ? raw.updatedAt.toDate() : new Date(),
        } as Product;
      });
    } catch (e) {
      console.error('Error loading seller products', e);
      return [];
    }
  },

  async createPromotionRequest(params: { sellerId: string; productIds: string[]; amount: number; durationDays: number; note?: string }): Promise<string> {
    const payload = {
      sellerId: params.sellerId,
      productIds: params.productIds,
      amount: params.amount,
      durationDays: params.durationDays,
      note: params.note || '',
      status: 'pending',
      paymentStatus: 'unpaid',
      createdAt: new Date(),
      updatedAt: new Date(),
    } as any;
    const ref = await addDoc(collection(db, 'promotion-requests'), payload);
    return ref.id;
  },

  async listPromotionRequests(status?: 'pending' | 'approved' | 'rejected' | 'deleted') {
    let qRef: any = collection(db, 'promotion-requests');
    if (status) qRef = query(qRef, where('status', '==', status));
    const snap = await getDocs(qRef);
    return snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }));
  },

  async approvePromotionRequest(requestId: string) {
    const reqSnap = await getDoc(doc(db, 'promotion-requests', requestId));
    if (!reqSnap.exists()) throw new Error('Request not found');
    const data = reqSnap.data() as any;
    const now = new Date();
    const expiresAt = new Date(now.getTime() + (data.durationDays || 7) * 24 * 60 * 60 * 1000);

    for (const pid of (data.productIds || [])) {
      try {
        await updateDoc(doc(db, 'products', pid), {
          trendingApproved: true,
          trendingExpiresAt: Timestamp.fromDate(expiresAt),
          updatedAt: new Date(),
        } as any);
      } catch (e) {
        console.warn('Failed to update product trending state', pid, e);
      }
    }

    await updateDoc(doc(db, 'promotion-requests', requestId), {
      status: 'approved',
      updatedAt: new Date(),
    } as any);
    return true;
  },

  async rejectPromotionRequest(requestId: string, reason?: string) {
    await updateDoc(doc(db, 'promotion-requests', requestId), {
      status: 'rejected',
      rejectionReason: reason || '',
      updatedAt: new Date(),
    } as any);
    return true;
  },

  async updatePromotionRequest(
    requestId: string,
    data: Partial<{ amount: number; durationDays: number; status: string; paymentStatus: string; note: string }>
  ) {
    await updateDoc(doc(db, 'promotion-requests', requestId), {
      ...data,
      updatedAt: new Date(),
    } as any);
    return true;
  },

  async deletePromotionRequest(requestId: string) {
    // Soft delete: move request to deleted status and, if it had been approved,
    // revert any product trending flags applied by approval.
    const reqRef = doc(db, 'promotion-requests', requestId);
    const reqSnap = await getDoc(reqRef);
    if (!reqSnap.exists()) throw new Error('Request not found');
    const data = reqSnap.data() as any;

    if (data.status === 'approved' && Array.isArray(data.productIds)) {
      for (const pid of data.productIds) {
        try {
          await updateDoc(doc(db, 'products', pid), {
            trendingApproved: false,
            trendingExpiresAt: null,
            updatedAt: new Date(),
          } as any);
        } catch (e) {
          console.warn('Failed to revert product trending state on delete', pid, e);
        }
      }
    }

    await updateDoc(reqRef, {
      status: 'deleted',
      deletedAt: new Date(),
      updatedAt: new Date(),
    } as any);
    return true;
  },

  async getTrendingProducts(limitCount: number = 8): Promise<Product[]> {
    try {
      const qRef = query(collection(db, 'products'), where('trendingApproved', '==', true));
      const snap = await getDocs(qRef);
      const nowMs = Date.now();
      const items: Product[] = snap.docs
        .map((d) => {
          const raw = d.data() as any;
          const exp: any = raw.trendingExpiresAt;
          const expiresMs = exp?.toMillis ? exp.toMillis() : (exp ? new Date(exp).getTime() : 0);
          if (expiresMs && expiresMs < nowMs) return null;

          const imageCandidates: string[] = [];
          if (Array.isArray(raw.images)) imageCandidates.push(...raw.images);
          if (Array.isArray(raw.imageUrls)) imageCandidates.push(...raw.imageUrls);
          if (typeof raw.imageUrl === 'string') imageCandidates.push(raw.imageUrl);
          if (typeof raw.image === 'string') imageCandidates.push(raw.image);
          if (typeof raw.photo === 'string') imageCandidates.push(raw.photo);
          if (typeof raw.thumbnail === 'string') imageCandidates.push(raw.thumbnail);
          if (typeof raw.coverUrl === 'string') imageCandidates.push(raw.coverUrl);
          const images: string[] = imageCandidates.filter(Boolean);

          return {
            id: d.id,
            title: raw.title ?? raw.name ?? 'Untitled',
            description: raw.description ?? '',
            images,
            category: raw.category ?? 'Uncategorized',
            tags: raw.tags ?? [],
            sellerId: raw.sellerId ?? '',
            basePriceSeller: raw.basePriceSeller ?? raw.finalPrice ?? raw.sellerPrice ?? raw.price ?? 0,
            upliftPercent: raw.upliftPercent ?? 20,
            projectAllocations: raw.projectAllocations ?? [],
            location: raw.location ?? null,
            badges: raw.badges ?? [],
            isRental: raw.isRental ?? false,
            customizable: !!raw.customizable,
            status: raw.status ?? 'active',
            published: raw.published ?? false,
            createdAt: raw.createdAt?.toDate ? raw.createdAt.toDate() : new Date(),
            updatedAt: raw.updatedAt?.toDate ? raw.updatedAt.toDate() : new Date(),
          } as Product;
        })
        .filter(Boolean) as Product[];
      return items.slice(0, limitCount);
    } catch (e) {
      console.error('Error fetching trending products', e);
      return [];
    }
  },
};

// Storage Service
export const storageService = {
  async uploadImage(file: File, path: string): Promise<string> {
    try {
      const imageRef = ref(storage, path);
      const snapshot = await uploadBytes(imageRef, file);
      return getDownloadURL(snapshot.ref);
    } catch (error) {
      console.error('Error uploading image:', error);
      throw error;
    }
  },

  async uploadUserAvatar(file: File, userId: string): Promise<string> {
    const path = `avatars/${userId}/${Date.now()}_${file.name}`;
    return this.uploadImage(file, path);
  },

  async uploadProductImage(file: File, productId: string): Promise<string> {
    const path = `products/${productId}/${Date.now()}_${file.name}`;
    return this.uploadImage(file, path);
  },

  async deleteFile(downloadUrl: string): Promise<void> {
    try {
      const fileRef = ref(storage, downloadUrl);
      await deleteObject(fileRef);
    } catch (error) {
      console.error('Error deleting file:', error);
      throw error;
    }
  }
};