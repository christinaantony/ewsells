import * as faceapi from 'face-api.js';
import { doc, getDoc, setDoc, runTransaction, updateDoc, collection, getDocs } from 'firebase/firestore';
import { db } from '@/lib/firebase';

// Interface for face descriptor data
export interface FaceDescriptor {
  descriptor: number[];
  timestamp: number;
}

// Interface for user face data
export interface UserFaceData {
  userId: string;
  faceDescriptors: FaceDescriptor[];
  faceImageUrl?: string;
}

// Main face authentication service
export const faceAuthService = {
  // Initialize face-api.js models
  async loadModels(): Promise<void> {
    try {
      // Check if models are already loaded
      if (
        faceapi.nets.ssdMobilenetv1.isLoaded && 
        faceapi.nets.faceLandmark68Net.isLoaded && 
        faceapi.nets.faceRecognitionNet.isLoaded
      ) {
        console.log('Face detection models already loaded');
        return;
      }
      
      // Load models from CDN if local models fail
      const MODEL_URL = 'https://justadudewhohacks.github.io/face-api.js/models';
      
      await Promise.all([
        faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL),
        faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
        faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL)
      ]);
      
      console.log('Face detection models loaded successfully');
      console.log('Face detection models loaded');
    } catch (error) {
      console.error('Error loading face detection models:', error);
      throw new Error('Failed to load face detection models');
    }
  },

  // Get face descriptor from image
  async getFaceDescriptor(imageElement: HTMLImageElement | HTMLVideoElement): Promise<Float32Array | null> {
    try {
      const detections = await faceapi
        .detectSingleFace(imageElement)
        .withFaceLandmarks()
        .withFaceDescriptor();

      if (!detections) {
        return null;
      }

      return detections.descriptor;
    } catch (error) {
      console.error('Error getting face descriptor:', error);
      return null;
    }
  },

  // Register a new face for a user
  async registerFace(userId: string, imageData: string): Promise<boolean> {
    try {
      console.log('Starting face registration process for user:', userId);
      
      // Ensure models are loaded
      await this.loadModels();
      
      // Get face descriptor from image
      const img = await this.createImageFromBase64(imageData);
      const descriptor = await this.getFaceDescriptor(img);

      if (!descriptor) {
        console.error('No face detected in the registration image');
        throw new Error('No face detected in the image');
      }
      
      console.log('Face descriptor extracted successfully');

      // Convert Float32Array to regular array for Firestore storage
      const descriptorArray = Array.from(descriptor);
      
      // Skip image upload entirely - it's causing CORS issues
      // Just save the face descriptor data which is what we need for authentication
      console.log('Skipping image upload due to CORS issues, saving descriptor only');
      
      // Save face descriptor to Firestore
      const userFaceData: UserFaceData = {
        userId,
        faceDescriptors: [
          {
            descriptor: descriptorArray,
            timestamp: Date.now()
          }
        ]
        // No image URL - we're skipping that part
      };

      // Use a transaction to ensure the write succeeds
      try {
        await runTransaction(db, async (transaction) => {
          const faceAuthRef = doc(db, 'faceAuth', userId);
          transaction.set(faceAuthRef, userFaceData);
          
          // Also ensure the useFaceAuth flag is set in the user document
          const userRef = doc(db, 'users', userId);
          transaction.set(userRef, { useFaceAuth: true }, { merge: true });
        });
        console.log('Face data saved to Firestore successfully in transaction');
      } catch (transactionError) {
        console.error('Transaction failed, falling back to regular write:', transactionError);
        // Fallback to regular write if transaction fails
        await setDoc(doc(db, 'faceAuth', userId), userFaceData);
        await setDoc(doc(db, 'users', userId), { useFaceAuth: true }, { merge: true });
        console.log('Face data saved to Firestore successfully with fallback method');
      }
      
      return true;
    } catch (error) {
      console.error('Error registering face:', error);
      // Return false instead of throwing to prevent registration failure
      return false;
    }
  },

  // Update existing face data with a new descriptor
  async updateFaceData(userId: string, imageData: string): Promise<boolean> {
    try {
      // Get face descriptor from image
      const img = await this.createImageFromBase64(imageData);
      const descriptor = await this.getFaceDescriptor(img);

      if (!descriptor) {
        throw new Error('No face detected in the image');
      }

      // Get existing face data
      const faceDoc = await getDoc(doc(db, 'faceAuth', userId));
      
      if (!faceDoc.exists()) {
        // If no existing data, create new
        return await this.registerFace(userId, imageData);
      }

      const existingData = faceDoc.data() as UserFaceData;
      
      // Convert Float32Array to regular array for Firestore storage
      const descriptorArray = Array.from(descriptor);
      
      // Add new descriptor to array
      const updatedDescriptors = [
        ...existingData.faceDescriptors,
        {
          descriptor: descriptorArray,
          timestamp: Date.now()
        }
      ];

      // Keep only the 5 most recent descriptors
      const recentDescriptors = updatedDescriptors
        .sort((a, b) => b.timestamp - a.timestamp)
        .slice(0, 5);

      // Update document
      await updateDoc(doc(db, 'faceAuth', userId), {
        faceDescriptors: recentDescriptors
      });

      return true;
    } catch (error) {
      console.error('Error updating face data:', error);
      throw error;
    }
  },

  // Authenticate user with face
  async authenticateWithFace(imageData: string): Promise<string | null> {
    try {
      console.log('Starting face authentication process...');
      
      // Ensure models are loaded
      await this.loadModels();
      
      // Get face descriptor from image
      const img = await this.createImageFromBase64(imageData);
      const descriptor = await this.getFaceDescriptor(img);

      if (!descriptor) {
        console.error('No face detected in the authentication image');
        throw new Error('No face detected in the image');
      }
      
      console.log('Face descriptor extracted for authentication');

      // Get all face data from Firestore (rules allow public read for matching)
      const faceAuthCollection = collection(db, 'faceAuth');
      const snapshot = await getDocs(faceAuthCollection);
      
      console.log(`Found ${snapshot.size} face records in faceAuth collection`);
      
      // Debug: Print all document IDs in the faceAuth collection
      snapshot.docs.forEach(docSnap => {
        console.log(`Face auth document ID: ${docSnap.id}`);
      });
      
      if (snapshot.empty) {
        console.warn('No face data found in Firestore');
        return null;
      }
      
      console.log(`Comparing with ${snapshot.size} stored face records`);

      let bestMatch: { userId: string | null; distance: number } = {
        userId: null,
        distance: 1.0 // Initialize with max distance
      };

      // Compare with all stored face descriptors
      for (const docSnapshot of snapshot.docs) {
        const userData = docSnapshot.data() as UserFaceData;
        console.log(`Checking face data for user: ${userData.userId}`);
        
        if (!userData.faceDescriptors || userData.faceDescriptors.length === 0) {
          console.warn(`No face descriptors found for user ${userData.userId}`);
          continue;
        }
        
        for (const storedFace of userData.faceDescriptors) {
          try {
            // Convert stored descriptor to Float32Array for comparison
            // It could be either a Float32Array or a regular array from Firestore
            const storedDescriptor = new Float32Array(
              Array.isArray(storedFace.descriptor) ? 
                storedFace.descriptor : 
                Object.values(storedFace.descriptor)
            );
            
            const distance = faceapi.euclideanDistance(descriptor, storedDescriptor);
            console.log(`Distance for user ${userData.userId}: ${distance.toFixed(4)}`);
            
            // Lower distance means better match
            if (distance < bestMatch.distance) {
              bestMatch = {
                userId: userData.userId,
                distance: distance
              };
            }
          } catch (err) {
            console.error(`Error comparing face for user ${userData.userId}:`, err);
          }
        }
      }

      // Use a stricter threshold for face matching (0.5 instead of 0.7)
      if (bestMatch.distance < 0.5 && bestMatch.userId) {
        // Optional: verify that the matched account has face auth enabled
        try {
          const matchedUserDoc = await getDoc(doc(db, 'users', bestMatch.userId));
          if (matchedUserDoc.exists() && (matchedUserDoc.data() as any)?.useFaceAuth === true) {
            console.log(`Face authenticated successfully! User: ${bestMatch.userId}, Match confidence: ${((1 - bestMatch.distance) * 100).toFixed(2)}%`);
            return bestMatch.userId;
          } else {
            console.warn('Matched user does not have face auth enabled');
            return null;
          }
        } catch (verifyErr) {
          // If verification fails due to rules, still return the ID and let caller handle next step
          console.warn('Could not verify matched user useFaceAuth flag:', verifyErr);
          return bestMatch.userId;
        }
      }
      
      console.warn(`Face authentication failed. Best match distance: ${bestMatch.distance.toFixed(2)}`);
      return null;
    } catch (error) {
      console.error('Error authenticating with face:', error);
      return null;
    }
  },

  // Check if a face is already registered in the system
  async checkFaceExists(imageData: string): Promise<{exists: boolean, userId?: string}> {
    try {
      await this.loadModels();
      const img = await this.createImageFromBase64(imageData);
      const descriptor = await this.getFaceDescriptor(img);
      
      if (!descriptor) {
        console.error('No face detected in the image');
        throw new Error('No face detected in the image');
      }
      
      // Get all face data from Firestore
      const faceAuthCollection = collection(db, 'faceAuth');
      const snapshot = await getDocs(faceAuthCollection);
      
      if (snapshot.empty) {
        return { exists: false };
      }
      
      let bestMatch: { userId: string | null, distance: number } = { userId: null, distance: 1.0 };
      
      // Compare with all stored face descriptors
      for (const docSnapshot of snapshot.docs) {
        const userData = docSnapshot.data() as UserFaceData;
        
        if (!userData.faceDescriptors || userData.faceDescriptors.length === 0) {
          continue;
        }
        
        for (const storedFace of userData.faceDescriptors) {
          try {
            // Convert stored descriptor to Float32Array for comparison
            const storedDescriptor = new Float32Array(
              Array.isArray(storedFace.descriptor) ? 
                storedFace.descriptor : 
                Object.values(storedFace.descriptor)
            );
            
            const distance = faceapi.euclideanDistance(descriptor, storedDescriptor);
            
            // Lower distance means better match
            if (distance < bestMatch.distance) {
              bestMatch = {
                userId: userData.userId,
                distance: distance
              };
            }
          } catch (err) {
            console.error(`Error comparing face:`, err);
          }
        }
      }
      
      // Use the same threshold as authentication (0.5)
      if (bestMatch.distance < 0.5 && bestMatch.userId) {
        console.log(`Face already exists! User: ${bestMatch.userId}, Match confidence: ${((1 - bestMatch.distance) * 100).toFixed(2)}%`);
        return { exists: true, userId: bestMatch.userId };
      }
      
      return { exists: false };
    } catch (error) {
      console.error('Error checking if face exists:', error);
      throw error;
    }
  },
  
  // Helper function to create image element from base64 data
  async createImageFromBase64(base64Image: string): Promise<HTMLImageElement> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = (err) => reject(err);
      img.src = base64Image;
    });
  }
};

export default faceAuthService;
