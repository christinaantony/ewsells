import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  sendPasswordResetEmail, 
  updateProfile,
  User
} from 'firebase/auth';
import { doc, setDoc, getDoc, Timestamp } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';

export interface UserData {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  createdAt: Date | Timestamp;
  useFaceAuth?: boolean;
  faceId?: string;
  role?: 'user' | 'seller' | 'admin';
}

export const authService = {
  async register(email: string, password: string, displayName: string): Promise<UserData> {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(userCredential.user, { displayName });
      
      const userData: UserData = {
        uid: userCredential.user.uid,
        email,
        displayName,
        createdAt: new Date(),
        useFaceAuth: false,
        role: 'user'
      };
      
      await setDoc(doc(db, 'users', userCredential.user.uid), userData);
      return userData;
    } catch (error: any) {
      console.error('Registration error:', error);
      throw error;
    }
  },

  async login(email: string, password: string | null, useFaceAuth = false, userId?: string): Promise<User> {
    try {
      if (useFaceAuth && userId) {
        // Face authentication login
        try {
          // Get user data from Firestore using the userId from face recognition
          const userDoc = await getDoc(doc(db, 'users', userId));
          if (userDoc.exists()) {
            const userData = userDoc.data();
            console.log('Face authentication successful, attempting to log in user:', userId);
            
            // Check if the user is already logged in
            const currentUser = auth.currentUser;
            if (currentUser && currentUser.uid === userId) {
              console.log('User is already logged in');
              return currentUser;
            }
            
            // Check if face auth is enabled for this user
            if (userData.useFaceAuth) {
              // First try to use stored credentials if available
              const storedEmail = localStorage.getItem(`faceAuth_${userId}_email`);
              const storedPassword = localStorage.getItem(`faceAuth_${userId}_password`);
              
              if (storedEmail && storedPassword) {
                try {
                  // We have stored credentials, use them to sign in
                  const userCredential = await signInWithEmailAndPassword(auth, storedEmail, storedPassword);
                  // Post-auth guard: verify Firestore user still exists and is allowed
                  const guardDoc = await getDoc(doc(db, 'users', userCredential.user.uid));
                  const guardData = guardDoc.data() as any | undefined;
                  const isBlocked = !guardDoc.exists() || guardData?.blocked === true || guardData?.disabled === true || guardData?.status === 'blocked' || guardData?.status === 'deleted';
                  if (isBlocked) {
                    await signOut(auth);
                    throw new Error('Your account is disabled or no longer exists.');
                  }
                  return userCredential.user;
                } catch (signInError) {
                  console.error('Error signing in with stored credentials:', signInError);
                  // If stored credentials fail, clear them and fall through to the next method
                  localStorage.removeItem(`faceAuth_${userId}_email`);
                  localStorage.removeItem(`faceAuth_${userId}_password`);
                }
              }
              
              // If we have no stored credentials or they failed, but face auth is enabled,
              // we'll use the email from userData if available
              if (userData.email) {
                if (password) {
                  // If we have a password provided, use it with the email from userData
                  try {
                    const userCredential = await signInWithEmailAndPassword(auth, userData.email, password);
                    // Post-auth guard
                    const guardDoc = await getDoc(doc(db, 'users', userCredential.user.uid));
                    const guardData = guardDoc.data() as any | undefined;
                    const isBlocked = !guardDoc.exists() || guardData?.blocked === true || guardData?.disabled === true || guardData?.status === 'blocked' || guardData?.status === 'deleted';
                    if (isBlocked) {
                      await signOut(auth);
                      throw new Error('Your account is disabled or no longer exists.');
                    }
                    
                    // Store credentials for future face auth
                    localStorage.setItem(`faceAuth_${userId}_email`, userData.email);
                    localStorage.setItem(`faceAuth_${userId}_password`, password);
                    
                    return userCredential.user;
                  } catch (signInError) {
                    console.error('Error signing in with provided password:', signInError);
                    throw new Error('Invalid password. Please try again.');
                  }
                } else {
                  // For users with face auth already enabled, try to sign in directly
                  // This is the key fix - we should attempt to sign in directly with the email
                  // from userData when face auth is already enabled
                  try {
                    // Create a custom token or use a server function
                    // Since we can't do that client-side, we'll use a special password recovery flow
                    // that allows face-authenticated users to sign in
                    
                    // For now, we'll just show a more helpful error message
                    throw new Error('Please enter your password to continue');
                  } catch (err) {
                    // Show a more user-friendly error message
                    throw new Error('Please enter your password to continue');
                  }
                }
              } else {
                throw new Error('User email not found. Please use email/password login.');
              }
            } else {
              // Face auth is not enabled for this user, we need password once to set it up
              if (email && password) {
                // Regular login with provided credentials
                const userCredential = await signInWithEmailAndPassword(auth, email, password);
                // Post-auth guard
                const guardDoc = await getDoc(doc(db, 'users', userCredential.user.uid));
                const guardData = guardDoc.data() as any | undefined;
                const isBlocked = !guardDoc.exists() || guardData?.blocked === true || guardData?.disabled === true || guardData?.status === 'blocked' || guardData?.status === 'deleted';
                if (isBlocked) {
                  await signOut(auth);
                  throw new Error('Your account is disabled or no longer exists.');
                }
                
                // Enable face auth and store credentials
                await this.enableFaceAuth(userId);
                localStorage.setItem(`faceAuth_${userId}_email`, email);
                localStorage.setItem(`faceAuth_${userId}_password`, password);
                
                return userCredential.user;
              } else {
                // Need password to set up face auth
                throw new Error('Please enter your password once to set up face authentication');
              }
            }
          } else {
            throw new Error('User data not found');
          }
        } catch (userLookupError) {
          console.error('Error looking up user data:', userLookupError);
          throw new Error('Face authentication failed. User data not found.');
        }
      } else if (email && password) {
        // Regular email/password login
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        // Post-auth guard for regular login
        const guardDoc = await getDoc(doc(db, 'users', user.uid));
        const guardData = guardDoc.data() as any | undefined;
        const isBlocked = !guardDoc.exists() || guardData?.blocked === true || guardData?.disabled === true || guardData?.status === 'blocked' || guardData?.status === 'deleted';
        if (isBlocked) {
          await signOut(auth);
          throw new Error('Your account is disabled or no longer exists.');
        }
        
        // Store credentials for face auth
        if (user) {
          localStorage.setItem(`faceAuth_${user.uid}_email`, email);
          localStorage.setItem(`faceAuth_${user.uid}_password`, password);
        }
        
        return user;
      } else {
        throw new Error('Invalid login credentials');
      }
      
      throw new Error('Authentication failed');
    } catch (error: any) {
      console.error('Login error:', error);
      throw error;
    }
  },

  async logout(): Promise<void> {
    try {
      // Get current user ID before signing out
      const currentUser = auth.currentUser;
      const uid = currentUser?.uid;
      
      // Sign out from Firebase
      await signOut(auth);
      
      // Clean up all face auth related localStorage items
      if (uid) {
        localStorage.removeItem(`faceAuth_${uid}_email`);
        localStorage.removeItem(`faceAuth_${uid}_password`);
      }
      
      localStorage.removeItem('faceAuthSession');
      localStorage.removeItem('faceAuthEmail');
      localStorage.removeItem('currentUser');
      
      console.log('Logout completed and localStorage cleaned up');
    } catch (error: any) {
      console.error('Logout error:', error);
      throw error;
    }
  },

  async resetPassword(email: string): Promise<void> {
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (error: any) {
      console.error('Reset password error:', error);
      throw error;
    }
  },

  async getCurrentUser(): Promise<User | null> {
    return new Promise((resolve) => {
      const unsubscribe = auth.onAuthStateChanged((user) => {
        unsubscribe();
        resolve(user);
      });
    });
  },

  async getUserData(uid: string): Promise<UserData | null> {
    try {
      const userDoc = await getDoc(doc(db, 'users', uid));
      if (userDoc.exists()) {
        return userDoc.data() as UserData;
      }
      return null;
    } catch (error: any) {
      console.error('Get user data error:', error);
      throw error;
    }
  },

  async enableFaceAuth(uid: string): Promise<void> {
    try {
      await setDoc(doc(db, 'users', uid), { useFaceAuth: true }, { merge: true });
    } catch (error: any) {
      console.error('Enable face auth error:', error);
      throw error;
    }
  },

  async disableFaceAuth(uid: string): Promise<void> {
    try {
      await setDoc(doc(db, 'users', uid), { useFaceAuth: false }, { merge: true });
    } catch (error: any) {
      console.error('Disable face auth error:', error);
      throw error;
    }
  },

  async hasFaceAuth(uid: string): Promise<boolean> {
    try {
      const userDoc = await getDoc(doc(db, 'users', uid));
      if (userDoc.exists()) {
        const userData = userDoc.data() as UserData;
        return !!userData.useFaceAuth;
      }
      return false;
    } catch (error: any) {
      console.error('Check face auth error:', error);
      return false;
    }
  },

  /**
   * Login with face authentication using only the user ID
   * This method directly authenticates a user after successful face recognition
   * without requiring a password
   */
  async loginWithFace(uid: string): Promise<User> {
    try {
      // Check if user is already logged in
      const currentUser = auth.currentUser;
      if (currentUser && currentUser.uid === uid) {
        console.log('User is already logged in with correct ID');
        return currentUser;
      }

      // Get user data from Firestore
      const userDoc = await getDoc(doc(db, 'users', uid));
      if (!userDoc.exists()) {
        throw new Error('User not found');
      }
      
      const userData = userDoc.data() as UserData;
      console.log('Face auth: Retrieved user data from Firestore:', userData.displayName);
      
      // Deny access if blocked/disabled/deleted
      const faceBlocked = (userData as any)?.blocked === true || (userData as any)?.disabled === true || (userData as any)?.status === 'blocked' || (userData as any)?.status === 'deleted';
      if (faceBlocked) {
        localStorage.removeItem('faceAuthSession');
        localStorage.removeItem('currentUser');
        throw new Error('Your account is blocked or disabled.');
      }
      
      // Check if face auth is enabled for this user
      if (!userData.useFaceAuth) {
        throw new Error('Face authentication not enabled for this user');
      }
      
      // Create a session marker for the recognized face and remember email for UI
      localStorage.setItem('faceAuthSession', uid);
      localStorage.setItem('faceAuthEmail', userData.email || '');

      // Try to authenticate with stored credentials to obtain Firebase Auth session
      const storedEmail = localStorage.getItem(`faceAuth_${uid}_email`);
      const storedPassword = localStorage.getItem(`faceAuth_${uid}_password`);

      if (storedEmail && storedPassword) {
        try {
          const userCredential = await signInWithEmailAndPassword(auth, storedEmail, storedPassword);
          // Post-auth guard: verify Firestore user still exists and is allowed
          const guardDoc = await getDoc(doc(db, 'users', userCredential.user.uid));
          const guardData = guardDoc.data() as any | undefined;
          const isBlocked = !guardDoc.exists() || guardData?.blocked === true || guardData?.disabled === true || guardData?.status === 'blocked' || guardData?.status === 'deleted';
          if (isBlocked) {
            await signOut(auth);
            throw new Error('Your account is disabled or no longer exists.');
          }
          return userCredential.user;
        } catch (e) {
          console.warn('Stored face-auth credentials failed, requesting password.', e);
          // Clear invalid stored credentials and require password entry
          localStorage.removeItem(`faceAuth_${uid}_email`);
          localStorage.removeItem(`faceAuth_${uid}_password`);
          throw new Error('Authentication failed: password required');
        }
      }

      // No stored credentials; require password once to establish them
      throw new Error('Authentication failed: password required');
    } catch (error: any) {
      console.error('Face login error:', error);
      throw error;
    }
  }
};

export default authService;
