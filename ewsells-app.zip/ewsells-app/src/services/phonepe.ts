import { db, functions } from '@/lib/firebase';
import { httpsCallable } from 'firebase/functions';
import { doc, setDoc, updateDoc } from 'firebase/firestore';

export interface PhonePePaymentRequest {
  amount: number;
  userId: string;
  orderId: string;
  userPhone?: string;
  userName?: string;
  email?: string;
}

export interface PhonePePaymentResponse {
  success: boolean;
  redirectUrl?: string;
  error?: string;
  transactionId?: string;
}

/**
 * Initiates a PhonePe payment request
 * @param paymentDetails Payment details including amount and user information
 * @returns Payment response with redirect URL or error
 */
export const initiatePhonePePayment = async (
  paymentDetails: PhonePePaymentRequest
): Promise<PhonePePaymentResponse> => {
  try {
    // Create a payment record in Firestore first
    const paymentRef = doc(db, 'payments', paymentDetails.orderId);
    await setDoc(paymentRef, {
      amount: paymentDetails.amount,
      userId: paymentDetails.userId,
      orderId: paymentDetails.orderId,
      status: 'initiated',
      paymentMethod: 'phonepe',
      createdAt: new Date().toISOString(),
      userPhone: paymentDetails.userPhone || '',
      userName: paymentDetails.userName || '',
      email: paymentDetails.email || '',
    });

    // Call Firebase Cloud Function to initiate payment
    const initiatePayment = httpsCallable(functions, 'initiatePhonePePayment');
    const result = await initiatePayment(paymentDetails);
    
    const data = result.data as any;
    
    if (data.success && data.redirectUrl) {
      // Update payment record with transaction ID
      await updateDoc(paymentRef, {
        transactionId: data.transactionId,
        status: 'pending',
      });
      
      return {
        success: true,
        redirectUrl: data.redirectUrl,
        transactionId: data.transactionId,
      };
    } else {
      // Update payment record with error
      await updateDoc(paymentRef, {
        status: 'failed',
        error: data.error || 'Unknown error',
      });
      
      return {
        success: false,
        error: data.error || 'Failed to initiate payment',
      };
    }
  } catch (error) {
    console.error('PhonePe payment initiation error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred',
    };
  }
};

/**
 * Checks the status of a PhonePe payment
 * @param params Object containing transactionId and userId
 * @returns Payment status information
 */
export const checkPhonePePaymentStatus = async (params: { 
  transactionId: string; 
  userId: string;
}): Promise<{
  success: boolean;
  status?: 'initiated' | 'pending' | 'completed' | 'failed';
  error?: string;
  paymentDetails?: any;
}> => {
  try {
    // Call Firebase Cloud Function to check payment status
    const checkPayment = httpsCallable(functions, 'checkPhonePePaymentStatus');
    const result = await checkPayment(params);
    
    const data = result.data as any;
    
    if (data.success) {
      return {
        success: true,
        status: data.status,
        paymentDetails: data.paymentDetails
      };
    } else {
      return { 
        success: false, 
        error: data.error || 'Payment verification failed' 
      };
    }
  } catch (error) {
    console.error('Error checking payment status:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred',
    };
  }
};
