import { 
  collection, 
  getDocs, 
  query, 
  where, 
  limit, 
  orderBy,
  doc, 
  getDoc 
} from 'firebase/firestore';
import { db } from '@/lib/firebase';

// Interface for safe context data
export interface ChatContext {
  products: SafeProductInfo[];
  categories: string[];
  projects: SafeProjectInfo[];
  orderStatusTypes: string[];
  orderStatistics: OrderStatistics;
  helpingHandsStats: HelpingHandsStats;
  appCapabilities: string[];
  generalStats: GeneralStats;
}

interface SafeProductInfo {
  name: string;
  category: string;
  description: string;
  price: number;
  inStock: boolean;
}

interface SafeProjectInfo {
  title: string;
  description: string;
  category: string;
  impact: string;
}

interface GeneralStats {
  totalProducts: number;
  totalCategories: number;
  totalProjects: number;
}

interface OrderStatistics {
  totalOrders: number;
  commonStatuses: string[];
  averageOrderValue: number;
}

interface HelpingHandsStats {
  totalRequests: number;
  totalUsers: number;
  requestCategories: string[];
  commonRequestTypes: string[];
}

interface UserSpecificContext {
  userProfile: UserProfile | null;
  userOrders: UserOrder[];
  userHelpingHandsRequests: UserHelpingHandsRequest[];
}

interface UserProfile {
  name: string;
  email: string;
  role: string;
  joinDate: string;
}

interface UserOrder {
  id: string;
  status: string;
  amount: number;
  items: OrderItem[];
  createdAt: string;
  shippingAddress: any;
}

interface OrderItem {
  name: string;
  quantity: number;
  price: number;
  category: string;
}

interface UserHelpingHandsRequest {
  id: string;
  type: string;
  status: string;
  createdAt: string;
}

// Cache for context data to avoid repeated Firestore calls
let contextCache: ChatContext | null = null;
let cacheTimestamp: number = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

/**
 * Sanitizes product data to remove any personal information
 */
function sanitizeProductData(products: any[]): SafeProductInfo[] {
  return products.map(product => ({
    name: product.name || 'Unknown Product',
    category: product.category || 'General',
    description: product.description || 'No description available',
    price: typeof product.price === 'number' ? product.price : 0,
    inStock: product.inStock !== false
  })).filter(product => 
    // Filter out any products that might contain personal info in name/description
    !containsPersonalInfo(product.name) && 
    !containsPersonalInfo(product.description)
  );
}

/**
 * Sanitizes project data to remove any personal information
 */
function sanitizeProjectData(projects: any[]): SafeProjectInfo[] {
  return projects.map(project => ({
    title: project.title || 'Charity Project',
    description: project.description || 'No description available',
    category: project.category || 'General',
    impact: project.impact || 'Making a positive difference'
  })).filter(project => 
    !containsPersonalInfo(project.title) && 
    !containsPersonalInfo(project.description)
  );
}

/**
 * Checks if text contains potential personal information
 */
function containsPersonalInfo(text: string): boolean {
  if (!text) return false;
  
  const personalInfoPatterns = [
    // Email patterns
    /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/,
    // Phone patterns
    /\b\d{10,}\b/,
    // Address patterns (basic)
    /\b\d+\s+[A-Za-z\s]+(?:street|st|avenue|ave|road|rd|lane|ln|drive|dr|court|ct|place|pl)\b/i,
    // Names with titles
    /\b(?:mr|mrs|ms|dr|prof)\.\s+[A-Za-z]+/i,
    // Credit card patterns
    /\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b/
  ];
  
  return personalInfoPatterns.some(pattern => pattern.test(text));
}

/**
 * Fetches safe product data from Firestore
 */
async function fetchSafeProductData(): Promise<{ products: SafeProductInfo[], categories: string[] }> {
  try {
    const productsRef = collection(db, 'products');
    const productsQuery = query(productsRef, limit(50)); // Limit to avoid large data transfer
    const snapshot = await getDocs(productsQuery);
    
    const products = snapshot.docs.map(doc => doc.data());
    const sanitizedProducts = sanitizeProductData(products);
    
    // Extract unique categories
    const categories = [...new Set(sanitizedProducts.map(p => p.category))];
    
    return { products: sanitizedProducts, categories };
  } catch (error) {
    console.error('Error fetching product data:', error);
    return { products: [], categories: [] };
  }
}

/**
 * Fetches safe project data from Firestore
 */
async function fetchSafeProjectData(): Promise<SafeProjectInfo[]> {
  try {
    const projectsRef = collection(db, 'projects');
    const snapshot = await getDocs(projectsRef);
    
    const projects = snapshot.docs.map(doc => doc.data());
    return sanitizeProjectData(projects);
  } catch (error) {
    console.error('Error fetching project data:', error);
    return [];
  }
}

/**
 * Fetches safe order status types from order-status-corrections
 */
async function fetchOrderStatusTypes(): Promise<string[]> {
  try {
    const statusCorrectionsRef = collection(db, 'order-status-corrections');
    const snapshot = await getDocs(statusCorrectionsRef);
    
    const statusTypes = new Set<string>();
    snapshot.docs.forEach(doc => {
      const data = doc.data();
      if (data.status && typeof data.status === 'string') {
        statusTypes.add(data.status);
      }
      if (data.newStatus && typeof data.newStatus === 'string') {
        statusTypes.add(data.newStatus);
      }
    });
    
    return Array.from(statusTypes);
  } catch (error) {
    console.error('Error fetching order status types:', error);
    return ['pending', 'processing', 'shipped', 'delivered', 'cancelled']; // Default statuses
  }
}

/**
 * Fetches safe order statistics without exposing personal data
 */
async function fetchOrderStatistics(): Promise<OrderStatistics> {
  try {
    const ordersRef = collection(db, 'orders');
    const ordersQuery = query(ordersRef, limit(100)); // Limit for performance
    const snapshot = await getDocs(ordersQuery);
    
    const orders = snapshot.docs.map(doc => doc.data());
    const statusCounts: { [key: string]: number } = {};
    let totalAmount = 0;
    let validAmounts = 0;
    
    orders.forEach(order => {
      // Count statuses
      if (order.status && typeof order.status === 'string') {
        statusCounts[order.status] = (statusCounts[order.status] || 0) + 1;
      }
      
      // Calculate average order value (without exposing individual amounts)
      if (order.amount && typeof order.amount === 'number' && order.amount > 0) {
        totalAmount += order.amount;
        validAmounts++;
      }
    });
    
    // Get most common statuses
    const commonStatuses = Object.entries(statusCounts)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([status]) => status);
    
    return {
      totalOrders: snapshot.size,
      commonStatuses,
      averageOrderValue: validAmounts > 0 ? Math.round(totalAmount / validAmounts) : 0
    };
  } catch (error) {
    console.error('Error fetching order statistics:', error);
    return {
      totalOrders: 0,
      commonStatuses: ['pending', 'processing', 'shipped', 'delivered'],
      averageOrderValue: 0
    };
  }
}

/**
 * Fetches safe helping hands statistics without exposing personal data
 */
async function fetchHelpingHandsStats(): Promise<HelpingHandsStats> {
  try {
    const [requestsSnapshot, usersSnapshot] = await Promise.all([
      getDocs(collection(db, 'helping-hands-requests')),
      getDocs(collection(db, 'helping-hands-users'))
    ]);
    
    const requests = requestsSnapshot.docs.map(doc => doc.data());
    const requestCategories = new Set<string>();
    const requestTypes = new Set<string>();
    
    requests.forEach(request => {
      // Extract categories and types without exposing personal info
      if (request.category && typeof request.category === 'string') {
        requestCategories.add(request.category);
      }
      if (request.type && typeof request.type === 'string') {
        requestTypes.add(request.type);
      }
      if (request.requestType && typeof request.requestType === 'string') {
        requestTypes.add(request.requestType);
      }
    });
    
    return {
      totalRequests: requestsSnapshot.size,
      totalUsers: usersSnapshot.size,
      requestCategories: Array.from(requestCategories),
      commonRequestTypes: Array.from(requestTypes).slice(0, 10) // Limit to top 10
    };
  } catch (error) {
    console.error('Error fetching helping hands stats:', error);
    return {
      totalRequests: 0,
      totalUsers: 0,
      requestCategories: ['general', 'emergency', 'support'],
      commonRequestTypes: ['assistance', 'support', 'help']
    };
  }
}

/**
 * Generates general statistics without exposing personal data
 */
async function fetchGeneralStats(): Promise<GeneralStats> {
  try {
    const [productsSnapshot, projectsSnapshot] = await Promise.all([
      getDocs(collection(db, 'products')),
      getDocs(collection(db, 'projects'))
    ]);
    
    return {
      totalProducts: productsSnapshot.size,
      totalCategories: 0, // Will be set from product categories
      totalProjects: projectsSnapshot.size
    };
  } catch (error) {
    console.error('Error fetching general stats:', error);
    return {
      totalProducts: 0,
      totalCategories: 0,
      totalProjects: 0
    };
  }
}

/**
 * Fetches user-specific context for authenticated users
 */
async function getUserSpecificContext(userId: string): Promise<UserSpecificContext> {
  try {
    const [userProfile, userOrders, userHelpingHandsRequests] = await Promise.all([
      fetchUserProfile(userId),
      fetchUserOrders(userId),
      fetchUserHelpingHandsRequests(userId)
    ]);

    return {
      userProfile,
      userOrders,
      userHelpingHandsRequests
    };
  } catch (error) {
    console.error('Error fetching user-specific context:', error);
    return {
      userProfile: null,
      userOrders: [],
      userHelpingHandsRequests: []
    };
  }
}

/**
 * Fetches user profile data
 */
async function fetchUserProfile(userId: string): Promise<UserProfile | null> {
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    if (!userDoc.exists()) {
      console.log('User document does not exist, creating fallback profile');
      return null;
    }

    const userData = userDoc.data();
    console.log('Fetched user data:', userData);
    
    return {
      name: userData.name || userData.displayName || 'User',
      email: userData.email || '',
      role: userData.role || 'customer',
      joinDate: userData.createdAt?.toDate?.()?.toISOString() || new Date().toISOString()
    };
  } catch (error) {
    console.error('Error fetching user profile:', error);
    // Return null to trigger fallback in getUserSpecificContext
    return null;
  }
}

/**
 * Fetches user's own orders
 */
async function fetchUserOrders(userId: string): Promise<UserOrder[]> {
  try {
    console.log('Fetching orders for user:', userId);
    const ordersQuery = query(
      collection(db, 'orders'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc'),
      limit(20) // Limit to recent orders
    );
    const snapshot = await getDocs(ordersQuery);
    
    console.log('Found orders:', snapshot.size);
    
    const orders = snapshot.docs.map(doc => {
      const data = doc.data();
      console.log('Order data:', doc.id, data);
      
      return {
        id: doc.id,
        status: data.status || 'unknown',
        amount: data.amount || data.totalAmount || 0,
        items: (data.items || data.products || []).map((item: any) => ({
          name: item.name || item.productName || item.title || 'Unknown Item',
          quantity: item.quantity || 1,
          price: item.price || item.amount || 0,
          category: item.category || 'Unknown Category'
        })),
        createdAt: data.createdAt?.toDate?.()?.toISOString() || data.timestamp?.toDate?.()?.toISOString() || new Date().toISOString(),
        shippingAddress: data.shippingAddress || data.address || {}
      };
    });
    
    console.log('Processed orders:', orders);
    return orders;
  } catch (error) {
    console.error('Error fetching user orders:', error);
    return [];
  }
}

/**
 * Fetches user's helping hands requests
 */
async function fetchUserHelpingHandsRequests(userId: string): Promise<UserHelpingHandsRequest[]> {
  try {
    const requestsQuery = query(
      collection(db, 'helping-hands-requests'),
      where('uid', '==', userId),
      limit(10)
    );
    const snapshot = await getDocs(requestsQuery);

    return snapshot.docs.map(doc => {
      const data = doc.data();
      return {
        id: doc.id,
        type: data.type || data.requestType || 'general',
        status: data.status || 'pending',
        createdAt: data.createdAt?.toDate?.()?.toISOString() || new Date().toISOString()
      };
    });
  } catch (error) {
    console.error('Error fetching user helping hands requests:', error);
    return [];
  }
}

/**
 * Gets app capabilities that the AI should know about
 */
function getAppCapabilities(): string[] {
  return [
    'Browse and search products in various categories',
    'Learn about charity projects and social impact',
    'Get information about Smile Foundation initiatives',
    'Help with product recommendations',
    'Provide information about orders and shopping process',
    'Answer questions about the platform and its mission',
    'Assist with account-related queries and personal data',
    'Explain how purchases contribute to charitable causes',
    'Check order status and tracking information',
    'Access user profile and account details',
    'Review helping hands requests and status'
  ];
}

/**
 * Main function to get all context data for the chat AI with user-specific context
 */
export async function getChatContextWithUser(userId?: string): Promise<ChatContext & { userContext?: UserSpecificContext }> {
  // Get general platform context
  const generalContext = await getChatContext();
  
  // If user is provided, get user-specific context
  if (userId) {
    const userContext = await getUserSpecificContext(userId);
    return {
      ...generalContext,
      userContext
    };
  }
  
  return generalContext;
}

/**
 * Main function to get all context data for the chat AI
 */
export async function getChatContext(): Promise<ChatContext> {
  // Check cache first
  const now = Date.now();
  if (contextCache && (now - cacheTimestamp) < CACHE_DURATION) {
    return contextCache;
  }
  
  try {
    const [productData, projects, generalStats, orderStatusTypes, orderStatistics, helpingHandsStats] = await Promise.all([
      fetchSafeProductData(),
      fetchSafeProjectData(),
      fetchGeneralStats(),
      fetchOrderStatusTypes(),
      fetchOrderStatistics(),
      fetchHelpingHandsStats()
    ]);
    
    const context: ChatContext = {
      products: productData.products,
      categories: productData.categories,
      projects,
      orderStatusTypes,
      orderStatistics,
      helpingHandsStats,
      appCapabilities: getAppCapabilities(),
      generalStats: {
        ...generalStats,
        totalCategories: productData.categories.length
      }
    };
    
    // Update cache
    contextCache = context;
    cacheTimestamp = now;
    
    return context;
  } catch (error) {
    console.error('Error getting chat context:', error);
    
    // Return minimal safe context on error
    return {
      products: [],
      categories: [],
      projects: [],
      orderStatusTypes: ['pending', 'processing', 'shipped', 'delivered', 'cancelled'],
      orderStatistics: {
        totalOrders: 0,
        commonStatuses: ['pending', 'processing', 'shipped', 'delivered'],
        averageOrderValue: 0
      },
      helpingHandsStats: {
        totalRequests: 0,
        totalUsers: 0,
        requestCategories: ['general', 'emergency', 'support'],
        commonRequestTypes: ['assistance', 'support', 'help']
      },
      appCapabilities: getAppCapabilities(),
      generalStats: {
        totalProducts: 0,
        totalCategories: 0,
        totalProjects: 0
      }
    };
  }
}

/**
 * Formats user-specific context for the AI system message
 */
export function formatUserContextForAI(userContext: UserSpecificContext): string {
  const sections = [];
  
  if (userContext.userProfile) {
    sections.push(
      'USER PROFILE:',
      `Name: ${userContext.userProfile.name}`,
      `Email: ${userContext.userProfile.email}`,
      `Role: ${userContext.userProfile.role}`,
      `Member since: ${new Date(userContext.userProfile.joinDate).toLocaleDateString()}`,
      ''
    );
  }
  
  if (userContext.userOrders.length > 0) {
    sections.push(
      'USER ORDERS:',
      ...userContext.userOrders.map(order => {
        const itemsList = order.items.map(item => `${item.name} (${item.category}) x${item.quantity} - ₹${item.price}`).join(', ');
        return `Order ${order.id}: ${order.status} - ₹${order.amount} - Items: ${itemsList} (${new Date(order.createdAt).toLocaleDateString()})`;
      }),
      ''
    );
  }
  
  if (userContext.userHelpingHandsRequests.length > 0) {
    sections.push(
      'USER HELPING HANDS REQUESTS:',
      ...userContext.userHelpingHandsRequests.map(request => 
        `Request ${request.id}: ${request.type} - ${request.status} (${new Date(request.createdAt).toLocaleDateString()})`
      ),
      ''
    );
  }
  
  return sections.join('\n');
}

/**
 * Formats context data into a string for the AI system message
 */
export function formatContextForAI(context: ChatContext): string {
  const contextSections = [
    `Available Categories: ${context.categories.join(', ')}`,
    `Total Products: ${context.generalStats.totalProducts}`,
    `Active Charity Projects: ${context.generalStats.totalProjects}`,
    `Total Orders: ${context.orderStatistics.totalOrders}`,
    `Average Order Value: ₹${context.orderStatistics.averageOrderValue}`,
    `Helping Hands Requests: ${context.helpingHandsStats.totalRequests}`,
    `Helping Hands Users: ${context.helpingHandsStats.totalUsers}`,
    '',
    'Order Status Types:',
    ...context.orderStatusTypes.map(status => `- ${status}`),
    '',
    'Common Order Statuses:',
    ...context.orderStatistics.commonStatuses.map(status => `- ${status}`),
    '',
    'Helping Hands Request Categories:',
    ...context.helpingHandsStats.requestCategories.map(category => `- ${category}`),
    '',
    'Common Helping Hands Request Types:',
    ...context.helpingHandsStats.commonRequestTypes.map(type => `- ${type}`),
    '',
    'App Capabilities:',
    ...context.appCapabilities.map(cap => `- ${cap}`),
    '',
    'Sample Products:',
    ...context.products.slice(0, 10).map(product => 
      `- ${product.name} (${product.category}) - ₹${product.price}`
    ),
    '',
    'Charity Projects:',
    ...context.projects.slice(0, 5).map(project => 
      `- ${project.title}: ${project.impact}`
    )
  ];
  
  return contextSections.join('\n');
}

/**
 * Clears the context cache (useful for testing or manual refresh)
 */
export function clearContextCache(): void {
  contextCache = null;
  cacheTimestamp = 0;
}
