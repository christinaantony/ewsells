import { db } from '@/lib/firebase';
import { 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  arrayUnion, 
  serverTimestamp,
} from 'firebase/firestore';
import { ChatMessage } from './chatService';

const CHATS_COLLECTION = 'chats';

interface ChatDocument {
  messages: ChatMessage[];
  userId: string;
  updatedAt: any;
  createdAt: any;
}

export const saveChatMessage = async (userId: string, message: ChatMessage) => {
  try {
    const chatRef = doc(db, CHATS_COLLECTION, userId);
    const chatDoc = await getDoc(chatRef);
    
    if (chatDoc.exists()) {
      // Update existing chat
      await updateDoc(chatRef, {
        messages: arrayUnion(message),
        updatedAt: serverTimestamp()
      });
    } else {
      // Create new chat
      await setDoc(chatRef, {
        messages: [message],
        userId,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    }
    return true;
  } catch (error) {
    console.error('Error saving message:', error);
    throw error;
  }
};

export const saveChatMessages = async (userId: string, messages: ChatMessage[]) => {
  try {
    const chatRef = doc(db, CHATS_COLLECTION, userId);
    await setDoc(chatRef, {
      messages,
      userId,
      updatedAt: serverTimestamp(),
      ...(messages.length > 0 && { createdAt: serverTimestamp() })
    }, { merge: true });
    return true;
  } catch (error) {
    console.error('Error saving messages:', error);
    throw error;
  }
};

export const getChatMessages = async (userId: string): Promise<ChatMessage[]> => {
  try {
    const chatRef = doc(db, CHATS_COLLECTION, userId);
    const chatDoc = await getDoc(chatRef);
    
    if (chatDoc.exists()) {
      const data = chatDoc.data() as ChatDocument;
      return data.messages || [];
    }
    return [];
  } catch (error) {
    console.error('Error getting messages:', error);
    throw error;
  }
};
