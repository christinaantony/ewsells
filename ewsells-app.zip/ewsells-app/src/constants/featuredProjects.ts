export type FeaturedProject = {
  id: number;
  title: string;
  focusArea: string;
  keywords: string[];
};

// Central source of truth for the 7 EWSELLS Featured Projects
export const featuredProjects: FeaturedProject[] = [
  {
    id: 1,
    title: 'Be a Proud Indian',
    focusArea: 'Civic Education & Legal Awareness',
    keywords: ['civic', 'constitution', 'law', 'legal', 'education', 'schools', 'colleges', 'awareness', 'citizen']
  },
  {
    id: 2,
    title: 'You Have Rights',
    focusArea: 'Civil Rights & Public Support',
    keywords: ['rights', 'legal', 'public', 'elderly', 'welfare', 'government services', 'support', 'access']
  },
  {
    id: 3,
    title: 'Green Revive Genesis',
    focusArea: 'Environmental Protection & Eco-Tourism',
    keywords: ['green', 'environment', 'eco', 'sustainable', 'plastic', 'recycle', 'upcycle', 'plants', 'nature']
  },
  {
    id: 4,
    title: 'Pathway to Progress',
    focusArea: 'Education & Child Empowerment',
    keywords: ['education', 'children', 'youth', 'entrepreneurship', 'learning', 'training', 'skills', 'school']
  },
  {
    id: 5,
    title: 'Reform Home',
    focusArea: 'Mental Health & Community Support',
    keywords: ['mental', 'counsel', 'therapy', 'wellbeing', 'wellness', 'beauty', 'self-care', 'support', 'stress']
  },
  {
    id: 6,
    title: 'Helping Hands',
    focusArea: 'Medical & Community Development Support',
    keywords: ['medical', 'health', 'aid', 'community', 'fund', 'help', 'support', 'relief']
  },
  {
    id: 7,
    title: 'HELPRING',
    focusArea: 'Emotional, Legal & Mental Support (Volunteering)',
    keywords: ['volunteer', 'helpline', 'listening', 'emotional', 'support', 'youth', 'community']
  }
];
