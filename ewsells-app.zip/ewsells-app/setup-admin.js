// Admin Account Setup Script
// Run this script once to create an admin account
// Usage: node setup-admin.js admin@example.com YourSecurePassword "Admin Name"

import { initializeApp } from 'firebase/app';
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';
import { getFirestore, doc, setDoc } from 'firebase/firestore';

// Your Firebase configuration
const firebaseConfig = {
        apiKey: "AIzaSyAOuv4Wa6_D46MiCIVMwpin2s2Y4pmvq_Y",
        authDomain: "ewsells-app.firebaseapp.com",
        projectId: "ewsells-app",
        storageBucket: "ewsells-app.firebasestorage.app",
        messagingSenderId: "425040547115",
        appId: "1:425040547115:web:763f05e3b41f66843bc96e",
        measurementId: "G-L1YZ97SF0L"

};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

async function createAdminAccount(email, password, displayName = 'System Administrator') {
  try {
    console.log(`Creating admin account for ${email}...`);
    
    // Create the user account in Firebase Authentication
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    
    // Create the admin user document in Firestore
    await setDoc(doc(db, 'users', user.uid), {
      email,
      displayName,
      role: 'admin',
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString()
    });
    
    console.log(`✅ Admin account created successfully!`);
    console.log(`Admin ID: ${user.uid}`);
    console.log(`Email: ${email}`);
    console.log(`Name: ${displayName}`);
    console.log(`\nYou can now log in at: /admin-login`);
    
    return user.uid;
  } catch (error) {
    console.error('❌ Error creating admin account:', error.message);
    process.exit(1);
  }
}

// Get command line arguments
const args = process.argv.slice(2);
if (args.length < 2) {
  console.error('Usage: node setup-admin.js <email> <password> [displayName]');
  process.exit(1);
}

const email = args[0];
const password = args[1];
const displayName = args[2] || 'System Administrator';

// Validate email format
if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
  console.error('❌ Invalid email format');
  process.exit(1);
}

// Validate password strength (minimum 8 characters)
if (password.length < 8) {
  console.error('❌ Password must be at least 8 characters long');
  process.exit(1);
}

// Create the admin account
createAdminAccount(email, password, displayName)
  .then(() => {
    setTimeout(() => process.exit(0), 2000); // Allow time for Firebase operations to complete
  })
  .catch(error => {
    console.error('Failed to create admin:', error);
    process.exit(1);
  });
