import { onRequest } from 'firebase-functions/v2/https';
import * as logger from 'firebase-functions/logger';
import { defineSecret } from 'firebase-functions/params';
import cors from 'cors';
import OpenAI from 'openai';

// Initialize CORS middleware
const corsHandler = cors({ origin: true });

// Define TypeScript interfaces
interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface ChatRequest {
  messages: ChatMessage[];
}

// Define the secret
const openaiApiKey = defineSecret('OPENAI_API_KEY');

export const chat = onRequest(
  {
    secrets: [openaiApiKey],
    region: 'us-central1',
    cors: true,
    timeoutSeconds: 60,
    memory: '256MiB',
    minInstances: 0,
    maxInstances: 10
  },
  async (req, res) => {
    // Handle CORS preflight
    if (req.method === 'OPTIONS') {
      res.set('Access-Control-Allow-Origin', '*');
      res.set('Access-Control-Allow-Methods', 'POST, OPTIONS');
      res.set('Access-Control-Allow-Headers', 'Content-Type');
      res.status(204).send('');
      return;
    }

    // Handle CORS for the actual request
    return corsHandler(req, res, async () => {
      try {
        // Log the incoming request
        logger.info('Received request', { body: req.body });

        // Validate request
        if (!req.body || !req.body.messages) {
          logger.error('Missing messages in request');
          return res.status(400).json({ error: 'Missing required field: messages' });
        }

        const { messages } = req.body as ChatRequest;

        // Initialize OpenAI client with the secret
        const openai = new OpenAI({
          apiKey: openaiApiKey.value()
        });

        // Add system message
        const chatMessages: ChatMessage[] = [
          {
            role: 'system',
            content: 'You are Smile Sales AI, a helpful shopping assistant for Smile Foundation. Be friendly, concise, and helpful.'
          },
          ...messages
        ];

        logger.info('Sending to OpenAI:', { messages: chatMessages });

        // Call OpenAI API
        const completion = await openai.chat.completions.create({
          model: 'gpt-3.5-turbo',
          messages: chatMessages,
          temperature: 0.7,
          max_tokens: 500,
        });

        logger.info('Received response from OpenAI');

        // Send response
        return res.status(200).json({
          id: completion.id,
          message: completion.choices[0]?.message,
          usage: completion.usage
        });

      } catch (error: any) {
        logger.error('Error in chat function:', error);
        return res.status(500).json({
          error: 'Failed to process chat request',
          details: error?.message || 'Unknown error occurred'
        });
      }
    });
  }
);