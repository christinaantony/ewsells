const admin = require('firebase-admin');
const { onDocumentCreated } = require('firebase-functions/v2/firestore');
// const { onCall } = require('firebase-functions/v2/https');

// Initialize Firebase Admin SDK
admin.initializeApp();

// Import and export chat functionality
const { chat } = require('./chat');
const { chatCompletion } = require('./genkit-sample');

// Export all functions
async function getUserToken(uid: string) {
  try {
    const snap = await admin.firestore().doc(`users/${uid}`).get();
    return snap.exists ? (snap.data() as any)?.fcmToken || null : null;
  } catch {
    return null;
  }
}

exports.onCustomizationMessageCreate = onDocumentCreated('customizationChats/{chatId}/messages/{messageId}', async (event: any) => {
  const message = event?.data?.data && event.data.data();
  const chatId = event?.params?.chatId as string;
  try {
    const chatSnap = await admin.firestore().doc(`customizationChats/${chatId}`).get();
    if (!chatSnap.exists) return null;
    const chat = chatSnap.data() as any;
    const senderId = message?.senderId;
    const isBuyerMessage = senderId === chat.buyerId;
    const recipientId = isBuyerMessage ? chat.sellerId : chat.buyerId;

    const token = await getUserToken(recipientId);
    if (!token) return null;

    // Build deep link
    let link = '';
    if (recipientId === chat.sellerId) {
      // Seller view
      link = `/seller/customizations/${chatId}`;
    } else {
      // Buyer view; open order customization page
      link = `/customize/${chat.productId}?orderId=${chat.orderId}`;
    }

    const title = isBuyerMessage ? 'New customization message from buyer' : 'New customization message from seller';
    const body = (message?.text && message.text.toString().slice(0, 120)) || 'New message';

    const payload: any = {
      token,
      notification: {
        title,
        body,
      },
      webpush: {
        fcmOptions: { link },
      },
      data: {
        chatId,
        orderId: chat.orderId || '',
        productId: chat.productId || '',
        link,
      },
    };

    await admin.messaging().send(payload);
    return null;
  } catch (e) {
    console.error('Failed to send FCM notification', e);
    return null;
  }
});
// Re-export chat functions
exports.chat = chat;
exports.chatCompletion = chatCompletion;
