import { onCall } from 'firebase-functions/v2/https';
import { defineSecret } from 'firebase-functions/params';
import { CallableRequest } from 'firebase-functions/v2/https';
import OpenAI from 'openai';

// Define the API key secret
const openaiApiKey = defineSecret("OPENAI_API_KEY");

// ❌ remove top-level initialization with .value()
// const openai = new OpenAI({ apiKey: openaiApiKey.value() });

// Define the model
const model = "gpt-4o";

// Define the chat completion function
exports.chatCompletion = onCall(
  {
    region: 'asia-south1',
    secrets: [openaiApiKey],
    // Uncomment to enable authentication
    // enforceAppCheck: true,
    // authPolicy: (auth) => !!auth.uid,
  },
  async (request: CallableRequest<{ messages: any[] }>) => {
    if (!request.data || !request.data.messages) {
      throw new Error('Missing required field: messages');
    }
    const { messages } = request.data;
    
    try {
      // ✅ Initialize OpenAI client here (runtime safe)
      const openai = new OpenAI({
        apiKey: openaiApiKey.value()
      });

      const completion = await openai.chat.completions.create({
        model: model,
        messages: messages,
        temperature: 0.7,
        max_tokens: 500,
      });

      return {
        success: true,
        response: completion.choices[0]?.message?.content || 'No response from AI'
      };
    } catch (error) {
      console.error('Error in chat completion:', error);
      throw new Error('Failed to generate response');
    }
  }
);
