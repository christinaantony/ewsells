
const connectorConfig = {
  connector: 'default',
  service: 'ewsells-app',
  location: 'us-central1'
};
exports.connectorConfig = connectorConfig;
