// This script will download the face-api.js models directly in the browser
// and save them to the correct location

// Models to download
const models = [
  'ssd_mobilenetv1_model-weights_manifest.json',
  'ssd_mobilenetv1_model-shard1',
  'ssd_mobilenetv1_model-shard2',
  'face_landmark_68_model-weights_manifest.json',
  'face_landmark_68_model-shard1',
  'face_recognition_model-weights_manifest.json',
  'face_recognition_model-shard1',
  'face_recognition_model-shard2'
];

// Base URL for face-api.js models
const MODELS_URL = 'https://raw.githubusercontent.com/justadudewhohacks/face-api.js/master/weights';

// Function to download a file
async function downloadFile(url) {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Failed to download ${url}: ${response.status} ${response.statusText}`);
    }
    return await response.blob();
  } catch (error) {
    console.error(`Error downloading ${url}:`, error);
    throw error;
  }
}

// Function to save a blob to a file
function saveBlob(blob, filename) {
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

// Download all models
async function downloadModels() {
  const results = document.getElementById('results');
  results.innerHTML = '<p>Starting download of face-api.js models...</p>';
  
  for (const model of models) {
    try {
      const url = `${MODELS_URL}/${model}`;
      results.innerHTML += `<p>Downloading ${model}...</p>`;
      const blob = await downloadFile(url);
      saveBlob(blob, model);
      results.innerHTML += `<p>✅ Downloaded ${model}</p>`;
    } catch (error) {
      results.innerHTML += `<p>❌ Error downloading ${model}: ${error.message}</p>`;
    }
  }
  
  results.innerHTML += '<p><strong>Download complete!</strong> Please move all downloaded files to the public/models folder in your project.</p>';
}

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
  const container = document.createElement('div');
  container.style.fontFamily = 'Arial, sans-serif';
  container.style.maxWidth = '800px';
  container.style.margin = '0 auto';
  container.style.padding = '20px';
  
  container.innerHTML = `
    <h1>Face-API.js Models Downloader</h1>
    <p>This page will download the required face detection models for your application.</p>
    <p>After downloading, please move all files to the public/models folder in your project.</p>
    <button id="downloadBtn" style="padding: 10px 20px; background: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;">
      Download Models
    </button>
    <div id="results" style="margin-top: 20px; padding: 10px; background: #f5f5f5; border-radius: 4px;"></div>
  `;
  
  document.body.appendChild(container);
  
  document.getElementById('downloadBtn').addEventListener('click', downloadModels);
});
