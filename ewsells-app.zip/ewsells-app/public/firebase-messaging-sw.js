/* eslint-disable no-undef */
// Firebase Cloud Messaging SW for background notifications
// Uses Firebase Hosting auto-init scripts so you don't need to hardcode config here.
importScripts('/__/firebase/9.23.0/firebase-app-compat.js');
importScripts('/__/firebase/9.23.0/firebase-messaging-compat.js');
importScripts('/__/firebase/init.js');

try {
  const messaging = firebase.messaging();
  // Handle background messages
  messaging.onBackgroundMessage((payload) => {
    const title = payload.notification?.title || 'New message';
    const options = {
      body: payload.notification?.body || 'You have a new chat message',
      icon: payload.notification?.icon || '/favicon.png',
      data: payload.data || {},
    };
    self.registration.showNotification(title, options);
  });
} catch (e) {
  // no-op
}
