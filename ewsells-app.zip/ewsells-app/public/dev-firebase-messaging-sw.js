// Lightweight dev service worker for FCM on localhost
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (event) => event.waitUntil(self.clients.claim()));

self.addEventListener('push', (event) => {
  const data = event.data ? event.data.json() : {};
  const title = (data.notification && data.notification.title) || 'New message';
  const options = {
    body: (data.notification && data.notification.body) || 'You have a new chat message',
    icon: (data.notification && data.notification.icon) || '/favicon.png',
    data: data.data || {},
  };
  event.waitUntil(self.registration.showNotification(title, options));
});
